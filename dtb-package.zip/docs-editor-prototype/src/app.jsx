// ---------- App root ----------
const { useState, useEffect, useMemo } = React;

const ACCENT_MAP = { ink: 255, forest: 155, ember: 30, plum: 310, iron: 260 };
const FONT_PAIR_MAP = {
  "serif-sans": { display: '"Instrument Serif", serif', body: '"Inter Tight", system-ui, sans-serif', mono: '"JetBrains Mono", monospace' },
  "editorial":  { display: '"Fraunces", serif',          body: '"Newsreader", Georgia, serif',         mono: '"JetBrains Mono", monospace' },
  "geometric":  { display: '"Geist", sans-serif',        body: '"Geist", system-ui, sans-serif',       mono: '"Geist Mono", monospace' },
  "plex":       { display: '"IBM Plex Sans", sans-serif', body: '"IBM Plex Sans", sans-serif',          mono: '"IBM Plex Mono", monospace' },
};

const App = () => {
  // Tweaks
  const [tweaks, setTweaks] = useState(window.__TWEAKS__);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  // Theme / fonts / accent applied to :root
  useEffect(() => {
    const body = document.body;
    body.classList.toggle("theme-light", tweaks.theme === "light");
    body.classList.toggle("theme-dark", tweaks.theme === "dark");
    body.classList.toggle("serif-body", !!tweaks.serifBody);

    const root = document.documentElement.style;
    root.setProperty("--accent-h", ACCENT_MAP[tweaks.accent] ?? 255);
    if (tweaks.accent === "iron") {
      root.setProperty("--accent", "oklch(45% 0.03 260)");
      root.setProperty("--accent-soft", "oklch(45% 0.03 260 / 0.14)");
      root.setProperty("--accent-ink", "oklch(35% 0.03 260)");
    } else {
      root.removeProperty("--accent");
      root.removeProperty("--accent-soft");
      root.removeProperty("--accent-ink");
    }
    root.setProperty("--reading-width", tweaks.readingWidth + "px");
    root.setProperty("--density", tweaks.density === "compact" ? "0.6" : "1");

    const fp = FONT_PAIR_MAP[tweaks.fontPair];
    if (fp) {
      root.setProperty("--font-display", fp.display);
      root.setProperty("--font-ui", fp.body);
      root.setProperty("--font-body", fp.body);
      root.setProperty("--font-mono", fp.mono);
    }
  }, [tweaks]);

  // Persist tweak changes so the host rewrites the EDITMODE JSON
  const applyTweak = (patch) => {
    const next = { ...tweaks, ...patch };
    setTweaks(next);
    try {
      window.parent?.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
    } catch {}
  };

  // Tweaks/edit mode protocol
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", handler);
    window.parent?.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  // Pages tree
  const [pages, setPages] = useState(PAGES);
  const [spaces, setSpaces] = useState(SPACES);
  const initialSpaceId = (typeof ACTIVE_SPACE_ID !== "undefined" && ACTIVE_SPACE_ID) ? ACTIVE_SPACE_ID : (SPACES[0]?.id || null);
  const [activeSpaceId, setActiveSpaceId] = useState(initialSpaceId);
  const [activePageId, setActivePageId] = useState(ACTIVE_PAGE_ID);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [rightTab, setRightTab] = useState("outline");
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const [publishing, setPublishing] = useState(false);

  // Pages → content map (use the single seeded page for now, synthesize empties for others)
  const [contentMap, setContentMap] = useState(() => {
    const map = { ...PAGE_CONTENT };
    const ensure = (list) => list.forEach((p) => {
      if (!map[p.id]) {
        map[p.id] = {
          title: p.title,
          subtitle: "This page is a draft — click to add a subtitle.",
          updated: "just now", readTime: "1 min",
          author: { name: "You", role: "Editor", initials: "YO", color: "oklch(55% 0.14 255)" },
          collaborators: [{ initials: "YO", color: "oklch(55% 0.14 255)" }],
          blocks: [
            { id: uid("b"), kind: "p", html: "Start writing, or press <code>/</code> to insert a block." },
          ],
        };
      }
      if (p.children) ensure(p.children);
    });
    ensure(PAGES);
    return map;
  });

  const [comments, setComments] = useState(COMMENTS);
  const [activeHeadingId, setActiveHeadingId] = useState(null);
  const [jumpToBlockId, setJumpToBlockId] = useState(null);

  // ---- Undo/redo history of contentMap snapshots ----
  const historyRef = React.useRef({ past: [], future: [] });
  const skipHistoryRef = React.useRef(false);
  const lastPushAtRef = React.useRef(0);
  const [, forceBump] = useState(0);

  const pushHistory = (prev) => {
    const now = Date.now();
    // coalesce rapid edits within 400ms
    if (now - lastPushAtRef.current < 400 && historyRef.current.past.length) {
      lastPushAtRef.current = now;
      return;
    }
    historyRef.current.past.push(prev);
    if (historyRef.current.past.length > 100) historyRef.current.past.shift();
    historyRef.current.future = [];
    lastPushAtRef.current = now;
    forceBump((n) => n + 1);
  };

  const undo = () => {
    const h = historyRef.current;
    if (!h.past.length) return;
    const prev = h.past.pop();
    h.future.push(contentMap);
    skipHistoryRef.current = true;
    setContentMap(prev);
    forceBump((n) => n + 1);
  };
  const redo = () => {
    const h = historyRef.current;
    if (!h.future.length) return;
    const next = h.future.pop();
    h.past.push(contentMap);
    skipHistoryRef.current = true;
    setContentMap(next);
    forceBump((n) => n + 1);
  };

  // Selection + clipboard shared between editor + palette
  const [selectedBlocks, setSelectedBlocks] = useState([]);
  const [clipboard, setClipboard] = useState(null);

  const page = contentMap[activePageId];

  // Canonicalize the URL so it always reflects /editor/{spaceUuid}/{pageSlug}
  useEffect(() => {
    try {
      const sp = spaces.find((s) => s.id === activeSpaceId);
      const meta = contentMap[activePageId];
      const slug = meta?.slug;
      if (!sp?.uuid || !slug) return;
      const target = `/editor/${sp.uuid}/${slug}`;
      if (window.location.pathname !== target) {
        window.history.replaceState(null, "", target);
      }
    } catch (e) { /* no-op */ }
  }, [activeSpaceId, activePageId, contentMap, spaces]);

  const setPage = (next) => {
    setContentMap((m) => {
      if (skipHistoryRef.current) { skipHistoryRef.current = false; return { ...m, [activePageId]: next }; }
      pushHistory(m);
      return { ...m, [activePageId]: next };
    });
  };

  // Page tree operations
  const updateNode = (list, id, fn) =>
    list.map((n) => {
      if (n.id === id) return fn(n);
      if (n.children) return { ...n, children: updateNode(n.children, id, fn) };
      return n;
    });

  const onRenamePage = (id, title) => {
    setPages((pp) => updateNode(pp, id, (n) => ({ ...n, title })));
    setContentMap((m) => m[id] ? ({ ...m, [id]: { ...m[id], title } }) : m);
  };

  const onDeletePage = (id) => {
    const removeFrom = (list) => list
      .filter((n) => n.id !== id)
      .map((n) => n.children ? { ...n, children: removeFrom(n.children) } : n);
    setPages((pp) => removeFrom(pp));
    if (activePageId === id) {
      // fall back to the first remaining page
      const first = (list) => {
        for (const n of list) {
          if (n.id !== id) return n.id;
          if (n.children) { const r = first(n.children); if (r) return r; }
        }
        return null;
      };
      const next = first(pages);
      if (next) setActivePageId(next);
    }
  };

  const onMovePage = (fromId, toId, pos) => {
    setPages((pp) => {
      // 1) find & detach the dragged node
      let dragged = null;
      const detach = (list) => {
        const out = [];
        for (const n of list) {
          if (n.id === fromId) { dragged = n; continue; }
          const node = { ...n };
          if (node.children) node.children = detach(node.children);
          out.push(node);
        }
        return out;
      };
      const withoutDragged = detach(pp);
      if (!dragged) return pp;

      // guard against dropping a node onto its own descendant
      const contains = (n, id) => {
        if (!n.children) return false;
        for (const c of n.children) {
          if (c.id === id) return true;
          if (contains(c, id)) return true;
        }
        return false;
      };
      if (contains(dragged, toId)) return pp;

      // 2) insert relative to target
      const insert = (list) => {
        const out = [];
        for (const n of list) {
          if (n.id === toId) {
            if (pos === "before") { out.push(dragged); out.push(n); }
            else if (pos === "after") { out.push(n); out.push(dragged); }
            else { // inside
              out.push({ ...n, expanded: true, children: [...(n.children || []), dragged] });
            }
          } else {
            const node = { ...n };
            if (node.children) node.children = insert(node.children);
            out.push(node);
          }
        }
        return out;
      };
      return insert(withoutDragged);
    });
  };

  const onAddPage = (parentId) => {
    const newId = uid("p");
    const newPage = { id: newId, title: "Untitled", icon: "page" };
    if (parentId === null) {
      setPages((pp) => [...pp, newPage]);
    } else {
      setPages((pp) => updateNode(pp, parentId, (n) => ({
        ...n, expanded: true, children: [...(n.children || []), newPage],
      })));
    }
    setContentMap((m) => ({ ...m, [newId]: {
      title: "Untitled",
      subtitle: "",
      updated: "just now", readTime: "1 min",
      author: { name: "You", role: "Editor", initials: "YO", color: "oklch(55% 0.14 255)" },
      collaborators: [{ initials: "YO", color: "oklch(55% 0.14 255)" }],
      blocks: [{ id: uid("b"), kind: "p", html: "" }],
    } }));
    setActivePageId(newId);
  };

  // Cmd+K, undo/redo
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault(); setPaletteOpen(true); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "/") {
        e.preventDefault(); setPaletteOpen(true); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" && !e.shiftKey) {
        e.preventDefault(); undo(); return;
      }
      if ((e.metaKey || e.ctrlKey) && (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))) {
        e.preventDefault(); redo(); return;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [contentMap]);

  const onPublish = () => {
    setPublishing(true);
    setTimeout(() => {
      setPublishing(false);
      setToast("Published to lexicon.page/handbook/quickstart");
      setTimeout(() => setToast(null), 2400);
    }, 1600);
  };

  const onPaletteAction = (id) => {
    if (id === "new-page") onAddPage(null);
    if (id === "toggle-theme") applyTweak({ theme: tweaks.theme === "light" ? "dark" : "light" });
    if (id === "publish") onPublish();
    if (id === "tweaks") setTweaksOpen(true);
    if (id === "share") { setToast("Public link copied to clipboard"); setTimeout(() => setToast(null), 2000); }
    if (id === "undo") undo();
    if (id === "redo") redo();
  };

  const spaceName = spaces.find((s) => s.id === activeSpaceId)?.name || "";

  const onAddSpace = (name) => {
    const clean = (name || "").trim();
    if (!clean) return;
    const palette = [
      "oklch(55% 0.14 255)", "oklch(52% 0.15 155)", "oklch(55% 0.15 25)",
      "oklch(58% 0.14 305)", "oklch(60% 0.14 70)", "oklch(55% 0.13 205)",
    ];
    const newSp = {
      id: "sp_" + Date.now(),
      name: clean,
      color: palette[spaces.length % palette.length],
      count: 0,
      icon: clean[0].toUpperCase(),
    };
    setSpaces((arr) => [...arr, newSp]);
    setActiveSpaceId(newSp.id);
    setToast(`Created space "${clean}"`);
    setTimeout(() => setToast(null), 2000);
  };

  const onAddComment = (blockId) => {
    const ref = "Selection in current page";
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref,
      body: "New comment — reply below.", replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setRightTab("comments");
  };

  // SPA-style space switching: fetch the target space's state and swap in-place
  // (no full page navigation). Mirrors the runtime patches the Laravel controller
  // injects into bundle.jsx (PrototypeEditorController::rewriteBundleAutosaveBridge).
  const editorConfig = () => window.__LARAVEL_EDITOR_CONFIG__ || null;
  const siteBootstrap = () => (window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.site) || {};

  const requestEditorJson = (url, options = {}) => {
    const config = editorConfig();
    if (!config || typeof url !== "string" || !url) return Promise.resolve(null);
    const headers = {
      "Accept": "application/json",
      "X-CSRF-TOKEN": config.csrfToken,
      ...(options.headers || {}),
    };
    if (options.body !== undefined && headers["Content-Type"] === undefined) {
      headers["Content-Type"] = "application/json";
    }
    return fetch(url, { ...options, headers, credentials: "same-origin" }).then(async (response) => {
      if (response.ok) return response.json();
      const payload = await response.json().catch(() => null);
      throw new Error(payload && payload.message ? payload.message : "Editor request failed");
    });
  };

  const editorPageUrlFor = (space, pageMeta) => {
    if (!space || !space.editorUrl) return null;
    const slug = pageMeta && pageMeta.slug ? String(pageMeta.slug) : "";
    const root = String(space.editorUrl || "").replace(/\/+$/, "");
    return slug ? `${root}/${encodeURIComponent(slug)}` : root;
  };

  const stateUrlForSpace = (space) => {
    const config = editorConfig();
    const site = siteBootstrap();
    if (!config || typeof config.spaceStateUrlTemplate !== "string" || !site.uuid || !space || !space.uuid) {
      return null;
    }
    return config.spaceStateUrlTemplate
      .replace("__SITE__", encodeURIComponent(site.uuid))
      .replace("__SPACE__", encodeURIComponent(space.uuid));
  };

  const applyEditorState = (payload, fallbackSpace) => {
    const state = payload && payload.state ? payload.state : payload;
    if (!state) return false;
    if (payload && payload.bootstrap) {
      window.__LARAVEL_BOOTSTRAP__ = { ...(window.__LARAVEL_BOOTSTRAP__ || {}), ...payload.bootstrap };
    }
    const nextSpaces = Array.isArray(state.spaces) ? state.spaces : spaces;
    const nextPages = Array.isArray(state.pages) ? state.pages : [];
    const nextContent = state.pageContent && typeof state.pageContent === "object" ? state.pageContent : {};
    const nextComments = Array.isArray(state.comments) ? state.comments : [];
    const nextSpaceId = state.activeSpaceId || (fallbackSpace && fallbackSpace.id) || activeSpaceId;
    const nextPageId = state.activePageId || (nextPages[0] && nextPages[0].id) || null;

    setSpaces(nextSpaces);
    setPages(nextPages);
    setContentMap(nextContent);
    setComments(nextComments);
    historyRef.current = { past: [], future: [] };
    setActiveSpaceId(nextSpaceId);
    if (nextPageId) setActivePageId(nextPageId);

    const nextSpace = nextSpaces.find((item) => item.id === nextSpaceId) || fallbackSpace;
    const nextPage = nextPageId ? nextContent[nextPageId] : null;
    const target = editorPageUrlFor(nextSpace, nextPage);
    if (target && window.location.pathname !== target) {
      window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
    }
    return true;
  };

  const loadEditorState = (space) => {
    const url = stateUrlForSpace(space);
    if (!url) return Promise.resolve(false);
    return requestEditorJson(url)
      .then((payload) => applyEditorState(payload, space))
      .catch((error) => {
        setToast("Space switch failed");
        setTimeout(() => setToast(null), 2200);
        console.error(error);
        return false;
      });
  };

  const activateSpace = (id) => {
    if (id === activeSpaceId) return;
    const nextSpace = spaces.find((s) => s.id === id);
    if (!nextSpace) return;
    loadEditorState(nextSpace).then((loaded) => {
      if (loaded) return;
      setActiveSpaceId(id);
      const target = editorPageUrlFor(nextSpace, contentMap[activePageId]);
      if (target && window.location.pathname !== target) {
        window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
      }
    });
  };

  return (
    <div className={`app ${!tweaks.rightPanel ? "no-right" : ""} ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <TopBar
        page={page}
        spaceName={spaceName}
        onToggleSidebar={() => setSidebarCollapsed((c) => !c)}
        onOpenPalette={() => setPaletteOpen(true)}
        onTogglePanel={() => applyTweak({ rightPanel: !tweaks.rightPanel })}
        theme={tweaks.theme}
        onToggleTheme={() => applyTweak({ theme: tweaks.theme === "light" ? "dark" : "light" })}
        onPublish={onPublish}
        publishing={publishing}
        onToggleTweaks={() => setTweaksOpen((o) => !o)}
      />

      <div className="workspace">
        <Sidebar
          spaces={spaces}
          activeSpaceId={activeSpaceId}
          onSpace={activateSpace}
          onAddSpace={onAddSpace}
          pages={pages}
          activePageId={activePageId}
          onSelectPage={(id) => {
            setActivePageId(id);
            try {
              const sp = spaces.find((s) => s.id === activeSpaceId);
              const meta = contentMap[id];
              const slug = meta?.slug;
              if (sp?.uuid && slug) {
                window.history.replaceState(null, "", `/editor/${sp.uuid}/${slug}`);
              }
            } catch (e) { /* no-op */ }
          }}
          onAddPage={onAddPage}
          onRenamePage={onRenamePage}
          onDeletePage={onDeletePage}
          onMovePage={onMovePage}
        />

        <Editor
          page={page}
          onUpdate={setPage}
          onAddComment={onAddComment}
          onActiveHeadingChange={setActiveHeadingId}
          jumpToBlockId={jumpToBlockId}
          clearJump={() => setJumpToBlockId(null)}
          selectedBlocks={selectedBlocks}
          setSelectedBlocks={setSelectedBlocks}
          clipboard={clipboard}
          setClipboard={setClipboard}
          toast={toast}
          setToast={setToast}
        />

        {tweaks.rightPanel && (
          <RightPane
            page={page}
            comments={comments}
            setComments={setComments}
            history={HISTORY}
            openTab={rightTab}
            setOpenTab={setRightTab}
            activeHeadingId={activeHeadingId}
            onJumpTo={(id) => setJumpToBlockId(id)}
          />
        )}
      </div>

      <Palette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        pages={pages}
        contentMap={contentMap}
        onPickPage={(id) => setActivePageId(id)}
        onJumpToBlock={(pageId, blockId) => {
          setActivePageId(pageId);
          setTimeout(() => setJumpToBlockId(blockId), 60);
        }}
        onAction={onPaletteAction}
      />

      {tweaksOpen && (
        <TweaksPanel
          tweaks={tweaks}
          setTweaks={applyTweak}
          onClose={() => {
            setTweaksOpen(false);
            try { window.parent?.postMessage({ type: "__edit_mode_exited" }, "*"); } catch {}
          }}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
