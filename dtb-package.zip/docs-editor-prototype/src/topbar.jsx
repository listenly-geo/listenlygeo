// ---------- Top bar ----------
const TopBar = ({ page, spaceName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks }) => {
  const [publishOpen, setPublishOpen] = React.useState(false);
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark">L</div>
        <span className="brand-name">Lexicon</span>
        <span className="brand-divider">/</span>
        <span className="brand-space">{spaceName}</span>
      </div>

      <div className="crumbs">
        <span>Guides</span>
        <span className="sep">›</span>
        <span className="cur">{(page.title || "Untitled").replace(/<[^>]*>/g, "")}</span>
        <span className="saved">saved 12s ago · draft</span>
      </div>

      <div className="topbar-right">
        <button className="tb-search" onClick={onOpenPalette}>
          <Icon name="search" size={13} />
          <span>Search docs, pages, blocks…</span>
          <span className="kbd">⌘K</span>
        </button>

        <button className="tb-btn" onClick={onToggleTheme} title="Toggle theme">
          <Icon name={theme === "dark" ? "sun" : "moon"} size={14} />
        </button>
        <button className="tb-btn" onClick={onTogglePanel} title="Toggle side panel">
          <Icon name="panel" size={14} />
        </button>

        <div className="avatars" style={{ marginLeft: 4, marginRight: 4 }}>
          <div className="avatar" style={{ background: "oklch(60% 0.14 30)" }}>MO</div>
          <div className="avatar" style={{ background: "oklch(55% 0.14 220)" }}>JK</div>
          <div className="avatar" style={{ background: "oklch(55% 0.14 155)" }}>RH</div>
        </div>

        <div className="publish-wrap">
          <button className="tb-btn primary" onClick={() => setPublishOpen((o) => !o)}>
            {publishing ? "Publishing…" : "Publish"}
            <Icon name="chevronDown" size={12} />
          </button>
          {publishOpen && (
            <div className="publish-menu">
              <h4>Publish this page</h4>
              <div className="row"><span>Space</span><span className="val">handbook</span></div>
              <div className="row"><span>URL</span><span className="val">lexicon.page/handbook/quickstart</span></div>
              <div className="row"><span>Version</span><span className="val">v 1.4.2</span></div>
              <div className="row"><span>Changes</span><span className="val">+42 / −18</span></div>
              <hr />
              <div className="row" style={{ alignItems: "flex-start" }}>
                <span>Message</span>
              </div>
              <textarea
                placeholder="Clarified publish pipeline section"
                style={{ width: "100%", minHeight: 52, resize: "vertical",
                         background: "var(--bg-subtle)", border: "1px solid var(--border)",
                         borderRadius: 4, padding: 8, fontSize: 12.5, color: "var(--text)",
                         outline: "none", fontFamily: "inherit" }}
              />
              <button className="primary" onClick={() => { setPublishOpen(false); onPublish(); }}>
                Publish to production
              </button>
              <button style={{ width: "100%", marginTop: 6, padding: 8, fontSize: 12, color: "var(--text-muted)" }}>
                Publish to staging
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

window.TopBar = TopBar;
