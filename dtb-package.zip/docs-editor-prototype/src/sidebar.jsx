// ---------- Sidebar ----------
const TreeNode = ({ node, depth = 0, activeId, onSelect, onToggle, onRename, onDelete, onAdd, onDrop, expandedMap, dragId, setDragId, dropTarget, setDropTarget }) => {
  const expanded = expandedMap[node.id] !== undefined ? expandedMap[node.id] : !!node.expanded;
  const hasChildren = node.children && node.children.length > 0;
  const [editing, setEditing] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  React.useEffect(() => {
    if (!menuOpen) return;
    const onClick = () => setMenuOpen(false);
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, [menuOpen]);

  const active = activeId === node.id;
  const isDragging = dragId === node.id;
  const isTarget = dropTarget?.id === node.id;
  const targetPos = isTarget ? dropTarget.pos : null;

  const onDragOver = (e) => {
    if (!dragId || dragId === node.id) return;
    e.preventDefault();
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const y = e.clientY - rect.top;
    let pos;
    if (y < rect.height * 0.3) pos = "before";
    else if (y > rect.height * 0.7) pos = "after";
    else pos = "inside";
    setDropTarget({ id: node.id, pos });
  };

  return (
    <>
      <div
        className={`tree-item ${active ? "active" : ""} ${isDragging ? "dragging" : ""}`}
        style={{
          paddingLeft: 6 + depth * 14,
          boxShadow:
            targetPos === "before" ? "inset 0 2px 0 var(--accent)" :
            targetPos === "after"  ? "inset 0 -2px 0 var(--accent)" :
            targetPos === "inside" ? "inset 0 0 0 1.5px var(--accent)" :
            undefined,
          background: targetPos === "inside" ? "var(--accent-soft)" : undefined,
          opacity: isDragging ? 0.4 : 1,
        }}
        onClick={() => onSelect(node.id)}
        draggable
        onDragStart={(e) => {
          setDragId(node.id);
          e.dataTransfer.effectAllowed = "move";
          e.dataTransfer.setData("text/x-page", node.id);
        }}
        onDragEnd={() => { setDragId(null); setDropTarget(null); }}
        onDragOver={onDragOver}
        onDragLeave={(e) => {
          // only clear if the pointer actually left the row
          if (!e.currentTarget.contains(e.relatedTarget)) {
            if (dropTarget?.id === node.id) setDropTarget(null);
          }
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (dragId && dragId !== node.id && dropTarget?.id === node.id) {
            onDrop(dragId, node.id, dropTarget.pos);
          }
          setDragId(null);
          setDropTarget(null);
        }}
      >
        <span
          className={`tree-chevron ${hasChildren ? "" : "leaf"} ${expanded ? "expanded" : ""}`}
          onClick={(e) => { e.stopPropagation(); onToggle(node.id); }}
        >
          <Icon name="chevronRight" size={12} />
        </span>
        <span className="tree-icon"><Icon name={node.icon || "page"} size={13} /></span>
        {editing ? (
          <input
            ref={inputRef}
            className="tree-label editing"
            defaultValue={node.title}
            onBlur={(e) => { onRename(node.id, e.target.value || node.title); setEditing(false); }}
            onKeyDown={(e) => {
              if (e.key === "Enter") { onRename(node.id, e.target.value || node.title); setEditing(false); }
              if (e.key === "Escape") setEditing(false);
            }}
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span className="tree-label" onDoubleClick={() => setEditing(true)}>{node.title}</span>
        )}
        <span className="tree-actions" onClick={(e) => e.stopPropagation()}>
          <button className="tree-action" title="Add page" onClick={(e) => { e.stopPropagation(); onAdd(node.id); }}><Icon name="plus" size={12} /></button>
          <button className="tree-action" title="More" onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}><Icon name="ellipsis" size={12} /></button>
          {menuOpen && (
            <div className="tree-menu" onClick={(e) => e.stopPropagation()}>
              <button className="tree-menu-item"
                onClick={() => { setEditing(true); setMenuOpen(false); }}>
                <Icon name="rename" size={13} /><span>Rename</span>
              </button>
              <button className="tree-menu-item"
                onClick={() => { onAdd(node.id); setMenuOpen(false); }}>
                <Icon name="plus" size={13} /><span>Add subpage</span>
              </button>
              <div className="tree-menu-divider" />
              <button className="tree-menu-item danger"
                onClick={() => { onDelete(node.id); setMenuOpen(false); }}>
                <Icon name="trash" size={13} /><span>Delete</span>
              </button>
            </div>
          )}
        </span>
      </div>
      {hasChildren && expanded && (
        <div className="tree-children">
          {node.children.map((c) => (
            <TreeNode
              key={c.id}
              node={c}
              depth={depth + 1}
              activeId={activeId}
              onSelect={onSelect}
              onToggle={onToggle}
              onRename={onRename}
              onDelete={onDelete}
              onAdd={onAdd}
              onDrop={onDrop}
              expandedMap={expandedMap}
              dragId={dragId}
              setDragId={setDragId}
              dropTarget={dropTarget}
              setDropTarget={setDropTarget}
            />
          ))}
        </div>
      )}
    </>
  );
};

const Sidebar = ({ spaces, activeSpaceId, onSpace, onAddSpace, pages, activePageId, onSelectPage, onAddPage, onRenamePage, onDeletePage, onMovePage }) => {
  const [expanded, setExpanded] = React.useState(() =>
    Object.fromEntries(pages.filter((p) => p.expanded).map((p) => [p.id, true]))
  );
  const [query, setQuery] = React.useState("");
  const [dragId, setDragId] = React.useState(null);
  const [dropTarget, setDropTarget] = React.useState(null);
  const [spaceOpen, setSpaceOpen] = React.useState(false);
  const [creating, setCreating] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const pickerRef = React.useRef(null);

  React.useEffect(() => {
    if (!spaceOpen) return;
    const onDoc = (e) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target)) {
        setSpaceOpen(false);
        setCreating(false);
        setNewName("");
      }
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [spaceOpen]);

  const activeSpace = spaces.find((s) => s.id === activeSpaceId) || spaces[0];

  const commitNewSpace = () => {
    const v = newName.trim();
    if (!v) { setCreating(false); return; }
    onAddSpace(v);
    setNewName("");
    setCreating(false);
    setSpaceOpen(false);
  };

  const filter = (list) => {
    if (!query) return list;
    const q = query.toLowerCase();
    const walk = (node) => {
      const selfMatch = node.title.toLowerCase().includes(q);
      const kids = (node.children || []).map(walk).filter(Boolean);
      if (selfMatch || kids.length) return { ...node, children: kids };
      return null;
    };
    return list.map(walk).filter(Boolean);
  };

  const filtered = filter(pages);

  return (
    <aside className="sidebar">
      <div className="sidebar-spaces" ref={pickerRef}>
        <button
          className={`space-picker ${spaceOpen ? "open" : ""}`}
          onClick={() => setSpaceOpen((v) => !v)}
          title="Switch space"
        >
          <span className="space-icon" style={{ background: activeSpace.color }}>{activeSpace.icon}</span>
          <span className="space-picker-name">{activeSpace.name}</span>
          <span className="count">{activeSpace.count}</span>
          <Icon name="chevronDown" size={12} />
        </button>

        {spaceOpen && (
          <div className="space-menu" role="menu">
            <div className="space-menu-label">Spaces</div>
            {spaces.map((sp) => (
              <div
                key={sp.id}
                className={`space-row ${sp.id === activeSpaceId ? "active" : ""}`}
                onClick={() => { onSpace(sp.id); setSpaceOpen(false); }}
                role="menuitem"
              >
                <span className="space-icon" style={{ background: sp.color }}>{sp.icon}</span>
                <span>{sp.name}</span>
                <span className="count">{sp.count}</span>
                {sp.id === activeSpaceId && <Icon name="check" size={12} />}
              </div>
            ))}
            <div className="space-menu-divider" />
            {creating ? (
              <div className="space-row creating">
                <span className="space-icon" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                  {(newName.trim()[0] || "•").toUpperCase()}
                </span>
                <input
                  autoFocus
                  className="space-new-input"
                  placeholder="Space name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitNewSpace();
                    if (e.key === "Escape") { setCreating(false); setNewName(""); }
                  }}
                  onBlur={commitNewSpace}
                />
              </div>
            ) : (
              <div
                className="space-row new"
                onClick={() => setCreating(true)}
                role="menuitem"
              >
                <span className="space-icon" style={{ background: "var(--bg-subtle)", border: "1px dashed var(--border-strong)", color: "var(--text-faint)" }}>+</span>
                <span>New space</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="sidebar-section-label">
        <span>Pages</span>
        <button title="Add top-level page" onClick={() => onAddPage(null)}><Icon name="plus" size={12} /></button>
      </div>

      <div style={{ padding: "0 10px 8px" }}>
        <div className="tb-search" style={{ width: "100%" }}>
          <Icon name="search" size={13} />
          <input
            style={{ background: "transparent", border: 0, outline: 0, color: "var(--text)", flex: 1, fontSize: 12.5 }}
            placeholder="Filter pages…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>

      <nav
        className="tree"
        onDragOver={(e) => { if (dragId) e.preventDefault(); }}
      >
        {filtered.map((node) => (
          <TreeNode
            key={node.id}
            node={node}
            activeId={activePageId}
            onSelect={onSelectPage}
            onToggle={(id) => setExpanded((m) => ({ ...m, [id]: !(m[id] !== undefined ? m[id] : pages.find(p=>p.id===id)?.expanded) }))}
            onRename={onRenamePage}
            onAdd={onAddPage}
            onDelete={onDeletePage}
            onDrop={(fromId, toId, pos) => {
              onMovePage(fromId, toId, pos);
              if (pos === "inside") {
                setExpanded((m) => ({ ...m, [toId]: true }));
              }
            }}
            expandedMap={expanded}
            dragId={dragId}
            setDragId={setDragId}
            dropTarget={dropTarget}
            setDropTarget={setDropTarget}
          />
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="sf-row"><Icon name="globe" size={14} /><span>Share site</span></div>
        <div className="sf-row"><Icon name="settings" size={14} /><span>Settings</span></div>
      </div>
    </aside>
  );
};

window.Sidebar = Sidebar;
