// ---------- Tweaks panel ----------
const ACCENTS = [
  { id: "ink",    label: "Ink",    hue: 255 },
  { id: "forest", label: "Forest", hue: 155 },
  { id: "ember",  label: "Ember",  hue: 30 },
  { id: "plum",   label: "Plum",   hue: 310 },
  { id: "iron",   label: "Iron",   hue: 260, muted: true },
];

const FONT_PAIRS = [
  { id: "serif-sans", label: "Serif / Sans",
    display: "Instrument Serif", body: "Inter Tight", mono: "JetBrains Mono" },
  { id: "editorial",  label: "Editorial",
    display: "Fraunces", body: "Newsreader", mono: "JetBrains Mono" },
  { id: "geometric",  label: "Geometric",
    display: "Geist", body: "Geist", mono: "Geist Mono" },
  { id: "plex",       label: "Plex Tech",
    display: "IBM Plex Sans", body: "IBM Plex Sans", mono: "IBM Plex Mono" },
];

const TweaksPanel = ({ tweaks, setTweaks, onClose }) => {
  const set = (patch) => setTweaks({ ...tweaks, ...patch });

  return (
    <div className="tweaks-panel">
      <h3>
        <span>Tweaks</span>
        <button style={{ color: "var(--text-faint)" }} onClick={onClose}>×</button>
      </h3>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Theme</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.theme === "light" ? "active" : ""} onClick={() => set({ theme: "light" })}>Light</button>
          <button className={tweaks.theme === "dark" ? "active" : ""} onClick={() => set({ theme: "dark" })}>Dark</button>
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Accent</span><span className="v">{tweaks.accent}</span></div>
        <div className="tweaks-swatches">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              className={tweaks.accent === a.id ? "active" : ""}
              style={{ background: `oklch(55% ${a.muted ? 0.03 : 0.14} ${a.hue})` }}
              onClick={() => set({ accent: a.id })}
              title={a.label}
            />
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Font pairing</span></div>
        <div className="tweaks-seg" style={{ flexWrap: "wrap", gap: 2 }}>
          {FONT_PAIRS.map((p) => (
            <button
              key={p.id}
              className={tweaks.fontPair === p.id ? "active" : ""}
              onClick={() => set({ fontPair: p.id })}
            >{p.label}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Serif body</span>
          <span className="v">{tweaks.serifBody ? "on" : "off"}</span>
        </div>
        <div className="tweaks-seg">
          <button className={!tweaks.serifBody ? "active" : ""} onClick={() => set({ serifBody: false })}>Sans</button>
          <button className={tweaks.serifBody ? "active" : ""} onClick={() => set({ serifBody: true })}>Serif</button>
        </div>
      </div>

      <div className="tweaks-row tweaks-slider">
        <div className="tweaks-row-label"><span>Reading width</span><span className="v">{tweaks.readingWidth}px</span></div>
        <input type="range" min="560" max="900" step="20"
          value={tweaks.readingWidth}
          onChange={(e) => set({ readingWidth: Number(e.target.value) })} />
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Density</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.density === "compact" ? "active" : ""} onClick={() => set({ density: "compact" })}>Compact</button>
          <button className={tweaks.density === "comfortable" ? "active" : ""} onClick={() => set({ density: "comfortable" })}>Comfortable</button>
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Right panel</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.rightPanel ? "active" : ""} onClick={() => set({ rightPanel: true })}>Visible</button>
          <button className={!tweaks.rightPanel ? "active" : ""} onClick={() => set({ rightPanel: false })}>Hidden</button>
        </div>
      </div>
    </div>
  );
};

window.TweaksPanel = TweaksPanel;
window.ACCENTS = ACCENTS;
window.FONT_PAIRS = FONT_PAIRS;
