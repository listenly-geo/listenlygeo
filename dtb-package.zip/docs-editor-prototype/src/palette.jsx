// ---------- Command palette (Cmd+K) ----------
const stripHtml = (s) => (s || "").replace(/<[^>]*>/g, "");

// Derive searchable text + block-list from every page's content
const buildBlockIndex = (contentMap) => {
  const out = [];
  if (!contentMap) return out;
  for (const [pageId, page] of Object.entries(contentMap)) {
    const blocks = page.blocks || [];
    for (const b of blocks) {
      const parts = [];
      if (b.text) parts.push(stripHtml(b.text));
      if (b.html) parts.push(stripHtml(b.html));
      if (b.title) parts.push(stripHtml(b.title));
      if (b.caption) parts.push(stripHtml(b.caption));
      if (b.desc) parts.push(stripHtml(b.desc));
      if (b.code) parts.push(b.code);
      if (b.filename) parts.push(b.filename);
      if (b.path) parts.push(b.path);
      if (b.url) parts.push(b.url);
      if (b.alt) parts.push(b.alt);
      if (b.headers) parts.push(b.headers.join(" "));
      if (b.rows) parts.push(b.rows.flat().join(" "));
      if (b.items) parts.push(b.items.map((it) => `${stripHtml(it.text||"")} ${stripHtml(it.title||"")} ${stripHtml(it.desc||"")}`).join(" "));
      if (b.tabs) parts.push(b.tabs.map((t) => `${t.label} ${t.code}`).join(" "));
      if (b.params) parts.push(b.params.map((p) => `${p.name} ${p.type} ${p.desc}`).join(" "));
      const text = parts.join(" ").trim();
      if (!text) continue;
      out.push({
        pageId, pageTitle: page.title || "Untitled",
        blockId: b.id, kind: b.kind,
        text,
      });
    }
  }
  return out;
};

const Palette = ({ open, onClose, pages, contentMap, onPickPage, onJumpToBlock, onAction }) => {
  const [q, setQ] = React.useState("");
  const [focus, setFocus] = React.useState(0);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (open) { setQ(""); setFocus(0); setTimeout(() => inputRef.current?.focus(), 20); }
  }, [open]);

  // Flatten pages
  const flatPages = [];
  const walk = (list, parent = "") => {
    list.forEach((p) => {
      flatPages.push({ id: p.id, title: p.title, parent, icon: p.icon || "page" });
      if (p.children) walk(p.children, p.title);
    });
  };
  walk(pages);

  const actions = [
    { id: "new-page", title: "New page", desc: "Create an untitled page", icon: "plus", kbd: "N" },
    { id: "toggle-theme", title: "Toggle theme", desc: "Light / dark", icon: "moon", kbd: "⇧D" },
    { id: "publish", title: "Publish page", desc: "Deploy changes to production", icon: "rocket", kbd: "⇧⌘P" },
    { id: "tweaks", title: "Open Tweaks panel", desc: "Adjust accent, font, width…", icon: "paintbrush" },
    { id: "share", title: "Share page", desc: "Copy public link", icon: "link" },
    { id: "undo", title: "Undo", desc: "Revert last change", icon: "history", kbd: "⌘Z" },
    { id: "redo", title: "Redo", desc: "Re-apply last undone change", icon: "history", kbd: "⇧⌘Z" },
  ];

  const ql = q.toLowerCase().trim();
  const matchP = flatPages.filter((p) => !q || p.title.toLowerCase().includes(ql));
  const matchA = actions.filter((a) => !q || a.title.toLowerCase().includes(ql) || a.desc.toLowerCase().includes(ql));

  // Block content search (only when query is non-empty)
  const blockIndex = React.useMemo(() => buildBlockIndex(contentMap), [contentMap]);
  const matchContent = React.useMemo(() => {
    if (!ql) return [];
    return blockIndex
      .filter((entry) => entry.text.toLowerCase().includes(ql))
      .slice(0, 20)
      .map((entry) => {
        const t = entry.text;
        const i = t.toLowerCase().indexOf(ql);
        const before = Math.max(0, i - 30);
        const snippet = (before > 0 ? "…" : "") + t.slice(before, i)
          + "<mark>" + t.slice(i, i + ql.length) + "</mark>"
          + t.slice(i + ql.length, i + ql.length + 60)
          + (t.length > i + ql.length + 60 ? "…" : "");
        return { ...entry, snippet };
      });
  }, [ql, blockIndex]);

  const blocks = BLOCK_SPECS.filter((b) => q && (b.title.toLowerCase().includes(ql) || b.kind.includes(ql)));

  const flat = [
    ...matchA.map((x) => ({ ...x, _kind: "action" })),
    ...matchP.map((x) => ({ ...x, _kind: "page" })),
    ...matchContent.map((x) => ({ ...x, _kind: "content" })),
    ...blocks.map((x) => ({ ...x, _kind: "block", title: "Insert " + x.title, desc: x.desc })),
  ];

  React.useEffect(() => { setFocus(0); }, [q]);

  const select = (i) => {
    const item = flat[i];
    if (!item) return;
    if (item._kind === "page") onPickPage(item.id);
    else if (item._kind === "action") onAction(item.id);
    else if (item._kind === "content") onJumpToBlock(item.pageId, item.blockId);
    onClose();
  };

  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); }
      if (e.key === "ArrowDown") { e.preventDefault(); setFocus((f) => Math.min(flat.length - 1, f + 1)); }
      if (e.key === "ArrowUp") { e.preventDefault(); setFocus((f) => Math.max(0, f - 1)); }
      if (e.key === "Enter") { e.preventDefault(); select(focus); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, focus, flat, onClose]);

  if (!open) return null;

  let i = -1;
  const section = (label, items, render) => {
    if (items.length === 0) return null;
    return (
      <>
        <div className="palette-group">{label}</div>
        {items.map((item) => {
          i++;
          const focused = i === focus;
          const cap = i;
          return (
            <div
              key={(item.id || item.blockId || item.kind) + "-" + cap}
              className={`palette-item ${focused ? "focused" : ""}`}
              onMouseEnter={() => setFocus(cap)}
              onClick={() => select(cap)}
            >
              {render(item)}
            </div>
          );
        })}
      </>
    );
  };

  return (
    <div className="palette-backdrop" onClick={onClose}>
      <div className="palette" onClick={(e) => e.stopPropagation()}>
        <div className="palette-input">
          <Icon name="search" size={16} />
          <input
            ref={inputRef}
            placeholder="Search pages, contents, commands, blocks…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-faint)" }}>esc</span>
        </div>
        <div className="palette-list">
          {section("Actions", matchA, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "settings"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                <span className="pi-desc">{item.desc}</span>
              </div>
              {item.kbd && <div className="palette-kbd">{item.kbd}</div>}
            </>
          ))}
          {section("Pages", matchP, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "page"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                {item.parent && <span className="pi-desc">in {item.parent}</span>}
              </div>
            </>
          ))}
          {q && section("In content", matchContent, (item) => (
            <>
              <div className="pi-ico"><Icon name="text" size={15} /></div>
              <div style={{ minWidth: 0 }}>
                <span className="pi-page">{item.pageTitle.replace(/<[^>]*>/g,"")}</span>
                <span className="pi-desc pi-snippet" dangerouslySetInnerHTML={{ __html: item.snippet }} />
              </div>
              <div className="palette-kbd">{item.kind}</div>
            </>
          ))}
          {q && section("Insert block", blocks, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "plus"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                <span className="pi-desc">{item.desc}</span>
              </div>
            </>
          ))}
          {flat.length === 0 && (
            <div style={{ padding: 24, textAlign: "center", color: "var(--text-faint)", fontSize: 13 }}>
              No results for "{q}"
            </div>
          )}
        </div>
        <div className="palette-foot">
          <span><span className="kbd">↑↓</span> navigate</span>
          <span><span className="kbd">↵</span> select</span>
          <span><span className="kbd">esc</span> close</span>
        </div>
      </div>
    </div>
  );
};

window.Palette = Palette;
