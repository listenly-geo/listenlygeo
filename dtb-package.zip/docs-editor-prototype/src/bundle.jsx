﻿// ---------- Seed data ----------
const uid = (() => { let i = 0; return (p="id") => `${p}_${++i}_${Math.random().toString(36).slice(2,6)}`; })();

const SPACES = [
  { id: "sp_product", name: "Product Docs", color: "oklch(55% 0.14 255)", count: 24, icon: "P" },
  { id: "sp_api",     name: "API Reference", color: "oklch(52% 0.15 155)", count: 12, icon: "A" },
  { id: "sp_internal",name: "Team Handbook", color: "oklch(55% 0.15 30)",  count: 31, icon: "H" },
];

// Pages: id, title, icon, children, content (blocks)
const PAGES = [
  {
    id: "p_intro", title: "Introduction", icon: "book", expanded: true,
    children: [
      { id: "p_welcome",  title: "Welcome to Lexicon", icon: "rocket" },
      { id: "p_concepts", title: "Core Concepts", icon: "compass" },
      { id: "p_install",  title: "Installation", icon: "page" },
    ],
  },
  {
    id: "p_guides", title: "Guides", icon: "folder", expanded: true,
    children: [
      { id: "p_quickstart", title: "Quickstart", icon: "bolt" },
      { id: "p_auth",       title: "Authentication", icon: "page" },
      { id: "p_webhooks",   title: "Webhooks", icon: "send" },
    ],
  },
  {
    id: "p_api", title: "API Reference", icon: "api", expanded: false,
    children: [
      { id: "p_docs_api",   title: "Documents", icon: "page" },
      { id: "p_blocks_api", title: "Blocks", icon: "page" },
      { id: "p_users_api",  title: "Users", icon: "page" },
    ],
  },
  {
    id: "p_changelog", title: "Changelog", icon: "history",
  },
];

const ACTIVE_PAGE_ID = "p_quickstart";

// Content by page id
const PAGE_CONTENT = {
  p_quickstart: {
    title: "Quickstart",
    subtitle: "Go from zero to a published page in under three minutes â€” no framework, no build step.",
    updated: "Apr 16, 2026",
    readTime: "4 min",
    author: { name: "Mira Okafor", role: "Docs Lead", initials: "MO", color: "oklch(60% 0.14 30)" },
    collaborators: [
      { initials: "MO", color: "oklch(60% 0.14 30)" },
      { initials: "JK", color: "oklch(55% 0.14 220)" },
      { initials: "RH", color: "oklch(55% 0.14 155)" },
    ],
    blocks: [
      { id: uid("b"), kind: "callout", variant: "info", title: "Before you start",
        text: "You'll need a Lexicon workspace and a personal access token. If you don't have one yet, create a workspace from the dashboard â€” it takes about 30 seconds." },

      { id: uid("b"), kind: "p",
        html: "This guide walks you through creating your first <strong>space</strong>, writing a page, and publishing it to a public URL. Every step happens inside the editor you're reading right now â€” no terminal required." },

      { id: uid("b"), kind: "h2", text: "1. Create a space" },
      { id: uid("b"), kind: "p",
        html: "Open the sidebar and click <em>New space</em>. A space holds a collection of related documents â€” it's the unit we publish. Give it a name like <code>Handbook</code> or <code>API</code> and pick an accent color." },

      { id: uid("b"), kind: "cards", items: [
        { ico: "book", title: "Product Docs", desc: "User-facing guides and concepts. Defaults to public." },
        { ico: "api",  title: "API Reference", desc: "Endpoints, parameters, and response examples." },
        { ico: "folder", title: "Team Handbook", desc: "Internal-only. Auth required to read." },
      ]},

      { id: uid("b"), kind: "h2", text: "2. Write your first page" },
      { id: uid("b"), kind: "p",
        html: "Press <code>/</code> anywhere in a page to open the block menu. Lexicon pages are made from typed blocks â€” headings, text, code, callouts, tables, and more. You can drag them to reorder, and every block has its own settings menu." },

      { id: uid("b"), kind: "tabs",
        tabs: [
          { id: "js", label: "JavaScript", lang: "javascript", code:
`import { Lexicon } from "@lexicon/sdk";

const client = new Lexicon({ token: process.env.LEX_TOKEN });

const page = await client.pages.create({
  space: "handbook",
  title: "Onboarding",
  blocks: [
    { kind: "h1", text: "Welcome aboard" },
    { kind: "p",  text: "Your first week, day by day." },
  ],
});` },
          { id: "py", label: "Python", lang: "python", code:
`from lexicon import Client

client = Client(token=os.environ["LEX_TOKEN"])

page = client.pages.create(
    space="handbook",
    title="Onboarding",
    blocks=[
        {"kind": "h1", "text": "Welcome aboard"},
        {"kind": "p",  "text": "Your first week, day by day."},
    ],
)` },
          { id: "curl", label: "cURL", lang: "bash", code:
`curl https://api.lexicon.dev/v1/pages \\
  -H "Authorization: Bearer $LEX_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "space": "handbook",
    "title": "Onboarding",
    "blocks": [{"kind":"h1","text":"Welcome aboard"}]
  }'` },
        ],
      },

      { id: uid("b"), kind: "callout", variant: "warn", title: "Tokens are secrets",
        text: "Never commit your access token. Use an environment variable or the secrets manager built into the settings panel." },

      { id: uid("b"), kind: "h2", text: "3. Publish" },
      { id: uid("b"), kind: "p",
        html: "Hit <kbd>Publish</kbd> in the top right. You'll get a live URL on the <code>lexicon.page</code> subdomain, or attach a custom domain from Settings â†’ Domains." },

      { id: uid("b"), kind: "api",
        method: "POST", path: "/v1/spaces/{space_id}/publish",
        desc: "Builds the space and pushes a new public version. Idempotent â€” safe to retry.",
        params: [
          { name: "space_id", type: "string", desc: "The slug of the space to publish." },
          { name: "message",  type: "string?", desc: "Optional changelog note shown on the live site." },
          { name: "draft",    type: "boolean", desc: "If true, publishes to the staging URL instead of production." },
        ] },

      { id: uid("b"), kind: "h3", text: "What happens next" },
      { id: uid("b"), kind: "checklist", items: [
        { id: uid("c"), text: "Pages render to static HTML at the edge", done: true },
        { id: uid("c"), text: "Search index rebuilds from block content", done: true },
        { id: uid("c"), text: "Broken link checker runs across all pages", done: false },
        { id: uid("c"), text: "Slack and Discord webhooks fire (if configured)", done: false },
      ]},

      { id: uid("b"), kind: "figure",
        caption: "The publish pipeline takes around 4â€“12 seconds for a space of 50 pages. Cold starts are cached after the first deploy.",
        alt: "publish pipeline diagram" },

      { id: uid("b"), kind: "h2", text: "Going further" },
      { id: uid("b"), kind: "p",
        html: "Once published, you probably want to hook Lexicon into your code â€” either to sync docs from markdown files, or to render docs inside your own app." },

      { id: uid("b"), kind: "expand", title: "Syncing from GitHub",
        body: "Connect a GitHub repo from Settings â†’ Integrations. Lexicon watches the branch you select and converts matching .md or .mdx files to blocks on every push. Conflicts between the editor and the repo surface as pull requests." },

      { id: uid("b"), kind: "expand", title: "Embedding pages in your app",
        body: "Use the read-only JSON feed at /v1/pages/:id.json. It returns the same block tree you see in the editor â€” render it with our React component or map it yourself." },

      { id: uid("b"), kind: "quote",
        html: "The nicest surprise was that our support team started writing docs. The block editor finally made it feel like writing, not configuring." },

      { id: uid("b"), kind: "embed",
        source: "YouTube", title: "Lexicon in 90 seconds", url: "youtube.com/@lexicon/quickstart" },

      { id: uid("b"), kind: "divider" },

      { id: uid("b"), kind: "h3", text: "Formula: search relevance" },
      { id: uid("b"), kind: "math",
        expr: { type: "bm25" } },

      { id: uid("b"), kind: "table",
        headers: ["Plan", "Pages", "Custom domain", "Price / month"],
        rows: [
          ["Starter", "Up to 100", "â€”", "$0"],
          ["Team", "Up to 2,000", "âœ“", "$29 / editor"],
          ["Scale", "Unlimited", "âœ“ + SSO", "Custom"],
        ] },

      { id: uid("b"), kind: "p",
        html: "That's it â€” you've shipped a docs site. Dig into <a href='#'>Authentication</a> next, or browse the <a href='#'>full block reference</a>." },
    ],
  },
};

// Outline: derive on the fly from h1/h2/h3 blocks.

const COMMENTS = [
  { id: "c1", author: "Jin KovaÄ", initials: "JK", color: "oklch(55% 0.14 220)",
    time: "2h ago", ref: "Â§ 2. Write your first page",
    body: "Can we mention the keyboard shortcut for the slash menu here? Most new users miss it on mobile.",
    replies: [
      { author: "Mira Okafor", initials: "MO", color: "oklch(60% 0.14 30)",
        time: "1h ago", body: "Good call â€” I'll add a note under the tab block. Mobile gets a dedicated toolbar row." },
    ],
    resolved: false,
  },
  { id: "c2", author: "Rhea Hassan", initials: "RH", color: "oklch(55% 0.14 155)",
    time: "yesterday", ref: "API: POST /v1/spaces/{space_id}/publish",
    body: "The 'draft' flag is misleading â€” internally we call it staging. Align the names?",
    replies: [],
    resolved: false,
  },
  { id: "c3", author: "Dmitri Walsh", initials: "DW", color: "oklch(50% 0.14 295)",
    time: "3d ago", ref: "Going further",
    body: "Love this section. Minor: the GitHub sync only supports main branch today, not any branch.",
    replies: [
      { author: "Mira Okafor", initials: "MO", color: "oklch(60% 0.14 30)",
        time: "2d ago", body: "Fixed â€” now reads 'the branch you select'." },
    ],
    resolved: true,
  },
];

const HISTORY = [
  { day: "Today",
    items: [
      { id: "v_now", name: "Current draft", meta: "auto-saved 12s ago", msg: "editing Â§ Quickstart", who: "MO", current: true },
      { id: "v1", name: "Mira revised publish section", meta: "10:42 Â· 14 changes", msg: "Clarified staging URL behavior", who: "MO" },
      { id: "v2", name: "Jin merged comments", meta: "09:17 Â· 3 changes", msg: "Resolved RH's feedback on /draft", who: "JK" },
    ] },
  { day: "Yesterday",
    items: [
      { id: "v3", name: "Added GitHub sync callout", meta: "18:04 Â· 22 changes", msg: "New expandable block under 'Going further'", who: "MO" },
      { id: "v4", name: "Table: pricing tiers", meta: "14:31 Â· 8 changes", msg: "Updated Scale tier copy", who: "RH" },
    ] },
  { day: "Apr 14, 2026",
    items: [
      { id: "v5", name: "First draft published", meta: "11:02 Â· 146 changes", msg: "Initial Quickstart draft", who: "MO" },
    ] },
];

Object.assign(window, { uid, SPACES, PAGES, ACTIVE_PAGE_ID, PAGE_CONTENT, COMMENTS, HISTORY });
// ---------- Icon set ----------
// Inline SVGs â€” single stroke, Lucide-ish feel.
const Icon = ({ name, size = 16, ...rest }) => {
  const s = size;
  const common = { width: s, height: s, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", ...rest };
  const paths = {
    chevronRight: <polyline points="9 6 15 12 9 18" />,
    chevronDown: <polyline points="6 9 12 15 18 9" />,
    plus: <g><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></g>,
    ellipsis: <g><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></g>,
    grip: <g><circle cx="9" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="18" r="1"/></g>,
    page: <g><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></g>,
    folder: <path d="M4 6a2 2 0 0 1 2-2h3l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/>,
    book: <g><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22.5z"/><line x1="4" y1="19.5" x2="20" y2="19.5"/></g>,
    compass: <g><circle cx="12" cy="12" r="9"/><polygon points="16 8 14 14 8 16 10 10"/></g>,
    search: <g><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.5" y2="16.5"/></g>,
    bold: <g><path d="M7 5h6a3.5 3.5 0 0 1 0 7H7z"/><path d="M7 12h7a3.5 3.5 0 0 1 0 7H7z"/></g>,
    italic: <g><line x1="10" y1="4" x2="19" y2="4"/><line x1="5" y1="20" x2="14" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></g>,
    underline: <g><path d="M6 4v8a6 6 0 0 0 12 0V4"/><line x1="5" y1="20" x2="19" y2="20"/></g>,
    strike: <g><line x1="4" y1="12" x2="20" y2="12"/><path d="M16 7a4 4 0 0 0-8 0"/><path d="M8 17a4 4 0 0 0 8 0"/></g>,
    code: <g><polyline points="8 8 4 12 8 16"/><polyline points="16 8 20 12 16 16"/></g>,
    link: <g><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></g>,
    comment: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>,
    h1: <g><path d="M4 5v14"/><path d="M14 5v14"/><path d="M4 12h10"/><path d="M18 9l2-1v11"/></g>,
    h2: <g><path d="M4 5v14"/><path d="M14 5v14"/><path d="M4 12h10"/><path d="M17 9a2 2 0 1 1 3 1l-3 4h4"/></g>,
    h3: <g><path d="M4 5v14"/><path d="M14 5v14"/><path d="M4 12h10"/><path d="M17 8a2 2 0 1 1 3 1l-2 2 2 2a2 2 0 1 1-3 1"/></g>,
    text: <g><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="18" y2="18"/></g>,
    quote: <g><path d="M6 16V9a3 3 0 0 1 3-3"/><path d="M5 16h3V10H5z"/><path d="M15 16V9a3 3 0 0 1 3-3"/><path d="M14 16h3V10h-3z"/></g>,
    table: <g><rect x="3" y="5" width="18" height="14" rx="1"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="9" y1="5" x2="9" y2="19"/></g>,
    image: <g><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="m4 17 5-4 5 4 3-2 3 2"/></g>,
    callout: <g><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12" y2="16"/></g>,
    divider: <line x1="4" y1="12" x2="20" y2="12"/>,
    tabs: <g><path d="M3 10h6l2-3h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></g>,
    expand: <g><polyline points="6 9 12 15 18 9"/></g>,
    card: <g><rect x="3" y="5" width="8" height="14" rx="1"/><rect x="13" y="5" width="8" height="14" rx="1"/></g>,
    api: <g><path d="M5 12h14"/><path d="M5 7h6"/><path d="M13 17h6"/></g>,
    math: <g><path d="M5 5h10l-4 7 4 7H5"/></g>,
    embed: <g><rect x="3" y="5" width="18" height="14" rx="2"/><polygon points="10 9 16 12 10 15"/></g>,
    check: <polyline points="5 12 10 17 19 7"/>,
    checklist: <g><rect x="3" y="5" width="6" height="6" rx="1"/><rect x="3" y="13" width="6" height="6" rx="1"/><line x1="12" y1="8" x2="20" y2="8"/><line x1="12" y1="16" x2="20" y2="16"/></g>,
    eye: <g><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></g>,
    moon: <path d="M20 14A8 8 0 1 1 10 4a6 6 0 0 0 10 10z"/>,
    sun: <g><circle cx="12" cy="12" r="4"/><line x1="12" y1="3" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="21"/><line x1="3" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="21" y2="12"/><line x1="5.6" y1="5.6" x2="7" y2="7"/><line x1="17" y1="17" x2="18.4" y2="18.4"/><line x1="5.6" y1="18.4" x2="7" y2="17"/><line x1="17" y1="7" x2="18.4" y2="5.6"/></g>,
    history: <g><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><polyline points="3 3 3 8 8 8"/><polyline points="12 7 12 12 15 14"/></g>,
    panel: <g><rect x="3" y="5" width="18" height="14" rx="1"/><line x1="15" y1="5" x2="15" y2="19"/></g>,
    menu: <g><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></g>,
    globe: <g><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18"/><path d="M12 3a14 14 0 0 0 0 18"/></g>,
    settings: <g><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2 1.2L10 21h4l.6-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z"/></g>,
    rocket: <g><path d="M5 15l4-4 4 4-4 4z"/><path d="M14 3c5 0 7 2 7 7-3 0-5 1-8 4l-3-3c3-3 4-5 4-8z"/><circle cx="15" cy="9" r="1.5"/></g>,
    send: <g><polygon points="21 3 3 10 10 13 13 21"/></g>,
    info: <g><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16"/><line x1="12" y1="8" x2="12" y2="8"/></g>,
    warn: <g><path d="M12 3 2 20h20z"/><line x1="12" y1="10" x2="12" y2="14"/><line x1="12" y1="17" x2="12" y2="17"/></g>,
    bolt: <polygon points="13 3 4 14 11 14 11 21 20 10 13 10"/>,
    copy: <g><rect x="8" y="8" width="12" height="12" rx="1.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></g>,
    paintbrush: <g><path d="M7 21c-2 0-3-1-3-3s1-3 3-3"/><path d="M7 15a5 5 0 0 0 5-5l8-8 2 2-8 8a5 5 0 0 0-5 5"/></g>,
    play: <polygon points="7 4 20 12 7 20"/>,
    external: <g><path d="M14 4h6v6"/><line x1="10" y1="14" x2="20" y2="4"/><path d="M18 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"/></g>,
    rename: <g><path d="M12 20h9"/><path d="M16.5 3.5a2 2 0 0 1 3 3L7 19l-4 1 1-4z"/></g>,
    trash: <g><polyline points="4 7 20 7"/><path d="M6 7v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 7V4h6v3"/></g>,
    duplicate: <g><rect x="4" y="4" width="12" height="12" rx="1.5"/><path d="M8 20h10a2 2 0 0 0 2-2V8"/></g>,
  };
  return <svg {...common}>{paths[name] || null}</svg>;
};

window.Icon = Icon;
// ---------- Block renderer ----------
// Each block is a presentational React component. Most have editable text.

const SyntaxHighlight = ({ code, lang, onChange, editable = false }) => {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const rules = {
    javascript: [
      { re: /(\/\/[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?'|`.*?`)/g, cls: "tok-s" },
      { re: /\b(const|let|var|function|return|import|from|export|async|await|new|if|else|for|while|class|extends)\b/g, cls: "tok-k" },
      { re: /\b(\d+(?:\.\d+)?)\b/g, cls: "tok-n" },
      { re: /\b([A-Za-z_][A-Za-z0-9_]*)(?=\()/g, cls: "tok-f" },
    ],
    python: [
      { re: /(#[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?')/g, cls: "tok-s" },
      { re: /\b(def|class|import|from|return|if|else|elif|for|while|in|as|with|try|except|None|True|False|lambda)\b/g, cls: "tok-k" },
      { re: /\b(\d+(?:\.\d+)?)\b/g, cls: "tok-n" },
      { re: /\b([A-Za-z_][A-Za-z0-9_]*)(?=\()/g, cls: "tok-f" },
    ],
    bash: [
      { re: /(#[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?')/g, cls: "tok-s" },
      { re: /(\$[A-Z_][A-Z0-9_]*)/g, cls: "tok-n" },
      { re: /\b(curl|echo|export|cd|ls|cat|grep|sed|awk)\b/g, cls: "tok-f" },
      { re: /(-[A-Za-z]+|--[A-Za-z-]+)/g, cls: "tok-k" },
    ],
  };
  const ruleset = rules[lang] || rules.javascript;
  const lines = code.split("\n");
  const render = (line) => {
    const tokens = [];
    ruleset.forEach(({ re, cls }) => {
      line.replace(re, (m, ...rest) => {
        const offset = rest[rest.length - 2];
        tokens.push({ start: offset, end: offset + m.length, cls, text: m });
      });
    });
    tokens.sort((a,b) => a.start - b.start);
    const clean = [];
    let lastEnd = -1;
    for (const t of tokens) {
      if (t.start >= lastEnd) { clean.push(t); lastEnd = t.end; }
    }
    let out = "", cur = 0;
    for (const t of clean) {
      out += esc(line.slice(cur, t.start));
      out += `<span class="${t.cls}">${esc(t.text)}</span>`;
      cur = t.end;
    }
    out += esc(line.slice(cur));
    return out || "\u200b";
  };

  if (editable) {
    // Editable textarea overlay â€” syntax-highlighted display + invisible textarea on top
    return (
      <div className="code-editor">
        <div className="code-body code-display" aria-hidden="true">
          {lines.map((ln, i) => (
            <span key={i} className="ln" dangerouslySetInnerHTML={{ __html: render(ln) }} />
          ))}
        </div>
        <textarea
          className="code-textarea"
          spellCheck={false}
          value={code}
          onChange={(e) => onChange && onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Tab") {
              e.preventDefault();
              const s = e.target.selectionStart;
              const en = e.target.selectionEnd;
              const v = code.slice(0, s) + "  " + code.slice(en);
              onChange && onChange(v);
              requestAnimationFrame(() => {
                e.target.selectionStart = e.target.selectionEnd = s + 2;
              });
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="code-body">
      {lines.map((ln, i) => (
        <span key={i} className="ln" dangerouslySetInnerHTML={{ __html: render(ln) }} />
      ))}
    </div>
  );
};

// Editable contenteditable helper that doesn't thrash the cursor.
const Editable = ({ html, onChange, className, placeholder, tag="div", ...rest }) => {
  const ref = React.useRef(null);
  const last = React.useRef(html);
  React.useEffect(() => {
    if (ref.current && ref.current.innerHTML !== html && last.current !== html) {
      ref.current.innerHTML = html || "";
      last.current = html;
    }
  }, [html]);
  const Tag = tag;
  const isEmpty = !html || html === "<br>" || html.replace(/<[^>]*>/g,"").trim() === "";
  return (
    <Tag
      ref={ref}
      className={className}
      contentEditable
      suppressContentEditableWarning
      data-empty={isEmpty ? "true" : "false"}
      data-placeholder={placeholder}
      dangerouslySetInnerHTML={{ __html: html || "" }}
      onInput={(e) => {
        last.current = e.currentTarget.innerHTML;
        onChange && onChange(e.currentTarget.innerHTML);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();

          const sel = window.getSelection();
          if (!sel || sel.rangeCount === 0) return;

          const range = sel.getRangeAt(0);
          range.deleteContents();

          const br = document.createElement("br");
          const marker = document.createTextNode("");
          range.insertNode(br);
          br.parentNode?.insertBefore(marker, br.nextSibling);

          range.setStartAfter(br);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);

          last.current = e.currentTarget.innerHTML;
          onChange && onChange(e.currentTarget.innerHTML);
        }
      }}
      {...rest}
    />
  );
};

// Small icon button used in many editors
const IconBtn = ({ name, onClick, title, size = 13, danger }) => (
  <button
    className="ibtn"
    title={title}
    onClick={onClick}
    style={danger ? { color: "oklch(55% 0.15 25)" } : undefined}
  >
    <Icon name={name} size={size} />
  </button>
);

// ---------- Individual block components ----------
const ParagraphBlock = ({ block, update }) => (
  <Editable tag="p" className="blk-content blk-p" html={block.html}
    placeholder="Write, or press / for commands"
    onChange={(h) => update({ html: h })} />
);

const HeadingBlock = ({ block, update, level }) => {
  const Tag = `h${level}`;
  return (
    <Editable tag={Tag} className={`blk-content blk-h${level}`} html={block.text}
      placeholder={`Heading ${level}`}
      onChange={(h) => update({ text: h })} />
  );
};

const QuoteBlock = ({ block, update }) => (
  <Editable tag="blockquote" className="blk-content blk-quote" html={block.html}
    placeholder="Quote"
    onChange={(h) => update({ html: h })} />
);

const DividerBlock = () => (
  <div className="blk-divider"><span className="mark">Â§</span></div>
);

const CodeBlock = ({ block, update }) => {
  const [copied, setCopied] = React.useState(false);
  const langs = ["javascript","python","bash","typescript","json","rust","go","sql"];
  return (
    <div className="blk-code">
      <div className="code-head">
        <select
          className="lang"
          value={block.lang || "javascript"}
          onChange={(e) => update({ lang: e.target.value })}
          style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", appearance: "none", padding: 0 }}
        >
          {langs.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
        <input
          className="filename"
          value={block.filename || "example.js"}
          onChange={(e) => update({ filename: e.target.value })}
          style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", outline: "none", flex: 1, minWidth: 0 }}
        />
        <button className="copy" onClick={() => {
          navigator.clipboard?.writeText(block.code || "");
          setCopied(true);
          setTimeout(() => setCopied(false), 1200);
        }}>{copied ? "copied" : "copy"}</button>
      </div>
      <SyntaxHighlight
        code={block.code || ""}
        lang={block.lang || "javascript"}
        editable
        onChange={(c) => update({ code: c })}
      />
    </div>
  );
};

const CalloutBlock = ({ block, update }) => {
  const variants = {
    info:   { ico: "info",  label: "Info" },
    warn:   { ico: "warn",  label: "Careful" },
    ok:     { ico: "check", label: "Tip" },
    danger: { ico: "warn",  label: "Warning" },
  };
  const v = variants[block.variant] || variants.info;
  const [menu, setMenu] = React.useState(false);
  return (
    <div className={`blk-callout ${block.variant || "info"}`}>
      <div className="callout-ico" onClick={(e) => { e.stopPropagation(); setMenu(!menu); }} style={{ cursor: "pointer", position: "relative" }}>
        <Icon name={v.ico} size={12} strokeWidth={2.5} />
        {menu && (
          <div className="callout-menu" onClick={(e) => e.stopPropagation()}>
            {Object.keys(variants).map((k) => (
              <button key={k} onClick={() => { update({ variant: k }); setMenu(false); }}>
                <span className={`callout-dot ${k}`} />{variants[k].label}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="callout-body">
        <Editable tag="div" className="callout-title-edit"
          html={block.title || ""}
          placeholder={v.label}
          onChange={(h) => update({ title: h })} />
        <Editable tag="div" className="blk-content" html={block.text}
          placeholder="Callout message"
          onChange={(h) => update({ text: h })} />
      </div>
    </div>
  );
};

// ---------- Figure (Image) block ----------
const FigureBlock = ({ block, update }) => {
  const [modalOpen, setModalOpen] = React.useState(false);
  const widthPercent = Math.max(25, Math.min(100, Number(block.widthPercent || 100)));

  return (
    <figure className="blk-figure" style={{ width: `${widthPercent}%`, maxWidth: "100%", marginInline: "auto" }}>
      <div className="fig-img" onClick={(e) => { e.stopPropagation(); setModalOpen(true); }} style={{ cursor: "pointer" }}>
        {block.src ? (
          <img src={block.src} alt={block.alt || ""} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        ) : (
          <div className="placeholder">
            <Icon name="image" size={14} />
            <span style={{ marginLeft: 6 }}>Click to add image</span>
          </div>
        )}
      </div>
      <Editable tag="figcaption" className="fig-caption blk-content" html={block.caption}
        placeholder="Add a captionâ€¦"
        onChange={(h) => update({ caption: h })} />

      {modalOpen && (
        <ImageModal
          block={block}
          onSave={(patch) => { update(patch); setModalOpen(false); }}
          onClose={() => setModalOpen(false)}
        />
      )}
    </figure>
  );
};

const ImageModal = ({ block, onSave, onClose }) => {
  const [tab, setTab] = React.useState("url");
  const [url, setUrl] = React.useState(block.src || "");
  const [alt, setAlt] = React.useState(block.alt || "");
  const [widthPercent, setWidthPercent] = React.useState(Math.max(25, Math.min(100, Number(block.widthPercent || 100))));
  const [uploading, setUploading] = React.useState(false);
  const [uploadError, setUploadError] = React.useState("");
  const fileRef = React.useRef(null);

  const uploadUrl = () => {
    const config = window.__LARAVEL_EDITOR_CONFIG__ || null;
    const siteId = window.__LARAVEL_BOOTSTRAP__?.site?.id || null;

    if (!config || !siteId || typeof config.uploadMediaUrlTemplate !== "string") {
      return null;
    }

    return config.uploadMediaUrlTemplate.replace("__SITE__", String(siteId));
  };

  const onFile = async (f) => {
    if (!f) return;

    const nextUploadUrl = uploadUrl();
    if (!nextUploadUrl) {
      setUploadError("Image uploads are unavailable for this editor session.");
      return;
    }

    setUploadError("");
    setUploading(true);

    try {
      const form = new FormData();
      form.append("file", f);

      const csrf = window.__LARAVEL_EDITOR_CONFIG__?.csrfToken;
      if (csrf) {
        form.append("_token", csrf);
      }

      const response = await fetch(nextUploadUrl, {
        method: "POST",
        body: form,
        headers: {
          Accept: "application/json",
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload?.asset?.url) {
        throw new Error(payload?.message || "Upload failed");
      }

      setUrl(payload.asset.url);
      setAlt((prev) => prev || payload.asset.name || "");
    } catch (error) {
      setUploadError(error?.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="lx-modal-bg" onMouseDown={onClose} onClick={(e) => e.stopPropagation()}>
      <div className="lx-modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="lx-modal-head">
          <h3>Image</h3>
          <button onClick={onClose} className="lx-modal-close">Ã—</button>
        </div>
        <div className="lx-tab-bar">
          <button className={tab === "url" ? "on" : ""} onClick={() => setTab("url")}>From URL</button>
          <button className={tab === "upload" ? "on" : ""} onClick={() => setTab("upload")}>Upload</button>
        </div>

        {tab === "url" && (
          <div className="lx-field">
            <label>Image URL</label>
            <input autoFocus value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." />
          </div>
        )}

        {tab === "upload" && (
          <div
            className="lx-dropzone"
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add("drag"); }}
            onDragLeave={(e) => e.currentTarget.classList.remove("drag")}
            onDrop={(e) => {
              e.preventDefault();
              e.currentTarget.classList.remove("drag");
              onFile(e.dataTransfer.files[0]);
            }}
          >
            <Icon name="image" size={28} />
            <div style={{ marginTop: 10, fontSize: 13 }}>{uploading ? "Uploading image…" : "Drop an image or click to choose"}</div>
            <div style={{ fontSize: 11, color: "var(--text-faint)", marginTop: 4 }}>PNG, JPG, GIF, SVG up to 10 MB</div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }}
              onChange={(e) => onFile(e.target.files[0])} />
          </div>
        )}

        {uploadError ? (
          <div style={{ marginTop: 10, color: "oklch(55% 0.15 25)", fontSize: 12 }}>
            {uploadError}
          </div>
        ) : null}

        {url && (
          <div className="lx-preview">
            <img src={url} alt="" />
          </div>
        )}

        <div className="lx-field">
          <label>Alt text</label>
          <input value={alt} onChange={(e) => setAlt(e.target.value)} placeholder="Describe the image" />
        </div>

        <div className="lx-field">
          <label>Display width</label>
          <div style={{ display: "grid", gap: 8 }}>
            <input
              type="range"
              min="25"
              max="100"
              step="5"
              value={widthPercent}
              onChange={(e) => setWidthPercent(Number(e.target.value))}
            />
            <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{widthPercent}% of the content width</div>
          </div>
        </div>

        <div className="lx-modal-foot">
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" onClick={() => onSave({ src: url, alt, widthPercent })} disabled={!url || uploading}>Save</button>
        </div>
      </div>
    </div>
  );
};

// ---------- Table with row/col add-remove ----------
const TableBlock = ({ block, update }) => {
  const headers = block.headers || [];
  const rows = block.rows || [];

  const setCell = (ri, ci, val) => {
    const nrows = rows.map((r, i) => i === ri ? r.map((c, j) => j === ci ? val : c) : r);
    update({ rows: nrows });
  };
  const setHeader = (ci, val) => {
    const nh = headers.map((h, i) => i === ci ? val : h);
    update({ headers: nh });
  };
  const addCol = (at) => {
    const nh = [...headers];
    nh.splice(at, 0, "New column");
    const nr = rows.map((r) => {
      const cp = [...r]; cp.splice(at, 0, ""); return cp;
    });
    update({ headers: nh, rows: nr });
  };
  const removeCol = (at) => {
    if (headers.length <= 1) return;
    const nh = headers.filter((_, i) => i !== at);
    const nr = rows.map((r) => r.filter((_, i) => i !== at));
    update({ headers: nh, rows: nr });
  };
  const addRow = (at) => {
    const nr = [...rows];
    nr.splice(at, 0, headers.map(() => ""));
    update({ rows: nr });
  };
  const removeRow = (at) => {
    if (rows.length <= 1) return;
    update({ rows: rows.filter((_, i) => i !== at) });
  };

  return (
    <div className="blk-table">
      <table>
        <thead>
          <tr>
            <th className="tbl-corner"></th>
            {headers.map((h, i) => (
              <th key={i} className="tbl-head-cell">
                <div
                  contentEditable suppressContentEditableWarning
                  onBlur={(e) => setHeader(i, e.currentTarget.textContent)}
                  dangerouslySetInnerHTML={{ __html: h }}
                />
                <div className="col-tools">
                  <button title="Insert column before" onClick={() => addCol(i)}>+â—€</button>
                  <button title="Insert column after" onClick={() => addCol(i + 1)}>â–¶+</button>
                  <button title="Delete column" onClick={() => removeCol(i)}>âœ•</button>
                </div>
              </th>
            ))}
            <th className="tbl-add" onClick={() => addCol(headers.length)}>
              <Icon name="plus" size={12} />
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={ri}>
              <td className="tbl-row-handle">
                <button title="Delete row" onClick={() => removeRow(ri)}><Icon name="trash" size={11} /></button>
                <button title="Insert row below" onClick={() => addRow(ri + 1)}><Icon name="plus" size={11} /></button>
              </td>
              {r.map((c, ci) => (
                <td key={ci} contentEditable suppressContentEditableWarning
                  onBlur={(e) => setCell(ri, ci, e.currentTarget.textContent)}
                  dangerouslySetInnerHTML={{ __html: c }}
                />
              ))}
              <td />
            </tr>
          ))}
          <tr>
            <td className="tbl-add" colSpan={headers.length + 2} onClick={() => addRow(rows.length)}>
              <Icon name="plus" size={12} /><span style={{ marginLeft: 6 }}>Add row</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

// ---------- Tabs block (add/rename/remove + editable code) ----------
const TabsBlock = ({ block, update }) => {
  const tabs = block.tabs || [];
  const [active, setActive] = React.useState(tabs[0]?.id);
  const [editingLabel, setEditingLabel] = React.useState(null);

  React.useEffect(() => {
    if (!tabs.find((t) => t.id === active)) setActive(tabs[0]?.id);
  }, [tabs, active]);

  const cur = tabs.find((t) => t.id === active) || tabs[0];

  const updateTab = (id, patch) => {
    update({ tabs: tabs.map((t) => t.id === id ? { ...t, ...patch } : t) });
  };
  const addTab = () => {
    const nt = { id: uid("t"), label: "New tab", lang: "javascript", code: "// code here" };
    update({ tabs: [...tabs, nt] });
    setActive(nt.id);
  };
  const removeTab = (id) => {
    if (tabs.length <= 1) return;
    update({ tabs: tabs.filter((t) => t.id !== id) });
  };

  if (!cur) return null;

  return (
    <div className="blk-tabs">
      <div className="tabs-head">
        {tabs.map((t) => (
          <div key={t.id} className={`tab ${t.id === cur.id ? "active" : ""}`}
            onClick={() => setActive(t.id)}
            onDoubleClick={() => setEditingLabel(t.id)}
          >
            {editingLabel === t.id ? (
              <input
                autoFocus
                className="tab-rename"
                defaultValue={t.label}
                onBlur={(e) => { updateTab(t.id, { label: e.target.value || "Tab" }); setEditingLabel(null); }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") { updateTab(t.id, { label: e.target.value || "Tab" }); setEditingLabel(null); }
                  if (e.key === "Escape") setEditingLabel(null);
                }}
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <span onClick={(e) => { if (t.id === cur.id) { e.stopPropagation(); setEditingLabel(t.id); } }}>{t.label}</span>
            )}
            {tabs.length > 1 && (
              <button className="tab-close" onClick={(e) => { e.stopPropagation(); removeTab(t.id); }}>Ã—</button>
            )}
          </div>
        ))}
        <button className="tab-add" onClick={addTab} title="Add tab"><Icon name="plus" size={12} /></button>
      </div>
      <div className="tabs-body">
        <div className="blk-code" style={{ margin: 0 }}>
          <div className="code-head">
            <select
              className="lang"
              value={cur.lang}
              onChange={(e) => updateTab(cur.id, { lang: e.target.value })}
              style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", appearance: "none", padding: 0 }}
            >
              {["javascript","python","bash","typescript","json","rust","go","sql"].map((l) =>
                <option key={l} value={l}>{l}</option>
              )}
            </select>
            <span className="filename">example.{cur.lang === "python" ? "py" : cur.lang === "bash" ? "sh" : "js"}</span>
          </div>
          <SyntaxHighlight
            code={cur.code}
            lang={cur.lang}
            editable
            onChange={(c) => updateTab(cur.id, { code: c })}
          />
        </div>
      </div>
    </div>
  );
};

// ---------- Expandable block (editable title + body) ----------
const ExpandBlock = ({ block, update }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <div className={`blk-expand ${open ? "open" : ""}`}>
      <div className="expand-head">
        <span className="expand-chev" onClick={() => setOpen(!open)}><Icon name="chevronRight" size={14} /></span>
        <Editable tag="div" className="expand-title"
          html={block.title || ""}
          placeholder="Click to expand"
          onChange={(h) => update({ title: h })}
          onClick={(e) => e.stopPropagation()}
        />
      </div>
      {open && (
        <div className="expand-body">
          <Editable tag="div" className="blk-content"
            html={block.body || ""}
            placeholder="Hidden content â€” type anything here"
            onChange={(h) => update({ body: h })}
          />
        </div>
      )}
    </div>
  );
};

// ---------- Cards block (add/edit/remove) ----------
const CardsBlock = ({ block, update }) => {
  const items = block.items || [];
  const setItem = (i, patch) => {
    update({ items: items.map((it, idx) => idx === i ? { ...it, ...patch } : it) });
  };
  const addCard = () => update({ items: [...items, { ico: "book", title: "New card", desc: "Short description" }] });
  const removeCard = (i) => update({ items: items.filter((_, idx) => idx !== i) });

  const ICOS = ["book","api","folder","bolt","page","compass","send","rocket","code","globe"];

  return (
    <div className="blk-cards">
      {items.map((c, i) => (
        <div key={i} className="blk-card editable">
          <div className="card-tools">
            <button title="Remove card" onClick={() => removeCard(i)}><Icon name="trash" size={11} /></button>
          </div>
          <select
            className="card-ico card-ico-select"
            value={c.ico || "book"}
            onChange={(e) => setItem(i, { ico: e.target.value })}
            title="Icon"
          >
            {ICOS.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
          <div className="card-ico-preview"><Icon name={c.ico || "book"} size={16} /></div>
          <Editable tag="div" className="card-title"
            html={c.title}
            placeholder="Card title"
            onChange={(h) => setItem(i, { title: h })} />
          <Editable tag="div" className="card-desc"
            html={c.desc}
            placeholder="Short description"
            onChange={(h) => setItem(i, { desc: h })} />
          <div className="card-arrow">Learn more <Icon name="chevronRight" size={12} /></div>
        </div>
      ))}
      <button className="blk-card card-add" onClick={addCard}>
        <Icon name="plus" size={18} />
        <div style={{ fontSize: 12, marginTop: 6, color: "var(--text-muted)" }}>Add card</div>
      </button>
    </div>
  );
};

// ---------- API block (editable method/path/desc/params) ----------
const ApiBlock = ({ block, update }) => {
  const METHODS = ["GET","POST","PUT","PATCH","DELETE"];
  const params = block.params || [];
  const setParam = (i, patch) => {
    update({ params: params.map((p, idx) => idx === i ? { ...p, ...patch } : p) });
  };
  const addParam = () => update({ params: [...params, { name: "param", type: "string", desc: "Description" }] });
  const removeParam = (i) => update({ params: params.filter((_, idx) => idx !== i) });

  return (
    <div className="blk-api">
      <div className="api-head">
        <select
          className={`api-method ${block.method}`}
          value={block.method}
          onChange={(e) => update({ method: e.target.value })}
        >
          {METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <input
          className="api-path api-path-input"
          value={block.path || ""}
          onChange={(e) => update({ path: e.target.value })}
          placeholder="/v1/resource"
        />
        <button className="copy" style={{ color: "var(--text-faint)", fontSize: "10.5px" }}>try â†’</button>
      </div>
      <Editable tag="div" className="api-body blk-content"
        html={block.desc}
        placeholder="Describe the endpoint"
        onChange={(h) => update({ desc: h })}
      />
      <div className="api-params">
        <div>Parameter</div><div>Type</div><div>Description</div>
        {params.map((p, i) => (
          <React.Fragment key={i}>
            <div className="api-param-cell">
              <input
                value={p.name}
                onChange={(e) => setParam(i, { name: e.target.value })}
                placeholder="name"
              />
              <button className="api-param-rm" onClick={() => removeParam(i)} title="Remove"><Icon name="trash" size={10} /></button>
            </div>
            <div>
              <input
                className="param-type"
                value={p.type}
                onChange={(e) => setParam(i, { type: e.target.value })}
                placeholder="string"
              />
            </div>
            <div>
              <input
                className="param-desc"
                value={p.desc}
                onChange={(e) => setParam(i, { desc: e.target.value })}
                placeholder="What it does"
              />
            </div>
          </React.Fragment>
        ))}
      </div>
      <button className="api-add-param" onClick={addParam}>
        <Icon name="plus" size={12} /> <span style={{ marginLeft: 6 }}>Add parameter</span>
      </button>
    </div>
  );
};

const renderKatexMarkup = (value) => {
  const expression = String(value || "").trim();
  if (!expression || !window.katex || typeof window.katex.renderToString !== "function") return "";

  try {
    return window.katex.renderToString(expression, {
      throwOnError: false,
      displayMode: true,
    });
  } catch (error) {
    return "";
  }
};

const MathBlock = ({ block, update }) => {
  const expression = String(block.expr?.raw || "");
  const [previewMarkup, setPreviewMarkup] = React.useState(() => renderKatexMarkup(expression));

  React.useEffect(() => {
    setPreviewMarkup(renderKatexMarkup(expression));
  }, [expression]);

  return (
    <div className="blk-math-editor">
      <textarea
        className="math-input"
        value={expression}
        onChange={(event) => update({ expr: { ...(block.expr || {}), raw: event.target.value } })}
        placeholder="\\frac{a}{b} = c^2"
        spellCheck={false}
      />

      <div className="blk-math">
        {previewMarkup ? (
          <div className="math-preview" dangerouslySetInnerHTML={{ __html: previewMarkup }} />
        ) : (
          <div className="math-fallback">{expression || "Type a LaTeX expression to preview it here."}</div>
        )}
      </div>
    </div>
  );
};

const EmbedBlock = ({ block, update }) => {
  const normalizeUrl = (value) => {
    const raw = String(value || "").trim();
    if (!raw) return "";
    if (/^https?:\/\//i.test(raw)) return raw;
    return `https://${raw}`;
  };

  const parseYoutubeEmbed = (value) => {
    const url = normalizeUrl(value);
    if (!url) return null;

    try {
      const parsed = new URL(url);
      const host = parsed.hostname.replace(/^www\./i, "").toLowerCase();
      let id = "";

      if (host === "youtube.com" || host === "m.youtube.com") {
        id = parsed.searchParams.get("v") || "";
        if (!id && parsed.pathname.startsWith("/shorts/")) {
          id = parsed.pathname.split("/")[2] || "";
        }
      }

      if (host === "youtu.be") {
        id = parsed.pathname.split("/").filter(Boolean)[0] || "";
      }

      if (!id) return null;
      return `https://www.youtube.com/embed/${id}`;
    } catch (error) {
      return null;
    }
  };

  const parseDirectVideoUrl = (value, mimeType) => {
    const url = normalizeUrl(value);
    if (!url) return null;
    if (String(mimeType || "").startsWith("video/")) return url;

    try {
      const parsed = new URL(url);
      return /\.(mp4|webm|ogg)$/i.test(parsed.pathname) ? url : null;
    } catch (error) {
      return null;
    }
  };

  const parsePdfUrl = (value, mimeType) => {
    const url = normalizeUrl(value);
    if (!url) return null;
    if (String(mimeType || "") === "application/pdf") return url;

    try {
      const parsed = new URL(url);
      return /\.pdf$/i.test(parsed.pathname) ? url : null;
    } catch (error) {
      return null;
    }
  };

  const normalizedUrl = normalizeUrl(block.url || "");
  const youtubeEmbedUrl = parseYoutubeEmbed(block.url || "");
  const directVideoUrl = parseDirectVideoUrl(block.url || "", block.mimeType || "");
  const pdfUrl = parsePdfUrl(block.url || "", block.mimeType || "");

  return (
    <div className="blk-embed" style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "grid", gap: 8 }}>
        <input
          value={block.source || ""}
          onChange={(event) => update({ source: event.target.value })}
          placeholder="Source (YouTube, Loom, Figma...)"
          style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "7px 9px", fontSize: 12 }}
        />
        <input
          value={block.title || ""}
          onChange={(event) => update({ title: event.target.value })}
          placeholder="Embed title"
          style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "7px 9px", fontSize: 12 }}
        />
        <input
          value={block.url || ""}
          onChange={(event) => update({ url: event.target.value })}
          placeholder="Paste YouTube, video, PDF, or embed URL"
          style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "7px 9px", fontSize: 12 }}
        />
      </div>

      {youtubeEmbedUrl ? (
        <div style={{ position: "relative", width: "100%", paddingTop: "56.25%", borderRadius: 10, overflow: "hidden", border: "1px solid var(--border)", background: "var(--bg-subtle)" }}>
          <iframe
            src={youtubeEmbedUrl}
            title={block.title || "Embedded video"}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }}
          />
        </div>
      ) : directVideoUrl ? (
        <div style={{ position: "relative", width: "100%", borderRadius: 10, overflow: "hidden", border: "1px solid var(--border)", background: "var(--bg-subtle)" }}>
          <video
            src={directVideoUrl}
            title={block.title || "Embedded video"}
            controls
            playsInline
            preload="metadata"
            style={{ display: "block", width: "100%", maxHeight: 420, background: "oklch(18% 0.005 260)" }}
          />
        </div>
      ) : pdfUrl ? (
        <div style={{ position: "relative", width: "100%", minHeight: 420, borderRadius: 10, overflow: "hidden", border: "1px solid var(--border)", background: "var(--bg-subtle)" }}>
          <iframe
            src={pdfUrl}
            title={block.title || "Embedded document"}
            style={{ display: "block", width: "100%", height: 420, border: 0 }}
          />
        </div>
      ) : (
        <div className="embed-meta">
          <div className="embed-src">{block.source || "Embed"}</div>
          <div className="embed-title">{block.title || "Embedded content"}</div>
          <div className="embed-url">{block.url || "Paste a URL to preview"}</div>
        </div>
      )}

      {normalizedUrl ? (
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <a href={normalizedUrl} target="_blank" rel="noreferrer" className="tb-btn" title="Open" style={{ textDecoration: "none" }}>
            <Icon name="external" size={14} />
          </a>
        </div>
      ) : null}
    </div>
  );
};

const ChecklistBlock = ({ block, update }) => (
  <div className="blk-checklist">
    {block.items.map((item, i) => (
      <div key={item.id} className={`check-row ${item.done ? "done" : ""}`}>
        <div className={`check-box ${item.done ? "done" : ""}`}
          onClick={() => {
            const items = block.items.map((it, idx) => idx === i ? { ...it, done: !it.done } : it);
            update({ items });
          }}>
          {item.done && <Icon name="check" size={11} strokeWidth={3} />}
        </div>
        <Editable tag="div" className="check-text blk-content" html={item.text}
          placeholder="List item"
          onChange={(h) => {
            const items = block.items.map((it, idx) => idx === i ? { ...it, text: h } : it);
            update({ items });
          }} />
      </div>
    ))}
  </div>
);

// Registry for slash menu + rendering
const BLOCK_SPECS = [
  { kind: "h1",        group: "Structure", title: "Heading 1",     desc: "Big section title",              icon: "h1",       kbd: "/h1",    make: () => ({ kind: "h1", text: "" }) },
  { kind: "h2",        group: "Structure", title: "Heading 2",     desc: "Mid-level section heading",      icon: "h2",       kbd: "/h2",    make: () => ({ kind: "h2", text: "" }) },
  { kind: "h3",        group: "Structure", title: "Heading 3",     desc: "Subsection heading",             icon: "h3",       kbd: "/h3",    make: () => ({ kind: "h3", text: "" }) },
  { kind: "p",         group: "Text",      title: "Text",          desc: "Plain paragraph",                icon: "text",     kbd: "/text",  make: () => ({ kind: "p",  html: "" }) },
  { kind: "quote",     group: "Text",      title: "Quote",         desc: "Callout for emphasis or pull-quote", icon: "quote",kbd: "/quote", make: () => ({ kind: "quote", html: "" }) },
  { kind: "divider",   group: "Text",      title: "Divider",       desc: "A horizontal rule",              icon: "divider",  kbd: "/---",   make: () => ({ kind: "divider" }) },
  { kind: "code",      group: "Code",      title: "Code block",    desc: "Syntax-highlighted snippet",     icon: "code",     kbd: "/code",  make: () => ({ kind: "code", lang: "javascript", filename: "example.js", code: "// your code" }) },
  { kind: "api",       group: "Code",      title: "API endpoint",  desc: "Method, path, params",           icon: "api",      kbd: "/api",   make: () => ({ kind: "api", method: "GET", path: "/v1/resource", desc: "Describe the endpoint.", params: [{ name: "id", type: "string", desc: "The resource ID" }] }) },
  { kind: "callout",   group: "Media",     title: "Callout",        desc: "Info, warning, tip, or danger", icon: "callout",  kbd: "/note",  make: () => ({ kind: "callout", variant: "info", title: "Note", text: "" }) },
  { kind: "figure",    group: "Media",     title: "Image",          desc: "Upload or paste a URL",         icon: "image",    kbd: "/img",   make: () => ({ kind: "figure", alt: "", caption: "" }) },
  { kind: "table",     group: "Media",     title: "Table",          desc: "Grid of rows and columns",      icon: "table",    kbd: "/table", make: () => ({ kind: "table", headers: ["Column A","Column B","Column C"], rows: [["","",""],["","",""]] }) },
  { kind: "tabs",      group: "Media",     title: "Tabs",           desc: "Switch between code examples", icon: "tabs",     kbd: "/tabs",  make: () => ({ kind: "tabs", tabs: [{ id: uid("t"), label: "JavaScript", lang: "javascript", code: "// new" }, { id: uid("t"), label: "Python", lang: "python", code: "# new" }] }) },
  { kind: "expand",    group: "Media",     title: "Expandable",     desc: "Click-to-open section",         icon: "expand",   kbd: "/toggle",make: () => ({ kind: "expand", title: "Read more", body: "Hidden content" }) },
  { kind: "cards",     group: "Media",     title: "Cards grid",     desc: "Grid of linkable cards",        icon: "card",     kbd: "/cards", make: () => ({ kind: "cards", items: [{ ico: "book", title: "Card A", desc: "Short description" }, { ico: "api", title: "Card B", desc: "Short description" }] }) },
  { kind: "math",      group: "Advanced",  title: "Math block",     desc: "LaTeX-style formula",           icon: "math",     kbd: "/math",  make: () => ({ kind: "math", expr: { raw: "\\frac{a}{b} = c^2" } }) },
  { kind: "embed",     group: "Advanced",  title: "Embed",          desc: "YouTube, Figma, Loomâ€¦",         icon: "embed",    kbd: "/embed", make: () => ({ kind: "embed", source: "YouTube", title: "Embedded", url: "youtube.com/â€¦" }) },
  { kind: "checklist", group: "Advanced",  title: "Checklist",      desc: "Tracked tasks",                 icon: "checklist",kbd: "/todo",  make: () => ({ kind: "checklist", items: [{ id: uid("c"), text: "Task", done: false }] }) },
];

// Map kind â†’ component
const renderBlock = (block, update) => {
  switch (block.kind) {
    case "p":         return <ParagraphBlock block={block} update={update} />;
    case "h1":        return <HeadingBlock block={block} update={update} level={1} />;
    case "h2":        return <HeadingBlock block={block} update={update} level={2} />;
    case "h3":        return <HeadingBlock block={block} update={update} level={3} />;
    case "quote":     return <QuoteBlock block={block} update={update} />;
    case "divider":   return <DividerBlock />;
    case "code":      return <CodeBlock block={block} update={update} />;
    case "callout":   return <CalloutBlock block={block} update={update} />;
    case "figure":    return <FigureBlock block={block} update={update} />;
    case "table":     return <TableBlock block={block} update={update} />;
    case "tabs":      return <TabsBlock block={block} update={update} />;
    case "expand":    return <ExpandBlock block={block} update={update} />;
    case "cards":     return <CardsBlock block={block} update={update} />;
    case "api":       return <ApiBlock block={block} update={update} />;
    case "math":      return <MathBlock block={block} update={update} />;
    case "embed":     return <EmbedBlock block={block} update={update} />;
    case "checklist": return <ChecklistBlock block={block} update={update} />;
    default: return <div style={{ color: "var(--text-faint)" }}>Unknown block: {block.kind}</div>;
  }
};

Object.assign(window, { BLOCK_SPECS, renderBlock, Editable, SyntaxHighlight });
// ---------- Sidebar ----------
const TreeNode = ({ node, depth = 0, activeId, onSelect, onToggle, onRename, onDelete, onAdd, onDrop, expandedMap, dragId, setDragId, dropTarget, setDropTarget }) => {
  const expanded = expandedMap[node.id] !== undefined ? expandedMap[node.id] : !!node.expanded;
  const hasChildren = node.children && node.children.length > 0;
  const [editing, setEditing] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  React.useEffect(() => {
    if (!menuOpen) return;
    const onClick = () => setMenuOpen(false);
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, [menuOpen]);

  const active = activeId === node.id;
  const isDragging = dragId === node.id;
  const isTarget = dropTarget?.id === node.id;
  const targetPos = isTarget ? dropTarget.pos : null;

  const onDragOver = (e) => {
    if (!dragId || dragId === node.id) return;
    e.preventDefault();
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const y = e.clientY - rect.top;
    let pos;
    if (y < rect.height * 0.3) pos = "before";
    else if (y > rect.height * 0.7) pos = "after";
    else pos = "inside";
    setDropTarget({ id: node.id, pos });
  };

  return (
    <>
      <div
        className={`tree-item ${active ? "active" : ""} ${isDragging ? "dragging" : ""}`}
        style={{
          paddingLeft: 6 + depth * 14,
          boxShadow:
            targetPos === "before" ? "inset 0 2px 0 var(--accent)" :
            targetPos === "after"  ? "inset 0 -2px 0 var(--accent)" :
            targetPos === "inside" ? "inset 0 0 0 1.5px var(--accent)" :
            undefined,
          background: targetPos === "inside" ? "var(--accent-soft)" : undefined,
          opacity: isDragging ? 0.4 : 1,
        }}
        onClick={() => onSelect(node.id)}
        draggable
        onDragStart={(e) => {
          setDragId(node.id);
          e.dataTransfer.effectAllowed = "move";
          e.dataTransfer.setData("text/x-page", node.id);
        }}
        onDragEnd={() => { setDragId(null); setDropTarget(null); }}
        onDragOver={onDragOver}
        onDragLeave={(e) => {
          // only clear if the pointer actually left the row
          if (!e.currentTarget.contains(e.relatedTarget)) {
            if (dropTarget?.id === node.id) setDropTarget(null);
          }
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (dragId && dragId !== node.id && dropTarget?.id === node.id) {
            onDrop(dragId, node.id, dropTarget.pos);
          }
          setDragId(null);
          setDropTarget(null);
        }}
      >
        <span
          className={`tree-chevron ${hasChildren ? "" : "leaf"} ${expanded ? "expanded" : ""}`}
          onClick={(e) => { e.stopPropagation(); onToggle(node.id); }}
        >
          <Icon name="chevronRight" size={12} />
        </span>
        <span className="tree-icon"><Icon name={node.icon || "page"} size={13} /></span>
        {editing ? (
          <input
            ref={inputRef}
            className="tree-label editing"
            defaultValue={node.title}
            onBlur={(e) => { onRename(node.id, e.target.value || node.title); setEditing(false); }}
            onKeyDown={(e) => {
              if (e.key === "Enter") { onRename(node.id, e.target.value || node.title); setEditing(false); }
              if (e.key === "Escape") setEditing(false);
            }}
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span className="tree-label" onDoubleClick={() => setEditing(true)}>{node.title}</span>
        )}
        <span className="tree-actions" onClick={(e) => e.stopPropagation()}>
          <button className="tree-action" title="Add page" onClick={(e) => { e.stopPropagation(); onAdd(node.id); }}><Icon name="plus" size={12} /></button>
          <button className="tree-action" title="More" onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}><Icon name="ellipsis" size={12} /></button>
          {menuOpen && (
            <div className="tree-menu" onClick={(e) => e.stopPropagation()}>
              <button className="tree-menu-item"
                onClick={() => { setEditing(true); setMenuOpen(false); }}>
                <Icon name="rename" size={13} /><span>Rename</span>
              </button>
              <button className="tree-menu-item"
                onClick={() => { onAdd(node.id); setMenuOpen(false); }}>
                <Icon name="plus" size={13} /><span>Add subpage</span>
              </button>
              <div className="tree-menu-divider" />
              <button className="tree-menu-item danger"
                onClick={() => { onDelete(node.id); setMenuOpen(false); }}>
                <Icon name="trash" size={13} /><span>Delete</span>
              </button>
            </div>
          )}
        </span>
      </div>
      {hasChildren && expanded && (
        <div className="tree-children">
          {node.children.map((c) => (
            <TreeNode
              key={c.id}
              node={c}
              depth={depth + 1}
              activeId={activeId}
              onSelect={onSelect}
              onToggle={onToggle}
              onRename={onRename}
              onDelete={onDelete}
              onAdd={onAdd}
              onDrop={onDrop}
              expandedMap={expandedMap}
              dragId={dragId}
              setDragId={setDragId}
              dropTarget={dropTarget}
              setDropTarget={setDropTarget}
            />
          ))}
        </div>
      )}
    </>
  );
};

const Sidebar = ({ spaces, activeSpaceId, onSpace, onAddSpace, pages, activePageId, onSelectPage, onAddPage, onRenamePage, onDeletePage, onMovePage }) => {
  const [expanded, setExpanded] = React.useState(() =>
    Object.fromEntries(pages.filter((p) => p.expanded).map((p) => [p.id, true]))
  );
  const [query, setQuery] = React.useState("");
  const [dragId, setDragId] = React.useState(null);
  const [dropTarget, setDropTarget] = React.useState(null);
  const [spaceOpen, setSpaceOpen] = React.useState(false);
  const [creating, setCreating] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const pickerRef = React.useRef(null);

  React.useEffect(() => {
    if (!spaceOpen) return;
    const onDoc = (e) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target)) {
        setSpaceOpen(false);
        setCreating(false);
        setNewName("");
      }
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [spaceOpen]);

  const activeSpace = spaces.find((s) => s.id === activeSpaceId) || spaces[0];

  const commitNewSpace = () => {
    const v = newName.trim();
    if (!v) { setCreating(false); return; }
    onAddSpace(v);
    setNewName("");
    setCreating(false);
    setSpaceOpen(false);
  };

  const filter = (list) => {
    if (!query) return list;
    const q = query.toLowerCase();
    const walk = (node) => {
      const selfMatch = node.title.toLowerCase().includes(q);
      const kids = (node.children || []).map(walk).filter(Boolean);
      if (selfMatch || kids.length) return { ...node, children: kids };
      return null;
    };
    return list.map(walk).filter(Boolean);
  };

  const filtered = filter(pages);

  return (
    <aside className="sidebar">
      <div className="sidebar-spaces" ref={pickerRef}>
        <button
          className={`space-picker ${spaceOpen ? "open" : ""}`}
          onClick={() => setSpaceOpen((v) => !v)}
          title="Switch space"
        >
          <span className="space-icon" style={{ background: activeSpace.color }}>{activeSpace.icon}</span>
          <span className="space-picker-name">{activeSpace.name}</span>
          <span className="count">{activeSpace.count}</span>
          <Icon name="chevronDown" size={12} />
        </button>

        {spaceOpen && (
          <div className="space-menu" role="menu">
            <div className="space-menu-label">Spaces</div>
            {spaces.map((sp) => (
              <div
                key={sp.id}
                className={`space-row ${sp.id === activeSpaceId ? "active" : ""}`}
                onClick={() => { onSpace(sp.id); setSpaceOpen(false); }}
                role="menuitem"
              >
                <span className="space-icon" style={{ background: sp.color }}>{sp.icon}</span>
                <span>{sp.name}</span>
                <span className="count">{sp.count}</span>
                {sp.id === activeSpaceId && <Icon name="check" size={12} />}
              </div>
            ))}
            <div className="space-menu-divider" />
            {creating ? (
              <div className="space-row creating">
                <span className="space-icon" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                  {(newName.trim()[0] || "â€¢").toUpperCase()}
                </span>
                <input
                  autoFocus
                  className="space-new-input"
                  placeholder="Space name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitNewSpace();
                    if (e.key === "Escape") { setCreating(false); setNewName(""); }
                  }}
                  onBlur={commitNewSpace}
                />
              </div>
            ) : (
              <div
                className="space-row new"
                onClick={() => setCreating(true)}
                role="menuitem"
              >
                <span className="space-icon" style={{ background: "var(--bg-subtle)", border: "1px dashed var(--border-strong)", color: "var(--text-faint)" }}>+</span>
                <span>New space</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="sidebar-section-label">
        <span>Pages</span>
        <button title="Add top-level page" onClick={() => onAddPage(null)}><Icon name="plus" size={12} /></button>
      </div>

      <div style={{ padding: "0 10px 8px" }}>
        <div className="tb-search" style={{ width: "100%" }}>
          <Icon name="search" size={13} />
          <input
            style={{ background: "transparent", border: 0, outline: 0, color: "var(--text)", flex: 1, fontSize: 12.5 }}
            placeholder="Filter pagesâ€¦"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>

      <nav
        className="tree"
        onDragOver={(e) => { if (dragId) e.preventDefault(); }}
      >
        {filtered.map((node) => (
          <TreeNode
            key={node.id}
            node={node}
            activeId={activePageId}
            onSelect={onSelectPage}
            onToggle={(id) => setExpanded((m) => ({ ...m, [id]: !(m[id] !== undefined ? m[id] : pages.find(p=>p.id===id)?.expanded) }))}
            onRename={onRenamePage}
            onAdd={onAddPage}
            onDelete={onDeletePage}
            onDrop={(fromId, toId, pos) => {
              onMovePage(fromId, toId, pos);
              if (pos === "inside") {
                setExpanded((m) => ({ ...m, [toId]: true }));
              }
            }}
            expandedMap={expanded}
            dragId={dragId}
            setDragId={setDragId}
            dropTarget={dropTarget}
            setDropTarget={setDropTarget}
          />
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="sf-row"><Icon name="globe" size={14} /><span>Share site</span></div>
        <div className="sf-row"><Icon name="settings" size={14} /><span>Settings</span></div>
      </div>
    </aside>
  );
};

window.Sidebar = Sidebar;
// ---------- Editor canvas ----------
const BlockRow = ({ block, index, update, onAddAfter, onDelete, onMove, onOpenSlash, onSelectText, dragState, setDragState, selected, onSelectBlock }) => {
  const rowRef = React.useRef(null);

  return (
    <div
      ref={rowRef}
      className={`block-row ${dragState.dragging === block.id ? "dragging" : ""} ${dragState.over === block.id ? "drag-over" : ""} ${selected ? "multi-selected" : ""}`}
      data-block-id={block.id}
      onDragOver={(e) => {
        if (dragState.dragging && dragState.dragging !== block.id) {
          e.preventDefault();
          setDragState((s) => ({ ...s, over: block.id }));
        }
      }}
      onDragLeave={() => setDragState((s) => (s.over === block.id ? { ...s, over: null } : s))}
      onDrop={(e) => {
        e.preventDefault();
        if (dragState.dragging && dragState.dragging !== block.id) {
          onMove(dragState.dragging, block.id);
        }
        setDragState({ dragging: null, over: null });
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          const target = e.target;
          const tagName = target?.tagName;
          const inFormField = tagName === "INPUT" || tagName === "TEXTAREA";
          const inContent = !!target?.closest?.(".blk-content");

          if (!inFormField && inContent && e.shiftKey) {
            e.preventDefault();
            onAddAfter({ kind: "p", html: "" });

            requestAnimationFrame(() => {
              const current = rowRef.current;
              const next = current?.nextElementSibling;
              const editable = next?.querySelector?.(".blk-content");

              if (!editable) return;

              editable.focus();

              const sel = window.getSelection();
              if (!sel) return;

              const range = document.createRange();
              range.selectNodeContents(editable);
              range.collapse(true);
              sel.removeAllRanges();
              sel.addRange(range);
            });
          }

          return;
        }

        if (e.key === "/" && ["p","h1","h2","h3"].includes(block.kind)) {
          const text = e.currentTarget.querySelector(".blk-content")?.textContent || "";
          if (text.trim() === "") {
            e.preventDefault();
            const r = rowRef.current.getBoundingClientRect();
            const scrollEl = rowRef.current.closest(".editor-wrap");
            const sr = scrollEl.getBoundingClientRect();
            onOpenSlash({
              blockId: block.id,
              x: r.left - sr.left,
              y: r.top - sr.top + r.height + (scrollEl.scrollTop),
            });
          }
        }
        if (e.key === "Backspace") {
          const text = e.currentTarget.querySelector(".blk-content")?.textContent || "";
          if (text === "" && ["p","h1","h2","h3"].includes(block.kind)) {
            e.preventDefault();
            onDelete(block.id);
          }
        }
      }}
      onMouseUp={() => {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed) { onSelectText(null); return; }
        const range = sel.getRangeAt(0);
        const contained = rowRef.current?.contains(range.commonAncestorContainer);
        if (!contained) return;
        const rect = range.getBoundingClientRect();
        const scrollEl = rowRef.current.closest(".editor-wrap");
        const sr = scrollEl.getBoundingClientRect();
        onSelectText({
          blockId: block.id,
          x: rect.left + rect.width / 2 - sr.left,
          y: rect.top - sr.top + scrollEl.scrollTop,
        });
      }}
    >
      <div className="block-gutter">
        <button
          className="gutter-btn"
          title="Add block below"
          onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            const scrollEl = rowRef.current.closest(".editor-wrap");
            const sr = scrollEl.getBoundingClientRect();
            onOpenSlash({
              blockId: block.id,
              x: r.left - sr.left + 30,
              y: r.top - sr.top + r.height + scrollEl.scrollTop,
              below: true,
            });
          }}
        >
          <Icon name="plus" size={14} />
        </button>
        <button
          className="gutter-btn drag"
          draggable
          title="Drag to reorder Â· click to select"
          onClick={(e) => {
            e.stopPropagation();
            onSelectBlock(block.id, { shift: e.shiftKey, meta: e.metaKey || e.ctrlKey });
          }}
          onDragStart={(e) => {
            setDragState({ dragging: block.id, over: null });
            e.dataTransfer.setData("text/x-block", block.id);
            e.dataTransfer.effectAllowed = "move";
          }}
          onDragEnd={() => setDragState({ dragging: null, over: null })}
        >
          <Icon name="grip" size={14} />
        </button>
      </div>

      {renderBlock(block, update)}
    </div>
  );
};

// ---------- Inline toolbar with link bubble editor ----------
const InlineToolbar = ({ position, onClose, onComment, savedRange, setSavedRange }) => {
  const toolbarRef = React.useRef(null);
  const [linkEditor, setLinkEditor] = React.useState(null); // { href }

  const exec = (cmd, val) => {
    restoreRange();
    document.execCommand(cmd, false, val);
  };

  const saveRange = () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount) {
      setSavedRange(sel.getRangeAt(0).cloneRange());
    }
  };
  const restoreRange = () => {
    if (savedRange) {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(savedRange);
    }
  };

  React.useEffect(() => {
    const onDown = (e) => {
      if (toolbarRef.current && !toolbarRef.current.contains(e.target)) {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed) onClose();
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [onClose]);

  if (!position) return null;

  const openLinkEditor = () => {
    saveRange();
    // Pre-fill if the selection contains a link
    const sel = window.getSelection();
    let href = "";
    if (sel && sel.rangeCount) {
      let node = sel.getRangeAt(0).commonAncestorContainer;
      if (node.nodeType === 3) node = node.parentElement;
      const a = node?.closest?.("a");
      if (a) href = a.getAttribute("href") || "";
    }
    setLinkEditor({ href });
  };

  const applyLink = (href) => {
    restoreRange();
    if (href) {
      document.execCommand("createLink", false, href);
      // After createLink, find inserted <a> and set target
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        let node = sel.getRangeAt(0).commonAncestorContainer;
        if (node.nodeType === 3) node = node.parentElement;
        const a = node?.closest?.("a");
        if (a) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); }
      }
    } else {
      document.execCommand("unlink");
    }
    setLinkEditor(null);
    onClose();
  };

  return (
    <div
      ref={toolbarRef}
      className="inline-toolbar"
      style={{ left: position.x, top: position.y }}
      onMouseDown={(e) => e.preventDefault()}
    >
      {!linkEditor && (
        <>
          <button className="itb-btn" onClick={() => exec("bold")}><Icon name="bold" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("italic")}><Icon name="italic" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("underline")}><Icon name="underline" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("strikeThrough")}><Icon name="strike" size={13} /></button>
          <div className="itb-sep" />
          <button className="itb-btn" onClick={() => {
            const html = document.getSelection()?.toString() || "";
            exec("insertHTML", `<code style="background:var(--bg-subtle);padding:1px 5px;border-radius:3px;font-family:var(--font-mono);font-size:0.88em;">${html}</code>`);
          }}><Icon name="code" size={13} /></button>
          <button className="itb-btn" onClick={openLinkEditor}><Icon name="link" size={13} /></button>
          <div className="itb-sep" />
          <button className="itb-btn" title="Comment" onClick={onComment}><Icon name="comment" size={13} /></button>
        </>
      )}
      {linkEditor && (
        <div className="link-bubble" onMouseDown={(e) => e.stopPropagation()}>
          <Icon name="link" size={13} />
          <input
            autoFocus
            placeholder="Paste URL, or typeâ€¦"
            defaultValue={linkEditor.href}
            onKeyDown={(e) => {
              if (e.key === "Enter") { e.preventDefault(); applyLink(e.target.value.trim()); }
              if (e.key === "Escape") setLinkEditor(null);
            }}
            onMouseDown={(e) => e.stopPropagation()}
          />
          <button className="itb-btn" title="Apply" onClick={(e) => {
            const inp = e.currentTarget.parentElement.querySelector("input");
            applyLink(inp.value.trim());
          }}><Icon name="check" size={13} /></button>
          <button className="itb-btn" title="Remove link" onClick={() => applyLink("")}>
            <Icon name="trash" size={13} />
          </button>
        </div>
      )}
    </div>
  );
};

const SlashMenu = ({ position, onPick, onClose }) => {
  const [q, setQ] = React.useState("");
  const [focus, setFocus] = React.useState(0);
  const inputRef = React.useRef(null);

  React.useEffect(() => { inputRef.current?.focus(); }, []);

  const filtered = React.useMemo(() => {
    const ql = q.toLowerCase();
    return BLOCK_SPECS.filter((b) =>
      !q || b.title.toLowerCase().includes(ql) || b.kbd.includes(ql) || b.kind.includes(ql)
    );
  }, [q]);

  React.useEffect(() => { setFocus(0); }, [q]);

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); }
      if (e.key === "ArrowDown") { e.preventDefault(); setFocus((f) => Math.min(filtered.length - 1, f + 1)); }
      if (e.key === "ArrowUp") { e.preventDefault(); setFocus((f) => Math.max(0, f - 1)); }
      if (e.key === "Enter") { e.preventDefault(); if (filtered[focus]) onPick(filtered[focus]); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [focus, filtered, onPick, onClose]);

  if (!position) return null;

  const groups = filtered.reduce((acc, b) => {
    (acc[b.group] = acc[b.group] || []).push(b);
    return acc;
  }, {});

  let flatIdx = -1;
  return (
    <div className="slash-menu" style={{ left: position.x, top: position.y + 6 }}>
      <div style={{ padding: 6, borderBottom: "1px solid var(--border)" }}>
        <input
          ref={inputRef}
          style={{ width: "100%", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 4, padding: "6px 8px", outline: "none", fontSize: 12.5 }}
          placeholder="Filter blocksâ€¦"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>
      {Object.entries(groups).map(([group, items]) => (
        <div key={group}>
          <div className="slash-group-label">{group}</div>
          {items.map((b) => {
            flatIdx++;
            const focused = flatIdx === focus;
            return (
              <div
                key={b.kind}
                className={`slash-item ${focused ? "focused" : ""}`}
                onMouseEnter={() => setFocus(flatIdx)}
                onClick={() => onPick(b)}
              >
                <div className="slash-ico"><Icon name={b.icon} size={16} /></div>
                <div className="slash-meta">
                  <div className="title">{b.title}</div>
                  <div className="desc">{b.desc}</div>
                </div>
                <div className="slash-kbd">{b.kbd}</div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};

// ---------- Selection action bar ----------
const SelectionBar = ({ count, onDuplicate, onDelete, onCopy, onClear, position = null }) => (
  <div className="selection-bar" style={position ? { top: position.top, left: position.left } : undefined}>
    <span className="sb-count">{count} selected</span>
    <button onClick={onDuplicate}><Icon name="duplicate" size={12} /> Duplicate</button>
    <button onClick={onCopy}><Icon name="copy" size={12} /> Copy</button>
    <button onClick={onDelete} className="danger"><Icon name="trash" size={12} /> Delete</button>
    <button className="close" onClick={onClear}>Ã—</button>
  </div>
);

const Editor = ({
  page, onUpdate, onAddComment, onActiveHeadingChange, jumpToBlockId, clearJump,
  selectedBlocks, setSelectedBlocks,
  clipboard, setClipboard,
  toast, setToast,
}) => {
  const [slash, setSlash] = React.useState(null);
  const [selection, setSelection] = React.useState(null);
  const [dragState, setDragState] = React.useState({ dragging: null, over: null });
  const [savedRange, setSavedRange] = React.useState(null);
  const [selectionBarPosition, setSelectionBarPosition] = React.useState(null);
  const wrapRef = React.useRef(null);

  React.useEffect(() => {
    if (wrapRef.current) wrapRef.current.scrollTop = 0;
    setSlash(null); setSelection(null);
  }, [page.title, page.blocks?.[0]?.id]);

  // Active heading tracking
  React.useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap || !onActiveHeadingChange) return;
    const calc = () => {
      const headings = page.blocks.filter((b) => ["h1","h2","h3"].includes(b.kind));
      if (headings.length === 0) { onActiveHeadingChange(null); return; }
      const wrapRect = wrap.getBoundingClientRect();
      const threshold = wrapRect.top + 120;
      let activeId = headings[0].id;
      for (const h of headings) {
        const el = wrap.querySelector(`[data-block-id="${h.id}"]`);
        if (!el) continue;
        const r = el.getBoundingClientRect();
        if (r.top <= threshold) activeId = h.id;
        else break;
      }
      onActiveHeadingChange(activeId);
    };
    calc();
    wrap.addEventListener("scroll", calc, { passive: true });
    return () => wrap.removeEventListener("scroll", calc);
  }, [page.blocks, onActiveHeadingChange]);

  React.useEffect(() => {
    if (!jumpToBlockId || !wrapRef.current) return;
    const el = wrapRef.current.querySelector(`[data-block-id="${jumpToBlockId}"]`);
    if (el) {
      const wrap = wrapRef.current;
      const y = el.getBoundingClientRect().top - wrap.getBoundingClientRect().top + wrap.scrollTop - 24;
      wrap.scrollTo({ top: y, behavior: "smooth" });
    }
    clearJump && clearJump();
  }, [jumpToBlockId]);

  React.useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap || selectedBlocks.length === 0) {
      setSelectionBarPosition(null);
      return undefined;
    }

    let frame = 0;

    const syncSelectionBarPosition = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const elements = selectedBlocks
          .map((id) => wrap.querySelector(`[data-block-id="${id}"]`))
          .filter(Boolean);

        if (!elements.length) {
          setSelectionBarPosition(null);
          return;
        }

        const wrapRect = wrap.getBoundingClientRect();
        let minTop = Number.POSITIVE_INFINITY;
        let minLeft = Number.POSITIVE_INFINITY;
        let maxRight = Number.NEGATIVE_INFINITY;

        elements.forEach((element) => {
          const rect = element.getBoundingClientRect();
          minTop = Math.min(minTop, rect.top);
          minLeft = Math.min(minLeft, rect.left);
          maxRight = Math.max(maxRight, rect.right);
        });

        const anchorTop = minTop - wrapRect.top + wrap.scrollTop;
        const anchorLeft = (minLeft + maxRight) / 2 - wrapRect.left + wrap.scrollLeft;
        const minLeftBound = wrap.scrollLeft + 108;
        const maxLeftBound = wrap.scrollLeft + wrap.clientWidth - 108;

        setSelectionBarPosition({
          top: Math.max(wrap.scrollTop + 24, anchorTop),
          left: Math.min(maxLeftBound, Math.max(minLeftBound, anchorLeft)),
        });
      });
    };

    syncSelectionBarPosition();
    wrap.addEventListener("scroll", syncSelectionBarPosition, { passive: true });
    window.addEventListener("resize", syncSelectionBarPosition);

    return () => {
      cancelAnimationFrame(frame);
      wrap.removeEventListener("scroll", syncSelectionBarPosition);
      window.removeEventListener("resize", syncSelectionBarPosition);
    };
  }, [selectedBlocks, page.blocks]);

  const updateBlock = (blockId, patch) => {
    const blocks = page.blocks.map((b) => b.id === blockId ? { ...b, ...patch } : b);
    onUpdate({ ...page, blocks });
  };

  const addAfter = (blockId, newBlock) => {
    const i = page.blocks.findIndex((b) => b.id === blockId);
    const blocks = [...page.blocks];
    blocks.splice(i + 1, 0, { id: uid("b"), ...newBlock });
    onUpdate({ ...page, blocks });
  };

  const replaceBlock = (blockId, newBlock) => {
    const blocks = page.blocks.map((b) => b.id === blockId ? { id: b.id, ...newBlock } : b);
    onUpdate({ ...page, blocks });
  };

  const deleteBlock = (blockId) => {
    if (page.blocks.length <= 1) return;
    const blocks = page.blocks.filter((b) => b.id !== blockId);
    onUpdate({ ...page, blocks });
  };

  const moveBlock = (fromId, toId) => {
    const fromIdx = page.blocks.findIndex((b) => b.id === fromId);
    const toIdx = page.blocks.findIndex((b) => b.id === toId);
    if (fromIdx < 0 || toIdx < 0) return;
    const blocks = [...page.blocks];
    const [m] = blocks.splice(fromIdx, 1);
    blocks.splice(toIdx, 0, m);
    onUpdate({ ...page, blocks });
  };

  // Multi-select helpers
  const toggleBlockSelect = (id, { shift, meta }) => {
    setSelectedBlocks((prev) => {
      if (shift && prev.length > 0) {
        // range-select between last selected and this
        const ids = page.blocks.map((b) => b.id);
        const from = ids.indexOf(prev[prev.length - 1]);
        const to = ids.indexOf(id);
        if (from < 0 || to < 0) return [id];
        const [a, b] = from < to ? [from, to] : [to, from];
        return ids.slice(a, b + 1);
      }
      if (meta) {
        return prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      }
      return prev.length === 1 && prev[0] === id ? [] : [id];
    });
  };

  // Deep clone helper (regenerate ids)
  const cloneBlock = (b) => {
    const c = JSON.parse(JSON.stringify(b));
    c.id = uid("b");
    if (c.items) c.items = c.items.map((it) => it.id ? { ...it, id: uid("c") } : it);
    if (c.tabs)  c.tabs  = c.tabs.map((t) => ({ ...t, id: uid("t") }));
    return c;
  };

  const duplicateSelected = () => {
    if (selectedBlocks.length === 0) return;
    const lastId = selectedBlocks[selectedBlocks.length - 1];
    const lastIdx = page.blocks.findIndex((b) => b.id === lastId);
    const selBlocks = selectedBlocks
      .map((id) => page.blocks.find((b) => b.id === id))
      .filter(Boolean)
      .map(cloneBlock);
    const blocks = [...page.blocks];
    blocks.splice(lastIdx + 1, 0, ...selBlocks);
    onUpdate({ ...page, blocks });
    setSelectedBlocks(selBlocks.map((b) => b.id));
  };
  const deleteSelected = () => {
    if (selectedBlocks.length === 0) return;
    if (page.blocks.length <= selectedBlocks.length) return;
    const blocks = page.blocks.filter((b) => !selectedBlocks.includes(b.id));
    onUpdate({ ...page, blocks });
    setSelectedBlocks([]);
  };
  const copySelected = () => {
    if (selectedBlocks.length === 0) return;
    const selBlocks = selectedBlocks
      .map((id) => page.blocks.find((b) => b.id === id))
      .filter(Boolean);
    setClipboard(selBlocks);
    try {
      navigator.clipboard?.writeText(`__LEXICON_BLOCKS__${JSON.stringify(selBlocks)}`);
    } catch {}
    setToast && setToast(`Copied ${selBlocks.length} block${selBlocks.length===1?"":"s"}`);
    setTimeout(() => setToast && setToast(null), 1600);
  };
  const pasteBlocks = () => {
    if (!clipboard || clipboard.length === 0) return;
    const insertAfter = selectedBlocks.length
      ? page.blocks.findIndex((b) => b.id === selectedBlocks[selectedBlocks.length - 1])
      : page.blocks.length - 1;
    const nb = clipboard.map(cloneBlock);
    const blocks = [...page.blocks];
    blocks.splice(insertAfter + 1, 0, ...nb);
    onUpdate({ ...page, blocks });
    setSelectedBlocks(nb.map((b) => b.id));
  };

  // Keyboard shortcuts for selection / paste
  React.useEffect(() => {
    const onKey = (e) => {
      const active = document.activeElement;
      const inEditable = active && (active.isContentEditable || active.tagName === "INPUT" || active.tagName === "TEXTAREA");

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d" && selectedBlocks.length) {
        e.preventDefault(); duplicateSelected(); return;
      }
      if ((e.key === "Delete" || e.key === "Backspace") && selectedBlocks.length && !inEditable) {
        e.preventDefault(); deleteSelected(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "c" && selectedBlocks.length && !inEditable) {
        e.preventDefault(); copySelected(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "v" && !inEditable && clipboard) {
        e.preventDefault(); pasteBlocks(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "a" && !inEditable) {
        e.preventDefault();
        setSelectedBlocks(page.blocks.map((b) => b.id));
      }
      if (e.key === "Escape" && selectedBlocks.length) {
        setSelectedBlocks([]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedBlocks, clipboard, page.blocks]);

  // Listen for external paste (from OS clipboard containing __LEXICON_BLOCKS__)
  React.useEffect(() => {
    const onPaste = (e) => {
      const active = document.activeElement;
      const inEditable = active && (active.isContentEditable || active.tagName === "INPUT" || active.tagName === "TEXTAREA");
      if (inEditable) return;
      const text = e.clipboardData?.getData("text/plain") || "";
      if (text.startsWith("__LEXICON_BLOCKS__")) {
        e.preventDefault();
        try {
          const arr = JSON.parse(text.slice("__LEXICON_BLOCKS__".length));
          setClipboard(arr);
          setTimeout(pasteBlocks, 0);
        } catch {}
      }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [selectedBlocks, page.blocks]);

  const onPickBlock = (spec) => {
    if (!slash) return;
    const newBlock = spec.make();
    if (slash.below) addAfter(slash.blockId, newBlock);
    else replaceBlock(slash.blockId, newBlock);
    setSlash(null);
  };

  return (
    <div className="editor-wrap" ref={wrapRef}
      onMouseDown={(e) => {
        // click on blank area clears multi-selection
        if (e.target.classList?.contains("editor-wrap") || e.target.classList?.contains("editor-body") || e.target.classList?.contains("editor-hero")) {
          if (selectedBlocks.length) setSelectedBlocks([]);
        }
      }}
    >
      <div className="editor-hero">
        <div className="hero-meta">
          <span className="tag">{page.updated ? `Updated ${page.updated}` : "Draft"}</span>
          <span className="dot" />
          <span>{page.readTime || "â€”"}</span>
          <span className="dot" />
          <span>en Â· english</span>
        </div>

        <Editable
          tag="h1"
          className="doc-title"
          html={page.title}
          placeholder="Untitled"
          onChange={(h) => onUpdate({ ...page, title: h })}
        />
        <Editable
          tag="p"
          className="doc-subtitle"
          html={page.subtitle}
          placeholder="Add a short subtitle or descriptionâ€¦"
          onChange={(h) => onUpdate({ ...page, subtitle: h })}
        />

        <div className="hero-byline">
          <div className="avatar" style={{ background: page.author.color }}>{page.author.initials}</div>
          <div className="by-meta">
            <span className="by-name">{page.author.name}</span>
            <span className="by-sub">{page.author.role}</span>
          </div>
          <div className="right">
            <div className="item"><Icon name="eye" size={12} /> 1,284</div>
            <div className="item"><Icon name="comment" size={12} /> 3</div>
            <div className="avatars">
              {page.collaborators.map((c, i) => (
                <div key={i} className="avatar" style={{ background: c.color }}>{c.initials}</div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="editor-body">
        {page.blocks.map((b, i) => (
          <BlockRow
            key={b.id}
            block={b}
            index={i}
            update={(patch) => updateBlock(b.id, patch)}
            onAddAfter={(nb) => addAfter(b.id, nb)}
            onDelete={deleteBlock}
            onMove={moveBlock}
            onOpenSlash={setSlash}
            onSelectText={setSelection}
            dragState={dragState}
            setDragState={setDragState}
            selected={selectedBlocks.includes(b.id)}
            onSelectBlock={toggleBlockSelect}
          />
        ))}
        <div style={{ height: 60, display: "flex", alignItems: "center", color: "var(--text-faint)", fontSize: 13, cursor: "text", paddingLeft: 2 }}
          onClick={(e) => {
            const last = page.blocks[page.blocks.length - 1];
            if (last) {
              const r = e.currentTarget.getBoundingClientRect();
              const scrollEl = e.currentTarget.closest(".editor-wrap");
              const sr = scrollEl.getBoundingClientRect();
              setSlash({ blockId: last.id, x: 0, y: r.top - sr.top + scrollEl.scrollTop, below: true });
            }
          }}
        >
          <span style={{ opacity: 0.6 }}>Click to add a block, or press <kbd style={{ fontFamily: "var(--font-mono)", fontSize: 11, border: "1px solid var(--border)", padding: "1px 4px", borderRadius: 3 }}>/</kbd> anywhere</span>
        </div>
      </div>

      <InlineToolbar
        position={selection}
        onClose={() => setSelection(null)}
        onComment={() => {
          const selectedText = (window.getSelection()?.toString() || "").trim();
          onAddComment(selection?.blockId, selectedText);
          setSelection(null);
        }}
        savedRange={savedRange}
        setSavedRange={setSavedRange}
      />

      <SlashMenu
        position={slash}
        onPick={onPickBlock}
        onClose={() => setSlash(null)}
      />

      {selectedBlocks.length > 0 && (
        <SelectionBar
          count={selectedBlocks.length}
          onDuplicate={duplicateSelected}
          onDelete={deleteSelected}
          onCopy={copySelected}
          position={selectionBarPosition}
          onClear={() => setSelectedBlocks([])}
        />
      )}
    </div>
  );
};

window.Editor = Editor;
// ---------- Right pane: Outline / Comments / History ----------
const Outline = ({ blocks, activeId, onJump }) => {
  const headings = blocks
    .filter((b) => ["h1","h2","h3"].includes(b.kind))
    .map((b) => ({ id: b.id, level: parseInt(b.kind.slice(1), 10), text: (b.text || "").replace(/<[^>]*>/g,"") || "Untitled heading" }));

  if (headings.length === 0) {
    return (
      <div className="outline outline-v2">
        <div className="outline-label">On this page</div>
        <div style={{ padding: "6px 10px", fontSize: 12, color: "var(--text-faint)" }}>No headings yet.</div>
      </div>
    );
  }

  const minLevel = Math.min(...headings.map(h => h.level));

  return (
    <div className="outline outline-v2">
      <div className="outline-label">On this page</div>
      <div className="otl-list">
        <div className="otl-rail" aria-hidden="true" />
        {headings.map((h, i) => {
          const isActive = h.id === activeId;
          const isParent = h.level === minLevel;
          return (
            <button
              key={h.id}
              className={`otl-item level-${h.level} ${isParent ? "parent" : "child"} ${isActive ? "active" : ""}`}
              onClick={() => onJump(h.id)}
              title={h.text}
            >
              {isActive && <span className="otl-dot" />}
              <span className="otl-text">{h.text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

const ThreadComment = ({ comment, onResolve, onReply }) => {
  const [reply, setReply] = React.useState("");
  return (
    <div className={`comment ${comment.resolved ? "resolved" : ""}`}>
      <div className="comment-head">
        <div className="avatar" style={{ background: comment.color }}>{comment.initials}</div>
        <span className="name">{comment.author}</span>
        <span className="time">{comment.time}</span>
      </div>
      <div className="comment-ref">on {comment.ref}</div>
      <div className="comment-body">{comment.body}</div>
      {comment.replies?.map((r, i) => (
        <div key={i} style={{ borderTop: "1px solid var(--border)", marginTop: 8, paddingTop: 8 }}>
          <div className="comment-head">
            <div className="avatar" style={{ background: r.color || "oklch(55% 0.1 260)" }}>{r.initials}</div>
            <span className="name">{r.author}</span>
            <span className="time">{r.time}</span>
          </div>
          <div className="comment-body">{r.body}</div>
        </div>
      ))}
      <div className="comment-actions">
        <button onClick={() => onResolve(comment.id)}>{comment.resolved ? "Reopen" : "Resolve"}</button>
        <button onClick={() => onReply(comment.id, reply)}>Reply</button>
      </div>
    </div>
  );
};

const Comments = ({ comments, setComments }) => {
  const [filter, setFilter] = React.useState("open"); // open | all | resolved
  const [draft, setDraft] = React.useState("");

  const visible = comments.filter((c) =>
    filter === "all" ? true :
    filter === "open" ? !c.resolved :
    c.resolved
  );

  const resolve = (id) =>
    setComments((cs) => cs.map((c) => c.id === id ? { ...c, resolved: !c.resolved } : c));

  const reply = () => {
    if (!draft.trim()) return;
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref: "General",
      body: draft, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setDraft("");
  };

  return (
    <div>
      <div style={{ display: "flex", gap: 4, padding: "10px 12px 4px" }}>
        {["open","all","resolved"].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: "4px 10px", fontSize: 11.5,
              borderRadius: 4,
              background: filter === f ? "var(--accent-soft)" : "transparent",
              color: filter === f ? "var(--accent-ink)" : "var(--text-muted)",
              textTransform: "capitalize", fontWeight: 500,
            }}
          >{f}</button>
        ))}
      </div>

      <div className="comment-list">
        {visible.map((c) => <ThreadComment key={c.id} comment={c} onResolve={resolve} onReply={() => {}} />)}
        {visible.length === 0 && (
          <div style={{ padding: 16, textAlign: "center", color: "var(--text-faint)", fontSize: 12.5 }}>Nothing here yet.</div>
        )}
      </div>

      <div className="comment-reply-input">
        <input
          placeholder="Start a discussionâ€¦"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") reply(); }}
        />
        <button className="tb-btn primary" style={{ height: 28 }} onClick={reply}>Post</button>
      </div>
    </div>
  );
};

const History = ({ groups }) => (
  <div className="history-list">
    {groups.map((g) => (
      <React.Fragment key={g.day}>
        <div className="history-day">{g.day}</div>
        {g.items.map((it) => (
          <div key={it.id} className={`history-item ${it.current ? "current" : ""}`}>
            <div className="history-dot" />
            <div>
              <div className="history-name">{it.name}</div>
              <div className="history-meta">{it.meta} Â· {it.who}</div>
              {it.msg && <div className="history-msg">{it.msg}</div>}
              {it.canRestore && it.revisionId ? (
                <button
                  type="button"
                  className="tb-btn"
                  style={{ marginTop: 8 }}
                  onClick={() => {
                    if (typeof window.__editorRestoreRevision === "function") {
                      window.__editorRestoreRevision(it.revisionId);
                    }
                  }}
                >
                  Restore
                </button>
              ) : null}
            </div>
          </div>
        ))}
      </React.Fragment>
    ))}
  </div>
);

const RightPane = ({ page, comments, setComments, history, openTab, setOpenTab, activeHeadingId, onJumpTo }) => {
  const openCount = comments.filter((c) => !c.resolved).length;
  return (
    <aside className="rightpane">
      <div className="rp-tabs">
        <button className={`rp-tab ${openTab === "outline" ? "active" : ""}`} onClick={() => setOpenTab("outline")}>
          <Icon name="menu" size={13} /> Outline
        </button>
        <button className={`rp-tab ${openTab === "comments" ? "active" : ""}`} onClick={() => setOpenTab("comments")}>
          <Icon name="comment" size={13} /> Comments
          {openCount > 0 && <span className="count">{openCount}</span>}
        </button>
        <button className={`rp-tab ${openTab === "history" ? "active" : ""}`} onClick={() => setOpenTab("history")}>
          <Icon name="history" size={13} /> History
        </button>
      </div>
      <div className="rp-body">
        {openTab === "outline" && <Outline blocks={page.blocks} activeId={activeHeadingId} onJump={onJumpTo} />}
        {openTab === "comments" && <Comments comments={comments} setComments={setComments} />}
        {openTab === "history" && <History groups={history} />}
      </div>
    </aside>
  );
};

window.RightPane = RightPane;
// ---------- Top bar ----------
const TopBar = ({ page, spaceName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks }) => {
  const [publishOpen, setPublishOpen] = React.useState(false);
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark">L</div>
        <span className="brand-name">Lexicon</span>
        <span className="brand-divider">/</span>
        <span className="brand-space">{spaceName}</span>
      </div>

      <div className="crumbs">
        <span>Guides</span>
        <span className="sep">â€º</span>
        <span className="cur">{(page.title || "Untitled").replace(/<[^>]*>/g, "")}</span>
        <span className="saved">saved 12s ago Â· draft</span>
      </div>

      <div className="topbar-right">
        <button className="tb-search" onClick={onOpenPalette}>
          <Icon name="search" size={13} />
          <span>Search docs, pages, blocksâ€¦</span>
          <span className="kbd">âŒ˜K</span>
        </button>

        <button className="tb-btn" onClick={onToggleTheme} title="Toggle theme">
          <Icon name={theme === "dark" ? "sun" : "moon"} size={14} />
        </button>
        <button className="tb-btn" onClick={onTogglePanel} title="Toggle side panel">
          <Icon name="panel" size={14} />
        </button>

        <div className="avatars" style={{ marginLeft: 4, marginRight: 4 }}>
          <div className="avatar" style={{ background: "oklch(60% 0.14 30)" }}>MO</div>
          <div className="avatar" style={{ background: "oklch(55% 0.14 220)" }}>JK</div>
          <div className="avatar" style={{ background: "oklch(55% 0.14 155)" }}>RH</div>
        </div>

        <div className="publish-wrap">
          <button className="tb-btn primary" onClick={() => setPublishOpen((o) => !o)}>
            {publishing ? "Publishingâ€¦" : "Publish"}
            <Icon name="chevronDown" size={12} />
          </button>
          {publishOpen && (
            <div className="publish-menu">
              <h4>Publish this page</h4>
              <div className="row"><span>Space</span><span className="val">handbook</span></div>
              <div className="row"><span>URL</span><span className="val">lexicon.page/handbook/quickstart</span></div>
              <div className="row"><span>Version</span><span className="val">v 1.4.2</span></div>
              <div className="row"><span>Changes</span><span className="val">+42 / âˆ’18</span></div>
              <hr />
              <div className="row" style={{ alignItems: "flex-start" }}>
                <span>Message</span>
              </div>
              <textarea
                placeholder="Clarified publish pipeline section"
                style={{ width: "100%", minHeight: 52, resize: "vertical",
                         background: "var(--bg-subtle)", border: "1px solid var(--border)",
                         borderRadius: 4, padding: 8, fontSize: 12.5, color: "var(--text)",
                         outline: "none", fontFamily: "inherit" }}
              />
              <button className="primary" onClick={() => { setPublishOpen(false); onPublish(); }}>
                Publish to production
              </button>
              <button style={{ width: "100%", marginTop: 6, padding: 8, fontSize: 12, color: "var(--text-muted)" }}>
                Publish to staging
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

window.TopBar = TopBar;
// ---------- Command palette (Cmd+K) ----------
const stripHtml = (s) => (s || "").replace(/<[^>]*>/g, "");

// Derive searchable text + block-list from every page's content
const buildBlockIndex = (contentMap) => {
  const out = [];
  if (!contentMap) return out;
  for (const [pageId, page] of Object.entries(contentMap)) {
    const blocks = page.blocks || [];
    for (const b of blocks) {
      const parts = [];
      if (b.text) parts.push(stripHtml(b.text));
      if (b.html) parts.push(stripHtml(b.html));
      if (b.title) parts.push(stripHtml(b.title));
      if (b.caption) parts.push(stripHtml(b.caption));
      if (b.desc) parts.push(stripHtml(b.desc));
      if (b.code) parts.push(b.code);
      if (b.filename) parts.push(b.filename);
      if (b.path) parts.push(b.path);
      if (b.url) parts.push(b.url);
      if (b.alt) parts.push(b.alt);
      if (b.headers) parts.push(b.headers.join(" "));
      if (b.rows) parts.push(b.rows.flat().join(" "));
      if (b.items) parts.push(b.items.map((it) => `${stripHtml(it.text||"")} ${stripHtml(it.title||"")} ${stripHtml(it.desc||"")}`).join(" "));
      if (b.tabs) parts.push(b.tabs.map((t) => `${t.label} ${t.code}`).join(" "));
      if (b.params) parts.push(b.params.map((p) => `${p.name} ${p.type} ${p.desc}`).join(" "));
      const text = parts.join(" ").trim();
      if (!text) continue;
      out.push({
        pageId, pageTitle: page.title || "Untitled",
        blockId: b.id, kind: b.kind,
        text,
      });
    }
  }
  return out;
};

const Palette = ({ open, onClose, pages, contentMap, onPickPage, onJumpToBlock, onAction }) => {
  const [q, setQ] = React.useState("");
  const [focus, setFocus] = React.useState(0);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (open) { setQ(""); setFocus(0); setTimeout(() => inputRef.current?.focus(), 20); }
  }, [open]);

  // Flatten pages
  const flatPages = [];
  const walk = (list, parent = "") => {
    list.forEach((p) => {
      flatPages.push({ id: p.id, title: p.title, parent, icon: p.icon || "page" });
      if (p.children) walk(p.children, p.title);
    });
  };
  walk(pages);

  const actions = [
    { id: "new-page", title: "New page", desc: "Create an untitled page", icon: "plus", kbd: "N" },
    { id: "toggle-theme", title: "Toggle theme", desc: "Light / dark", icon: "moon", kbd: "â‡§D" },
    { id: "publish", title: "Publish page", desc: "Deploy changes to production", icon: "rocket", kbd: "â‡§âŒ˜P" },
    { id: "tweaks", title: "Open Tweaks panel", desc: "Adjust accent, font, widthâ€¦", icon: "paintbrush" },
    { id: "share", title: "Share page", desc: "Copy public link", icon: "link" },
    { id: "undo", title: "Undo", desc: "Revert last change", icon: "history", kbd: "âŒ˜Z" },
    { id: "redo", title: "Redo", desc: "Re-apply last undone change", icon: "history", kbd: "â‡§âŒ˜Z" },
  ];

  const ql = q.toLowerCase().trim();
  const matchP = flatPages.filter((p) => !q || p.title.toLowerCase().includes(ql));
  const matchA = actions.filter((a) => !q || a.title.toLowerCase().includes(ql) || a.desc.toLowerCase().includes(ql));

  // Block content search (only when query is non-empty)
  const blockIndex = React.useMemo(() => buildBlockIndex(contentMap), [contentMap]);
  const matchContent = React.useMemo(() => {
    if (!ql) return [];
    return blockIndex
      .filter((entry) => entry.text.toLowerCase().includes(ql))
      .slice(0, 20)
      .map((entry) => {
        const t = entry.text;
        const i = t.toLowerCase().indexOf(ql);
        const before = Math.max(0, i - 30);
        const snippet = (before > 0 ? "â€¦" : "") + t.slice(before, i)
          + "<mark>" + t.slice(i, i + ql.length) + "</mark>"
          + t.slice(i + ql.length, i + ql.length + 60)
          + (t.length > i + ql.length + 60 ? "â€¦" : "");
        return { ...entry, snippet };
      });
  }, [ql, blockIndex]);

  const blocks = BLOCK_SPECS.filter((b) => q && (b.title.toLowerCase().includes(ql) || b.kind.includes(ql)));

  const flat = [
    ...matchA.map((x) => ({ ...x, _kind: "action" })),
    ...matchP.map((x) => ({ ...x, _kind: "page" })),
    ...matchContent.map((x) => ({ ...x, _kind: "content" })),
    ...blocks.map((x) => ({ ...x, _kind: "block", title: "Insert " + x.title, desc: x.desc })),
  ];

  React.useEffect(() => { setFocus(0); }, [q]);

  const select = (i) => {
    const item = flat[i];
    if (!item) return;
    if (item._kind === "page") onPickPage(item.id);
    else if (item._kind === "action") onAction(item.id);
    else if (item._kind === "content") onJumpToBlock(item.pageId, item.blockId);
    onClose();
  };

  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); }
      if (e.key === "ArrowDown") { e.preventDefault(); setFocus((f) => Math.min(flat.length - 1, f + 1)); }
      if (e.key === "ArrowUp") { e.preventDefault(); setFocus((f) => Math.max(0, f - 1)); }
      if (e.key === "Enter") { e.preventDefault(); select(focus); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, focus, flat, onClose]);

  if (!open) return null;

  let i = -1;
  const section = (label, items, render) => {
    if (items.length === 0) return null;
    return (
      <>
        <div className="palette-group">{label}</div>
        {items.map((item) => {
          i++;
          const focused = i === focus;
          const cap = i;
          return (
            <div
              key={(item.id || item.blockId || item.kind) + "-" + cap}
              className={`palette-item ${focused ? "focused" : ""}`}
              onMouseEnter={() => setFocus(cap)}
              onClick={() => select(cap)}
            >
              {render(item)}
            </div>
          );
        })}
      </>
    );
  };

  return (
    <div className="palette-backdrop" onClick={onClose}>
      <div className="palette" onClick={(e) => e.stopPropagation()}>
        <div className="palette-input">
          <Icon name="search" size={16} />
          <input
            ref={inputRef}
            placeholder="Search pages, contents, commands, blocksâ€¦"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-faint)" }}>esc</span>
        </div>
        <div className="palette-list">
          {section("Actions", matchA, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "settings"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                <span className="pi-desc">{item.desc}</span>
              </div>
              {item.kbd && <div className="palette-kbd">{item.kbd}</div>}
            </>
          ))}
          {section("Pages", matchP, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "page"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                {item.parent && <span className="pi-desc">in {item.parent}</span>}
              </div>
            </>
          ))}
          {q && section("In content", matchContent, (item) => (
            <>
              <div className="pi-ico"><Icon name="text" size={15} /></div>
              <div style={{ minWidth: 0 }}>
                <span className="pi-page">{item.pageTitle.replace(/<[^>]*>/g,"")}</span>
                <span className="pi-desc pi-snippet" dangerouslySetInnerHTML={{ __html: item.snippet }} />
              </div>
              <div className="palette-kbd">{item.kind}</div>
            </>
          ))}
          {q && section("Insert block", blocks, (item) => (
            <>
              <div className="pi-ico"><Icon name={item.icon || "plus"} size={15} /></div>
              <div>
                <span>{item.title}</span>
                <span className="pi-desc">{item.desc}</span>
              </div>
            </>
          ))}
          {flat.length === 0 && (
            <div style={{ padding: 24, textAlign: "center", color: "var(--text-faint)", fontSize: 13 }}>
              No results for "{q}"
            </div>
          )}
        </div>
        <div className="palette-foot">
          <span><span className="kbd">â†‘â†“</span> navigate</span>
          <span><span className="kbd">â†µ</span> select</span>
          <span><span className="kbd">esc</span> close</span>
        </div>
      </div>
    </div>
  );
};

window.Palette = Palette;
// ---------- Tweaks panel ----------
const ACCENTS = [
  { id: "ink",    label: "Ink",    hue: 255 },
  { id: "forest", label: "Forest", hue: 155 },
  { id: "ember",  label: "Ember",  hue: 30 },
  { id: "plum",   label: "Plum",   hue: 310 },
  { id: "iron",   label: "Iron",   hue: 260, muted: true },
];

const FONT_PAIRS = [
  { id: "serif-sans", label: "Serif / Sans",
    display: "Instrument Serif", body: "Inter Tight", mono: "JetBrains Mono" },
  { id: "editorial",  label: "Editorial",
    display: "Fraunces", body: "Newsreader", mono: "JetBrains Mono" },
  { id: "geometric",  label: "Geometric",
    display: "Geist", body: "Geist", mono: "Geist Mono" },
  { id: "plex",       label: "Plex Tech",
    display: "IBM Plex Sans", body: "IBM Plex Sans", mono: "IBM Plex Mono" },
];

const TweaksPanel = ({ tweaks, setTweaks, onClose }) => {
  const set = (patch) => setTweaks({ ...tweaks, ...patch });

  return (
    <div className="tweaks-panel">
      <h3>
        <span>Tweaks</span>
        <button style={{ color: "var(--text-faint)" }} onClick={onClose}>Ã—</button>
      </h3>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Theme</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.theme === "light" ? "active" : ""} onClick={() => set({ theme: "light" })}>Light</button>
          <button className={tweaks.theme === "dark" ? "active" : ""} onClick={() => set({ theme: "dark" })}>Dark</button>
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Accent</span><span className="v">{tweaks.accent}</span></div>
        <div className="tweaks-swatches">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              className={tweaks.accent === a.id ? "active" : ""}
              style={{ background: `oklch(55% ${a.muted ? 0.03 : 0.14} ${a.hue})` }}
              onClick={() => set({ accent: a.id })}
              title={a.label}
            />
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Font pairing</span></div>
        <div className="tweaks-seg" style={{ flexWrap: "wrap", gap: 2 }}>
          {FONT_PAIRS.map((p) => (
            <button
              key={p.id}
              className={tweaks.fontPair === p.id ? "active" : ""}
              onClick={() => set({ fontPair: p.id })}
            >{p.label}</button>
          ))}
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Serif body</span>
          <span className="v">{tweaks.serifBody ? "on" : "off"}</span>
        </div>
        <div className="tweaks-seg">
          <button className={!tweaks.serifBody ? "active" : ""} onClick={() => set({ serifBody: false })}>Sans</button>
          <button className={tweaks.serifBody ? "active" : ""} onClick={() => set({ serifBody: true })}>Serif</button>
        </div>
      </div>

      <div className="tweaks-row tweaks-slider">
        <div className="tweaks-row-label"><span>Reading width</span><span className="v">{tweaks.readingWidth}px</span></div>
        <input type="range" min="560" max="900" step="20"
          value={tweaks.readingWidth}
          onChange={(e) => set({ readingWidth: Number(e.target.value) })} />
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Density</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.density === "compact" ? "active" : ""} onClick={() => set({ density: "compact" })}>Compact</button>
          <button className={tweaks.density === "comfortable" ? "active" : ""} onClick={() => set({ density: "comfortable" })}>Comfortable</button>
        </div>
      </div>

      <div className="tweaks-row">
        <div className="tweaks-row-label"><span>Right panel</span></div>
        <div className="tweaks-seg">
          <button className={tweaks.rightPanel ? "active" : ""} onClick={() => set({ rightPanel: true })}>Visible</button>
          <button className={!tweaks.rightPanel ? "active" : ""} onClick={() => set({ rightPanel: false })}>Hidden</button>
        </div>
      </div>
    </div>
  );
};

window.TweaksPanel = TweaksPanel;
window.ACCENTS = ACCENTS;
window.FONT_PAIRS = FONT_PAIRS;
// ---------- App root ----------
const { useState, useEffect, useMemo } = React;

const ACCENT_MAP = { ink: 255, forest: 155, ember: 30, plum: 310, iron: 260 };
const FONT_PAIR_MAP = {
  "serif-sans": { display: '"Instrument Serif", serif', body: '"Inter Tight", system-ui, sans-serif', mono: '"JetBrains Mono", monospace' },
  "editorial":  { display: '"Fraunces", serif',          body: '"Newsreader", Georgia, serif',         mono: '"JetBrains Mono", monospace' },
  "geometric":  { display: '"Geist", sans-serif',        body: '"Geist", system-ui, sans-serif',       mono: '"Geist Mono", monospace' },
  "plex":       { display: '"IBM Plex Sans", sans-serif', body: '"IBM Plex Sans", sans-serif',          mono: '"IBM Plex Mono", monospace' },
};

const App = () => {
  const isMobileViewport = () => typeof window !== "undefined" && window.innerWidth <= 760;

  // Tweaks
  const [tweaks, setTweaks] = useState(window.__TWEAKS__);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  // Theme / fonts / accent applied to :root
  useEffect(() => {
    const body = document.body;
    body.classList.toggle("theme-light", tweaks.theme === "light");
    body.classList.toggle("theme-dark", tweaks.theme === "dark");
    body.classList.toggle("serif-body", !!tweaks.serifBody);

    const root = document.documentElement.style;
    root.setProperty("--accent-h", ACCENT_MAP[tweaks.accent] ?? 255);
    if (tweaks.accent === "iron") {
      root.setProperty("--accent", "oklch(45% 0.03 260)");
      root.setProperty("--accent-soft", "oklch(45% 0.03 260 / 0.14)");
      root.setProperty("--accent-ink", "oklch(35% 0.03 260)");
    } else {
      root.removeProperty("--accent");
      root.removeProperty("--accent-soft");
      root.removeProperty("--accent-ink");
    }
    root.setProperty("--reading-width", tweaks.readingWidth + "px");
    root.setProperty("--density", tweaks.density === "compact" ? "0.6" : "1");

    const fp = FONT_PAIR_MAP[tweaks.fontPair];
    if (fp) {
      root.setProperty("--font-display", fp.display);
      root.setProperty("--font-ui", fp.body);
      root.setProperty("--font-body", fp.body);
      root.setProperty("--font-mono", fp.mono);
    }
  }, [tweaks]);

  // Persist tweak changes so the host rewrites the EDITMODE JSON
  const applyTweak = (patch) => {
    const next = { ...tweaks, ...patch };
    setTweaks(next);
    try {
      window.parent?.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
    } catch {}
  };

  // Tweaks/edit mode protocol
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", handler);
    window.parent?.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  // Pages tree
  const [pages, setPages] = useState(PAGES);
  const [spaces, setSpaces] = useState(SPACES);
  const [activeSpaceId, setActiveSpaceId] = useState(SPACES[0].id);
  const [activePageId, setActivePageId] = useState(ACTIVE_PAGE_ID);
  const [mobileViewport, setMobileViewport] = useState(() => isMobileViewport());
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => isMobileViewport());
  const [rightTab, setRightTab] = useState("outline");
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const [publishing, setPublishing] = useState(false);
  const hasAutoCollapsedMobileRef = React.useRef(false);

  useEffect(() => {
    const syncViewport = () => setMobileViewport(isMobileViewport());
    syncViewport();
    window.addEventListener("resize", syncViewport);
    return () => window.removeEventListener("resize", syncViewport);
  }, []);

  useEffect(() => {
    if (!mobileViewport) {
      hasAutoCollapsedMobileRef.current = false;
      return;
    }

    setSidebarCollapsed(true);

    if (!hasAutoCollapsedMobileRef.current && tweaks.rightPanel) {
      applyTweak({ rightPanel: false });
    }

    hasAutoCollapsedMobileRef.current = true;
  }, [mobileViewport]);

  // Pages â†’ content map (use the single seeded page for now, synthesize empties for others)
  const [contentMap, setContentMap] = useState(() => {
    const map = { ...PAGE_CONTENT };
    const ensure = (list) => list.forEach((p) => {
      if (!map[p.id]) {
        map[p.id] = {
          title: p.title,
          subtitle: "This page is a draft â€” click to add a subtitle.",
          updated: "just now", readTime: "1 min",
          author: { name: "You", role: "Editor", initials: "YO", color: "oklch(55% 0.14 255)" },
          collaborators: [{ initials: "YO", color: "oklch(55% 0.14 255)" }],
          blocks: [
            { id: uid("b"), kind: "p", html: "Start writing, or press <code>/</code> to insert a block." },
          ],
        };
      }
      if (p.children) ensure(p.children);
    });
    ensure(PAGES);
    return map;
  });

  const [comments, setComments] = useState(COMMENTS);
  const [activeHeadingId, setActiveHeadingId] = useState(null);
  const [jumpToBlockId, setJumpToBlockId] = useState(null);

  // ---- Undo/redo history of contentMap snapshots ----
  const historyRef = React.useRef({ past: [], future: [] });
  const skipHistoryRef = React.useRef(false);
  const lastPushAtRef = React.useRef(0);
  const [, forceBump] = useState(0);

  const pushHistory = (prev) => {
    const now = Date.now();
    // coalesce rapid edits within 400ms
    if (now - lastPushAtRef.current < 400 && historyRef.current.past.length) {
      lastPushAtRef.current = now;
      return;
    }
    historyRef.current.past.push(prev);
    if (historyRef.current.past.length > 100) historyRef.current.past.shift();
    historyRef.current.future = [];
    lastPushAtRef.current = now;
    forceBump((n) => n + 1);
  };

  const undo = () => {
    const h = historyRef.current;
    if (!h.past.length) return;
    const prev = h.past.pop();
    h.future.push(contentMap);
    skipHistoryRef.current = true;
    setContentMap(prev);
    forceBump((n) => n + 1);
  };
  const redo = () => {
    const h = historyRef.current;
    if (!h.future.length) return;
    const next = h.future.pop();
    h.past.push(contentMap);
    skipHistoryRef.current = true;
    setContentMap(next);
    forceBump((n) => n + 1);
  };

  // Selection + clipboard shared between editor + palette
  const [selectedBlocks, setSelectedBlocks] = useState([]);
  const [clipboard, setClipboard] = useState(null);

  const page = contentMap[activePageId];

  const setPage = (next) => {
    setContentMap((m) => {
      if (skipHistoryRef.current) { skipHistoryRef.current = false; return { ...m, [activePageId]: next }; }
      pushHistory(m);
      return { ...m, [activePageId]: next };
    });
  };

  // Page tree operations
  const updateNode = (list, id, fn) =>
    list.map((n) => {
      if (n.id === id) return fn(n);
      if (n.children) return { ...n, children: updateNode(n.children, id, fn) };
      return n;
    });

  const onRenamePage = (id, title) => {
    setPages((pp) => updateNode(pp, id, (n) => ({ ...n, title })));
    setContentMap((m) => m[id] ? ({ ...m, [id]: { ...m[id], title } }) : m);
  };

  const onDeletePage = (id) => {
    const removeFrom = (list) => list
      .filter((n) => n.id !== id)
      .map((n) => n.children ? { ...n, children: removeFrom(n.children) } : n);
    setPages((pp) => removeFrom(pp));
    if (activePageId === id) {
      // fall back to the first remaining page
      const first = (list) => {
        for (const n of list) {
          if (n.id !== id) return n.id;
          if (n.children) { const r = first(n.children); if (r) return r; }
        }
        return null;
      };
      const next = first(pages);
      if (next) setActivePageId(next);
    }
  };

  const onMovePage = (fromId, toId, pos) => {
    setPages((pp) => {
      // 1) find & detach the dragged node
      let dragged = null;
      const detach = (list) => {
        const out = [];
        for (const n of list) {
          if (n.id === fromId) { dragged = n; continue; }
          const node = { ...n };
          if (node.children) node.children = detach(node.children);
          out.push(node);
        }
        return out;
      };
      const withoutDragged = detach(pp);
      if (!dragged) return pp;

      // guard against dropping a node onto its own descendant
      const contains = (n, id) => {
        if (!n.children) return false;
        for (const c of n.children) {
          if (c.id === id) return true;
          if (contains(c, id)) return true;
        }
        return false;
      };
      if (contains(dragged, toId)) return pp;

      // 2) insert relative to target
      const insert = (list) => {
        const out = [];
        for (const n of list) {
          if (n.id === toId) {
            if (pos === "before") { out.push(dragged); out.push(n); }
            else if (pos === "after") { out.push(n); out.push(dragged); }
            else { // inside
              out.push({ ...n, expanded: true, children: [...(n.children || []), dragged] });
            }
          } else {
            const node = { ...n };
            if (node.children) node.children = insert(node.children);
            out.push(node);
          }
        }
        return out;
      };
      return insert(withoutDragged);
    });
  };

  const onAddPage = (parentId) => {
    const newId = uid("p");
    const newPage = { id: newId, title: "Untitled", icon: "page" };
    if (parentId === null) {
      setPages((pp) => [...pp, newPage]);
    } else {
      setPages((pp) => updateNode(pp, parentId, (n) => ({
        ...n, expanded: true, children: [...(n.children || []), newPage],
      })));
    }
    setContentMap((m) => ({ ...m, [newId]: {
      title: "Untitled",
      subtitle: "",
      updated: "just now", readTime: "1 min",
      author: { name: "You", role: "Editor", initials: "YO", color: "oklch(55% 0.14 255)" },
      collaborators: [{ initials: "YO", color: "oklch(55% 0.14 255)" }],
      blocks: [{ id: uid("b"), kind: "p", html: "" }],
    } }));
    setActivePageId(newId);
  };

  // Cmd+K, undo/redo
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault(); setPaletteOpen(true); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "/") {
        e.preventDefault(); setPaletteOpen(true); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" && !e.shiftKey) {
        e.preventDefault(); undo(); return;
      }
      if ((e.metaKey || e.ctrlKey) && (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))) {
        e.preventDefault(); redo(); return;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [contentMap]);

  const onPublish = () => {
    setPublishing(true);
    setTimeout(() => {
      setPublishing(false);
      setToast("Published to lexicon.page/handbook/quickstart");
      setTimeout(() => setToast(null), 2400);
    }, 1600);
  };

  const onPaletteAction = (id) => {
    if (id === "new-page") onAddPage(null);
    if (id === "toggle-theme") applyTweak({ theme: tweaks.theme === "light" ? "dark" : "light" });
    if (id === "publish") onPublish();
    if (id === "tweaks") setTweaksOpen(true);
    if (id === "share") { setToast("Public link copied to clipboard"); setTimeout(() => setToast(null), 2000); }
    if (id === "undo") undo();
    if (id === "redo") redo();
  };

  const spaceName = spaces.find((s) => s.id === activeSpaceId)?.name || "";

  const onAddSpace = (name) => {
    const clean = (name || "").trim();
    if (!clean) return;
    const palette = [
      "oklch(55% 0.14 255)", "oklch(52% 0.15 155)", "oklch(55% 0.15 25)",
      "oklch(58% 0.14 305)", "oklch(60% 0.14 70)", "oklch(55% 0.13 205)",
    ];
    const newSp = {
      id: "sp_" + Date.now(),
      name: clean,
      color: palette[spaces.length % palette.length],
      count: 0,
      icon: clean[0].toUpperCase(),
    };
    setSpaces((arr) => [...arr, newSp]);
    setActiveSpaceId(newSp.id);
    setToast(`Created space "${clean}"`);
    setTimeout(() => setToast(null), 2000);
  };

  const onAddComment = (blockId, selectedText = "") => {
    const ref = blockId ? `Block ${blockId}` : "Selection in current page";
    const body = selectedText ? `Comment on: "${selectedText}"` : "New comment - reply below.";
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref,
      body, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setRightTab("comments");
  };

  return (
    <div className={`app ${!tweaks.rightPanel ? "no-right" : ""} ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <TopBar
        page={page}
        spaceName={spaceName}
        onToggleSidebar={() => setSidebarCollapsed((c) => !c)}
        onOpenPalette={() => setPaletteOpen(true)}
        onTogglePanel={() => applyTweak({ rightPanel: !tweaks.rightPanel })}
        theme={tweaks.theme}
        onToggleTheme={() => applyTweak({ theme: tweaks.theme === "light" ? "dark" : "light" })}
        onPublish={onPublish}
        publishing={publishing}
        onToggleTweaks={() => setTweaksOpen((o) => !o)}
      />

      <div className="workspace">
        <Sidebar
          spaces={spaces}
          activeSpaceId={activeSpaceId}
          onSpace={setActiveSpaceId}
          onAddSpace={onAddSpace}
          pages={pages}
          activePageId={activePageId}
          onSelectPage={setActivePageId}
          onAddPage={onAddPage}
          onRenamePage={onRenamePage}
          onDeletePage={onDeletePage}
          onMovePage={onMovePage}
        />

        <Editor
          page={page}
          onUpdate={setPage}
          onAddComment={onAddComment}
          onActiveHeadingChange={setActiveHeadingId}
          jumpToBlockId={jumpToBlockId}
          clearJump={() => setJumpToBlockId(null)}
          selectedBlocks={selectedBlocks}
          setSelectedBlocks={setSelectedBlocks}
          clipboard={clipboard}
          setClipboard={setClipboard}
          toast={toast}
          setToast={setToast}
        />

        {tweaks.rightPanel && (
          <RightPane
            page={page}
            comments={comments}
            setComments={setComments}
            history={HISTORY}
            openTab={rightTab}
            setOpenTab={setRightTab}
            activeHeadingId={activeHeadingId}
            onJumpTo={(id) => setJumpToBlockId(id)}
          />
        )}
      </div>

      <Palette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        pages={pages}
        contentMap={contentMap}
        onPickPage={(id) => setActivePageId(id)}
        onJumpToBlock={(pageId, blockId) => {
          setActivePageId(pageId);
          setTimeout(() => setJumpToBlockId(blockId), 60);
        }}
        onAction={onPaletteAction}
      />

      {tweaksOpen && (
        <TweaksPanel
          tweaks={tweaks}
          setTweaks={applyTweak}
          onClose={() => {
            setTweaksOpen(false);
            try { window.parent?.postMessage({ type: "__edit_mode_exited" }, "*"); } catch {}
          }}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
