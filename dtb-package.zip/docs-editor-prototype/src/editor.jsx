// ---------- Editor canvas ----------
const BlockRow = ({ block, index, update, onAddAfter, onDelete, onMove, onOpenSlash, onSelectText, dragState, setDragState, selected, onSelectBlock }) => {
  const rowRef = React.useRef(null);

  return (
    <div
      ref={rowRef}
      className={`block-row ${dragState.dragging === block.id ? "dragging" : ""} ${dragState.over === block.id ? "drag-over" : ""} ${selected ? "multi-selected" : ""}`}
      data-block-id={block.id}
      onDragOver={(e) => {
        if (dragState.dragging && dragState.dragging !== block.id) {
          e.preventDefault();
          setDragState((s) => ({ ...s, over: block.id }));
        }
      }}
      onDragLeave={() => setDragState((s) => (s.over === block.id ? { ...s, over: null } : s))}
      onDrop={(e) => {
        e.preventDefault();
        if (dragState.dragging && dragState.dragging !== block.id) {
          onMove(dragState.dragging, block.id);
        }
        setDragState({ dragging: null, over: null });
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          const target = e.target;
          const tagName = target?.tagName;
          const inFormField = tagName === "INPUT" || tagName === "TEXTAREA";
          const inContent = !!target?.closest?.(".blk-content");

          if (!inFormField && inContent && e.shiftKey) {
            e.preventDefault();
            onAddAfter({ kind: "p", html: "" });

            requestAnimationFrame(() => {
              const current = rowRef.current;
              const next = current?.nextElementSibling;
              const editable = next?.querySelector?.(".blk-content");

              if (!editable) return;

              editable.focus();

              const sel = window.getSelection();
              if (!sel) return;

              const range = document.createRange();
              range.selectNodeContents(editable);
              range.collapse(true);
              sel.removeAllRanges();
              sel.addRange(range);
            });
          }

          return;
        }

        if (e.key === "/" && ["p","h1","h2","h3"].includes(block.kind)) {
          const text = e.currentTarget.querySelector(".blk-content")?.textContent || "";
          if (text.trim() === "") {
            e.preventDefault();
            const r = rowRef.current.getBoundingClientRect();
            const scrollEl = rowRef.current.closest(".editor-wrap");
            const sr = scrollEl.getBoundingClientRect();
            onOpenSlash({
              blockId: block.id,
              x: r.left - sr.left,
              y: r.top - sr.top + r.height + (scrollEl.scrollTop),
            });
          }
        }
        if (e.key === "Backspace") {
          const text = e.currentTarget.querySelector(".blk-content")?.textContent || "";
          if (text === "" && ["p","h1","h2","h3"].includes(block.kind)) {
            e.preventDefault();
            onDelete(block.id);
          }
        }
      }}
      onMouseUp={() => {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed) { onSelectText(null); return; }
        const range = sel.getRangeAt(0);
        const contained = rowRef.current?.contains(range.commonAncestorContainer);
        if (!contained) return;
        const rect = range.getBoundingClientRect();
        const scrollEl = rowRef.current.closest(".editor-wrap");
        const sr = scrollEl.getBoundingClientRect();
        onSelectText({
          blockId: block.id,
          x: rect.left + rect.width / 2 - sr.left,
          y: rect.top - sr.top + scrollEl.scrollTop,
        });
      }}
    >
      <div className="block-gutter">
        <button
          className="gutter-btn"
          title="Add block below"
          onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            const scrollEl = rowRef.current.closest(".editor-wrap");
            const sr = scrollEl.getBoundingClientRect();
            onOpenSlash({
              blockId: block.id,
              x: r.left - sr.left + 30,
              y: r.top - sr.top + r.height + scrollEl.scrollTop,
              below: true,
            });
          }}
        >
          <Icon name="plus" size={14} />
        </button>
        <button
          className="gutter-btn drag"
          draggable
          title="Drag to reorder · click to select"
          onClick={(e) => {
            e.stopPropagation();
            onSelectBlock(block.id, { shift: e.shiftKey, meta: e.metaKey || e.ctrlKey });
          }}
          onDragStart={(e) => {
            setDragState({ dragging: block.id, over: null });
            e.dataTransfer.setData("text/x-block", block.id);
            e.dataTransfer.effectAllowed = "move";
          }}
          onDragEnd={() => setDragState({ dragging: null, over: null })}
        >
          <Icon name="grip" size={14} />
        </button>
      </div>

      {renderBlock(block, update)}
    </div>
  );
};

// ---------- Inline toolbar with link bubble editor ----------
const InlineToolbar = ({ position, onClose, onComment, savedRange, setSavedRange }) => {
  const toolbarRef = React.useRef(null);
  const [linkEditor, setLinkEditor] = React.useState(null); // { href }

  const exec = (cmd, val) => {
    restoreRange();
    document.execCommand(cmd, false, val);
  };

  const saveRange = () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount) {
      setSavedRange(sel.getRangeAt(0).cloneRange());
    }
  };
  const restoreRange = () => {
    if (savedRange) {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(savedRange);
    }
  };

  React.useEffect(() => {
    const onDown = (e) => {
      if (toolbarRef.current && !toolbarRef.current.contains(e.target)) {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed) onClose();
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [onClose]);

  if (!position) return null;

  const openLinkEditor = () => {
    saveRange();
    // Pre-fill if the selection contains a link
    const sel = window.getSelection();
    let href = "";
    if (sel && sel.rangeCount) {
      let node = sel.getRangeAt(0).commonAncestorContainer;
      if (node.nodeType === 3) node = node.parentElement;
      const a = node?.closest?.("a");
      if (a) href = a.getAttribute("href") || "";
    }
    setLinkEditor({ href });
  };

  const applyLink = (href) => {
    restoreRange();
    if (href) {
      document.execCommand("createLink", false, href);
      // After createLink, find inserted <a> and set target
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        let node = sel.getRangeAt(0).commonAncestorContainer;
        if (node.nodeType === 3) node = node.parentElement;
        const a = node?.closest?.("a");
        if (a) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); }
      }
    } else {
      document.execCommand("unlink");
    }
    setLinkEditor(null);
    onClose();
  };

  return (
    <div
      ref={toolbarRef}
      className="inline-toolbar"
      style={{ left: position.x, top: position.y }}
      onMouseDown={(e) => e.preventDefault()}
    >
      {!linkEditor && (
        <>
          <button className="itb-btn" onClick={() => exec("bold")}><Icon name="bold" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("italic")}><Icon name="italic" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("underline")}><Icon name="underline" size={13} /></button>
          <button className="itb-btn" onClick={() => exec("strikeThrough")}><Icon name="strike" size={13} /></button>
          <div className="itb-sep" />
          <button className="itb-btn" onClick={() => {
            const html = document.getSelection()?.toString() || "";
            exec("insertHTML", `<code style="background:var(--bg-subtle);padding:1px 5px;border-radius:3px;font-family:var(--font-mono);font-size:0.88em;">${html}</code>`);
          }}><Icon name="code" size={13} /></button>
          <button className="itb-btn" onClick={openLinkEditor}><Icon name="link" size={13} /></button>
          <div className="itb-sep" />
          <button className="itb-btn" title="Comment" onClick={onComment}><Icon name="comment" size={13} /></button>
        </>
      )}
      {linkEditor && (
        <div className="link-bubble" onMouseDown={(e) => e.stopPropagation()}>
          <Icon name="link" size={13} />
          <input
            autoFocus
            placeholder="Paste URL, or type…"
            defaultValue={linkEditor.href}
            onKeyDown={(e) => {
              if (e.key === "Enter") { e.preventDefault(); applyLink(e.target.value.trim()); }
              if (e.key === "Escape") setLinkEditor(null);
            }}
            onMouseDown={(e) => e.stopPropagation()}
          />
          <button className="itb-btn" title="Apply" onClick={(e) => {
            const inp = e.currentTarget.parentElement.querySelector("input");
            applyLink(inp.value.trim());
          }}><Icon name="check" size={13} /></button>
          <button className="itb-btn" title="Remove link" onClick={() => applyLink("")}>
            <Icon name="trash" size={13} />
          </button>
        </div>
      )}
    </div>
  );
};

const SlashMenu = ({ position, onPick, onClose }) => {
  const [q, setQ] = React.useState("");
  const [focus, setFocus] = React.useState(0);
  const inputRef = React.useRef(null);

  React.useEffect(() => { inputRef.current?.focus(); }, []);

  const filtered = React.useMemo(() => {
    const ql = q.toLowerCase();
    return BLOCK_SPECS.filter((b) =>
      !q || b.title.toLowerCase().includes(ql) || b.kbd.includes(ql) || b.kind.includes(ql)
    );
  }, [q]);

  React.useEffect(() => { setFocus(0); }, [q]);

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); }
      if (e.key === "ArrowDown") { e.preventDefault(); setFocus((f) => Math.min(filtered.length - 1, f + 1)); }
      if (e.key === "ArrowUp") { e.preventDefault(); setFocus((f) => Math.max(0, f - 1)); }
      if (e.key === "Enter") { e.preventDefault(); if (filtered[focus]) onPick(filtered[focus]); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [focus, filtered, onPick, onClose]);

  if (!position) return null;

  const groups = filtered.reduce((acc, b) => {
    (acc[b.group] = acc[b.group] || []).push(b);
    return acc;
  }, {});

  let flatIdx = -1;
  return (
    <div className="slash-menu" style={{ left: position.x, top: position.y + 6 }}>
      <div style={{ padding: 6, borderBottom: "1px solid var(--border)" }}>
        <input
          ref={inputRef}
          style={{ width: "100%", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 4, padding: "6px 8px", outline: "none", fontSize: 12.5 }}
          placeholder="Filter blocks…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>
      {Object.entries(groups).map(([group, items]) => (
        <div key={group}>
          <div className="slash-group-label">{group}</div>
          {items.map((b) => {
            flatIdx++;
            const focused = flatIdx === focus;
            return (
              <div
                key={b.kind}
                className={`slash-item ${focused ? "focused" : ""}`}
                onMouseEnter={() => setFocus(flatIdx)}
                onClick={() => onPick(b)}
              >
                <div className="slash-ico"><Icon name={b.icon} size={16} /></div>
                <div className="slash-meta">
                  <div className="title">{b.title}</div>
                  <div className="desc">{b.desc}</div>
                </div>
                <div className="slash-kbd">{b.kbd}</div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};

// ---------- Selection action bar ----------
const SelectionBar = ({ count, onDuplicate, onDelete, onCopy, onClear }) => (
  <div className="selection-bar">
    <span className="sb-count">{count} selected</span>
    <button onClick={onDuplicate}><Icon name="duplicate" size={12} /> Duplicate</button>
    <button onClick={onCopy}><Icon name="copy" size={12} /> Copy</button>
    <button onClick={onDelete} className="danger"><Icon name="trash" size={12} /> Delete</button>
    <button className="close" onClick={onClear}>×</button>
  </div>
);

const Editor = ({
  page, onUpdate, onAddComment, onActiveHeadingChange, jumpToBlockId, clearJump,
  selectedBlocks, setSelectedBlocks,
  clipboard, setClipboard,
  toast, setToast,
}) => {
  const [slash, setSlash] = React.useState(null);
  const [selection, setSelection] = React.useState(null);
  const [dragState, setDragState] = React.useState({ dragging: null, over: null });
  const [savedRange, setSavedRange] = React.useState(null);
  const wrapRef = React.useRef(null);

  React.useEffect(() => {
    if (wrapRef.current) wrapRef.current.scrollTop = 0;
    setSlash(null); setSelection(null);
  }, [page.title, page.blocks?.[0]?.id]);

  // Active heading tracking
  React.useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap || !onActiveHeadingChange) return;
    const calc = () => {
      const headings = page.blocks.filter((b) => ["h1","h2","h3"].includes(b.kind));
      if (headings.length === 0) { onActiveHeadingChange(null); return; }
      const wrapRect = wrap.getBoundingClientRect();
      const threshold = wrapRect.top + 120;
      let activeId = headings[0].id;
      for (const h of headings) {
        const el = wrap.querySelector(`[data-block-id="${h.id}"]`);
        if (!el) continue;
        const r = el.getBoundingClientRect();
        if (r.top <= threshold) activeId = h.id;
        else break;
      }
      onActiveHeadingChange(activeId);
    };
    calc();
    wrap.addEventListener("scroll", calc, { passive: true });
    return () => wrap.removeEventListener("scroll", calc);
  }, [page.blocks, onActiveHeadingChange]);

  React.useEffect(() => {
    if (!jumpToBlockId || !wrapRef.current) return;
    const el = wrapRef.current.querySelector(`[data-block-id="${jumpToBlockId}"]`);
    if (el) {
      const wrap = wrapRef.current;
      const y = el.getBoundingClientRect().top - wrap.getBoundingClientRect().top + wrap.scrollTop - 24;
      wrap.scrollTo({ top: y, behavior: "smooth" });
    }
    clearJump && clearJump();
  }, [jumpToBlockId]);

  const updateBlock = (blockId, patch) => {
    const blocks = page.blocks.map((b) => b.id === blockId ? { ...b, ...patch } : b);
    onUpdate({ ...page, blocks });
  };

  const addAfter = (blockId, newBlock) => {
    const i = page.blocks.findIndex((b) => b.id === blockId);
    const blocks = [...page.blocks];
    blocks.splice(i + 1, 0, { id: uid("b"), ...newBlock });
    onUpdate({ ...page, blocks });
  };

  const replaceBlock = (blockId, newBlock) => {
    const blocks = page.blocks.map((b) => b.id === blockId ? { id: b.id, ...newBlock } : b);
    onUpdate({ ...page, blocks });
  };

  const deleteBlock = (blockId) => {
    if (page.blocks.length <= 1) return;
    const blocks = page.blocks.filter((b) => b.id !== blockId);
    onUpdate({ ...page, blocks });
  };

  const moveBlock = (fromId, toId) => {
    const fromIdx = page.blocks.findIndex((b) => b.id === fromId);
    const toIdx = page.blocks.findIndex((b) => b.id === toId);
    if (fromIdx < 0 || toIdx < 0) return;
    const blocks = [...page.blocks];
    const [m] = blocks.splice(fromIdx, 1);
    blocks.splice(toIdx, 0, m);
    onUpdate({ ...page, blocks });
  };

  // Multi-select helpers
  const toggleBlockSelect = (id, { shift, meta }) => {
    setSelectedBlocks((prev) => {
      if (shift && prev.length > 0) {
        // range-select between last selected and this
        const ids = page.blocks.map((b) => b.id);
        const from = ids.indexOf(prev[prev.length - 1]);
        const to = ids.indexOf(id);
        if (from < 0 || to < 0) return [id];
        const [a, b] = from < to ? [from, to] : [to, from];
        return ids.slice(a, b + 1);
      }
      if (meta) {
        return prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      }
      return prev.length === 1 && prev[0] === id ? [] : [id];
    });
  };

  // Deep clone helper (regenerate ids)
  const cloneBlock = (b) => {
    const c = JSON.parse(JSON.stringify(b));
    c.id = uid("b");
    if (c.items) c.items = c.items.map((it) => it.id ? { ...it, id: uid("c") } : it);
    if (c.tabs)  c.tabs  = c.tabs.map((t) => ({ ...t, id: uid("t") }));
    return c;
  };

  const duplicateSelected = () => {
    if (selectedBlocks.length === 0) return;
    const lastId = selectedBlocks[selectedBlocks.length - 1];
    const lastIdx = page.blocks.findIndex((b) => b.id === lastId);
    const selBlocks = selectedBlocks
      .map((id) => page.blocks.find((b) => b.id === id))
      .filter(Boolean)
      .map(cloneBlock);
    const blocks = [...page.blocks];
    blocks.splice(lastIdx + 1, 0, ...selBlocks);
    onUpdate({ ...page, blocks });
    setSelectedBlocks(selBlocks.map((b) => b.id));
  };
  const deleteSelected = () => {
    if (selectedBlocks.length === 0) return;
    if (page.blocks.length <= selectedBlocks.length) return;
    const blocks = page.blocks.filter((b) => !selectedBlocks.includes(b.id));
    onUpdate({ ...page, blocks });
    setSelectedBlocks([]);
  };
  const copySelected = () => {
    if (selectedBlocks.length === 0) return;
    const selBlocks = selectedBlocks
      .map((id) => page.blocks.find((b) => b.id === id))
      .filter(Boolean);
    setClipboard(selBlocks);
    try {
      navigator.clipboard?.writeText(`__LEXICON_BLOCKS__${JSON.stringify(selBlocks)}`);
    } catch {}
    setToast && setToast(`Copied ${selBlocks.length} block${selBlocks.length===1?"":"s"}`);
    setTimeout(() => setToast && setToast(null), 1600);
  };
  const pasteBlocks = () => {
    if (!clipboard || clipboard.length === 0) return;
    const insertAfter = selectedBlocks.length
      ? page.blocks.findIndex((b) => b.id === selectedBlocks[selectedBlocks.length - 1])
      : page.blocks.length - 1;
    const nb = clipboard.map(cloneBlock);
    const blocks = [...page.blocks];
    blocks.splice(insertAfter + 1, 0, ...nb);
    onUpdate({ ...page, blocks });
    setSelectedBlocks(nb.map((b) => b.id));
  };

  // Keyboard shortcuts for selection / paste
  React.useEffect(() => {
    const onKey = (e) => {
      const active = document.activeElement;
      const inEditable = active && (active.isContentEditable || active.tagName === "INPUT" || active.tagName === "TEXTAREA");

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d" && selectedBlocks.length) {
        e.preventDefault(); duplicateSelected(); return;
      }
      if ((e.key === "Delete" || e.key === "Backspace") && selectedBlocks.length && !inEditable) {
        e.preventDefault(); deleteSelected(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "c" && selectedBlocks.length && !inEditable) {
        e.preventDefault(); copySelected(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "v" && !inEditable && clipboard) {
        e.preventDefault(); pasteBlocks(); return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "a" && !inEditable) {
        e.preventDefault();
        setSelectedBlocks(page.blocks.map((b) => b.id));
      }
      if (e.key === "Escape" && selectedBlocks.length) {
        setSelectedBlocks([]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedBlocks, clipboard, page.blocks]);

  // Listen for external paste (from OS clipboard containing __LEXICON_BLOCKS__)
  React.useEffect(() => {
    const onPaste = (e) => {
      const active = document.activeElement;
      const inEditable = active && (active.isContentEditable || active.tagName === "INPUT" || active.tagName === "TEXTAREA");
      if (inEditable) return;
      const text = e.clipboardData?.getData("text/plain") || "";
      if (text.startsWith("__LEXICON_BLOCKS__")) {
        e.preventDefault();
        try {
          const arr = JSON.parse(text.slice("__LEXICON_BLOCKS__".length));
          setClipboard(arr);
          setTimeout(pasteBlocks, 0);
        } catch {}
      }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [selectedBlocks, page.blocks]);

  const onPickBlock = (spec) => {
    if (!slash) return;
    const newBlock = spec.make();
    if (slash.below) addAfter(slash.blockId, newBlock);
    else replaceBlock(slash.blockId, newBlock);
    setSlash(null);
  };

  return (
    <div className="editor-wrap" ref={wrapRef}
      onMouseDown={(e) => {
        // click on blank area clears multi-selection
        if (e.target.classList?.contains("editor-wrap") || e.target.classList?.contains("editor-body") || e.target.classList?.contains("editor-hero")) {
          if (selectedBlocks.length) setSelectedBlocks([]);
        }
      }}
    >
      <div className="editor-hero">
        <div className="hero-meta">
          <span className="tag">{page.updated ? `Updated ${page.updated}` : "Draft"}</span>
          <span className="dot" />
          <span>{page.readTime || "—"}</span>
          <span className="dot" />
          <span>en · english</span>
        </div>

        <Editable
          tag="h1"
          className="doc-title"
          html={page.title}
          placeholder="Untitled"
          onChange={(h) => onUpdate({ ...page, title: h })}
        />
        <Editable
          tag="p"
          className="doc-subtitle"
          html={page.subtitle}
          placeholder="Add a short subtitle or description…"
          onChange={(h) => onUpdate({ ...page, subtitle: h })}
        />

        <div className="hero-byline">
          <div className="avatar" style={{ background: page.author.color }}>{page.author.initials}</div>
          <div className="by-meta">
            <span className="by-name">{page.author.name}</span>
            <span className="by-sub">{page.author.role}</span>
          </div>
          <div className="right">
            <div className="item"><Icon name="eye" size={12} /> 1,284</div>
            <div className="item"><Icon name="comment" size={12} /> 3</div>
            <div className="avatars">
              {page.collaborators.map((c, i) => (
                <div key={i} className="avatar" style={{ background: c.color }}>{c.initials}</div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="editor-body">
        {page.blocks.map((b, i) => (
          <BlockRow
            key={b.id}
            block={b}
            index={i}
            update={(patch) => updateBlock(b.id, patch)}
            onAddAfter={(nb) => addAfter(b.id, nb)}
            onDelete={deleteBlock}
            onMove={moveBlock}
            onOpenSlash={setSlash}
            onSelectText={setSelection}
            dragState={dragState}
            setDragState={setDragState}
            selected={selectedBlocks.includes(b.id)}
            onSelectBlock={toggleBlockSelect}
          />
        ))}
        <div style={{ height: 60, display: "flex", alignItems: "center", color: "var(--text-faint)", fontSize: 13, cursor: "text", paddingLeft: 2 }}
          onClick={(e) => {
            const last = page.blocks[page.blocks.length - 1];
            if (last) {
              const r = e.currentTarget.getBoundingClientRect();
              const scrollEl = e.currentTarget.closest(".editor-wrap");
              const sr = scrollEl.getBoundingClientRect();
              setSlash({ blockId: last.id, x: 0, y: r.top - sr.top + scrollEl.scrollTop, below: true });
            }
          }}
        >
          <span style={{ opacity: 0.6 }}>Click to add a block, or press <kbd style={{ fontFamily: "var(--font-mono)", fontSize: 11, border: "1px solid var(--border)", padding: "1px 4px", borderRadius: 3 }}>/</kbd> anywhere</span>
        </div>
      </div>

      <InlineToolbar
        position={selection}
        onClose={() => setSelection(null)}
        onComment={() => { onAddComment(selection?.blockId); setSelection(null); }}
        savedRange={savedRange}
        setSavedRange={setSavedRange}
      />

      <SlashMenu
        position={slash}
        onPick={onPickBlock}
        onClose={() => setSlash(null)}
      />

      {selectedBlocks.length > 0 && (
        <SelectionBar
          count={selectedBlocks.length}
          onDuplicate={duplicateSelected}
          onDelete={deleteSelected}
          onCopy={copySelected}
          onClear={() => setSelectedBlocks([])}
        />
      )}
    </div>
  );
};

window.Editor = Editor;
