// ---------- Right pane: Outline / Comments / History ----------
const Outline = ({ blocks, activeId, onJump }) => {
  const headings = blocks
    .filter((b) => ["h1","h2","h3"].includes(b.kind))
    .map((b) => ({ id: b.id, level: parseInt(b.kind.slice(1), 10), text: (b.text || "").replace(/<[^>]*>/g,"") || "Untitled heading" }));

  if (headings.length === 0) {
    return (
      <div className="outline outline-v2">
        <div className="outline-label">On this page</div>
        <div style={{ padding: "6px 10px", fontSize: 12, color: "var(--text-faint)" }}>No headings yet.</div>
      </div>
    );
  }

  const minLevel = Math.min(...headings.map(h => h.level));

  return (
    <div className="outline outline-v2">
      <div className="outline-label">On this page</div>
      <div className="otl-list">
        <div className="otl-rail" aria-hidden="true" />
        {headings.map((h, i) => {
          const isActive = h.id === activeId;
          const isParent = h.level === minLevel;
          return (
            <button
              key={h.id}
              className={`otl-item level-${h.level} ${isParent ? "parent" : "child"} ${isActive ? "active" : ""}`}
              onClick={() => onJump(h.id)}
              title={h.text}
            >
              {isActive && <span className="otl-dot" />}
              <span className="otl-text">{h.text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

const Comment = ({ comment, onResolve, onReply }) => {
  const [reply, setReply] = React.useState("");
  return (
    <div className={`comment ${comment.resolved ? "resolved" : ""}`}>
      <div className="comment-head">
        <div className="avatar" style={{ background: comment.color }}>{comment.initials}</div>
        <span className="name">{comment.author}</span>
        <span className="time">{comment.time}</span>
      </div>
      <div className="comment-ref">on {comment.ref}</div>
      <div className="comment-body">{comment.body}</div>
      {comment.replies?.map((r, i) => (
        <div key={i} style={{ borderTop: "1px solid var(--border)", marginTop: 8, paddingTop: 8 }}>
          <div className="comment-head">
            <div className="avatar" style={{ background: r.color || "oklch(55% 0.1 260)" }}>{r.initials}</div>
            <span className="name">{r.author}</span>
            <span className="time">{r.time}</span>
          </div>
          <div className="comment-body">{r.body}</div>
        </div>
      ))}
      <div className="comment-actions">
        <button onClick={() => onResolve(comment.id)}>{comment.resolved ? "Reopen" : "Resolve"}</button>
        <button onClick={() => onReply(comment.id, reply)}>Reply</button>
      </div>
    </div>
  );
};

const Comments = ({ comments, setComments }) => {
  const [filter, setFilter] = React.useState("open"); // open | all | resolved
  const [draft, setDraft] = React.useState("");

  const visible = comments.filter((c) =>
    filter === "all" ? true :
    filter === "open" ? !c.resolved :
    c.resolved
  );

  const resolve = (id) =>
    setComments((cs) => cs.map((c) => c.id === id ? { ...c, resolved: !c.resolved } : c));

  const reply = () => {
    if (!draft.trim()) return;
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref: "General",
      body: draft, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setDraft("");
  };

  return (
    <div>
      <div style={{ display: "flex", gap: 4, padding: "10px 12px 4px" }}>
        {["open","all","resolved"].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: "4px 10px", fontSize: 11.5,
              borderRadius: 4,
              background: filter === f ? "var(--accent-soft)" : "transparent",
              color: filter === f ? "var(--accent-ink)" : "var(--text-muted)",
              textTransform: "capitalize", fontWeight: 500,
            }}
          >{f}</button>
        ))}
      </div>

      <div className="comment-list">
        {visible.map((c) => <Comment key={c.id} comment={c} onResolve={resolve} onReply={() => {}} />)}
        {visible.length === 0 && (
          <div style={{ padding: 16, textAlign: "center", color: "var(--text-faint)", fontSize: 12.5 }}>Nothing here yet.</div>
        )}
      </div>

      <div className="comment-reply-input">
        <input
          placeholder="Start a discussion…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") reply(); }}
        />
        <button className="tb-btn primary" style={{ height: 28 }} onClick={reply}>Post</button>
      </div>
    </div>
  );
};

const History = ({ groups }) => (
  <div className="history-list">
    {groups.map((g) => (
      <React.Fragment key={g.day}>
        <div className="history-day">{g.day}</div>
        {g.items.map((it) => (
          <div key={it.id} className={`history-item ${it.current ? "current" : ""}`}>
            <div className="history-dot" />
            <div>
              <div className="history-name">{it.name}</div>
              <div className="history-meta">{it.meta} · {it.who}</div>
              {it.msg && <div className="history-msg">{it.msg}</div>}
            </div>
          </div>
        ))}
      </React.Fragment>
    ))}
  </div>
);

const RightPane = ({ page, comments, setComments, history, openTab, setOpenTab, activeHeadingId, onJumpTo }) => {
  const openCount = comments.filter((c) => !c.resolved).length;
  return (
    <aside className="rightpane">
      <div className="rp-tabs">
        <button className={`rp-tab ${openTab === "outline" ? "active" : ""}`} onClick={() => setOpenTab("outline")}>
          <Icon name="menu" size={13} /> Outline
        </button>
        <button className={`rp-tab ${openTab === "comments" ? "active" : ""}`} onClick={() => setOpenTab("comments")}>
          <Icon name="comment" size={13} /> Comments
          {openCount > 0 && <span className="count">{openCount}</span>}
        </button>
        <button className={`rp-tab ${openTab === "history" ? "active" : ""}`} onClick={() => setOpenTab("history")}>
          <Icon name="history" size={13} /> History
        </button>
      </div>
      <div className="rp-body">
        {openTab === "outline" && <Outline blocks={page.blocks} activeId={activeHeadingId} onJump={onJumpTo} />}
        {openTab === "comments" && <Comments comments={comments} setComments={setComments} />}
        {openTab === "history" && <History groups={history} />}
      </div>
    </aside>
  );
};

window.RightPane = RightPane;
