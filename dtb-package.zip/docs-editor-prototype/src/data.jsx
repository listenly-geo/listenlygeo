// ---------- Seed data ----------
const uid = (() => { let i = 0; return (p="id") => `${p}_${++i}_${Math.random().toString(36).slice(2,6)}`; })();

const SPACES = [
  { id: "sp_product", name: "Product Docs", color: "oklch(55% 0.14 255)", count: 24, icon: "P" },
  { id: "sp_api",     name: "API Reference", color: "oklch(52% 0.15 155)", count: 12, icon: "A" },
  { id: "sp_internal",name: "Team Handbook", color: "oklch(55% 0.15 30)",  count: 31, icon: "H" },
];

// Pages: id, title, icon, children, content (blocks)
const PAGES = [
  {
    id: "p_intro", title: "Introduction", icon: "book", expanded: true,
    children: [
      { id: "p_welcome",  title: "Welcome to Lexicon", icon: "rocket" },
      { id: "p_concepts", title: "Core Concepts", icon: "compass" },
      { id: "p_install",  title: "Installation", icon: "page" },
    ],
  },
  {
    id: "p_guides", title: "Guides", icon: "folder", expanded: true,
    children: [
      { id: "p_quickstart", title: "Quickstart", icon: "bolt" },
      { id: "p_auth",       title: "Authentication", icon: "page" },
      { id: "p_webhooks",   title: "Webhooks", icon: "send" },
    ],
  },
  {
    id: "p_api", title: "API Reference", icon: "api", expanded: false,
    children: [
      { id: "p_docs_api",   title: "Documents", icon: "page" },
      { id: "p_blocks_api", title: "Blocks", icon: "page" },
      { id: "p_users_api",  title: "Users", icon: "page" },
    ],
  },
  {
    id: "p_changelog", title: "Changelog", icon: "history",
  },
];

const ACTIVE_PAGE_ID = "p_quickstart";

// Content by page id
const PAGE_CONTENT = {
  p_quickstart: {
    title: "Quickstart",
    subtitle: "Go from zero to a published page in under three minutes — no framework, no build step.",
    updated: "Apr 16, 2026",
    readTime: "4 min",
    author: { name: "Mira Okafor", role: "Docs Lead", initials: "MO", color: "oklch(60% 0.14 30)" },
    collaborators: [
      { initials: "MO", color: "oklch(60% 0.14 30)" },
      { initials: "JK", color: "oklch(55% 0.14 220)" },
      { initials: "RH", color: "oklch(55% 0.14 155)" },
    ],
    blocks: [
      { id: uid("b"), kind: "callout", variant: "info", title: "Before you start",
        text: "You'll need a Lexicon workspace and a personal access token. If you don't have one yet, create a workspace from the dashboard — it takes about 30 seconds." },

      { id: uid("b"), kind: "p",
        html: "This guide walks you through creating your first <strong>space</strong>, writing a page, and publishing it to a public URL. Every step happens inside the editor you're reading right now — no terminal required." },

      { id: uid("b"), kind: "h2", text: "1. Create a space" },
      { id: uid("b"), kind: "p",
        html: "Open the sidebar and click <em>New space</em>. A space holds a collection of related documents — it's the unit we publish. Give it a name like <code>Handbook</code> or <code>API</code> and pick an accent color." },

      { id: uid("b"), kind: "cards", items: [
        { ico: "book", title: "Product Docs", desc: "User-facing guides and concepts. Defaults to public." },
        { ico: "api",  title: "API Reference", desc: "Endpoints, parameters, and response examples." },
        { ico: "folder", title: "Team Handbook", desc: "Internal-only. Auth required to read." },
      ]},

      { id: uid("b"), kind: "h2", text: "2. Write your first page" },
      { id: uid("b"), kind: "p",
        html: "Press <code>/</code> anywhere in a page to open the block menu. Lexicon pages are made from typed blocks — headings, text, code, callouts, tables, and more. You can drag them to reorder, and every block has its own settings menu." },

      { id: uid("b"), kind: "tabs",
        tabs: [
          { id: "js", label: "JavaScript", lang: "javascript", code:
`import { Lexicon } from "@lexicon/sdk";

const client = new Lexicon({ token: process.env.LEX_TOKEN });

const page = await client.pages.create({
  space: "handbook",
  title: "Onboarding",
  blocks: [
    { kind: "h1", text: "Welcome aboard" },
    { kind: "p",  text: "Your first week, day by day." },
  ],
});` },
          { id: "py", label: "Python", lang: "python", code:
`from lexicon import Client

client = Client(token=os.environ["LEX_TOKEN"])

page = client.pages.create(
    space="handbook",
    title="Onboarding",
    blocks=[
        {"kind": "h1", "text": "Welcome aboard"},
        {"kind": "p",  "text": "Your first week, day by day."},
    ],
)` },
          { id: "curl", label: "cURL", lang: "bash", code:
`curl https://api.lexicon.dev/v1/pages \\
  -H "Authorization: Bearer $LEX_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "space": "handbook",
    "title": "Onboarding",
    "blocks": [{"kind":"h1","text":"Welcome aboard"}]
  }'` },
        ],
      },

      { id: uid("b"), kind: "callout", variant: "warn", title: "Tokens are secrets",
        text: "Never commit your access token. Use an environment variable or the secrets manager built into the settings panel." },

      { id: uid("b"), kind: "h2", text: "3. Publish" },
      { id: uid("b"), kind: "p",
        html: "Hit <kbd>Publish</kbd> in the top right. You'll get a live URL on the <code>lexicon.page</code> subdomain, or attach a custom domain from Settings → Domains." },

      { id: uid("b"), kind: "api",
        method: "POST", path: "/v1/spaces/{space_id}/publish",
        desc: "Builds the space and pushes a new public version. Idempotent — safe to retry.",
        params: [
          { name: "space_id", type: "string", desc: "The slug of the space to publish." },
          { name: "message",  type: "string?", desc: "Optional changelog note shown on the live site." },
          { name: "draft",    type: "boolean", desc: "If true, publishes to the staging URL instead of production." },
        ] },

      { id: uid("b"), kind: "h3", text: "What happens next" },
      { id: uid("b"), kind: "checklist", items: [
        { id: uid("c"), text: "Pages render to static HTML at the edge", done: true },
        { id: uid("c"), text: "Search index rebuilds from block content", done: true },
        { id: uid("c"), text: "Broken link checker runs across all pages", done: false },
        { id: uid("c"), text: "Slack and Discord webhooks fire (if configured)", done: false },
      ]},

      { id: uid("b"), kind: "figure",
        caption: "The publish pipeline takes around 4–12 seconds for a space of 50 pages. Cold starts are cached after the first deploy.",
        alt: "publish pipeline diagram" },

      { id: uid("b"), kind: "h2", text: "Going further" },
      { id: uid("b"), kind: "p",
        html: "Once published, you probably want to hook Lexicon into your code — either to sync docs from markdown files, or to render docs inside your own app." },

      { id: uid("b"), kind: "expand", title: "Syncing from GitHub",
        body: "Connect a GitHub repo from Settings → Integrations. Lexicon watches the branch you select and converts matching .md or .mdx files to blocks on every push. Conflicts between the editor and the repo surface as pull requests." },

      { id: uid("b"), kind: "expand", title: "Embedding pages in your app",
        body: "Use the read-only JSON feed at /v1/pages/:id.json. It returns the same block tree you see in the editor — render it with our React component or map it yourself." },

      { id: uid("b"), kind: "quote",
        html: "The nicest surprise was that our support team started writing docs. The block editor finally made it feel like writing, not configuring." },

      { id: uid("b"), kind: "embed",
        source: "YouTube", title: "Lexicon in 90 seconds", url: "youtube.com/@lexicon/quickstart" },

      { id: uid("b"), kind: "divider" },

      { id: uid("b"), kind: "h3", text: "Formula: search relevance" },
      { id: uid("b"), kind: "math",
        expr: { type: "bm25" } },

      { id: uid("b"), kind: "table",
        headers: ["Plan", "Pages", "Custom domain", "Price / month"],
        rows: [
          ["Starter", "Up to 100", "—", "$0"],
          ["Team", "Up to 2,000", "✓", "$29 / editor"],
          ["Scale", "Unlimited", "✓ + SSO", "Custom"],
        ] },

      { id: uid("b"), kind: "p",
        html: "That's it — you've shipped a docs site. Dig into <a href='#'>Authentication</a> next, or browse the <a href='#'>full block reference</a>." },
    ],
  },
};

// Outline: derive on the fly from h1/h2/h3 blocks.

const COMMENTS = [
  { id: "c1", author: "Jin Kovač", initials: "JK", color: "oklch(55% 0.14 220)",
    time: "2h ago", ref: "§ 2. Write your first page",
    body: "Can we mention the keyboard shortcut for the slash menu here? Most new users miss it on mobile.",
    replies: [
      { author: "Mira Okafor", initials: "MO", color: "oklch(60% 0.14 30)",
        time: "1h ago", body: "Good call — I'll add a note under the tab block. Mobile gets a dedicated toolbar row." },
    ],
    resolved: false,
  },
  { id: "c2", author: "Rhea Hassan", initials: "RH", color: "oklch(55% 0.14 155)",
    time: "yesterday", ref: "API: POST /v1/spaces/{space_id}/publish",
    body: "The 'draft' flag is misleading — internally we call it staging. Align the names?",
    replies: [],
    resolved: false,
  },
  { id: "c3", author: "Dmitri Walsh", initials: "DW", color: "oklch(50% 0.14 295)",
    time: "3d ago", ref: "Going further",
    body: "Love this section. Minor: the GitHub sync only supports main branch today, not any branch.",
    replies: [
      { author: "Mira Okafor", initials: "MO", color: "oklch(60% 0.14 30)",
        time: "2d ago", body: "Fixed — now reads 'the branch you select'." },
    ],
    resolved: true,
  },
];

const HISTORY = [
  { day: "Today",
    items: [
      { id: "v_now", name: "Current draft", meta: "auto-saved 12s ago", msg: "editing § Quickstart", who: "MO", current: true },
      { id: "v1", name: "Mira revised publish section", meta: "10:42 · 14 changes", msg: "Clarified staging URL behavior", who: "MO" },
      { id: "v2", name: "Jin merged comments", meta: "09:17 · 3 changes", msg: "Resolved RH's feedback on /draft", who: "JK" },
    ] },
  { day: "Yesterday",
    items: [
      { id: "v3", name: "Added GitHub sync callout", meta: "18:04 · 22 changes", msg: "New expandable block under 'Going further'", who: "MO" },
      { id: "v4", name: "Table: pricing tiers", meta: "14:31 · 8 changes", msg: "Updated Scale tier copy", who: "RH" },
    ] },
  { day: "Apr 14, 2026",
    items: [
      { id: "v5", name: "First draft published", meta: "11:02 · 146 changes", msg: "Initial Quickstart draft", who: "MO" },
    ] },
];

Object.assign(window, { uid, SPACES, PAGES, ACTIVE_PAGE_ID, PAGE_CONTENT, COMMENTS, HISTORY });
