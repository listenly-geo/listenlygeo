// ---------- Block renderer ----------
// Each block is a presentational React component. Most have editable text.

const SyntaxHighlight = ({ code, lang, onChange, editable = false }) => {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const rules = {
    javascript: [
      { re: /(\/\/[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?'|`.*?`)/g, cls: "tok-s" },
      { re: /\b(const|let|var|function|return|import|from|export|async|await|new|if|else|for|while|class|extends)\b/g, cls: "tok-k" },
      { re: /\b(\d+(?:\.\d+)?)\b/g, cls: "tok-n" },
      { re: /\b([A-Za-z_][A-Za-z0-9_]*)(?=\()/g, cls: "tok-f" },
    ],
    python: [
      { re: /(#[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?')/g, cls: "tok-s" },
      { re: /\b(def|class|import|from|return|if|else|elif|for|while|in|as|with|try|except|None|True|False|lambda)\b/g, cls: "tok-k" },
      { re: /\b(\d+(?:\.\d+)?)\b/g, cls: "tok-n" },
      { re: /\b([A-Za-z_][A-Za-z0-9_]*)(?=\()/g, cls: "tok-f" },
    ],
    bash: [
      { re: /(#[^\n]*)/g, cls: "tok-c" },
      { re: /(\".*?\"|'.*?')/g, cls: "tok-s" },
      { re: /(\$[A-Z_][A-Z0-9_]*)/g, cls: "tok-n" },
      { re: /\b(curl|echo|export|cd|ls|cat|grep|sed|awk)\b/g, cls: "tok-f" },
      { re: /(-[A-Za-z]+|--[A-Za-z-]+)/g, cls: "tok-k" },
    ],
  };
  const ruleset = rules[lang] || rules.javascript;
  const lines = code.split("\n");
  const render = (line) => {
    const tokens = [];
    ruleset.forEach(({ re, cls }) => {
      line.replace(re, (m, ...rest) => {
        const offset = rest[rest.length - 2];
        tokens.push({ start: offset, end: offset + m.length, cls, text: m });
      });
    });
    tokens.sort((a,b) => a.start - b.start);
    const clean = [];
    let lastEnd = -1;
    for (const t of tokens) {
      if (t.start >= lastEnd) { clean.push(t); lastEnd = t.end; }
    }
    let out = "", cur = 0;
    for (const t of clean) {
      out += esc(line.slice(cur, t.start));
      out += `<span class="${t.cls}">${esc(t.text)}</span>`;
      cur = t.end;
    }
    out += esc(line.slice(cur));
    return out || "\u200b";
  };

  if (editable) {
    // Editable textarea overlay — syntax-highlighted display + invisible textarea on top
    return (
      <div className="code-editor">
        <div className="code-body code-display" aria-hidden="true">
          {lines.map((ln, i) => (
            <span key={i} className="ln" dangerouslySetInnerHTML={{ __html: render(ln) }} />
          ))}
        </div>
        <textarea
          className="code-textarea"
          spellCheck={false}
          value={code}
          onChange={(e) => onChange && onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Tab") {
              e.preventDefault();
              const s = e.target.selectionStart;
              const en = e.target.selectionEnd;
              const v = code.slice(0, s) + "  " + code.slice(en);
              onChange && onChange(v);
              requestAnimationFrame(() => {
                e.target.selectionStart = e.target.selectionEnd = s + 2;
              });
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="code-body">
      {lines.map((ln, i) => (
        <span key={i} className="ln" dangerouslySetInnerHTML={{ __html: render(ln) }} />
      ))}
    </div>
  );
};

// Editable contenteditable helper that doesn't thrash the cursor.
const Editable = ({ html, onChange, className, placeholder, tag="div", ...rest }) => {
  const ref = React.useRef(null);
  const last = React.useRef(html);
  React.useEffect(() => {
    if (ref.current && ref.current.innerHTML !== html && last.current !== html) {
      ref.current.innerHTML = html || "";
      last.current = html;
    }
  }, [html]);
  const Tag = tag;
  const isEmpty = !html || html === "<br>" || html.replace(/<[^>]*>/g,"").trim() === "";
  return (
    <Tag
      ref={ref}
      className={className}
      contentEditable
      suppressContentEditableWarning
      data-empty={isEmpty ? "true" : "false"}
      data-placeholder={placeholder}
      dangerouslySetInnerHTML={{ __html: html || "" }}
      onInput={(e) => {
        last.current = e.currentTarget.innerHTML;
        onChange && onChange(e.currentTarget.innerHTML);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();

          const sel = window.getSelection();
          if (!sel || sel.rangeCount === 0) return;

          const range = sel.getRangeAt(0);
          range.deleteContents();

          const br = document.createElement("br");
          const marker = document.createTextNode("");
          range.insertNode(br);
          br.parentNode?.insertBefore(marker, br.nextSibling);

          range.setStartAfter(br);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);

          last.current = e.currentTarget.innerHTML;
          onChange && onChange(e.currentTarget.innerHTML);
        }
      }}
      {...rest}
    />
  );
};

// Small icon button used in many editors
const IconBtn = ({ name, onClick, title, size = 13, danger }) => (
  <button
    className="ibtn"
    title={title}
    onClick={onClick}
    style={danger ? { color: "oklch(55% 0.15 25)" } : undefined}
  >
    <Icon name={name} size={size} />
  </button>
);

// ---------- Individual block components ----------
const ParagraphBlock = ({ block, update }) => (
  <Editable tag="p" className="blk-content blk-p" html={block.html}
    placeholder="Write, or press / for commands"
    onChange={(h) => update({ html: h })} />
);

const HeadingBlock = ({ block, update, level }) => {
  const Tag = `h${level}`;
  return (
    <Editable tag={Tag} className={`blk-content blk-h${level}`} html={block.text}
      placeholder={`Heading ${level}`}
      onChange={(h) => update({ text: h })} />
  );
};

const QuoteBlock = ({ block, update }) => (
  <Editable tag="blockquote" className="blk-content blk-quote" html={block.html}
    placeholder="Quote"
    onChange={(h) => update({ html: h })} />
);

const DividerBlock = () => (
  <div className="blk-divider"><span className="mark">§</span></div>
);

const CodeBlock = ({ block, update }) => {
  const [copied, setCopied] = React.useState(false);
  const langs = ["javascript","python","bash","typescript","json","rust","go","sql"];
  return (
    <div className="blk-code">
      <div className="code-head">
        <select
          className="lang"
          value={block.lang || "javascript"}
          onChange={(e) => update({ lang: e.target.value })}
          style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", appearance: "none", padding: 0 }}
        >
          {langs.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
        <input
          className="filename"
          value={block.filename || "example.js"}
          onChange={(e) => update({ filename: e.target.value })}
          style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", outline: "none", flex: 1, minWidth: 0 }}
        />
        <button className="copy" onClick={() => {
          navigator.clipboard?.writeText(block.code || "");
          setCopied(true);
          setTimeout(() => setCopied(false), 1200);
        }}>{copied ? "copied" : "copy"}</button>
      </div>
      <SyntaxHighlight
        code={block.code || ""}
        lang={block.lang || "javascript"}
        editable
        onChange={(c) => update({ code: c })}
      />
    </div>
  );
};

const CalloutBlock = ({ block, update }) => {
  const variants = {
    info:   { ico: "info",  label: "Info" },
    warn:   { ico: "warn",  label: "Careful" },
    ok:     { ico: "check", label: "Tip" },
    danger: { ico: "warn",  label: "Warning" },
  };
  const v = variants[block.variant] || variants.info;
  const [menu, setMenu] = React.useState(false);
  return (
    <div className={`blk-callout ${block.variant || "info"}`}>
      <div className="callout-ico" onClick={(e) => { e.stopPropagation(); setMenu(!menu); }} style={{ cursor: "pointer", position: "relative" }}>
        <Icon name={v.ico} size={12} strokeWidth={2.5} />
        {menu && (
          <div className="callout-menu" onClick={(e) => e.stopPropagation()}>
            {Object.keys(variants).map((k) => (
              <button key={k} onClick={() => { update({ variant: k }); setMenu(false); }}>
                <span className={`callout-dot ${k}`} />{variants[k].label}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="callout-body">
        <Editable tag="div" className="callout-title-edit"
          html={block.title || ""}
          placeholder={v.label}
          onChange={(h) => update({ title: h })} />
        <Editable tag="div" className="blk-content" html={block.text}
          placeholder="Callout message"
          onChange={(h) => update({ text: h })} />
      </div>
    </div>
  );
};

// ---------- Figure (Image) block ----------
const FigureBlock = ({ block, update }) => {
  const [modalOpen, setModalOpen] = React.useState(false);

  return (
    <figure className="blk-figure">
      <div className="fig-img" onClick={(e) => { e.stopPropagation(); setModalOpen(true); }} style={{ cursor: "pointer" }}>
        {block.src ? (
          <img src={block.src} alt={block.alt || ""} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        ) : (
          <div className="placeholder">
            <Icon name="image" size={14} />
            <span style={{ marginLeft: 6 }}>Click to add image</span>
          </div>
        )}
      </div>
      <Editable tag="figcaption" className="fig-caption blk-content" html={block.caption}
        placeholder="Add a caption…"
        onChange={(h) => update({ caption: h })} />

      {modalOpen && (
        <ImageModal
          block={block}
          onSave={(patch) => { update(patch); setModalOpen(false); }}
          onClose={() => setModalOpen(false)}
        />
      )}
    </figure>
  );
};

const ImageModal = ({ block, onSave, onClose }) => {
  const [tab, setTab] = React.useState("url");
  const [url, setUrl] = React.useState(block.src || "");
  const [alt, setAlt] = React.useState(block.alt || "");
  const fileRef = React.useRef(null);

  const onFile = (f) => {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (e) => setUrl(e.target.result);
    reader.readAsDataURL(f);
  };

  return (
    <div className="lx-modal-bg" onMouseDown={onClose} onClick={(e) => e.stopPropagation()}>
      <div className="lx-modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="lx-modal-head">
          <h3>Image</h3>
          <button onClick={onClose} className="lx-modal-close">×</button>
        </div>
        <div className="lx-tab-bar">
          <button className={tab === "url" ? "on" : ""} onClick={() => setTab("url")}>From URL</button>
          <button className={tab === "upload" ? "on" : ""} onClick={() => setTab("upload")}>Upload</button>
        </div>

        {tab === "url" && (
          <div className="lx-field">
            <label>Image URL</label>
            <input autoFocus value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." />
          </div>
        )}

        {tab === "upload" && (
          <div
            className="lx-dropzone"
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add("drag"); }}
            onDragLeave={(e) => e.currentTarget.classList.remove("drag")}
            onDrop={(e) => {
              e.preventDefault();
              e.currentTarget.classList.remove("drag");
              onFile(e.dataTransfer.files[0]);
            }}
          >
            <Icon name="image" size={28} />
            <div style={{ marginTop: 10, fontSize: 13 }}>Drop an image or click to choose</div>
            <div style={{ fontSize: 11, color: "var(--text-faint)", marginTop: 4 }}>PNG, JPG, GIF, SVG up to 10 MB</div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }}
              onChange={(e) => onFile(e.target.files[0])} />
          </div>
        )}

        {url && (
          <div className="lx-preview">
            <img src={url} alt="" />
          </div>
        )}

        <div className="lx-field">
          <label>Alt text</label>
          <input value={alt} onChange={(e) => setAlt(e.target.value)} placeholder="Describe the image" />
        </div>

        <div className="lx-modal-foot">
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" onClick={() => onSave({ src: url, alt })} disabled={!url}>Save</button>
        </div>
      </div>
    </div>
  );
};

// ---------- Table with row/col add-remove ----------
const TableBlock = ({ block, update }) => {
  const headers = block.headers || [];
  const rows = block.rows || [];

  const setCell = (ri, ci, val) => {
    const nrows = rows.map((r, i) => i === ri ? r.map((c, j) => j === ci ? val : c) : r);
    update({ rows: nrows });
  };
  const setHeader = (ci, val) => {
    const nh = headers.map((h, i) => i === ci ? val : h);
    update({ headers: nh });
  };
  const addCol = (at) => {
    const nh = [...headers];
    nh.splice(at, 0, "New column");
    const nr = rows.map((r) => {
      const cp = [...r]; cp.splice(at, 0, ""); return cp;
    });
    update({ headers: nh, rows: nr });
  };
  const removeCol = (at) => {
    if (headers.length <= 1) return;
    const nh = headers.filter((_, i) => i !== at);
    const nr = rows.map((r) => r.filter((_, i) => i !== at));
    update({ headers: nh, rows: nr });
  };
  const addRow = (at) => {
    const nr = [...rows];
    nr.splice(at, 0, headers.map(() => ""));
    update({ rows: nr });
  };
  const removeRow = (at) => {
    if (rows.length <= 1) return;
    update({ rows: rows.filter((_, i) => i !== at) });
  };

  return (
    <div className="blk-table">
      <table>
        <thead>
          <tr>
            <th className="tbl-corner"></th>
            {headers.map((h, i) => (
              <th key={i} className="tbl-head-cell">
                <div
                  contentEditable suppressContentEditableWarning
                  onBlur={(e) => setHeader(i, e.currentTarget.textContent)}
                  dangerouslySetInnerHTML={{ __html: h }}
                />
                <div className="col-tools">
                  <button title="Insert column before" onClick={() => addCol(i)}>+◀</button>
                  <button title="Insert column after" onClick={() => addCol(i + 1)}>▶+</button>
                  <button title="Delete column" onClick={() => removeCol(i)}>✕</button>
                </div>
              </th>
            ))}
            <th className="tbl-add" onClick={() => addCol(headers.length)}>
              <Icon name="plus" size={12} />
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={ri}>
              <td className="tbl-row-handle">
                <button title="Delete row" onClick={() => removeRow(ri)}><Icon name="trash" size={11} /></button>
                <button title="Insert row below" onClick={() => addRow(ri + 1)}><Icon name="plus" size={11} /></button>
              </td>
              {r.map((c, ci) => (
                <td key={ci} contentEditable suppressContentEditableWarning
                  onBlur={(e) => setCell(ri, ci, e.currentTarget.textContent)}
                  dangerouslySetInnerHTML={{ __html: c }}
                />
              ))}
              <td />
            </tr>
          ))}
          <tr>
            <td className="tbl-add" colSpan={headers.length + 2} onClick={() => addRow(rows.length)}>
              <Icon name="plus" size={12} /><span style={{ marginLeft: 6 }}>Add row</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

// ---------- Tabs block (add/rename/remove + editable code) ----------
const TabsBlock = ({ block, update }) => {
  const tabs = block.tabs || [];
  const [active, setActive] = React.useState(tabs[0]?.id);
  const [editingLabel, setEditingLabel] = React.useState(null);

  React.useEffect(() => {
    if (!tabs.find((t) => t.id === active)) setActive(tabs[0]?.id);
  }, [tabs, active]);

  const cur = tabs.find((t) => t.id === active) || tabs[0];

  const updateTab = (id, patch) => {
    update({ tabs: tabs.map((t) => t.id === id ? { ...t, ...patch } : t) });
  };
  const addTab = () => {
    const nt = { id: uid("t"), label: "New tab", lang: "javascript", code: "// code here" };
    update({ tabs: [...tabs, nt] });
    setActive(nt.id);
  };
  const removeTab = (id) => {
    if (tabs.length <= 1) return;
    update({ tabs: tabs.filter((t) => t.id !== id) });
  };

  if (!cur) return null;

  return (
    <div className="blk-tabs">
      <div className="tabs-head">
        {tabs.map((t) => (
          <div key={t.id} className={`tab ${t.id === cur.id ? "active" : ""}`}
            onClick={() => setActive(t.id)}
            onDoubleClick={() => setEditingLabel(t.id)}
          >
            {editingLabel === t.id ? (
              <input
                autoFocus
                className="tab-rename"
                defaultValue={t.label}
                onBlur={(e) => { updateTab(t.id, { label: e.target.value || "Tab" }); setEditingLabel(null); }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") { updateTab(t.id, { label: e.target.value || "Tab" }); setEditingLabel(null); }
                  if (e.key === "Escape") setEditingLabel(null);
                }}
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <span onClick={(e) => { if (t.id === cur.id) { e.stopPropagation(); setEditingLabel(t.id); } }}>{t.label}</span>
            )}
            {tabs.length > 1 && (
              <button className="tab-close" onClick={(e) => { e.stopPropagation(); removeTab(t.id); }}>×</button>
            )}
          </div>
        ))}
        <button className="tab-add" onClick={addTab} title="Add tab"><Icon name="plus" size={12} /></button>
      </div>
      <div className="tabs-body">
        <div className="blk-code" style={{ margin: 0 }}>
          <div className="code-head">
            <select
              className="lang"
              value={cur.lang}
              onChange={(e) => updateTab(cur.id, { lang: e.target.value })}
              style={{ background: "transparent", border: 0, color: "inherit", font: "inherit", appearance: "none", padding: 0 }}
            >
              {["javascript","python","bash","typescript","json","rust","go","sql"].map((l) =>
                <option key={l} value={l}>{l}</option>
              )}
            </select>
            <span className="filename">example.{cur.lang === "python" ? "py" : cur.lang === "bash" ? "sh" : "js"}</span>
          </div>
          <SyntaxHighlight
            code={cur.code}
            lang={cur.lang}
            editable
            onChange={(c) => updateTab(cur.id, { code: c })}
          />
        </div>
      </div>
    </div>
  );
};

// ---------- Expandable block (editable title + body) ----------
const ExpandBlock = ({ block, update }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <div className={`blk-expand ${open ? "open" : ""}`}>
      <div className="expand-head">
        <span className="expand-chev" onClick={() => setOpen(!open)}><Icon name="chevronRight" size={14} /></span>
        <Editable tag="div" className="expand-title"
          html={block.title || ""}
          placeholder="Click to expand"
          onChange={(h) => update({ title: h })}
          onClick={(e) => e.stopPropagation()}
        />
      </div>
      {open && (
        <div className="expand-body">
          <Editable tag="div" className="blk-content"
            html={block.body || ""}
            placeholder="Hidden content — type anything here"
            onChange={(h) => update({ body: h })}
          />
        </div>
      )}
    </div>
  );
};

// ---------- Cards block (add/edit/remove) ----------
const CardsBlock = ({ block, update }) => {
  const items = block.items || [];
  const setItem = (i, patch) => {
    update({ items: items.map((it, idx) => idx === i ? { ...it, ...patch } : it) });
  };
  const addCard = () => update({ items: [...items, { ico: "book", title: "New card", desc: "Short description" }] });
  const removeCard = (i) => update({ items: items.filter((_, idx) => idx !== i) });

  const ICOS = ["book","api","folder","bolt","page","compass","send","rocket","code","globe"];

  return (
    <div className="blk-cards">
      {items.map((c, i) => (
        <div key={i} className="blk-card editable">
          <div className="card-tools">
            <button title="Remove card" onClick={() => removeCard(i)}><Icon name="trash" size={11} /></button>
          </div>
          <select
            className="card-ico card-ico-select"
            value={c.ico || "book"}
            onChange={(e) => setItem(i, { ico: e.target.value })}
            title="Icon"
          >
            {ICOS.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
          <div className="card-ico-preview"><Icon name={c.ico || "book"} size={16} /></div>
          <Editable tag="div" className="card-title"
            html={c.title}
            placeholder="Card title"
            onChange={(h) => setItem(i, { title: h })} />
          <Editable tag="div" className="card-desc"
            html={c.desc}
            placeholder="Short description"
            onChange={(h) => setItem(i, { desc: h })} />
          <div className="card-arrow">Learn more <Icon name="chevronRight" size={12} /></div>
        </div>
      ))}
      <button className="blk-card card-add" onClick={addCard}>
        <Icon name="plus" size={18} />
        <div style={{ fontSize: 12, marginTop: 6, color: "var(--text-muted)" }}>Add card</div>
      </button>
    </div>
  );
};

// ---------- API block (editable method/path/desc/params) ----------
const ApiBlock = ({ block, update }) => {
  const METHODS = ["GET","POST","PUT","PATCH","DELETE"];
  const params = block.params || [];
  const setParam = (i, patch) => {
    update({ params: params.map((p, idx) => idx === i ? { ...p, ...patch } : p) });
  };
  const addParam = () => update({ params: [...params, { name: "param", type: "string", desc: "Description" }] });
  const removeParam = (i) => update({ params: params.filter((_, idx) => idx !== i) });

  return (
    <div className="blk-api">
      <div className="api-head">
        <select
          className={`api-method ${block.method}`}
          value={block.method}
          onChange={(e) => update({ method: e.target.value })}
        >
          {METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <input
          className="api-path api-path-input"
          value={block.path || ""}
          onChange={(e) => update({ path: e.target.value })}
          placeholder="/v1/resource"
        />
        <button className="copy" style={{ color: "var(--text-faint)", fontSize: "10.5px" }}>try →</button>
      </div>
      <Editable tag="div" className="api-body blk-content"
        html={block.desc}
        placeholder="Describe the endpoint"
        onChange={(h) => update({ desc: h })}
      />
      <div className="api-params">
        <div>Parameter</div><div>Type</div><div>Description</div>
        {params.map((p, i) => (
          <React.Fragment key={i}>
            <div className="api-param-cell">
              <input
                value={p.name}
                onChange={(e) => setParam(i, { name: e.target.value })}
                placeholder="name"
              />
              <button className="api-param-rm" onClick={() => removeParam(i)} title="Remove"><Icon name="trash" size={10} /></button>
            </div>
            <div>
              <input
                className="param-type"
                value={p.type}
                onChange={(e) => setParam(i, { type: e.target.value })}
                placeholder="string"
              />
            </div>
            <div>
              <input
                className="param-desc"
                value={p.desc}
                onChange={(e) => setParam(i, { desc: e.target.value })}
                placeholder="What it does"
              />
            </div>
          </React.Fragment>
        ))}
      </div>
      <button className="api-add-param" onClick={addParam}>
        <Icon name="plus" size={12} /> <span style={{ marginLeft: 6 }}>Add parameter</span>
      </button>
    </div>
  );
};

const MathBlock = ({ block }) => {
  if (block.expr?.type === "bm25") {
    return (
      <div className="blk-math">
        score(D, Q) = ∑<span className="sub">i</span>&thinsp; IDF(q<span className="sub">i</span>) ·&nbsp;
        <span className="frac">
          <span className="num">f(q<span className="sub">i</span>, D) · (k<span className="sub">1</span> + 1)</span>
          <span className="den">f(q<span className="sub">i</span>, D) + k<span className="sub">1</span> · (1 − b + b · |D|/avgdl)</span>
        </span>
      </div>
    );
  }
  return <div className="blk-math">{block.expr?.raw || "Math expression"}</div>;
};

const EmbedBlock = ({ block }) => (
  <div className="blk-embed">
    <div className="embed-thumb"><Icon name="play" size={22} /></div>
    <div className="embed-meta">
      <div className="embed-src">{block.source}</div>
      <div className="embed-title">{block.title}</div>
      <div className="embed-url">{block.url}</div>
    </div>
    <button className="tb-btn" title="Open"><Icon name="external" size={14} /></button>
  </div>
);

const ChecklistBlock = ({ block, update }) => (
  <div className="blk-checklist">
    {block.items.map((item, i) => (
      <div key={item.id} className={`check-row ${item.done ? "done" : ""}`}>
        <div className={`check-box ${item.done ? "done" : ""}`}
          onClick={() => {
            const items = block.items.map((it, idx) => idx === i ? { ...it, done: !it.done } : it);
            update({ items });
          }}>
          {item.done && <Icon name="check" size={11} strokeWidth={3} />}
        </div>
        <Editable tag="div" className="check-text blk-content" html={item.text}
          placeholder="List item"
          onChange={(h) => {
            const items = block.items.map((it, idx) => idx === i ? { ...it, text: h } : it);
            update({ items });
          }} />
      </div>
    ))}
  </div>
);

// Registry for slash menu + rendering
const BLOCK_SPECS = [
  { kind: "h1",        group: "Structure", title: "Heading 1",     desc: "Big section title",              icon: "h1",       kbd: "/h1",    make: () => ({ kind: "h1", text: "" }) },
  { kind: "h2",        group: "Structure", title: "Heading 2",     desc: "Mid-level section heading",      icon: "h2",       kbd: "/h2",    make: () => ({ kind: "h2", text: "" }) },
  { kind: "h3",        group: "Structure", title: "Heading 3",     desc: "Subsection heading",             icon: "h3",       kbd: "/h3",    make: () => ({ kind: "h3", text: "" }) },
  { kind: "p",         group: "Text",      title: "Text",          desc: "Plain paragraph",                icon: "text",     kbd: "/text",  make: () => ({ kind: "p",  html: "" }) },
  { kind: "quote",     group: "Text",      title: "Quote",         desc: "Callout for emphasis or pull-quote", icon: "quote",kbd: "/quote", make: () => ({ kind: "quote", html: "" }) },
  { kind: "divider",   group: "Text",      title: "Divider",       desc: "A horizontal rule",              icon: "divider",  kbd: "/---",   make: () => ({ kind: "divider" }) },
  { kind: "code",      group: "Code",      title: "Code block",    desc: "Syntax-highlighted snippet",     icon: "code",     kbd: "/code",  make: () => ({ kind: "code", lang: "javascript", filename: "example.js", code: "// your code" }) },
  { kind: "api",       group: "Code",      title: "API endpoint",  desc: "Method, path, params",           icon: "api",      kbd: "/api",   make: () => ({ kind: "api", method: "GET", path: "/v1/resource", desc: "Describe the endpoint.", params: [{ name: "id", type: "string", desc: "The resource ID" }] }) },
  { kind: "callout",   group: "Media",     title: "Callout",        desc: "Info, warning, tip, or danger", icon: "callout",  kbd: "/note",  make: () => ({ kind: "callout", variant: "info", title: "Note", text: "" }) },
  { kind: "figure",    group: "Media",     title: "Image",          desc: "Upload or paste a URL",         icon: "image",    kbd: "/img",   make: () => ({ kind: "figure", alt: "", caption: "" }) },
  { kind: "table",     group: "Media",     title: "Table",          desc: "Grid of rows and columns",      icon: "table",    kbd: "/table", make: () => ({ kind: "table", headers: ["Column A","Column B","Column C"], rows: [["","",""],["","",""]] }) },
  { kind: "tabs",      group: "Media",     title: "Tabs",           desc: "Switch between code examples", icon: "tabs",     kbd: "/tabs",  make: () => ({ kind: "tabs", tabs: [{ id: uid("t"), label: "JavaScript", lang: "javascript", code: "// new" }, { id: uid("t"), label: "Python", lang: "python", code: "# new" }] }) },
  { kind: "expand",    group: "Media",     title: "Expandable",     desc: "Click-to-open section",         icon: "expand",   kbd: "/toggle",make: () => ({ kind: "expand", title: "Read more", body: "Hidden content" }) },
  { kind: "cards",     group: "Media",     title: "Cards grid",     desc: "Grid of linkable cards",        icon: "card",     kbd: "/cards", make: () => ({ kind: "cards", items: [{ ico: "book", title: "Card A", desc: "Short description" }, { ico: "api", title: "Card B", desc: "Short description" }] }) },
  { kind: "math",      group: "Advanced",  title: "Math block",     desc: "LaTeX-style formula",           icon: "math",     kbd: "/math",  make: () => ({ kind: "math", expr: { raw: "E = mc²" } }) },
  { kind: "embed",     group: "Advanced",  title: "Embed",          desc: "YouTube, Figma, Loom…",         icon: "embed",    kbd: "/embed", make: () => ({ kind: "embed", source: "YouTube", title: "Embedded", url: "youtube.com/…" }) },
  { kind: "checklist", group: "Advanced",  title: "Checklist",      desc: "Tracked tasks",                 icon: "checklist",kbd: "/todo",  make: () => ({ kind: "checklist", items: [{ id: uid("c"), text: "Task", done: false }] }) },
];

// Map kind → component
const renderBlock = (block, update) => {
  switch (block.kind) {
    case "p":         return <ParagraphBlock block={block} update={update} />;
    case "h1":        return <HeadingBlock block={block} update={update} level={1} />;
    case "h2":        return <HeadingBlock block={block} update={update} level={2} />;
    case "h3":        return <HeadingBlock block={block} update={update} level={3} />;
    case "quote":     return <QuoteBlock block={block} update={update} />;
    case "divider":   return <DividerBlock />;
    case "code":      return <CodeBlock block={block} update={update} />;
    case "callout":   return <CalloutBlock block={block} update={update} />;
    case "figure":    return <FigureBlock block={block} update={update} />;
    case "table":     return <TableBlock block={block} update={update} />;
    case "tabs":      return <TabsBlock block={block} update={update} />;
    case "expand":    return <ExpandBlock block={block} update={update} />;
    case "cards":     return <CardsBlock block={block} update={update} />;
    case "api":       return <ApiBlock block={block} update={update} />;
    case "math":      return <MathBlock block={block} />;
    case "embed":     return <EmbedBlock block={block} />;
    case "checklist": return <ChecklistBlock block={block} update={update} />;
    default: return <div style={{ color: "var(--text-faint)" }}>Unknown block: {block.kind}</div>;
  }
};

Object.assign(window, { BLOCK_SPECS, renderBlock, Editable, SyntaxHighlight });
