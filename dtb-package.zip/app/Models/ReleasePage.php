<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ReleasePage extends Model
{
    use HasFactory;

    protected $fillable = [
        'release_id',
        'page_id',
        'space_id',
        'space_name',
        'title',
        'subtitle',
        'path',
        'parent_path',
        'position',
        'blocks_json',
        'search_document',
    ];

    protected function casts(): array
    {
        return [
            'blocks_json' => 'array',
        ];
    }

    public function release(): BelongsTo
    {
        return $this->belongsTo(Release::class);
    }

    public function page(): BelongsTo
    {
        return $this->belongsTo(Page::class);
    }

    public function space(): BelongsTo
    {
        return $this->belongsTo(Space::class);
    }
}
