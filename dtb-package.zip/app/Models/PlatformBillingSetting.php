<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlatformBillingSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'provider',
        'mode',
        'status',
        'public_key',
        'secret_key',
        'webhook_endpoint',
        'webhook_secret',
        'metadata_json',
    ];

    protected function casts(): array
    {
        return [
            'secret_key' => 'encrypted',
            'webhook_secret' => 'encrypted',
            'metadata_json' => 'array',
        ];
    }
}
