<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrganizationSubscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'organization_id',
        'plan',
        'interval',
        'status',
        'stripe_subscription_id',
        'stripe_price_id',
        'stripe_checkout_session_id',
        'cancel_at_period_end',
        'current_period_starts_at',
        'current_period_ends_at',
        'stripe_synced_at',
    ];

    protected function casts(): array
    {
        return [
            'cancel_at_period_end' => 'boolean',
            'current_period_starts_at' => 'datetime',
            'current_period_ends_at' => 'datetime',
            'stripe_synced_at' => 'datetime',
        ];
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function subscriptionPlan(): BelongsTo
    {
        return $this->belongsTo(SubscriptionPlan::class, 'plan', 'slug');
    }
}
