<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Addon extends Model
{
    protected $fillable = [
        'slug',
        'name',
        'required_files',
        'enabled',
        'token',
        'installed_at',
    ];

    protected function casts(): array
    {
        return [
            'required_files' => 'array',
            'enabled' => 'boolean',
            'installed_at' => 'datetime',
        ];
    }

    /**
     * Check whether the addon is truly active by re-verifying the stored HMAC.
     * A manual DB flip of `enabled = true` without a valid token returns false.
     */
    public function isVerifiedEnabled(): bool
    {
        if (! $this->enabled || ! $this->token) {
            return false;
        }

        $expected = self::generateToken($this->slug, $this->name);

        return hash_equals($expected, $this->token);
    }

    /**
     * Generate an HMAC token for the given slug + name combination.
     * The signing key lives in ADDON_SIGNING_KEY (.env) and is never committed.
     */
    public static function generateToken(string $slug, string $name): string
    {
        $key = config('addons.signing_key');

        if (empty($key)) {
            throw new \RuntimeException('ADDON_SIGNING_KEY is not configured.');
        }

        return hash_hmac('sha256', $slug.'|'.$name, $key);
    }
}
