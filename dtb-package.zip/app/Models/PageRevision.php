<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PageRevision extends Model
{
    use HasFactory;

    protected $fillable = [
        'page_id',
        'version_number',
        'title',
        'subtitle',
        'blocks_json',
        'editor_meta_json',
        'search_document',
        'save_type',
        'change_message',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'blocks_json' => 'array',
            'editor_meta_json' => 'array',
        ];
    }

    public function page(): BelongsTo
    {
        return $this->belongsTo(Page::class);
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function comments(): HasMany
    {
        return $this->hasMany(PageComment::class, 'revision_id');
    }
}
