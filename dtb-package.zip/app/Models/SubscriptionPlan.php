<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SubscriptionPlan extends Model
{
    use HasFactory;

    protected $fillable = [
        'slug',
        'label',
        'description',
        'status',
        'monthly_price_cents',
        'annual_price_cents',
        'included_sites',
        'included_members',
        'included_published_pages',
        'included_storage_bytes',
        'sort_order',
        'is_featured',
        'stripe_product_id',
        'stripe_monthly_price_id',
        'stripe_annual_price_id',
        'stripe_synced_at',
    ];

    protected function casts(): array
    {
        return [
            'monthly_price_cents' => 'integer',
            'annual_price_cents' => 'integer',
            'included_sites' => 'integer',
            'included_members' => 'integer',
            'included_published_pages' => 'integer',
            'included_storage_bytes' => 'integer',
            'sort_order' => 'integer',
            'is_featured' => 'boolean',
            'stripe_synced_at' => 'datetime',
        ];
    }

    public function organizationSubscriptions(): HasMany
    {
        return $this->hasMany(OrganizationSubscription::class, 'plan', 'slug');
    }
}
