<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Site extends Model
{
    use HasFactory;

    protected $fillable = [
        'organization_id',
        'uuid',
        'name',
        'slug',
        'visibility',
        'status',
        'default_space_id',
        'current_release_id',
        'settings_json',
        'created_by',
        'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'settings_json' => 'array',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Site $site): void {
            if (! $site->uuid) {
                $site->uuid = (string) Str::uuid();
            }
        });
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function defaultSpace(): BelongsTo
    {
        return $this->belongsTo(Space::class, 'default_space_id');
    }

    public function currentRelease(): BelongsTo
    {
        return $this->belongsTo(Release::class, 'current_release_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function domains(): HasMany
    {
        return $this->hasMany(SiteDomain::class);
    }

    public function spaces(): HasMany
    {
        return $this->hasMany(Space::class);
    }

    public function pages(): HasMany
    {
        return $this->hasMany(Page::class);
    }

    public function releases(): HasMany
    {
        return $this->hasMany(Release::class);
    }

    public function mediaAssets(): HasMany
    {
        return $this->hasMany(MediaAsset::class);
    }
}
