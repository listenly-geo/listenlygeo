<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Space extends Model
{
    use HasFactory;

    protected $fillable = [
        'site_id',
        'uuid',
        'name',
        'slug',
        'icon',
        'color',
        'position',
        'created_by',
        'updated_by',
    ];

    protected static function booted(): void
    {
        static::creating(function (Space $space): void {
            if (! $space->uuid) {
                $space->uuid = (string) Str::uuid();
            }
        });
    }

    public function site(): BelongsTo
    {
        return $this->belongsTo(Site::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function pages(): HasMany
    {
        return $this->hasMany(Page::class);
    }
}
