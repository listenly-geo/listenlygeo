<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrganizationUsageCounter extends Model
{
    use HasFactory;

    protected $fillable = [
        'organization_id',
        'site_count',
        'member_count',
        'published_page_count',
        'storage_bytes',
    ];

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }
}
