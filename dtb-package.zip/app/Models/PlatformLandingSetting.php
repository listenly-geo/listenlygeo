<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlatformLandingSetting extends Model
{
    protected $fillable = [
        'copyright_text',
        'social_links',
    ];

    protected $casts = [
        'social_links' => 'array',
    ];

    protected $table = 'platform_landing_settings';
}
