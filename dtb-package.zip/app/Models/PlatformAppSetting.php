<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlatformAppSetting extends Model
{
    protected $fillable = [
        'app_name',
        'logo_path',
        'favicon_path',
    ];

    protected $table = 'platform_app_settings';
}
