<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlatformLandingContent extends Model
{
    protected $fillable = [
        'section',
        'label',
        'kicker',
        'title',
        'subtitle',
        'description',
        'data',
        'is_active',
    ];

    protected $casts = [
        'data' => 'array',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $table = 'platform_landing_contents';
}
