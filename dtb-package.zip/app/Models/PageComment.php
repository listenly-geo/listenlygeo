<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PageComment extends Model
{
    use HasFactory;

    protected $fillable = [
        'page_id',
        'revision_id',
        'block_id',
        'author_id',
        'body',
        'selection_json',
        'resolved_at',
        'resolved_by',
    ];

    protected function casts(): array
    {
        return [
            'selection_json' => 'array',
            'resolved_at' => 'datetime',
        ];
    }

    public function page(): BelongsTo
    {
        return $this->belongsTo(Page::class);
    }

    public function revision(): BelongsTo
    {
        return $this->belongsTo(PageRevision::class, 'revision_id');
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function resolver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }

    public function replies(): HasMany
    {
        return $this->hasMany(PageCommentReply::class, 'comment_id');
    }
}
