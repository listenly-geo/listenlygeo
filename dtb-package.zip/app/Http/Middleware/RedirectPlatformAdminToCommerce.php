<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RedirectPlatformAdminToCommerce
{
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->user()?->is_platform_admin === true) {
            abort_unless($request->isMethod('GET'), 403);

            return redirect()->route('admin.dashboard');
        }

        return $next($request);
    }
}
