<?php

namespace App\Http\Middleware;

use App\Models\Addon;
use App\Models\PlatformAppSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that's loaded on the first page visit.
     *
     * @see https://inertiajs.com/server-side-setup#root-template
     *
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determines the current asset version.
     *
     * @see https://inertiajs.com/asset-versioning
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Pass extra data to the root Blade view (for favicon / title in <head>).
     */
    public function viewData(Request $request): array
    {
        $appSetting = PlatformAppSetting::query()->first();

        return [
            'faviconUrl' => $appSetting?->favicon_path
                ? Storage::url($appSetting->favicon_path)
                : null,
            'logoUrl' => $appSetting?->logo_path
                ? Storage::url($appSetting->logo_path)
                : null,
            'appDisplayName' => $appSetting?->app_name
                ? $appSetting->app_name
                : config('app.name', 'App'),
        ];
    }

    /**
     * Define the props that are shared by default.
     *
     * @see https://inertiajs.com/shared-data
     *
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        $user = $request->user();
        $appSetting = PlatformAppSetting::query()->first();

        return [
            ...parent::share($request),
            'name' => config('app.name'),
            'appBranding' => [
                'appName' => $appSetting?->app_name ?: config('app.name', 'App'),
                'logoUrl' => $appSetting?->logo_path ? Storage::url($appSetting->logo_path) : null,
                'faviconUrl' => $appSetting?->favicon_path ? Storage::url($appSetting->favicon_path) : null,
            ],
            'auth' => [
                'user' => $user ? [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'email_verified_at' => $user->email_verified_at,
                    'created_at' => $user->created_at,
                    'updated_at' => $user->updated_at,
                    'isPlatformAdmin' => $user->is_platform_admin,
                    'is_platform_admin' => $user->is_platform_admin,
                    'two_factor_enabled' => filled($user->two_factor_secret),
                ] : null,
            ],
            'sidebarOpen' => ! $request->hasCookie('sidebar_state') || $request->cookie('sidebar_state') === 'true',
            'addons' => $this->resolveAddons(),
        ];
    }

    /**
     * Returns a map of addon slug → bool where each value is only true when
     * the stored HMAC token re-verifies against ADDON_SIGNING_KEY.
     * A manual DB flip of `enabled = true` without a valid token stays false.
     *
     * @return array<string, bool>
     */
    private function resolveAddons(): array
    {
        // Only load addons when the signing key is configured.
        if (empty(config('addons.signing_key'))) {
            return [];
        }

        return Addon::query()
            ->select(['slug', 'name', 'enabled', 'token'])
            ->get()
            ->mapWithKeys(fn (Addon $addon) => [$addon->slug => $addon->isVerifiedEnabled()])
            ->all();
    }
}
