<?php

namespace App\Http\Controllers;

use App\Actions\Docs\ExportSiteProject;
use App\Models\Site;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Throwable;

class DashboardSiteExportController extends Controller
{
    public function __construct(
        private readonly ExportSiteProject $exportSiteProject,
    ) {}

    public function __invoke(Request $request, Site $site, string $format): BinaryFileResponse
    {
        Gate::authorize('update', $site);

        try {
            $archive = ($this->exportSiteProject)($site, $format);
        } catch (Throwable $exception) {
            report($exception);
            abort(500, 'Site export failed. Please try again.');
        }

        return response()
            ->download($archive['path'], $archive['filename'], [
                'Content-Type' => $archive['contentType'],
            ])
            ->deleteFileAfterSend(true);
    }
}
