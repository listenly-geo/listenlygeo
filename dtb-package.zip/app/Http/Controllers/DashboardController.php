<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Models\Organization;
use App\Models\Page;
use App\Models\PageRevision;
use App\Models\Site;
use App\Models\Space;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
    ) {}

    public function __invoke(Request $request): Response
    {
        $bootstrap = ($this->ensureEditorWorkspace)($request->user());

        $organization = Organization::query()
            ->with('usageCounter')
            ->findOrFail($bootstrap['organization']['id']);

        $siteIds = $organization->sites()->pluck('id');
        $totalSites = $siteIds->count();
        $totalSpaces = Space::query()->whereIn('site_id', $siteIds)->count();
        $totalPages = Page::query()->whereIn('site_id', $siteIds)->count();
        $totalMembers = $organization->memberships()->where('status', 'active')->count();
        $totalPublishedPages = Page::query()
            ->whereIn('site_id', $siteIds)
            ->whereNotNull('published_revision_id')
            ->count();
        $totalMediaAssets = $organization->mediaAssets()->count();

        $primarySite = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'defaultSpace:id,site_id,name',
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount(['spaces', 'pages', 'domains'])
            ->orderBy('id')
            ->firstOrFail();

        $spaces = $primarySite->spaces()
            ->withCount('pages')
            ->withCount([
                'pages as published_pages_count' => fn ($query) => $query->whereNotNull('published_revision_id'),
                'pages as unpublished_pages_count' => fn ($query) => $query->whereNull('published_revision_id'),
            ])
            ->orderBy('position')
            ->get()
            ->map(fn (Space $space) => [
                'id' => $space->id,
                'name' => $space->name,
                'slug' => $space->slug,
                'icon' => $space->icon ?: 'space',
                'color' => $space->color ?: 'oklch(55% 0.14 255)',
                'pagesCount' => $space->pages_count,
                'publishedPagesCount' => $space->published_pages_count,
                'unpublishedPagesCount' => $space->unpublished_pages_count,
            ])
            ->values()
            ->all();

        $activity = PageRevision::query()
            ->whereHas('page', fn ($query) => $query->where('site_id', $primarySite->id))
            ->with([
                'page:id,title,path',
                'author:id,name',
            ])
            ->latest('id')
            ->limit(6)
            ->get()
            ->map(fn (PageRevision $revision) => [
                'id' => $revision->id,
                'title' => $revision->title ?: $revision->page?->title ?: 'Untitled',
                'path' => $revision->page?->path,
                'message' => $revision->change_message ?: 'Draft updated',
                'saveType' => $revision->save_type,
                'author' => $revision->author?->name ?: $request->user()->name,
                'createdAt' => $revision->created_at?->toIso8601String(),
            ])
            ->values()
            ->all();

        $structureCustomized = $totalSites > 1 || $primarySite->spaces_count > 1 || $primarySite->pages_count > 1;

        $onboardingSteps = [
            [
                'id' => 'structure',
                'title' => 'Shape the starter structure',
                'description' => 'Add spaces or pages so the scaffold reflects the real product information architecture.',
                'href' => '/dashboard/sites',
                'actionLabel' => 'Open sites & spaces',
                'completed' => $structureCustomized,
            ],
            [
                'id' => 'release',
                'title' => 'Publish the first release',
                'description' => 'Create the first immutable snapshot so public docs resolve to a real release instead of draft-only state.',
                'href' => '/dashboard/releases',
                'actionLabel' => 'Open releases',
                'completed' => $totalPublishedPages > 0,
            ],
            [
                'id' => 'media',
                'title' => 'Upload shared media',
                'description' => 'Seed the media library with images or files that documentation pages can reuse.',
                'href' => '/dashboard/media',
                'actionLabel' => 'Open media library',
                'completed' => $totalMediaAssets > 0,
            ],
            [
                'id' => 'team',
                'title' => 'Add collaborators',
                'description' => 'Bring another member into the workspace before editing and publishing become team workflows.',
                'href' => '/dashboard/team',
                'actionLabel' => 'Open team & roles',
                'completed' => $totalMembers > 1,
            ],
            [
                'id' => 'domain',
                'title' => 'Connect a custom domain',
                'description' => 'Configure the branded hostname and public surface that should front the published docs.',
                'href' => '/dashboard/settings',
                'actionLabel' => 'Open settings',
                'completed' => $primarySite->domains_count > 0,
            ],
        ];

        $completedOnboardingSteps = collect($onboardingSteps)
            ->where('completed', true)
            ->count();

        return Inertia::render('dashboard', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
            ],
            'summary' => [
                'totalSites' => $totalSites,
                'totalSpaces' => $totalSpaces,
                'totalPages' => $totalPages,
                'totalMembers' => $totalMembers,
                'totalPublishedPages' => $totalPublishedPages,
                'storageBytes' => (int) ($organization->usageCounter?->storage_bytes ?? 0),
            ],
            'primarySite' => [
                'name' => $primarySite->name,
                'slug' => $primarySite->slug,
                'status' => $primarySite->status,
                'visibility' => $primarySite->visibility,
                'defaultSpaceName' => $primarySite->defaultSpace?->name,
                'spacesCount' => $primarySite->spaces_count,
                'pagesCount' => $primarySite->pages_count,
                'domainsCount' => $primarySite->domains_count,
                'currentReleaseVersion' => $primarySite->currentRelease?->version,
                'currentReleasePublishedAt' => $primarySite->currentRelease?->published_at?->toIso8601String(),
                'lastEditedAt' => $activity[0]['createdAt'] ?? null,
            ],
            'onboarding' => [
                'isFreshWorkspace' => $totalSites === 1
                    && $totalSpaces === 1
                    && $totalPages === 1
                    && $totalMembers === 1
                    && $totalPublishedPages === 0
                    && $totalMediaAssets === 0
                    && $primarySite->domains_count === 0,
                'completedSteps' => $completedOnboardingSteps,
                'remainingSteps' => count($onboardingSteps) - $completedOnboardingSteps,
                'steps' => $onboardingSteps,
            ],
            'spaces' => $spaces,
            'activity' => $activity,
        ]);
    }
}
