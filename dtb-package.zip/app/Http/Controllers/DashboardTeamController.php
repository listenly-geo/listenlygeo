<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Models\Organization;
use App\Models\OrganizationInvitation;
use App\Models\OrganizationMembership;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class DashboardTeamController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
    ) {}

    public function __invoke(Request $request): Response
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationView($request->user(), $organization);

        $memberships = $organization->memberships()
            ->with('user:id,name,email')
            ->orderByRaw("case when role = 'owner' then 0 when role = 'admin' then 1 when role = 'editor' then 2 else 3 end")
            ->orderBy('id')
            ->get();

        $invitations = $organization->invitations()
            ->with('inviter:id,name')
            ->whereNull('accepted_at')
            ->latest('id')
            ->get();

        $currentMembership = $memberships->firstWhere('user_id', $request->user()->id);
        $canManageTeam = in_array($currentMembership?->role, ['owner', 'admin'], true);

        return Inertia::render('dashboard/team', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
                'ownerUserId' => $organization->owner_user_id,
            ],
            'summary' => [
                'totalMembers' => $memberships->where('status', 'active')->count(),
                'adminCount' => $memberships->whereIn('role', ['owner', 'admin'])->where('status', 'active')->count(),
                'editorCount' => $memberships->where('role', 'editor')->where('status', 'active')->count(),
                'viewerCount' => $memberships->where('role', 'viewer')->where('status', 'active')->count(),
                'pendingInvitesCount' => $invitations->count(),
            ],
            'permissions' => [
                'canManageTeam' => $canManageTeam,
                'currentUserRole' => $currentMembership?->role ?? 'viewer',
            ],
            'members' => $memberships->map(fn (OrganizationMembership $membership) => [
                'id' => $membership->id,
                'userId' => $membership->user_id,
                'name' => $membership->user?->name ?? 'Unknown user',
                'email' => $membership->user?->email ?? '',
                'role' => $membership->role,
                'status' => $membership->status,
                'joinedAt' => $membership->created_at?->toIso8601String(),
                'isOwner' => $membership->user_id === $organization->owner_user_id,
                'isCurrentUser' => $membership->user_id === $request->user()->id,
                'canChangeRole' => $canManageTeam
                    && $membership->user_id !== $organization->owner_user_id
                    && $membership->user_id !== $request->user()->id,
            ])->values()->all(),
            'invitations' => $invitations->map(fn (OrganizationInvitation $invitation) => [
                'id' => $invitation->id,
                'email' => $invitation->email,
                'role' => $invitation->role,
                'invitedBy' => $invitation->inviter?->name,
                'invitedAt' => $invitation->created_at?->toIso8601String(),
                'expiresAt' => $invitation->expires_at?->toIso8601String(),
                'isExpired' => $invitation->expires_at?->isPast() ?? false,
            ])->values()->all(),
        ]);
    }

    public function storeInvitation(Request $request): RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationMutation($request->user(), $organization);

        $validated = $request->validate([
            'email' => ['required', 'email:rfc', 'max:255'],
            'role' => ['required', Rule::in(['admin', 'editor', 'viewer'])],
        ]);

        $email = Str::lower(trim((string) $validated['email']));

        $existingMember = $organization->memberships()
            ->where('status', 'active')
            ->whereHas('user', fn ($query) => $query->whereRaw('lower(email) = ?', [$email]))
            ->exists();

        if ($existingMember) {
            throw ValidationException::withMessages([
                'email' => 'This collaborator already belongs to the workspace.',
            ]);
        }

        $invitation = $organization->invitations()
            ->whereRaw('lower(email) = ?', [$email])
            ->whereNull('accepted_at')
            ->latest('id')
            ->first();

        $message = 'Invitation prepared.';

        if ($invitation) {
            $invitation->forceFill([
                'email' => $email,
                'role' => $validated['role'],
                'token' => Str::random(40),
                'expires_at' => now()->addDays(7),
                'invited_by' => $request->user()->id,
            ])->save();

            $message = 'Invitation refreshed.';
        } else {
            $organization->invitations()->create([
                'email' => $email,
                'role' => $validated['role'],
                'token' => Str::random(40),
                'expires_at' => now()->addDays(7),
                'invited_by' => $request->user()->id,
            ]);
        }

        Inertia::flash('toast', ['type' => 'success', 'message' => $message]);

        return redirect()->route('dashboard.team');
    }

    public function updateMembershipRole(Request $request, OrganizationMembership $membership): RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationMutation($request->user(), $organization);

        abort_unless($membership->organization_id === $organization->id, 404);
        abort_if(
            $membership->user_id === $organization->owner_user_id || $membership->user_id === $request->user()->id,
            403,
        );

        $validated = $request->validate([
            'role' => ['required', Rule::in(['admin', 'editor', 'viewer'])],
        ]);

        $membership->forceFill([
            'role' => $validated['role'],
        ])->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Member role updated.']);

        return redirect()->route('dashboard.team');
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }

    private function authorizeOrganizationMutation(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->whereIn('role', ['owner', 'admin'])
                ->exists(),
            403,
        );
    }
}
