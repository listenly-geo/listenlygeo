<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Actions\Docs\SyncOrganizationUsageCounter;
use App\Models\Organization;
use App\Models\Page;
use App\Models\Site;
use App\Models\Space;
use App\Models\User;
use App\Support\DocsTheme;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class DashboardSitesController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
        private readonly SyncOrganizationUsageCounter $syncOrganizationUsageCounter,
    ) {}

    public function __invoke(Request $request): Response|RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());

        if ($request->filled('site')) {
            return redirect()->route('dashboard.sites.show', ['site' => $request->integer('site')]);
        }

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'defaultSpace:id,uuid,site_id,name',
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount(['spaces', 'pages', 'domains'])
            ->orderBy('id')
            ->get();

        $firstSite = $sites->firstOrFail();

        Gate::authorize('view', $firstSite);

        $siteIds = $sites->pluck('id');

        return Inertia::render('dashboard/sites', [
            'mode' => 'index',
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
            ],
            'permissions' => [
                'canManageSites' => Gate::forUser($request->user())->allows('configure', $firstSite),
            ],
            'summary' => $this->summaryPayload($siteIds),
            'sites' => $this->siteListPayload($sites),
            'selectedSite' => null,
        ]);
    }

    public function show(Request $request, Site $site): Response
    {
        $organization = $this->resolveOrganization($request->user());

        abort_unless($site->organization_id === $organization->id, 404);

        Gate::authorize('view', $site);

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'defaultSpace:id,uuid,site_id,name',
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount(['spaces', 'pages', 'domains'])
            ->orderBy('id')
            ->get();

        $site->load([
            'defaultSpace:id,uuid,site_id,name',
            'currentRelease:id,site_id,version,published_at',
            'spaces' => fn ($query) => $query
                ->withCount('pages')
                ->withCount([
                    'pages as published_pages_count' => fn ($pageQuery) => $pageQuery->whereNotNull('published_revision_id'),
                    'pages as unpublished_pages_count' => fn ($pageQuery) => $pageQuery->whereNull('published_revision_id'),
                ])
                ->orderBy('position')
                ->orderBy('id'),
        ]);
        $site->loadCount([
            'spaces',
            'pages',
            'domains',
            'pages as published_pages_count' => fn ($query) => $query->whereNotNull('published_revision_id'),
            'pages as unpublished_pages_count' => fn ($query) => $query->whereNull('published_revision_id'),
        ]);

        $siteIds = $sites->pluck('id');
        $settings = $site->settings_json ?? [];

        return Inertia::render('dashboard/sites', [
            'mode' => 'show',
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
            ],
            'permissions' => [
                'canManageSites' => Gate::forUser($request->user())->allows('configure', $site),
            ],
            'summary' => $this->summaryPayload($siteIds),
            'sites' => $this->siteListPayload($sites, $site),
            'selectedSite' => [
                'id' => $site->id,
                'uuid' => $site->uuid,
                'name' => $site->name,
                'slug' => $site->slug,
                'status' => $site->status,
                'visibility' => $site->visibility,
                'defaultSpaceId' => $site->default_space_id,
                'defaultSpaceName' => $site->defaultSpace?->name,
                'spacesCount' => $site->spaces_count,
                'pagesCount' => $site->pages_count,
                'publishedPagesCount' => $site->published_pages_count,
                'unpublishedPagesCount' => $site->unpublished_pages_count,
                'domainsCount' => $site->domains_count,
                'currentReleaseVersion' => $site->currentRelease?->version,
                'currentReleasePublishedAt' => $site->currentRelease?->published_at?->toIso8601String(),
                'createdAt' => $site->created_at?->toIso8601String(),
                'updatedAt' => $site->updated_at?->toIso8601String(),
                'docsUrl' => $site->currentRelease ? '/docs/'.$site->slug : null,
                'editorUrl' => $this->editorUrl($site),
                'fullSiteExportThemedHtmlUrl' => route('dashboard.sites.export', ['site' => $site, 'format' => 'html'], false),
                'fullSiteExportPlainHtmlUrl' => route('dashboard.sites.export', ['site' => $site, 'format' => 'plain-html'], false),
                'fullSiteExportPdfUrl' => route('dashboard.sites.export', ['site' => $site, 'format' => 'pdf'], false),
                'branding' => [
                    'logoUrl' => Arr::get($settings, 'branding.logo_path')
                        ? Storage::disk('public')->url(Arr::get($settings, 'branding.logo_path'))
                        : null,
                ],
                'appearance' => [
                    'docsTheme' => DocsTheme::normalize(Arr::get($settings, 'appearance.docs_theme')),
                    'docsThemeOptions' => DocsTheme::optionsPayload(Arr::get($settings, 'appearance.docs_theme_options')),
                ],
                'spaces' => $site->spaces->map(fn (Space $space) => [
                    'id' => $space->id,
                    'name' => $space->name,
                    'slug' => $space->slug,
                    'icon' => $space->icon ?: 'space',
                    'color' => $space->color ?: 'oklch(55% 0.14 255)',
                    'pagesCount' => $space->pages_count,
                    'publishedPagesCount' => $space->published_pages_count,
                    'unpublishedPagesCount' => $space->unpublished_pages_count,
                    'isDefault' => $space->id === $site->default_space_id,
                    'updatedAt' => $space->updated_at?->toIso8601String(),
                ])->values()->all(),
            ],
        ]);
    }

    public function storeSite(Request $request): RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationMutation($request->user(), $organization);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'visibility' => ['required', Rule::in(['private', 'public'])],
            'initialSpaceName' => ['nullable', 'string', 'max:80'],
        ]);

        $site = DB::transaction(function () use ($organization, $request, $validated) {
            $site = $organization->sites()->create([
                'name' => trim((string) $validated['name']),
                'slug' => $this->availableSiteSlug($organization, (string) $validated['name']),
                'visibility' => $validated['visibility'],
                'status' => 'draft',
                'created_by' => $request->user()->id,
                'updated_by' => $request->user()->id,
            ]);

            $spaceName = trim((string) ($validated['initialSpaceName'] ?? '')) ?: 'Getting Started';

            $space = $site->spaces()->create([
                'name' => $spaceName,
                'slug' => $this->availableSpaceSlug($site, $spaceName),
                'icon' => 'book',
                'color' => 'oklch(55% 0.14 255)',
                'position' => 0,
                'created_by' => $request->user()->id,
                'updated_by' => $request->user()->id,
            ]);

            $site->forceFill([
                'default_space_id' => $space->id,
                'updated_by' => $request->user()->id,
            ])->save();

            $page = $space->pages()->create([
                'site_id' => $site->id,
                'title' => 'Quickstart',
                'slug' => 'quickstart',
                'path' => 'quickstart',
                'icon' => 'bolt',
                'position' => 0,
                'status' => 'draft',
                'created_by' => $request->user()->id,
                'updated_by' => $request->user()->id,
            ]);

            $revision = $page->revisions()->create([
                'version_number' => 1,
                'title' => $page->title,
                'subtitle' => 'Go from zero to a published page in under three minutes.',
                'blocks_json' => [
                    [
                        'id' => 'b_1',
                        'kind' => 'p',
                        'html' => 'Start writing, or press <code>/</code> to insert a block.',
                    ],
                ],
                'editor_meta_json' => [
                    'updated' => now()->toIso8601String(),
                    'readTime' => '1 min',
                ],
                'save_type' => 'manual',
                'change_message' => 'Initial page scaffold',
                'created_by' => $request->user()->id,
            ]);

            $page->forceFill([
                'current_revision_id' => $revision->id,
                'updated_by' => $request->user()->id,
            ])->save();

            ($this->syncOrganizationUsageCounter)($organization);

            return $site;
        });

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Site created.']);

        return redirect()->route('dashboard.sites.show', $site);
    }

    public function storeSpace(Request $request, Site $site): RedirectResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('configure', $site);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:80'],
        ]);

        $space = $site->spaces()->create([
            'name' => trim((string) $validated['name']),
            'slug' => $this->availableSpaceSlug($site, (string) $validated['name']),
            'icon' => 'folder',
            'color' => 'oklch(66% 0.11 180)',
            'position' => ((int) ($site->spaces()->max('position') ?? -1)) + 1,
            'created_by' => $request->user()->id,
            'updated_by' => $request->user()->id,
        ]);

        if (! $site->default_space_id) {
            $site->forceFill([
                'default_space_id' => $space->id,
                'updated_by' => $request->user()->id,
            ])->save();
        }

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Space created.']);

        return redirect()->route('dashboard.sites.show', $site);
    }

    public function updateAppearance(Request $request, Site $site): RedirectResponse
    {
        Gate::authorize('configure', $site);

        $validated = $request->validate([
            'docsTheme' => ['nullable', 'string', Rule::in(DocsTheme::ids())],
            'docsThemeAccent' => ['nullable', 'string', Rule::in(DocsTheme::accentColors())],
            'docsThemeFont' => ['nullable', 'string', Rule::in(DocsTheme::fontFamilies())],
            'docsThemeLayout' => ['nullable', 'string', Rule::in(DocsTheme::layoutWidths())],
        ]);

        $existing = $site->settings_json ?? [];
        $currentOptions = DocsTheme::normalizeOptions(Arr::get($existing, 'appearance.docs_theme_options'));

        $site->forceFill([
            'settings_json' => [
                ...$existing,
                'appearance' => [
                    ...(Arr::get($existing, 'appearance', [])),
                    'docs_theme' => $validated['docsTheme'] ?? DocsTheme::normalize(Arr::get($existing, 'appearance.docs_theme')),
                    'docs_theme_options' => [
                        'accent_color' => $validated['docsThemeAccent'] ?? $currentOptions['accent_color'],
                        'font_family' => $validated['docsThemeFont'] ?? $currentOptions['font_family'],
                        'layout_width' => $validated['docsThemeLayout'] ?? $currentOptions['layout_width'],
                    ],
                ],
            ],
            'updated_by' => $request->user()->id,
        ])->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Docs appearance updated.']);

        return redirect()->route('dashboard.sites.show', $site);
    }

    public function updateLogo(Request $request, Site $site): RedirectResponse
    {
        Gate::authorize('configure', $site);

        $request->validate([
            'logo' => ['nullable', 'file', 'mimes:png,jpg,jpeg,webp', 'max:2048'],
            'clearLogo' => ['nullable', 'boolean'],
        ]);

        $existing = $site->settings_json ?? [];
        $branding = Arr::get($existing, 'branding', []);
        $branding = is_array($branding) ? $branding : [];
        $currentLogoPath = Arr::get($branding, 'logo_path');
        $nextLogoPath = $request->boolean('clearLogo') ? null : $currentLogoPath;

        if (($request->boolean('clearLogo') || $request->hasFile('logo')) && is_string($currentLogoPath) && $currentLogoPath !== '') {
            Storage::disk('public')->delete($currentLogoPath);
        }

        if ($request->hasFile('logo')) {
            $nextLogoPath = $request->file('logo')->store('site-logos/'.$site->id, 'public');
        }

        if (is_string($nextLogoPath) && $nextLogoPath !== '') {
            $branding['logo_path'] = $nextLogoPath;
        } else {
            unset($branding['logo_path']);
        }

        $nextSettings = [...$existing];

        if ($branding === []) {
            unset($nextSettings['branding']);
        } else {
            $nextSettings['branding'] = $branding;
        }

        $site->forceFill([
            'settings_json' => $nextSettings,
            'updated_by' => $request->user()->id,
        ])->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Site logo updated.']);

        return redirect()->route('dashboard.sites.show', $site);
    }

    public function updateDefaultSpace(Request $request, Site $site): RedirectResponse
    {
        Gate::authorize('configure', $site);

        $validated = $request->validate([
            'spaceId' => [
                'required',
                'integer',
                Rule::exists('spaces', 'id')->where(fn ($query) => $query->where('site_id', $site->id)),
            ],
        ]);

        $site->forceFill([
            'default_space_id' => (int) $validated['spaceId'],
            'updated_by' => $request->user()->id,
        ])->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Default space updated.']);

        return redirect()->route('dashboard.sites.show', $site);
    }

    private function siteListPayload($sites, ?Site $selectedSite = null): array
    {
        return $sites->map(fn (Site $site) => [
            'id' => $site->id,
            'name' => $site->name,
            'slug' => $site->slug,
            'status' => $site->status,
            'visibility' => $site->visibility,
            'defaultSpaceName' => $site->defaultSpace?->name,
            'spacesCount' => $site->spaces_count,
            'pagesCount' => $site->pages_count,
            'domainsCount' => $site->domains_count,
            'currentReleaseVersion' => $site->currentRelease?->version,
            'updatedAt' => $site->updated_at?->toIso8601String(),
            'editorUrl' => $this->editorUrl($site),
            'detailsUrl' => route('dashboard.sites.show', $site, false),
            'docsUrl' => $site->currentRelease ? '/docs/'.$site->slug : null,
            'isSelected' => $selectedSite?->id === $site->id,
        ])->values()->all();
    }

    private function summaryPayload($siteIds): array
    {
        return [
            'totalSites' => $siteIds->count(),
            'totalSpaces' => Space::query()->whereIn('site_id', $siteIds)->count(),
            'totalPages' => Page::query()->whereIn('site_id', $siteIds)->count(),
            'totalPublishedPages' => Page::query()
                ->whereIn('site_id', $siteIds)
                ->whereNotNull('published_revision_id')
                ->count(),
        ];
    }

    private function editorUrl(Site $site): string
    {
        if ($site->defaultSpace?->uuid) {
            return route('editor.space', ['site' => $site->uuid, 'space' => $site->defaultSpace->uuid], false);
        }

        return route('editor.prototype.entry', [], false);
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationMutation(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->whereIn('role', ['owner', 'admin'])
                ->exists(),
            403,
        );
    }

    private function availableSiteSlug(Organization $organization, string $name): string
    {
        $baseSlug = Str::slug($name) ?: 'site';
        $candidate = $baseSlug;
        $suffix = 2;

        while ($organization->sites()->where('slug', $candidate)->exists()) {
            $candidate = $baseSlug.'-'.$suffix;
            $suffix++;
        }

        return $candidate;
    }

    private function availableSpaceSlug(Site $site, string $name): string
    {
        $baseSlug = Str::slug($name) ?: 'space';
        $candidate = $baseSlug;
        $suffix = 2;

        while ($site->spaces()->where('slug', $candidate)->exists()) {
            $candidate = $baseSlug.'-'.$suffix;
            $suffix++;
        }

        return $candidate;
    }
}
