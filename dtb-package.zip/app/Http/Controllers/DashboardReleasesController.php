<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Actions\Docs\PublishSiteRelease;
use App\Http\Requests\Editor\PublishSiteReleaseRequest;
use App\Models\Organization;
use App\Models\Release;
use App\Models\Site;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;
use Inertia\Response;

class DashboardReleasesController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
        private readonly PublishSiteRelease $publishSiteRelease,
    ) {}

    public function __invoke(Request $request): Response
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationView($request->user(), $organization);

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount([
                'pages',
                'releases',
                'pages as releasable_pages_count' => fn ($query) => $query->whereNotNull('current_revision_id'),
            ])
            ->orderBy('id')
            ->get();

        $selectedSite = $sites->firstWhere('id', $request->integer('site'))
            ?? $sites->firstOrFail();

        Gate::authorize('view', $selectedSite);

        $selectedSite->load([
            'currentRelease:id,site_id,version,published_at',
            'releases' => fn ($query) => $query
                ->with('publisher:id,name')
                ->withCount('pages')
                ->latest('published_at')
                ->latest('id'),
        ]);

        return Inertia::render('dashboard/releases', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
            ],
            'permissions' => [
                'canPublish' => Gate::forUser($request->user())->allows('update', $selectedSite),
            ],
            'sites' => $sites->map(fn (Site $site) => [
                'id' => $site->id,
                'name' => $site->name,
                'slug' => $site->slug,
                'status' => $site->status,
                'visibility' => $site->visibility,
                'pagesCount' => $site->pages_count,
                'releaseCount' => $site->releases_count,
                'releasablePagesCount' => $site->releasable_pages_count,
                'currentReleaseVersion' => $site->currentRelease?->version,
                'isSelected' => $site->id === $selectedSite->id,
            ])->values()->all(),
            'selectedSite' => [
                'id' => $selectedSite->id,
                'name' => $selectedSite->name,
                'slug' => $selectedSite->slug,
                'status' => $selectedSite->status,
                'visibility' => $selectedSite->visibility,
                'docsUrl' => $selectedSite->currentRelease ? '/docs/'.$selectedSite->slug : null,
                'currentReleaseVersion' => $selectedSite->currentRelease?->version,
                'currentReleasePublishedAt' => $selectedSite->currentRelease?->published_at?->toIso8601String(),
                'releaseCount' => $selectedSite->releases_count,
                'releasablePagesCount' => $selectedSite->releasable_pages_count,
                'releases' => $selectedSite->releases->map(fn (Release $release) => [
                    'id' => $release->id,
                    'version' => $release->version,
                    'status' => $release->status,
                    'environment' => $release->environment,
                    'message' => $release->message,
                    'publishedAt' => $release->published_at?->toIso8601String(),
                    'publishedBy' => $release->publisher?->name,
                    'publishedPagesCount' => $release->pages_count,
                    'isCurrent' => $release->id === $selectedSite->current_release_id,
                ])->values()->all(),
            ],
        ]);
    }

    public function publish(PublishSiteReleaseRequest $request, Site $site): RedirectResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $published = ($this->publishSiteRelease)($site, $request->user(), $request->validated());

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Release '.$published['release']['version'].' published.',
        ]);

        return redirect()->route('dashboard.releases', ['site' => $site->id]);
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }
}
