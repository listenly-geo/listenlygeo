<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Models\Organization;
use App\Models\PageRevision;
use App\Models\Release;
use App\Models\Site;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;
use Inertia\Response;

class DashboardAnalyticsController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
    ) {}

    public function __invoke(Request $request): Response
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationView($request->user(), $organization);

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount([
                'pages',
                'releases',
                'pages as published_pages_count' => fn ($query) => $query->whereNotNull('published_revision_id'),
            ])
            ->orderBy('id')
            ->get();

        $selectedSite = $sites->firstWhere('id', $request->integer('site'))
            ?? $sites->firstOrFail();

        Gate::authorize('view', $selectedSite);

        $revisionScope = PageRevision::query()->whereHas('page', fn ($query) => $query->where('site_id', $selectedSite->id));
        $releaseScope = Release::query()->where('site_id', $selectedSite->id);

        $activity = $this->buildActivityFeed($selectedSite->id);

        return Inertia::render('dashboard/analytics', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
            ],
            'sites' => $sites->map(fn (Site $site) => [
                'id' => $site->id,
                'name' => $site->name,
                'slug' => $site->slug,
                'status' => $site->status,
                'visibility' => $site->visibility,
                'pagesCount' => $site->pages_count,
                'publishedPagesCount' => $site->published_pages_count,
                'releaseCount' => $site->releases_count,
                'currentReleaseVersion' => $site->currentRelease?->version,
                'isSelected' => $site->id === $selectedSite->id,
            ])->values()->all(),
            'selectedSite' => [
                'id' => $selectedSite->id,
                'name' => $selectedSite->name,
                'slug' => $selectedSite->slug,
                'status' => $selectedSite->status,
                'visibility' => $selectedSite->visibility,
                'docsUrl' => $selectedSite->currentRelease ? '/docs/'.$selectedSite->slug : null,
                'currentReleaseVersion' => $selectedSite->currentRelease?->version,
                'currentReleasePublishedAt' => $selectedSite->currentRelease?->published_at?->toIso8601String(),
                'analytics' => [
                    'totalPages' => $selectedSite->pages_count,
                    'totalPublishedPages' => $selectedSite->published_pages_count,
                    'totalRevisions' => (clone $revisionScope)->count(),
                    'totalManualSaves' => (clone $revisionScope)->where('save_type', 'manual')->count(),
                    'totalAutosaves' => (clone $revisionScope)->where('save_type', 'autosave')->count(),
                    'totalReleases' => (clone $releaseScope)->count(),
                    'productionReleases' => (clone $releaseScope)->where('environment', 'production')->count(),
                    'stagingReleases' => (clone $releaseScope)->where('environment', 'staging')->count(),
                    'totalContributors' => (clone $revisionScope)
                        ->whereNotNull('created_by')
                        ->distinct('created_by')
                        ->count('created_by'),
                    'recentEventsLast7Days' => (clone $revisionScope)->where('created_at', '>=', now()->subDays(7))->count()
                        + (clone $releaseScope)->where('published_at', '>=', now()->subDays(7))->count(),
                    'publishesLast30Days' => (clone $releaseScope)->where('published_at', '>=', now()->subDays(30))->count(),
                ],
                'activity' => $activity,
            ],
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function buildActivityFeed(int $siteId): array
    {
        $revisionActivity = PageRevision::query()
            ->whereHas('page', fn ($query) => $query->where('site_id', $siteId))
            ->with([
                'page:id,title,path',
                'author:id,name',
            ])
            ->latest('id')
            ->limit(12)
            ->get()
            ->map(fn (PageRevision $revision) => [
                'id' => 'revision-'.$revision->id,
                'kind' => 'revision',
                'tone' => $revision->save_type ?: 'manual',
                'title' => $revision->title ?: $revision->page?->title ?: 'Untitled',
                'message' => $revision->change_message ?: 'Draft updated',
                'actor' => $revision->author?->name ?: 'Unknown editor',
                'createdAt' => $revision->created_at?->toIso8601String(),
                'meta' => trim(($revision->page?->path ? '/'.$revision->page->path.' · ' : '').($revision->save_type ?: 'manual')),
                'sortAt' => $revision->created_at?->format('YmdHis.u') ?? '0',
                'sortPriority' => 0,
            ]);

        $releaseActivity = Release::query()
            ->where('site_id', $siteId)
            ->with([
                'publisher:id,name',
            ])
            ->withCount('pages')
            ->latest('published_at')
            ->latest('id')
            ->limit(12)
            ->get()
            ->map(fn (Release $release) => [
                'id' => 'release-'.$release->id,
                'kind' => 'release',
                'tone' => 'release',
                'title' => $release->version,
                'message' => $release->message ?: 'Published release',
                'actor' => $release->publisher?->name ?: 'Unknown publisher',
                'createdAt' => $release->published_at?->toIso8601String(),
                'meta' => trim($release->environment.' · '.$release->pages_count.' pages'),
                'sortAt' => $release->published_at?->format('YmdHis.u') ?? '0',
                'sortPriority' => 1,
            ]);

        return $revisionActivity
            ->merge($releaseActivity)
            ->sortBy([
                ['sortAt', 'desc'],
                ['sortPriority', 'desc'],
            ])
            ->take(12)
            ->map(fn (array $item) => collect($item)->except(['sortAt', 'sortPriority'])->all())
            ->values()
            ->all();
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }
}
