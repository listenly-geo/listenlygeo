<?php

namespace App\Http\Controllers;

use App\Services\Billing\StripeBillingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class StripeWebhookController extends Controller
{
    public function __invoke(Request $request, StripeBillingService $stripeBilling): JsonResponse
    {
        $payload = $request->getContent();

        if (! $this->hasValidSignature($payload, (string) $request->header('Stripe-Signature'), $stripeBilling->webhookSecret())) {
            return response()->json(['message' => 'Invalid signature.'], Response::HTTP_BAD_REQUEST);
        }

        $event = json_decode($payload, true);

        if (! is_array($event)) {
            return response()->json(['message' => 'Invalid payload.'], Response::HTTP_BAD_REQUEST);
        }

        $object = data_get($event, 'data.object', []);

        match (data_get($event, 'type')) {
            'checkout.session.completed' => $stripeBilling->applyCheckoutSession($object),
            'customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted' => $stripeBilling->applySubscriptionEvent($object),
            default => null,
        };

        return response()->json(['received' => true]);
    }

    private function hasValidSignature(string $payload, string $signatureHeader, ?string $webhookSecret): bool
    {
        $secret = (string) $webhookSecret;

        if ($secret === '') {
            return true;
        }

        $parts = collect(explode(',', $signatureHeader))
            ->mapWithKeys(function (string $part): array {
                [$key, $value] = array_pad(explode('=', $part, 2), 2, '');

                return [$key => $value];
            });

        $timestamp = $parts->get('t');
        $signature = $parts->get('v1');

        if (! $timestamp || ! $signature) {
            return false;
        }

        $expected = hash_hmac('sha256', $timestamp.'.'.$payload, $secret);

        return hash_equals($expected, $signature);
    }
}
