<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Actions\Docs\SyncOrganizationUsageCounter;
use App\Models\MediaAsset;
use App\Models\Organization;
use App\Models\Site;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class DashboardMediaController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
        private readonly SyncOrganizationUsageCounter $syncOrganizationUsageCounter,
    ) {}

    public function __invoke(Request $request): Response
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationView($request->user(), $organization);

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'currentRelease:id,site_id,version,published_at',
            ])
            ->withCount(['mediaAssets', 'pages'])
            ->orderBy('id')
            ->get();

        $selectedSite = $sites->firstWhere('id', $request->integer('site'))
            ?? $sites->firstOrFail();

        Gate::authorize('view', $selectedSite);

        $selectedSite->load([
            'currentRelease:id,site_id,version,published_at',
            'mediaAssets' => fn ($query) => $query->with('uploader:id,name')->latest('id'),
        ]);

        return Inertia::render('dashboard/media', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
            ],
            'permissions' => [
                'canManageMedia' => Gate::forUser($request->user())->allows('update', $selectedSite),
            ],
            'sites' => $sites->map(fn (Site $site) => [
                'id' => $site->id,
                'name' => $site->name,
                'slug' => $site->slug,
                'status' => $site->status,
                'visibility' => $site->visibility,
                'assetsCount' => $site->media_assets_count,
                'pagesCount' => $site->pages_count,
                'currentReleaseVersion' => $site->currentRelease?->version,
                'isSelected' => $site->id === $selectedSite->id,
            ])->values()->all(),
            'selectedSite' => [
                'id' => $selectedSite->id,
                'name' => $selectedSite->name,
                'slug' => $selectedSite->slug,
                'status' => $selectedSite->status,
                'visibility' => $selectedSite->visibility,
                'docsUrl' => $selectedSite->currentRelease ? '/docs/'.$selectedSite->slug : null,
                'currentReleaseVersion' => $selectedSite->currentRelease?->version,
                'assetsCount' => $selectedSite->mediaAssets->count(),
                'assets' => $selectedSite->mediaAssets->map(fn (MediaAsset $asset) => [
                    'id' => $asset->id,
                    'name' => $asset->original_name ?: basename($asset->path),
                    'url' => route('media.assets.show', ['asset' => $asset]),
                    'mimeType' => $asset->mime_type,
                    'sizeBytes' => $asset->size_bytes,
                    'width' => $asset->width,
                    'height' => $asset->height,
                    'uploadedBy' => $asset->uploader?->name,
                    'uploadedAt' => $asset->created_at?->toIso8601String(),
                    'isImage' => Str::startsWith($asset->mime_type, 'image/'),
                    'isVideo' => Str::startsWith($asset->mime_type, 'video/'),
                ])->values()->all(),
            ],
            'usage' => [
                'storageBytes' => (int) $organization->mediaAssets()->sum('size_bytes'),
                'totalAssets' => $organization->mediaAssets()->count(),
                'siteStorageBytes' => (int) $selectedSite->mediaAssets()->sum('size_bytes'),
            ],
            'upload' => [
                'maxFileSizeBytes' => 10 * 1024 * 1024,
                'acceptedTypes' => [
                    'image/png',
                    'image/jpeg',
                    'image/gif',
                    'image/webp',
                    'image/svg+xml',
                    'video/mp4',
                    'video/webm',
                    'video/ogg',
                    'application/pdf',
                    'application/zip',
                    'application/x-zip-compressed',
                    'text/plain',
                ],
            ],
        ]);
    }

    public function store(Request $request, Site $site): RedirectResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $validated = $request->validate([
            'file' => [
                'required',
                'file',
                'max:10240',
                'mimetypes:image/png,image/jpeg,image/gif,image/webp,image/svg+xml,video/mp4,video/webm,video/ogg,application/pdf,application/zip,application/x-zip-compressed,text/plain',
            ],
        ]);

        /** @var UploadedFile $file */
        $file = $validated['file'];
        $mimeType = $file->getMimeType() ?: 'application/octet-stream';
        $extension = Str::lower($file->guessExtension() ?: $file->getClientOriginalExtension() ?: 'bin');
        $directory = 'media/org-'.$site->organization_id.'/site-'.$site->id;
        $filename = (string) Str::ulid().'.'.$extension;
        $path = $file->storeAs($directory, $filename, 'public');

        [$width, $height] = $this->imageDimensions($file, $mimeType);

        MediaAsset::query()->create([
            'organization_id' => $site->organization_id,
            'site_id' => $site->id,
            'disk' => 'public',
            'path' => $path,
            'original_name' => $file->getClientOriginalName() ?: basename($path),
            'mime_type' => $mimeType,
            'size_bytes' => $file->getSize() ?: 0,
            'width' => $width,
            'height' => $height,
            'uploaded_by' => $request->user()->id,
        ]);

        ($this->syncOrganizationUsageCounter)($site->organization);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Asset uploaded.']);

        return redirect()->route('dashboard.media', ['site' => $site->id]);
    }

    public function destroy(Request $request, MediaAsset $asset): RedirectResponse
    {
        $asset->loadMissing('site.organization');

        abort_unless($asset->site !== null, 404);
        Gate::authorize('update', $asset->site);

        $site = $asset->site;

        Storage::disk($asset->disk)->delete($asset->path);
        $asset->delete();

        ($this->syncOrganizationUsageCounter)($site->organization);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Asset removed.']);

        return redirect()->route('dashboard.media', ['site' => $site->id]);
    }

    public function show(MediaAsset $asset): BinaryFileResponse
    {
        abort_unless(Storage::disk($asset->disk)->exists($asset->path), 404);

        return response()->file(
            Storage::disk($asset->disk)->path($asset->path),
            ['Content-Type' => $asset->mime_type],
        );
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }

    /**
     * @return array{0: int|null, 1: int|null}
     */
    private function imageDimensions(UploadedFile $file, string $mimeType): array
    {
        if (! Str::startsWith($mimeType, 'image/') || $mimeType === 'image/svg+xml') {
            return [null, null];
        }

        $realPath = $file->getRealPath();

        if (! $realPath || ! is_file($realPath)) {
            return [null, null];
        }

        $dimensions = @getimagesize($realPath);

        if (! is_array($dimensions)) {
            return [null, null];
        }

        return [$dimensions[0] ?? null, $dimensions[1] ?? null];
    }
}
