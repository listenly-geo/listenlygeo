<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Models\Organization;
use App\Models\OrganizationSubscription;
use App\Models\Page;
use App\Models\PlatformBillingSetting;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Services\Billing\StripeBillingService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Client\RequestException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;
use Throwable;

class DashboardBillingController extends Controller
{
    /**
     * @var array<string, string>
     */
    private const PAYMENT_GATEWAYS = [
        'stripe' => 'Stripe',
    ];

    /**
     * @var array<int, string>
     */
    private const GATEWAY_STATUSES = ['setup_required', 'ready', 'paused'];

    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
        private readonly StripeBillingService $stripeBilling,
    ) {}

    public function __invoke(Request $request): Response|RedirectResponse
    {
        if ($this->canManagePlatformBilling($request->user())) {
            return redirect()->route('admin.commerce');
        }

        return $this->renderBilling($request, false);
    }

    public function commerce(Request $request): Response
    {
        $this->authorizePlatformBilling($request->user());

        return $this->renderBilling($request, true);
    }

    public function adminCommerce(Request $request): Response
    {
        $this->authorizePlatformBilling($request->user());

        return $this->renderBilling($request, true, 'admin/commerce');
    }

    private function renderBilling(Request $request, bool $canManagePlatformBilling, string $page = 'dashboard/billing'): Response
    {
        $user = $request->user();
        $planCatalog = $this->planCatalog();
        $organization = $canManagePlatformBilling
            ? $this->customerOrganizationsQuery()->with('subscription')->orderBy('name')->first()
            : $this->resolveOrganization($user);

        if (! $canManagePlatformBilling) {
            $this->authorizeOrganizationView($user, $organization);
        }

        $organization?->loadMissing('subscription');

        if (
            ! $canManagePlatformBilling
            && $organization
            && $organization->subscription
            && $this->stripeBilling->isConfigured()
            && (
                $request->query('checkout') === 'success'
                || $organization->subscription->status === 'incomplete'
                || (
                    filled($organization->subscription->stripe_checkout_session_id)
                    && blank($organization->subscription->stripe_subscription_id)
                )
            )
        ) {
            try {
                $this->stripeBilling->reconcileOrganizationSubscription($organization);
                $organization->refresh()->load('subscription');
            } catch (Throwable $exception) {
                report($exception);
            }
        }

        $subscription = $this->subscriptionPayload($organization?->subscription);
        $plan = $this->planFor($planCatalog, $subscription['plan']);
        $canManageCustomerBilling = $organization && ! $canManagePlatformBilling
            ? $this->canManageCustomerBilling($user, $organization)
            : false;

        return Inertia::render($page, [
            'billingMode' => $canManagePlatformBilling ? 'platform' : 'customer',
            'organization' => [
                'name' => $organization?->name ?? 'Customer accounts',
                'slug' => $organization?->slug ?? 'platform-commerce',
                'billingEmail' => $organization?->billing_email,
            ],
            'permissions' => [
                'canManageBilling' => $canManageCustomerBilling,
                'canManageCustomerBilling' => $canManageCustomerBilling,
                'canManagePlatformBilling' => $canManagePlatformBilling,
            ],
            'subscription' => [
                ...$subscription,
                'amountCents' => $this->amountFor($planCatalog, $subscription['plan'], $subscription['interval']),
                'stripeConfigured' => $this->stripeBilling->isConfigured(),
            ],
            'usage' => [
                'siteCount' => $organization?->sites()->count() ?? 0,
                'memberCount' => $organization?->memberships()->where('status', 'active')->count() ?? 0,
                'publishedPageCount' => $organization ? Page::query()
                    ->whereHas('site', fn ($query) => $query->where('organization_id', $organization->id))
                    ->whereNotNull('published_revision_id')
                    ->count() : 0,
                'storageBytes' => (int) ($organization?->mediaAssets()->sum('size_bytes') ?? 0),
                'limits' => [
                    'sites' => $plan['includedSites'],
                    'members' => $plan['includedMembers'],
                    'publishedPages' => $plan['includedPublishedPages'],
                    'storageBytes' => $plan['includedStorageBytes'],
                ],
            ],
            'plans' => collect($planCatalog)->map(function (array $planConfig, string $key) use ($subscription) {
                return [
                    'key' => $key,
                    'label' => $planConfig['label'],
                    'description' => $planConfig['description'],
                    'monthlyPriceCents' => $planConfig['monthlyPriceCents'],
                    'annualPriceCents' => $planConfig['annualPriceCents'],
                    'includedSites' => $planConfig['includedSites'],
                    'includedMembers' => $planConfig['includedMembers'],
                    'includedPublishedPages' => $planConfig['includedPublishedPages'],
                    'includedStorageBytes' => $planConfig['includedStorageBytes'],
                    'isFree' => $planConfig['monthlyPriceCents'] === 0 && $planConfig['annualPriceCents'] === 0,
                    'isCurrent' => $subscription['plan'] === $key,
                ];
            })->values()->all(),
            'platformBilling' => $canManagePlatformBilling ? $this->platformBillingPayload($planCatalog) : null,
            'paymentGateway' => $canManagePlatformBilling ? $this->paymentGatewayPayload() : null,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $isPlatformBilling = $request->routeIs('dashboard.commerce.update') || $request->routeIs('admin.commerce.update');
        $planSlugs = array_keys($this->planCatalog());

        if ($isPlatformBilling) {
            $this->authorizePlatformBilling($request->user());
            $validated = $request->validate([
                'organizationId' => ['required', 'integer', Rule::exists('organizations', 'id')],
                'billingEmail' => ['required', 'email:rfc', 'max:255'],
                'plan' => ['required', Rule::in($planSlugs)],
                'interval' => ['required', Rule::in(['monthly', 'annual'])],
                'status' => ['required', Rule::in(['trialing', 'active', 'past_due', 'canceled', 'incomplete'])],
                'cancelAtPeriodEnd' => ['required', 'boolean'],
            ]);
            $organization = $this->customerOrganizationsQuery()->findOrFail($validated['organizationId']);

            $organization->forceFill([
                'billing_email' => trim((string) $validated['billingEmail']),
            ])->save();

            OrganizationSubscription::query()->updateOrCreate(
                ['organization_id' => $organization->id],
                [
                    'plan' => $validated['plan'],
                    'interval' => $validated['interval'],
                    'status' => $validated['status'],
                    'cancel_at_period_end' => (bool) $validated['cancelAtPeriodEnd'],
                    'current_period_starts_at' => now(),
                    'current_period_ends_at' => $validated['status'] === 'trialing'
                        ? now()->addDays(14)
                        : ($validated['interval'] === 'annual' ? now()->addYear() : now()->addMonth()),
                ],
            );

            Inertia::flash('toast', ['type' => 'success', 'message' => 'Customer billing settings updated.']);

            return redirect()->route('admin.commerce');
        } else {
            $organization = $this->resolveOrganization($request->user());
            $this->authorizeCustomerBillingMutation($request->user(), $organization);
            $organization->loadMissing('subscription');
            $validated = $request->validate([
                'billingEmail' => ['required', 'email:rfc', 'max:255'],
                'interval' => ['required', Rule::in(['monthly', 'annual'])],
            ]);

            $organization->forceFill([
                'billing_email' => trim((string) $validated['billingEmail']),
            ])->save();

            $subscription = $organization->subscription;
            $selectedInterval = $validated['interval'];
            $currentPlan = SubscriptionPlan::query()->where('slug', $subscription?->plan ?? 'free')->first();

            if (
                $subscription?->stripe_subscription_id
                && $subscription->status !== 'canceled'
                && $subscription->interval !== $selectedInterval
                && $currentPlan
                && ($currentPlan->monthly_price_cents > 0 || $currentPlan->annual_price_cents > 0)
            ) {
                if (! $this->stripeBilling->isConfigured()) {
                    Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe is not configured yet, so the billing interval could not be updated.']);

                    return redirect()->route('dashboard.billing');
                }

                try {
                    $this->stripeBilling->updateSubscriptionPlan($organization, $currentPlan, $selectedInterval);
                    $organization->refresh()->load('subscription');
                } catch (Throwable $exception) {
                    report($exception);
                    Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe could not update the billing interval.']);

                    return redirect()->route('dashboard.billing');
                }
            } else {
                OrganizationSubscription::query()->updateOrCreate(
                    ['organization_id' => $organization->id],
                    [
                        'plan' => $subscription?->plan ?? 'free',
                        'interval' => $selectedInterval,
                        'status' => $subscription?->status ?? 'active',
                        'stripe_subscription_id' => $subscription?->stripe_subscription_id,
                        'stripe_price_id' => $subscription?->stripe_price_id,
                        'stripe_checkout_session_id' => $subscription?->stripe_checkout_session_id,
                        'cancel_at_period_end' => $subscription?->cancel_at_period_end ?? false,
                        'current_period_starts_at' => $subscription?->current_period_starts_at ?? now(),
                        'current_period_ends_at' => $subscription?->current_period_ends_at,
                        'stripe_synced_at' => $subscription?->stripe_synced_at ?? now(),
                    ],
                );
            }

            Inertia::flash('toast', ['type' => 'success', 'message' => 'Billing settings updated.']);

            return redirect()->route('dashboard.billing');
        }
    }

    public function checkout(Request $request): RedirectResponse|SymfonyResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeCustomerBillingMutation($request->user(), $organization);

        $validated = $request->validate([
            'plan' => ['required', Rule::exists('subscription_plans', 'slug')->where('status', 'active')],
            'interval' => ['required', Rule::in(['monthly', 'annual'])],
        ]);

        $plan = SubscriptionPlan::query()->where('slug', $validated['plan'])->where('status', 'active')->firstOrFail();
        $amount = $validated['interval'] === 'annual' ? $plan->annual_price_cents : $plan->monthly_price_cents;

        if ($amount === 0) {
            if ($organization->subscription?->stripe_subscription_id) {
                if (! $this->stripeBilling->isConfigured()) {
                    Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe is not configured yet.']);

                    return redirect()->route('dashboard.billing');
                }

                try {
                    $this->stripeBilling->updateSubscriptionPlan($organization, $plan, 'monthly');
                } catch (Throwable $exception) {
                    report($exception);
                    Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe could not move this subscription to free.']);

                    return redirect()->route('dashboard.billing');
                }

                Inertia::flash('toast', ['type' => 'success', 'message' => 'Subscription moved to the free plan in Stripe.']);

                return redirect()->route('dashboard.billing');
            }

            OrganizationSubscription::query()->updateOrCreate(
                ['organization_id' => $organization->id],
                [
                    'plan' => $plan->slug,
                    'interval' => 'monthly',
                    'status' => 'active',
                    'stripe_subscription_id' => null,
                    'stripe_price_id' => null,
                    'stripe_checkout_session_id' => null,
                    'cancel_at_period_end' => false,
                    'current_period_starts_at' => now(),
                    'current_period_ends_at' => null,
                    'stripe_synced_at' => now(),
                ],
            );

            Inertia::flash('toast', ['type' => 'success', 'message' => 'Free plan is active.']);

            return redirect()->route('dashboard.billing');
        }

        if (! $this->stripeBilling->isConfigured()) {
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe is not configured yet.']);

            return redirect()->route('dashboard.billing');
        }

        try {
            if ($organization->subscription?->stripe_subscription_id && $organization->subscription->status !== 'canceled') {
                $this->stripeBilling->updateSubscriptionPlan($organization, $plan, $validated['interval']);

                Inertia::flash('toast', ['type' => 'success', 'message' => 'Subscription updated in Stripe.']);

                return redirect()->route('dashboard.billing');
            }

            $checkoutUrl = $this->stripeBilling->createCheckoutSession(
                $organization,
                $plan,
                $validated['interval'],
                route('dashboard.billing', ['checkout' => 'success']),
                route('dashboard.billing', ['checkout' => 'cancelled']),
            );
        } catch (Throwable $exception) {
            report($exception);
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe checkout could not be started. Try again in a moment.']);

            return redirect()->route('dashboard.billing');
        }

        return Inertia::location($checkoutUrl);
    }

    public function portal(Request $request): RedirectResponse|SymfonyResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeCustomerBillingMutation($request->user(), $organization);

        if (! $this->stripeBilling->isConfigured()) {
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe is not configured yet.']);

            return redirect()->route('dashboard.billing');
        }

        try {
            return Inertia::location($this->stripeBilling->createBillingPortalSession($organization, route('dashboard.billing')));
        } catch (Throwable $exception) {
            report($exception);
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Stripe billing portal could not be opened.']);

            return redirect()->route('dashboard.billing');
        }
    }

    public function cancel(Request $request): RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeCustomerBillingMutation($request->user(), $organization);

        try {
            $this->stripeBilling->cancelAtPeriodEnd($organization);
            $organization->refresh()->load('subscription');
        } catch (Throwable $exception) {
            report($exception);
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Subscription cancellation could not be scheduled.']);

            return redirect()->route('dashboard.billing');
        }

        $periodEndsAt = $organization->subscription?->current_period_ends_at;
        $message = $periodEndsAt
            ? 'Cancellation scheduled. Your access remains active until '.$periodEndsAt->toDayDateTimeString().'.'
            : 'Cancellation scheduled. Your access remains active until the end of the current billing period.';

        Inertia::flash('toast', ['type' => 'success', 'message' => $message]);

        return redirect()->route('dashboard.billing');
    }

    public function resume(Request $request): RedirectResponse
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeCustomerBillingMutation($request->user(), $organization);

        try {
            $this->stripeBilling->resumeSubscription($organization);
        } catch (Throwable $exception) {
            report($exception);
            Inertia::flash('toast', ['type' => 'error', 'message' => 'Subscription could not be resumed.']);

            return redirect()->route('dashboard.billing');
        }

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Subscription resumed.']);

        return redirect()->route('dashboard.billing');
    }

    public function updateGateway(Request $request): RedirectResponse
    {
        $this->authorizePlatformBilling($request->user());

        $existingGateway = PlatformBillingSetting::query()->first();

        $validated = $request->validate([
            'provider' => ['required', Rule::in(array_keys(self::PAYMENT_GATEWAYS))],
            'mode' => ['required', Rule::in(['test', 'live'])],
            'status' => ['required', Rule::in(self::GATEWAY_STATUSES)],
            'publicKey' => ['required', 'string', 'max:255', 'starts_with:pk_'],
            'secretKey' => [
                Rule::requiredIf(fn () => blank($existingGateway?->secret_key) && blank(config('services.stripe.secret'))),
                'nullable',
                'string',
                'max:255',
                'starts_with:sk_',
            ],
            'webhookEndpoint' => ['nullable', 'url', 'max:255'],
        ]);

        $webhookEndpoint = blank($validated['webhookEndpoint'] ?? null)
            ? route('stripe.webhook')
            : trim((string) $validated['webhookEndpoint']);
        $endpointHost = strtolower((string) parse_url($webhookEndpoint, PHP_URL_HOST));
        $endpointScheme = strtolower((string) parse_url($webhookEndpoint, PHP_URL_SCHEME));
        $isLocalWebhookEndpoint = in_array($endpointHost, ['localhost', '127.0.0.1', '::1'], true)
            || str_ends_with($endpointHost, '.local')
            || str_ends_with($endpointHost, '.test');

        if ($validated['mode'] === 'live') {
            if ($endpointScheme !== 'https') {
                return back()
                    ->withErrors(['webhookEndpoint' => 'Live Stripe mode requires an HTTPS webhook endpoint.'])
                    ->withInput();
            }

            if (in_array($endpointHost, ['localhost', '127.0.0.1', '::1'], true)) {
                return back()
                    ->withErrors(['webhookEndpoint' => 'Live Stripe mode cannot use a localhost webhook URL. Use a public HTTPS URL.'])
                    ->withInput();
            }
        }

        $gateway = PlatformBillingSetting::query()->firstOrNew();

        $gateway->forceFill([
            'provider' => $validated['provider'],
            'mode' => $validated['mode'],
            'status' => $validated['status'],
            'public_key' => blank($validated['publicKey'] ?? null) ? null : trim((string) $validated['publicKey']),
            'webhook_endpoint' => $webhookEndpoint,
        ])->save();

        if (filled($validated['secretKey'] ?? null)) {
            $gateway->forceFill([
                'secret_key' => trim((string) $validated['secretKey']),
                'webhook_secret' => null,
                'metadata_json' => collect($gateway->metadata_json ?? [])
                    ->except(['stripe_webhook_endpoint_id', 'stripe_webhook_synced_at'])
                    ->all(),
            ])->save();
        }

        if ($validated['mode'] === 'test' && $isLocalWebhookEndpoint) {
            $gateway->forceFill([
                'status' => filled($gateway->public_key) ? 'setup_required' : $gateway->status,
            ])->save();

            Inertia::flash('toast', [
                'type' => 'warning',
                'message' => 'Keys saved. Stripe webhook endpoint was not created because the URL is local-only. Use a public HTTPS URL, or run Stripe CLI (stripe listen) and set STRIPE_WEBHOOK_SECRET for local testing.',
            ]);

            return redirect()->route('admin.commerce');
        }

        if ($this->stripeBilling->isConfigured()) {
            try {
                $this->stripeBilling->syncWebhookEndpoint($gateway->fresh());
                $gateway->refresh();

                if (filled($gateway->public_key) && filled($gateway->webhook_secret)) {
                    $gateway->forceFill(['status' => 'ready'])->save();
                }
            } catch (Throwable $exception) {
                report($exception);

                $stripeMessage = $exception instanceof RequestException
                    ? (data_get($exception->response?->json(), 'error.message') ?: $exception->getMessage())
                    : $exception->getMessage();

                Inertia::flash('toast', ['type' => 'error', 'message' => 'Keys saved, but Stripe webhook generation failed: '.$stripeMessage]);

                return redirect()->route('admin.commerce');
            }
        }

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Stripe gateway connected. Webhook secret is stored automatically.']);

        return redirect()->route('admin.commerce');
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }

    private function authorizeCustomerBillingMutation(User $user, Organization $organization): void
    {
        abort_unless($this->canManageCustomerBilling($user, $organization), 403);
    }

    private function canManageCustomerBilling(User $user, Organization $organization): bool
    {
        return $organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->whereIn('role', ['owner', 'admin'])
            ->exists();
    }

    private function authorizePlatformBilling(User $user): void
    {
        abort_unless($this->canManagePlatformBilling($user), 403);
    }

    private function canManagePlatformBilling(User $user): bool
    {
        return $user->is_platform_admin === true;
    }

    /**
     * @return Builder<Organization>
     */
    private function customerOrganizationsQuery(): Builder
    {
        return Organization::query()
            ->whereDoesntHave('owner', fn (Builder $query) => $query->where('is_platform_admin', true));
    }

    /**
     * @return array<string, mixed>
     */
    private function platformBillingPayload(array $planCatalog): array
    {
        $accounts = $this->customerOrganizationsQuery()
            ->with('subscription')
            ->withCount(['memberships', 'sites'])
            ->orderBy('name')
            ->get()
            ->map(function (Organization $organization) use ($planCatalog) {
                $subscription = $this->subscriptionPayload($organization->subscription);

                return [
                    'id' => $organization->id,
                    'name' => $organization->name,
                    'slug' => $organization->slug,
                    'billingEmail' => $organization->billing_email,
                    'plan' => $subscription['plan'],
                    'interval' => $subscription['interval'],
                    'status' => $subscription['status'],
                    'cancelAtPeriodEnd' => $subscription['cancelAtPeriodEnd'],
                    'currentPeriodEndsAt' => $subscription['currentPeriodEndsAt'],
                    'amountCents' => $this->amountFor($planCatalog, $subscription['plan'], $subscription['interval']),
                    'memberCount' => $organization->memberships_count,
                    'siteCount' => $organization->sites_count,
                ];
            })
            ->values();

        $monthlyRecurringRevenue = $accounts->sum(function (array $account) {
            if (! in_array($account['status'], ['trialing', 'active'], true)) {
                return 0;
            }

            return $account['interval'] === 'annual'
                ? (int) round($account['amountCents'] / 12)
                : $account['amountCents'];
        });

        return [
            'summary' => [
                'customerCount' => $this->customerOrganizationsQuery()->count(),
                'activeSubscriptionCount' => $accounts->whereIn('status', ['trialing', 'active'])->count(),
                'pastDueCount' => $accounts->where('status', 'past_due')->count(),
                'monthlyRecurringRevenueCents' => $monthlyRecurringRevenue,
            ],
            'accounts' => $accounts->all(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function paymentGatewayPayload(): array
    {
        $settings = PlatformBillingSetting::query()->first() ?? new PlatformBillingSetting([
            'provider' => 'stripe',
            'mode' => 'test',
            'status' => 'setup_required',
            'webhook_endpoint' => route('stripe.webhook'),
        ]);

        return [
            'provider' => $settings->provider,
            'mode' => $settings->mode,
            'status' => $settings->status,
            'publicKey' => $settings->public_key,
            'secretKeyConfigured' => filled($settings->secret_key) || filled(config('services.stripe.secret')),
            'webhookEndpoint' => $settings->webhook_endpoint && ! str_ends_with($settings->webhook_endpoint, '/webhooks/billing')
                ? $settings->webhook_endpoint
                : route('stripe.webhook'),
            'webhookSecretConfigured' => filled($settings->webhook_secret) || filled(config('services.stripe.webhook_secret')),
            'stripeWebhookEndpointId' => data_get($settings->metadata_json, 'stripe_webhook_endpoint_id'),
            'stripeWebhookSyncedAt' => data_get($settings->metadata_json, 'stripe_webhook_synced_at'),
            'providers' => collect(self::PAYMENT_GATEWAYS)->map(fn (string $label, string $key) => [
                'key' => $key,
                'label' => $label,
            ])->values()->all(),
            'statuses' => collect(self::GATEWAY_STATUSES)->map(fn (string $status) => [
                'key' => $status,
                'label' => str($status)->replace('_', ' ')->title()->toString(),
            ])->all(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function subscriptionPayload(?OrganizationSubscription $subscription): array
    {
        if (! $subscription) {
            return [
                'plan' => 'free',
                'interval' => 'monthly',
                'status' => 'active',
                'cancelAtPeriodEnd' => false,
                'currentPeriodStartsAt' => now()->toIso8601String(),
                'currentPeriodEndsAt' => null,
                'stripeSubscriptionId' => null,
                'stripePriceId' => null,
                'stripeSyncedAt' => null,
            ];
        }

        return [
            'plan' => $subscription->plan,
            'interval' => $subscription->interval,
            'status' => $subscription->status,
            'cancelAtPeriodEnd' => $subscription->cancel_at_period_end,
            'currentPeriodStartsAt' => $subscription->current_period_starts_at?->toIso8601String(),
            'currentPeriodEndsAt' => $subscription->current_period_ends_at?->toIso8601String(),
            'stripeSubscriptionId' => $subscription->stripe_subscription_id,
            'stripePriceId' => $subscription->stripe_price_id,
            'stripeSyncedAt' => $subscription->stripe_synced_at?->toIso8601String(),
        ];
    }

    /**
     * @return array<string, int|string>
     */
    private function planFor(array $planCatalog, string $plan): array
    {
        return $planCatalog[$plan] ?? array_values($planCatalog)[0] ?? [
            'label' => 'Free',
            'description' => 'Start publishing with a small workspace before upgrading.',
            'monthlyPriceCents' => 0,
            'annualPriceCents' => 0,
            'includedSites' => 1,
            'includedMembers' => 1,
            'includedPublishedPages' => 25,
            'includedStorageBytes' => 268_435_456,
        ];
    }

    private function amountFor(array $planCatalog, string $plan, string $interval): int
    {
        $config = $this->planFor($planCatalog, $plan);

        return (int) ($interval === 'annual' ? $config['annualPriceCents'] : $config['monthlyPriceCents']);
    }

    /**
     * @return array<string, array<string, int|string>>
     */
    private function planCatalog(): array
    {
        $plans = SubscriptionPlan::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->mapWithKeys(fn (SubscriptionPlan $plan) => [
                $plan->slug => [
                    'label' => $plan->label,
                    'description' => $plan->description,
                    'monthlyPriceCents' => $plan->monthly_price_cents,
                    'annualPriceCents' => $plan->annual_price_cents,
                    'includedSites' => $plan->included_sites,
                    'includedMembers' => $plan->included_members,
                    'includedPublishedPages' => $plan->included_published_pages,
                    'includedStorageBytes' => $plan->included_storage_bytes,
                ],
            ])
            ->all();

        if ($plans !== []) {
            return $plans;
        }

        return [
            'free' => [
                'label' => 'Free',
                'description' => 'Start publishing with a small workspace before upgrading.',
                'monthlyPriceCents' => 0,
                'annualPriceCents' => 0,
                'includedSites' => 1,
                'includedMembers' => 1,
                'includedPublishedPages' => 25,
                'includedStorageBytes' => 268_435_456,
            ],
        ];
    }
}
