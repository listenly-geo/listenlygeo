<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\ExportPageDocument;
use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Gate;
use InvalidArgumentException;
use Symfony\Component\HttpFoundation\HeaderUtils;

class PrototypeEditorExportController extends Controller
{
    public function __construct(
        private readonly ExportPageDocument $exportPageDocument,
    ) {}

    public function __invoke(Page $page, string $format): Response
    {
        $page->loadMissing(['site.organization', 'space', 'currentRevision']);
        Gate::authorize('update', $page);

        try {
            $export = ($this->exportPageDocument)($page, $format);
        } catch (InvalidArgumentException) {
            abort(404);
        }

        return response($export['content'], 200, [
            'Content-Type' => $export['contentType'],
            'Content-Disposition' => HeaderUtils::makeDisposition(HeaderUtils::DISPOSITION_ATTACHMENT, $export['filename']),
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
