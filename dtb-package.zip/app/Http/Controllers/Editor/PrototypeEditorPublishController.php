<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\PublishSiteRelease;
use App\Http\Controllers\Controller;
use App\Http\Requests\Editor\PublishSiteReleaseRequest;
use App\Models\Site;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class PrototypeEditorPublishController extends Controller
{
    public function __construct(
        private readonly PublishSiteRelease $publishSiteRelease,
    ) {}

    public function __invoke(PublishSiteReleaseRequest $request, Site $site): JsonResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $published = ($this->publishSiteRelease)($site, $request->user(), $request->validated());

        return response()->json([
            'status' => 'ok',
            'published' => $published,
        ]);
    }
}
