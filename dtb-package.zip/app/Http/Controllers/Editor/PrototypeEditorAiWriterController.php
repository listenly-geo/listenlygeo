<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Editor\GeneratePrototypeAiDraft;
use App\Http\Controllers\Controller;
use App\Http\Requests\Editor\AiWriteRequest;
use App\Models\Page;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use RuntimeException;

class PrototypeEditorAiWriterController extends Controller
{
    public function __construct(
        private readonly GeneratePrototypeAiDraft $generatePrototypeAiDraft,
    ) {}

    public function __invoke(AiWriteRequest $request, Page $page): JsonResponse
    {
        $page->loadMissing('site.organization', 'currentRevision');
        Gate::authorize('update', $page);

        try {
            $generation = ($this->generatePrototypeAiDraft)($page, $request->validated());
        } catch (RuntimeException $exception) {
            return response()->json([
                'message' => $exception->getMessage(),
            ], 503);
        }

        return response()->json([
            'status' => 'ok',
            'generation' => $generation,
        ]);
    }
}
