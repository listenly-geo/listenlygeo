<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\BuildDraftSitePayload;
use App\Http\Controllers\Controller;
use App\Models\Site;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Inertia\Inertia;
use Inertia\Response;

class DraftDocsPreviewController extends Controller
{
    public function __construct(
        private readonly BuildDraftSitePayload $buildDraftSitePayload,
    ) {}

    public function __invoke(Request $request, Site $site, ?string $path = null): Response|RedirectResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('view', $site);

        $payload = ($this->buildDraftSitePayload)($site, $path);

        if ($path === null || $path === '') {
            return redirect()->route('editor.sites.preview', [
                'site' => $site,
                'path' => $payload['page']['path'],
            ]);
        }

        return Inertia::render('docs/show', $payload);
    }
}
