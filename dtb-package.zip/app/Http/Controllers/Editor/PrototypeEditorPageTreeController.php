<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\ManagePrototypePageTree;
use App\Http\Controllers\Controller;
use App\Http\Requests\Editor\MovePrototypePageRequest;
use App\Http\Requests\Editor\StorePrototypePageRequest;
use App\Http\Requests\Editor\UpdatePrototypePageTreeRequest;
use App\Models\Page;
use App\Models\Site;
use App\Models\Space;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\ValidationException;

class PrototypeEditorPageTreeController extends Controller
{
    public function __construct(
        private readonly ManagePrototypePageTree $managePrototypePageTree,
    ) {}

    public function store(StorePrototypePageRequest $request, Site $site): JsonResponse
    {
        $site->loadMissing(['organization', 'defaultSpace']);
        Gate::authorize('update', $site);

        $parentPageId = $request->validated('parentPageId');
        $parentPage = $parentPageId ? Page::query()->find($parentPageId) : null;
        $spaceId = $request->validated('spaceId');
        $space = $spaceId ? Space::query()->find($spaceId) : null;

        if ($parentPage && $parentPage->site_id !== $site->id) {
            throw ValidationException::withMessages([
                'parentPageId' => 'The selected parent page is invalid.',
            ]);
        }

        if ($space && $space->site_id !== $site->id) {
            throw ValidationException::withMessages([
                'spaceId' => 'The selected space is invalid.',
            ]);
        }

        $page = $this->managePrototypePageTree->create($site, $request->user(), $parentPage, $space);

        return response()->json([
            'status' => 'ok',
            'page' => $page,
        ]);
    }

    public function update(UpdatePrototypePageTreeRequest $request, Page $page): JsonResponse
    {
        $page->loadMissing(['site.organization', 'parent', 'currentRevision']);
        Gate::authorize('update', $page);

        $saved = $this->managePrototypePageTree->rename(
            $page,
            $request->user(),
            (string) $request->validated('title'),
        );

        return response()->json([
            'status' => 'ok',
            'page' => $saved,
        ]);
    }

    public function move(MovePrototypePageRequest $request, Page $page): JsonResponse
    {
        $page->loadMissing(['site.organization', 'parent', 'currentRevision']);
        Gate::authorize('update', $page);

        $targetPage = Page::query()->findOrFail($request->integer('targetPageId'));

        if ($targetPage->site_id !== $page->site_id) {
            throw ValidationException::withMessages([
                'targetPageId' => 'The selected target page is invalid.',
            ]);
        }

        $saved = $this->managePrototypePageTree->move(
            $page,
            $targetPage,
            (string) $request->validated('position'),
            $request->user(),
        );

        return response()->json([
            'status' => 'ok',
            'page' => $saved,
        ]);
    }

    public function destroy(Page $page): JsonResponse
    {
        $page->loadMissing('site.organization');
        Gate::authorize('update', $page);

        $deletedPageId = 'p_'.$page->id;

        $this->managePrototypePageTree->delete($page, request()->user());

        return response()->json([
            'status' => 'ok',
            'deletedPageId' => $deletedPageId,
        ]);
    }
}
