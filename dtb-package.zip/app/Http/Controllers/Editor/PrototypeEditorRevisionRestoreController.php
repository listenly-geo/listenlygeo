<?php

namespace App\Http\Controllers\Editor;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\PageRevision;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class PrototypeEditorRevisionRestoreController extends Controller
{
    public function __invoke(Page $page, PageRevision $revision): JsonResponse
    {
        $page->loadMissing('site.organization');
        Gate::authorize('update', $page);

        abort_unless((int) $revision->page_id === (int) $page->id, 404);

        $nextVersion = ((int) $page->revisions()->max('version_number')) + 1;

        $restoredRevision = $page->revisions()->create([
            'version_number' => $nextVersion,
            'title' => $revision->title,
            'subtitle' => $revision->subtitle,
            'blocks_json' => $revision->blocks_json,
            'editor_meta_json' => $revision->editor_meta_json,
            'search_document' => $revision->search_document,
            'save_type' => 'manual',
            'change_message' => 'Restored from revision '.$revision->version_number,
            'created_by' => request()->user()?->id,
        ]);

        $page->forceFill([
            'title' => trim(strip_tags((string) $restoredRevision->title)) ?: 'Untitled',
            'current_revision_id' => $restoredRevision->id,
            'updated_by' => request()->user()?->id,
        ])->save();

        return response()->json([
            'status' => 'ok',
            'restored' => [
                'revisionId' => $restoredRevision->id,
                'version' => $restoredRevision->version_number,
                'sourceRevisionId' => $revision->id,
                'sourceVersion' => $revision->version_number,
            ],
        ]);
    }
}
