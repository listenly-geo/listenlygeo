<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\AutosavePageRevision;
use App\Http\Controllers\Controller;
use App\Http\Requests\Editor\AutosavePageRequest;
use App\Models\Page;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class PrototypeEditorAutosaveController extends Controller
{
    public function __construct(
        private readonly AutosavePageRevision $autosavePageRevision,
    ) {}

    public function __invoke(AutosavePageRequest $request, Page $page): JsonResponse
    {
        $page->loadMissing('site.organization');
        Gate::authorize('update', $page);

        $saved = ($this->autosavePageRevision)($page, $request->user(), $request->validated());

        return response()->json([
            'status' => 'ok',
            'saved' => $saved,
        ]);
    }
}
