<?php

namespace App\Http\Controllers\Editor;

use App\Http\Controllers\Controller;
use App\Models\Site;
use App\Models\Space;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class PrototypeEditorSpaceController extends Controller
{
    public function store(Request $request, Site $site): JsonResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:80'],
        ]);

        $name = trim((string) $validated['name']);

        $space = $site->spaces()->create([
            'name' => $name,
            'slug' => $this->availableSpaceSlug($site, $name),
            'icon' => 'folder',
            'color' => $this->colorForValue($name),
            'position' => ((int) ($site->spaces()->max('position') ?? -1)) + 1,
            'created_by' => $request->user()->id,
            'updated_by' => $request->user()->id,
        ]);

        if (! $site->default_space_id) {
            $site->forceFill([
                'default_space_id' => $space->id,
                'updated_by' => $request->user()->id,
            ])->save();
        }

        return response()->json([
            'status' => 'ok',
            'space' => $this->spacePayload($space),
        ]);
    }

    private function availableSpaceSlug(Site $site, string $name): string
    {
        $baseSlug = Str::slug($name) ?: 'space';
        $candidate = $baseSlug;
        $suffix = 2;

        while ($site->spaces()->where('slug', $candidate)->exists()) {
            $candidate = $baseSlug.'-'.$suffix;
            $suffix++;
        }

        return $candidate;
    }

    /**
     * @return array<string, mixed>
     */
    private function spacePayload(Space $space): array
    {
        $space->loadMissing('site');

        return [
            'id' => 'sp_'.$space->id,
            'dbId' => $space->id,
            'uuid' => $space->uuid,
            'editorUrl' => route('editor.space', ['site' => $space->site->uuid, 'space' => $space->uuid], false),
            'name' => $space->name,
            'slug' => $space->slug,
            'color' => $space->color,
            'count' => 0,
            'icon' => strtoupper(substr($space->name, 0, 1)) ?: 'D',
        ];
    }

    private function colorForValue(string $value): string
    {
        $palette = [
            'oklch(55% 0.14 255)',
            'oklch(52% 0.15 155)',
            'oklch(55% 0.15 30)',
            'oklch(58% 0.14 305)',
            'oklch(60% 0.14 70)',
            'oklch(55% 0.13 205)',
        ];

        return $palette[abs(crc32($value)) % count($palette)];
    }
}
