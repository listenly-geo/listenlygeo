<?php

namespace App\Http\Controllers\Editor;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\PageComment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class PrototypeEditorCommentController extends Controller
{
    public function store(Request $request, Page $page): JsonResponse
    {
        Gate::authorize('update', $page);

        $validated = $request->validate([
            'body' => 'required|string|max:5000',
            'block_id' => 'nullable|string|max:255',
        ]);

        $comment = $page->comments()->create([
            'author_id' => $request->user()->id,
            'body' => $validated['body'],
            'block_id' => $validated['block_id'] ?? null,
        ]);

        $comment->load('author');
        $authorName = $comment->author?->name ?: 'Unknown';

        return response()->json([
            'comment' => [
                'id' => 'c'.$comment->id,
                'author' => $authorName,
                'initials' => $this->initials($authorName),
                'color' => $this->colorForValue((string) ($comment->author?->id ?? $comment->id)),
                'time' => 'just now',
                'ref' => $comment->block_id ? 'Block '.$comment->block_id : 'Page comment',
                'body' => $comment->body,
                'replies' => [],
                'resolved' => false,
            ],
        ]);
    }

    public function resolve(Request $request, PageComment $comment): JsonResponse
    {
        Gate::authorize('update', $comment->page);

        $isResolved = $comment->resolved_at !== null;

        $comment->update($isResolved
            ? ['resolved_at' => null, 'resolved_by' => null]
            : ['resolved_at' => now(), 'resolved_by' => $request->user()->id]
        );

        return response()->json(['resolved' => ! $isResolved]);
    }

    private function initials(string $name): string
    {
        $words = array_values(array_filter(explode(' ', trim($name))));
        if (count($words) >= 2) {
            return strtoupper(substr($words[0], 0, 1).substr(end($words), 0, 1));
        }

        return strtoupper(substr($name, 0, 2));
    }

    private function colorForValue(string $value): string
    {
        $hue = abs(crc32($value)) % 360;

        return "oklch(55% 0.14 {$hue})";
    }
}
