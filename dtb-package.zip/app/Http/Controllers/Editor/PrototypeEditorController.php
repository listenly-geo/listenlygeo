<?php

namespace App\Http\Controllers\Editor;

use App\Actions\Docs\BuildPrototypeSeedData;
use App\Actions\Docs\EnsureEditorWorkspace;
use App\Http\Controllers\Controller;
use App\Models\Site;
use App\Models\Space;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

class PrototypeEditorController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
        private readonly BuildPrototypeSeedData $buildPrototypeSeedData,
    ) {}

    public function entry(Request $request): RedirectResponse
    {
        $bootstrap = ($this->ensureEditorWorkspace)($request->user());

        return redirect()->route('editor.space', [
            'site' => $bootstrap['site']['uuid'],
            'space' => $bootstrap['space']['uuid'],
        ]);
    }

    public function space(Request $request, Site $site, Space $space): Response
    {
        $this->authorizeSiteSpace($site, $space);

        return $this->servePrototypeFile($request, 'index.html', $space);
    }

    public function spacePage(Request $request, Site $site, Space $space, string $pageSlug): Response
    {
        $this->authorizeSiteSpace($site, $space);

        $page = $space->pages()->where('slug', $pageSlug)->first();
        abort_unless($page, 404);

        return $this->servePrototypeFile($request, 'index.html', $space, $page->slug);
    }

    public function state(Request $request, Site $site, Space $space): JsonResponse
    {
        $this->authorizeSiteSpace($site, $space);

        return response()->json([
            'status' => 'ok',
            'bootstrap' => ($this->ensureEditorWorkspace)($request->user(), $space),
            'state' => ($this->buildPrototypeSeedData)($request->user(), $space),
        ]);
    }

    public function __invoke(Request $request, ?string $path = null): Response|RedirectResponse
    {
        if ($path === null || $path === '') {
            return $this->entry($request);
        }

        return $this->servePrototypeFile($request, $path, $this->spaceFromRequest($request), (string) $request->query('page', '') ?: null);
    }

    private function servePrototypeFile(Request $request, string $path, ?Space $activeSpace = null, ?string $activePageSlug = null): Response
    {
        $basePath = realpath(base_path('docs-editor-prototype'));
        abort_unless($basePath, 404);

        $resolvedPath = realpath($basePath.DIRECTORY_SEPARATOR.$path);

        abort_unless(
            $resolvedPath !== false
            && str_starts_with($resolvedPath, $basePath.DIRECTORY_SEPARATOR)
            && is_file($resolvedPath),
            404,
        );

        $content = file_get_contents($resolvedPath);
        abort_if($content === false, 404);

        if (Str::endsWith($resolvedPath, DIRECTORY_SEPARATOR.'src'.DIRECTORY_SEPARATOR.'bundle.jsx')) {
            $content = $this->rewriteBundleSeedData($content, ($this->buildPrototypeSeedData)($request->user(), $activeSpace, $activePageSlug));
            $content = $this->rewriteBundleRefreshIcon($content);
            $content = $this->rewriteBundleOutlineTimeline($content);
            $content = $this->rewriteBundleAutosaveBridge($content);
            $content = $this->rewriteBundleMediaLibrary($content);
            $content = $this->rewriteBundleCommentPersistence($content);
            $content = $this->rewriteBundleChecklistEnhancements($content);
            $content = $this->rewriteBundleHistoryRestore($content);
            $content = $this->rewriteBundleAiWriterBridge($content);
            $content = $this->rewriteBundleExportBridge($content);
            $content = $this->rewriteBundleMobileEditorUX($content);
        }

        if (Str::endsWith($resolvedPath, DIRECTORY_SEPARATOR.'styles.css')) {
            $content = $this->rewriteResponsiveRightPaneStyles($content);
        }

        if (Str::endsWith($resolvedPath, DIRECTORY_SEPARATOR.'index.html')) {
            $bootstrap = ($this->ensureEditorWorkspace)($request->user(), $activeSpace, $activePageSlug);
            $loader = $this->editorEntryLoaderMarkup($bootstrap);
            $baseTag = '<base href="'.e($activeSpace ? rtrim(url('/editor'), '/').'/' : $this->editorBaseHref($request, $path)).'">';
            $bundleSrc = 'src/bundle.jsx';
            if ($activeSpace) {
                $bundleSrc .= '?space='.urlencode($activeSpace->uuid);
                if ($activePageSlug) {
                    $bundleSrc .= '&page='.urlencode($activePageSlug);
                }
            }
            $injected = '<script>'
                .'window.__LARAVEL_BOOTSTRAP__ = '.json_encode($bootstrap, JSON_THROW_ON_ERROR).';'
                .'window.__LARAVEL_EDITOR_CONFIG__ = '.json_encode($this->editorRuntimeConfig(), JSON_THROW_ON_ERROR).';'
                .'</script>';
            $content = str_replace('<head>', '<head>'.$baseTag, $content);
            $content = str_replace('</head>', $injected.'</head>', $content);
            $content = str_replace('<body class="theme-light">', '<body class="theme-light">'.$loader, $content);

            if ($activeSpace) {
                $content = str_replace('src="src/bundle.jsx"', 'src="'.e($bundleSrc).'"', $content);
            }
        }

        $headers = ['Content-Type' => $this->contentType($resolvedPath)];

        if (Str::endsWith($resolvedPath, [
            DIRECTORY_SEPARATOR.'src'.DIRECTORY_SEPARATOR.'bundle.jsx',
            DIRECTORY_SEPARATOR.'index.html',
        ])) {
            $headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
            $headers['Pragma'] = 'no-cache';
            $headers['Expires'] = '0';
        }

        return response($content, 200, $headers);
    }

    private function authorizeSiteSpace(Site $site, Space $space): void
    {
        $space->loadMissing('site.organization');

        abort_unless($space->site_id === $site->id, 404);

        Gate::authorize('update', $site);
    }

    private function spaceFromRequest(Request $request): ?Space
    {
        $uuid = (string) $request->query('space', '');

        if (! Str::isUuid($uuid)) {
            return null;
        }

        $space = Space::query()->with('site.organization')->where('uuid', $uuid)->first();

        if ($space) {
            Gate::authorize('update', $space->site);
        }

        return $space;
    }

    private function contentType(string $path): string
    {
        return match (pathinfo($path, PATHINFO_EXTENSION)) {
            'html' => 'text/html; charset=UTF-8',
            'css' => 'text/css; charset=UTF-8',
            'js' => 'application/javascript; charset=UTF-8',
            'jsx' => 'text/babel; charset=UTF-8',
            'json' => 'application/json; charset=UTF-8',
            'png' => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'svg' => 'image/svg+xml',
            default => mime_content_type($path) ?: 'application/octet-stream',
        };
    }

    private function rewriteResponsiveRightPaneStyles(string $styles): string
    {
        $append = '';

        if (! str_contains($styles, 'prototype-rightpane-drawer')) {
            $append .= <<<'CSS'
/* prototype-rightpane-drawer */
@media (max-width: 1100px) {
    .app:not(.no-right) .rightpane {
        display: flex !important;
        position: fixed;
        top: 44px;
        right: 0;
        bottom: 0;
        width: min(340px, calc(100vw - 16px));
        max-width: 100vw;
        background: var(--bg-elevated);
        border-left: 1px solid var(--border);
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.18);
        z-index: 35;
    }

    .app.no-right .rightpane {
        display: none !important;
    }

    .app:not(.no-right) .rp-body {
        overscroll-behavior: contain;
    }
}
CSS;
        }

        if (! str_contains($styles, 'prototype-rightpane-tab-fit')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-rightpane-tab-fit */
.rp-tabs {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    align-items: stretch;
    padding: 0 4px;
}

.rp-tab {
    min-width: 0;
    justify-content: center;
    gap: 4px;
    padding: 10px 4px 9px;
    font-size: 11.5px;
    text-align: center;
    line-height: 1.2;
    white-space: nowrap;
}

.rp-tab-history {
    grid-column: auto;
}

.rp-tab svg {
    width: 12px;
    height: 12px;
}

.rp-tab svg,
.rp-tab .count {
    flex: 0 0 auto;
}

.rp-tab .count {
    font-size: 9.5px;
    padding: 1px 4px;
}

@media (max-width: 1100px) {
    .app:not(.no-right) .rp-tabs {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .app:not(.no-right) .rp-tab {
        font-size: 11.5px;
    }
}
CSS;
        }

        if (! str_contains($styles, 'prototype-publish-menu-dynamic')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-publish-menu-dynamic */
.publish-menu .row {
    gap: 12px;
    align-items: flex-start;
}

.publish-menu .row > span:first-child {
    flex: 0 0 64px;
}

.publish-menu .row .val {
    flex: 1 1 auto;
    min-width: 0;
    text-align: right;
    overflow-wrap: anywhere;
}

.publish-menu .row a.val {
    display: block;
    line-height: 1.35;
}

.publish-menu .row a.val.publish-action-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 116px;
    min-height: 32px;
    padding: 0 12px;
    border: 1px solid var(--border-strong);
    border-radius: 7px;
    background: var(--bg-subtle);
    color: var(--text);
    font-family: var(--font-ui);
    font-size: 12px;
    font-weight: 650;
    line-height: 1;
    text-align: center;
    text-decoration: none;
    white-space: nowrap;
}

.publish-menu .row a.val.publish-action-link:hover {
    background: var(--bg-hover);
}
CSS;
        }

        if (! str_contains($styles, 'prototype-outline-timeline-polish')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-outline-timeline-polish */
.outline-v2 {
    padding: 18px 14px;
}

.outline-v2 .outline-label {
    padding: 0 2px 12px;
}

.outline-v2 .otl-list {
    --otl-progress: 0%;
    --otl-rail-left: 7px;
    padding: 2px 0 2px 22px;
}

.outline-v2 .otl-rail {
    display: none;
}

.outline-v2 .otl-list::before,
.outline-v2 .otl-list::after {
    content: "";
    position: absolute;
    left: var(--otl-rail-left);
    top: 13px;
    width: 2px;
    border-radius: 999px;
    pointer-events: none;
}

.outline-v2 .otl-list::before {
    bottom: 13px;
    background: var(--border);
}

.outline-v2 .otl-list::after {
    height: var(--otl-progress);
    min-height: 0;
    background: linear-gradient(180deg, var(--accent), var(--accent-ink));
    box-shadow: 0 0 0 3px var(--accent-soft);
}

.outline-v2 .otl-item {
    min-height: 30px;
    padding: 6px 10px 6px 12px;
    border-radius: 6px;
    transition: color 0.14s ease, background 0.14s ease, box-shadow 0.14s ease;
}

.outline-v2 .otl-item.child {
    padding-left: 24px;
}

.outline-v2 .otl-item.level-3 {
    padding-left: 40px;
}

.outline-v2 .otl-item::before {
    content: "";
    position: absolute;
    left: -20px;
    top: 50%;
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--bg);
    border: 1.5px solid var(--border-strong);
    box-shadow: 0 0 0 3px var(--bg);
    transform: translateY(-50%);
    z-index: 2;
}

.outline-v2 .otl-item::after {
    content: "";
    position: absolute;
    left: -12px;
    top: 50%;
    width: 8px;
    height: 1px;
    background: var(--border);
    transform: translateY(-50%);
    z-index: 1;
}

.outline-v2 .otl-item.seen::before {
    background: var(--accent-soft);
    border-color: var(--accent);
}

.outline-v2 .otl-item.active,
.outline-v2 .otl-item.active:hover {
    color: var(--accent-ink);
    background: var(--accent-soft);
    box-shadow: inset 0 0 0 1px var(--selection);
}

.outline-v2 .otl-item.active::before {
    left: -21px;
    width: 10px;
    height: 10px;
    background: var(--accent);
    border-color: var(--bg);
    box-shadow: 0 0 0 3px var(--bg), 0 0 0 6px var(--accent-soft);
}

.outline-v2 .otl-item:hover {
    background: var(--bg-hover);
}

.outline-v2 .otl-dot {
    display: none;
}
CSS;
        }

        if (! str_contains($styles, 'prototype-export-menu-actions')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-export-menu-actions */
.publish-menu .export-actions {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--border);
}

.publish-menu .export-label {
    margin-bottom: 8px;
    font-size: 11px;
    font-weight: 600;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0;
}

.publish-menu .export-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 6px;
}

.publish-menu .export-grid button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 32px;
    padding: 7px 8px;
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-subtle);
    color: var(--text);
    font-size: 12px;
}

.publish-menu .export-grid button:hover {
    border-color: var(--border-strong);
    background: var(--bg-hover);
}
CSS;
        }

        if (! str_contains($styles, 'prototype-mobile-editor-panels')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-mobile-editor-panels */
.mobile-panel-backdrop {
    display: none;
}

.tb-mobile-panels {
    display: none;
    align-items: center;
    gap: 4px;
}

.tb-mobile-toggle.active {
    background: var(--accent-soft);
    color: var(--accent-ink);
}

.tb-desktop-panel-toggle {
    display: inline-flex;
}

@media (max-width: 760px) {
    .app,
    .app.no-right,
    .app.sidebar-collapsed,
    .app.no-right.sidebar-collapsed {
        grid-template-columns: 1fr !important;
    }

    .app {
        --mobile-editor-inline-padding: clamp(14px, 3.6vw, 18px);
    }

    .app .workspace,
    .app.no-right .workspace,
    .app.sidebar-collapsed .workspace,
    .app.no-right.sidebar-collapsed .workspace {
        grid-template-columns: 1fr !important;
    }

    .tb-mobile-panels {
        display: inline-flex;
        flex: 0 0 auto;
    }

    .tb-desktop-panel-toggle {
        display: none !important;
    }

    .topbar {
        gap: 4px;
        padding: 0 4px;
    }

    .topbar .brand {
        min-width: 0;
        flex: 1 1 auto;
        padding-right: 4px;
    }

    .topbar .brand-name {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .topbar-right {
        margin-left: auto;
        min-width: 0;
        flex: 0 1 auto;
        gap: 1px;
    }

    .topbar-right > * {
        flex: 0 0 auto;
    }

    .topbar-right .tb-btn,
    .topbar-right .tb-search {
        min-width: 0;
    }

    .topbar-right .tb-btn {
        padding: 0 8px;
        gap: 4px;
    }

    .topbar-right .tb-search {
        width: 28px;
        min-width: 28px;
    }

    .topbar-right button[title="Toggle theme"] {
        display: none;
    }

    .topbar-right .tb-ai-trigger {
        display: none;
    }

    .topbar-right .publish-wrap > .tb-btn.primary {
        padding: 0 6px;
        white-space: nowrap;
        gap: 0;
        font-size: 12px;
    }

    .topbar-right .publish-wrap > .tb-btn.primary svg {
        display: none;
    }

    .workspace > .editor-wrap {
        grid-column: 1 / -1;
        width: 100%;
    }

    .editor-wrap {
        min-width: 0;
    }

    .editor-hero {
        width: 100%;
        box-sizing: border-box;
        max-width: none;
        padding: 28px var(--mobile-editor-inline-padding) 8px;
    }

    .editor-body {
        width: 100%;
        box-sizing: border-box;
        max-width: none;
        padding: 8px var(--mobile-editor-inline-padding) 120px;
    }

    .hero-byline {
        align-items: flex-start;
        gap: 8px;
    }

    .hero-byline .right {
        margin-left: 0;
        flex-wrap: wrap;
        gap: 6px;
    }

    .tb-mobile-toggle {
        width: 28px;
        padding: 0;
        justify-content: center;
        flex: 0 0 auto;
    }

    .app .sidebar {
        top: 52px;
        left: 8px;
        bottom: 8px;
        width: min(320px, calc(100vw - 16px));
        max-width: calc(100vw - 16px);
        border: 1px solid var(--border);
        border-radius: 16px;
        background: var(--bg-elevated);
        box-shadow: 0 20px 48px rgba(0, 0, 0, 0.18);
        z-index: 32;
    }

    .app.sidebar-collapsed .sidebar {
        transform: translateX(calc(-100% - 24px));
    }

    .app:not(.no-right) .rightpane {
        top: 52px !important;
        right: 8px;
        bottom: 8px;
        width: min(320px, calc(100vw - 16px));
        max-width: calc(100vw - 16px);
        border: 1px solid var(--border);
        border-radius: 16px;
        box-shadow: 0 20px 48px rgba(0, 0, 0, 0.22);
        z-index: 36;
    }

    .mobile-panel-backdrop {
        display: block;
        position: fixed;
        inset: 44px 0 0;
        border: 0;
        padding: 0;
        margin: 0;
        background: rgba(15, 23, 42, 0.22);
        backdrop-filter: blur(2px);
        z-index: 30;
    }
}
CSS;
        }

        if (! str_contains($styles, 'prototype-block-gutter-alignment')) {
            $append .= "\n\n".<<<'CSS'
/* prototype-block-gutter-alignment */
.block-row .block-gutter {
    top: 13px;
}
CSS;
        }

        return $append === '' ? $styles : rtrim($styles)."\n\n".ltrim($append);
    }

    /**
     * @param  array<string, mixed>  $bootstrap
     */
    private function editorEntryLoaderMarkup(array $bootstrap): string
    {
        $configuredAppName = trim((string) config('app.name', ''));
        $appName = $configuredAppName !== '' && strcasecmp($configuredAppName, 'Laravel') !== 0
                ? $configuredAppName
                : 'DocTheBuilder';
        $siteName = trim((string) data_get($bootstrap, 'site.name', ''));
        $spaceName = trim((string) data_get($bootstrap, 'space.name', ''));
        $contextLabel = $siteName !== ''
                ? $siteName.($spaceName !== '' ? ' / '.$spaceName : '')
                : 'Opening editor';

        $letters = preg_split('//u', $appName, -1, PREG_SPLIT_NO_EMPTY) ?: [];

        $wordmark = collect($letters)->map(function (string $letter, int $index): string {
            $value = $letter === ' ' ? '&nbsp;' : e($letter);
            $delay = min($index * 72, 576);

            return '<span class="editor-entry-loader-letter" style="--loader-index: '.($index + 1).'; --loader-delay: '.$delay.'ms">'.$value.'</span>';
        })->implode('');

        $markup = <<<'HTML'
<style>
    #editor-entry-loader {
        --loader-bg:
            radial-gradient(circle at 16% 14%, rgba(255, 245, 224, 0.96) 0%, rgba(255, 245, 224, 0) 34%),
            radial-gradient(circle at 82% 20%, rgba(228, 184, 122, 0.22) 0%, rgba(228, 184, 122, 0) 28%),
            linear-gradient(145deg, #f8f2e8 0%, #eee0cc 42%, #e0ccb2 100%);
        --loader-surface: linear-gradient(180deg, rgba(255, 252, 247, 0.8) 0%, rgba(248, 240, 228, 0.62) 100%);
        --loader-surface-edge: rgba(38, 27, 13, 0.1);
        --loader-ink: #16110d;
        --loader-muted: rgba(22, 17, 13, 0.58);
        --loader-accent: #ca7a1f;
        --loader-accent-soft: rgba(202, 122, 31, 0.16);
        position: fixed;
        inset: 0;
        z-index: 9999;
        display: grid;
        place-items: center;
        overflow: hidden;
        isolation: isolate;
        background: var(--loader-bg);
        color: var(--loader-ink);
        transition: opacity 360ms ease, visibility 360ms ease, transform 360ms ease;
    }

    #editor-entry-loader::before,
    #editor-entry-loader::after {
        content: "";
        position: absolute;
        inset: 0;
        pointer-events: none;
    }

    #editor-entry-loader::before {
        background:
            repeating-linear-gradient(90deg, rgba(73, 52, 23, 0.04) 0 1px, transparent 1px 92px),
            repeating-linear-gradient(0deg, rgba(73, 52, 23, 0.035) 0 1px, transparent 1px 92px);
        mask-image: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.5) 16%, rgba(0, 0, 0, 0.5) 84%, transparent 100%);
        opacity: 0.42;
        animation: editorLoaderGrid 14s linear infinite;
    }

    #editor-entry-loader::after {
        inset: auto;
        width: min(52vw, 520px);
        height: min(52vw, 520px);
        right: -10%;
        bottom: -22%;
        border-radius: 999px;
        background: radial-gradient(circle, rgba(198, 132, 40, 0.24) 0%, rgba(198, 132, 40, 0) 70%);
        filter: blur(20px);
        opacity: 0.85;
        animation: editorLoaderGlow 6.4s ease-in-out infinite;
    }

    #editor-entry-loader.is-hidden {
        opacity: 0;
        visibility: hidden;
        transform: scale(1.02);
    }

    .editor-entry-loader-panel {
        position: relative;
        width: min(92vw, 860px);
        padding: 22px;
        display: grid;
        place-items: center;
    }

    .editor-entry-loader-shell {
        position: relative;
        width: min(100%, 720px);
        padding: clamp(30px, 6vw, 56px) clamp(24px, 5vw, 50px) clamp(28px, 5vw, 42px);
        display: grid;
        gap: 22px;
        justify-items: center;
        text-align: center;
        border: 1px solid var(--loader-surface-edge);
        border-radius: 32px;
        background: var(--loader-surface);
        box-shadow:
            0 28px 70px rgba(78, 48, 17, 0.12),
            inset 0 1px 0 rgba(255, 255, 255, 0.72);
        backdrop-filter: blur(16px);
        overflow: hidden;
        opacity: 0;
        transform: translateY(18px) scale(0.985);
        animation: editorLoaderShellReveal 720ms cubic-bezier(.16, 1, .3, 1) forwards;
    }

    .editor-entry-loader-shell::before,
    .editor-entry-loader-shell::after {
        content: "";
        position: absolute;
        pointer-events: none;
    }

    .editor-entry-loader-shell::before {
        inset: 14px;
        border: 1px solid rgba(74, 51, 25, 0.08);
        border-radius: 22px;
    }

    .editor-entry-loader-shell::after {
        left: 30px;
        right: 30px;
        top: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.88) 50%, transparent 100%);
    }

    .editor-entry-loader-kicker {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 9px 15px;
        border: 1px solid rgba(28, 20, 10, 0.08);
        border-radius: 999px;
        background: rgba(255, 252, 248, 0.8);
        color: var(--loader-muted);
        font: 600 12px/1 'IBM Plex Mono', 'JetBrains Mono', monospace;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        box-shadow: 0 10px 24px rgba(53, 34, 11, 0.08);
        opacity: 0;
        transform: translateY(10px);
        animation: editorLoaderMetaReveal 460ms cubic-bezier(.16, 1, .3, 1) 90ms forwards;
    }

    .editor-entry-loader-kicker::before {
        content: "";
        width: 8px;
        height: 8px;
        border-radius: 999px;
        background: linear-gradient(180deg, #ffba61 0%, #c97217 100%);
        box-shadow: 0 0 0 6px var(--loader-accent-soft);
        animation: editorLoaderPulse 1.8s ease-out infinite;
    }

    .editor-entry-loader-wordmark {
        position: relative;
        display: inline-flex;
        flex-wrap: wrap;
        justify-content: center;
        perspective: 1200px;
        gap: 0.018em;
        padding: 0 0.08em;
        font-family: 'Fraunces', 'Instrument Serif', 'Newsreader', serif;
        font-size: clamp(52px, 10vw, 108px);
        font-weight: 600;
        letter-spacing: -0.06em;
        line-height: 0.92;
        color: transparent;
        background: linear-gradient(112deg, #17110d 0%, #664019 22%, #f0be7a 44%, #fff1dd 53%, #613c1d 72%, #15100c 100%);
        -webkit-background-clip: text;
        background-clip: text;
        text-shadow: 0 20px 42px rgba(86, 56, 20, 0.16);
    }

    .editor-entry-loader-wordmark::after {
        content: "";
        position: absolute;
        inset: auto 8% -12px;
        height: 18px;
        border-radius: 999px;
        background: radial-gradient(circle, rgba(192, 123, 29, 0.24) 0%, rgba(192, 123, 29, 0) 72%);
        filter: blur(18px);
    }

    .editor-entry-loader-letter {
        display: inline-block;
        transform-origin: 50% 100%;
        opacity: 0;
        filter: blur(12px);
        transform: translateY(34px) scale(0.86) rotateX(-84deg);
        animation: editorLoaderLetterReveal 640ms cubic-bezier(.19, 1, .22, 1) forwards;
        animation-delay: var(--loader-delay, 0ms);
        will-change: transform, opacity, filter;
    }

    .editor-entry-loader-meta {
        display: grid;
        gap: 14px;
        justify-items: center;
        max-width: 38rem;
        opacity: 0;
        transform: translateY(12px);
        animation: editorLoaderMetaReveal 520ms cubic-bezier(.16, 1, .3, 1) 340ms forwards;
    }

    .editor-entry-loader-context {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 16px;
        border: 1px solid rgba(36, 24, 11, 0.08);
        border-radius: 999px;
        background: rgba(255, 252, 247, 0.84);
        color: rgba(22, 17, 13, 0.78);
        font: 600 clamp(12px, 1.8vw, 14px)/1 'Inter Tight', 'IBM Plex Sans', sans-serif;
        letter-spacing: 0.01em;
        box-shadow: 0 10px 24px rgba(57, 36, 13, 0.06);
    }

    .editor-entry-loader-context::before {
        content: "";
        width: 7px;
        height: 7px;
        border-radius: 999px;
        background: linear-gradient(180deg, #f6b25f 0%, #bf6d18 100%);
        box-shadow: 0 0 0 5px rgba(198, 117, 26, 0.12);
    }

    .editor-entry-loader-copy {
        color: rgba(22, 17, 13, 0.62);
        font: 500 clamp(13px, 1.9vw, 16px)/1.7 'Inter Tight', 'IBM Plex Sans', sans-serif;
        letter-spacing: 0.01em;
    }

    .editor-entry-loader-track-wrap {
        display: grid;
        gap: 10px;
        justify-items: center;
        width: 100%;
        opacity: 0;
        transform: translateY(10px);
        animation: editorLoaderMetaReveal 520ms cubic-bezier(.16, 1, .3, 1) 460ms forwards;
    }

    .editor-entry-loader-track {
        position: relative;
        width: min(360px, 72vw);
        height: 5px;
        overflow: hidden;
        border-radius: 999px;
        background: rgba(23, 17, 12, 0.09);
        box-shadow: inset 0 1px 1px rgba(255, 255, 255, 0.55);
    }

    .editor-entry-loader-track::before,
    .editor-entry-loader-track::after {
        content: "";
        position: absolute;
        inset: 0;
        border-radius: inherit;
    }

    .editor-entry-loader-track::before {
        background: linear-gradient(90deg, rgba(255, 255, 255, 0.28) 0%, rgba(255, 255, 255, 0) 100%);
    }

    .editor-entry-loader-track::after {
        width: 38%;
        background: linear-gradient(90deg, rgba(246, 196, 129, 0) 0%, rgba(204, 118, 22, 0.98) 48%, rgba(246, 196, 129, 0) 100%);
        animation: editorLoaderTrack 1.55s cubic-bezier(.65,.05,.36,1) infinite;
    }

    .editor-entry-loader-track-caption {
        color: rgba(22, 17, 13, 0.48);
        font: 600 11px/1 'IBM Plex Mono', 'JetBrains Mono', monospace;
        letter-spacing: 0.18em;
        text-transform: uppercase;
    }

    @keyframes editorLoaderLetterReveal {
        0% {
            opacity: 0;
            filter: blur(12px);
            transform: translateY(34px) scale(0.86) rotateX(-84deg);
        }
        62% {
            opacity: 1;
            filter: blur(0);
            transform: translateY(-5px) scale(1.035) rotateX(0deg);
        }
        100% {
            opacity: 1;
            filter: blur(0);
            transform: translateY(0) scale(1) rotateX(0deg);
        }
    }

    @keyframes editorLoaderShellReveal {
        0% {
            opacity: 0;
            transform: translateY(18px) scale(0.985);
        }
        100% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    @keyframes editorLoaderMetaReveal {
        0% {
            opacity: 0;
            transform: translateY(10px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes editorLoaderTrack {
        0% { transform: translateX(-140%); }
        100% { transform: translateX(360%); }
    }

    @keyframes editorLoaderPulse {
        0% { box-shadow: 0 0 0 0 rgba(202, 122, 31, 0.2); }
        100% { box-shadow: 0 0 0 10px rgba(202, 122, 31, 0); }
    }

    @keyframes editorLoaderGlow {
        0%, 100% { transform: translate3d(0, 0, 0) scale(1); }
        50% { transform: translate3d(-18px, -16px, 0) scale(1.06); }
    }

    @keyframes editorLoaderGrid {
        0% { transform: translate3d(0, 0, 0); }
        100% { transform: translate3d(32px, 0, 0); }
    }

    @media (prefers-reduced-motion: reduce) {
        #editor-entry-loader,
        #editor-entry-loader::before,
        #editor-entry-loader::after,
        .editor-entry-loader-shell,
        .editor-entry-loader-kicker,
        .editor-entry-loader-meta,
        .editor-entry-loader-track-wrap,
        .editor-entry-loader-kicker::before,
        .editor-entry-loader-letter,
        .editor-entry-loader-track::after {
            animation: none !important;
        }

        .editor-entry-loader-shell,
        .editor-entry-loader-kicker,
        .editor-entry-loader-meta,
        .editor-entry-loader-track-wrap,
        .editor-entry-loader-letter {
            opacity: 1 !important;
            filter: none !important;
            transform: none !important;
        }
    }
</style>
<div id="editor-entry-loader" role="status" aria-live="polite" aria-label="Loading documentation editor">
    <div class="editor-entry-loader-panel">
        <div class="editor-entry-loader-shell">
            <div class="editor-entry-loader-kicker">Docs Editor</div>
            <div class="editor-entry-loader-wordmark">__WORDMARK__</div>
            <div class="editor-entry-loader-meta">
                <div class="editor-entry-loader-context">__CONTEXT__</div>
                <div class="editor-entry-loader-copy">Syncing pages, navigation, comments, and publishing state.</div>
            </div>
            <div class="editor-entry-loader-track-wrap">
                <div class="editor-entry-loader-track" aria-hidden="true"></div>
                <div class="editor-entry-loader-track-caption">Opening workspace</div>
            </div>
        </div>
    </div>
</div>
<script>
    (function () {
        const loader = document.getElementById('editor-entry-loader');
        const letterCount = loader ? loader.querySelectorAll('.editor-entry-loader-letter').length : 0;
        const shownAt = Date.now();
        const minimumVisibleMs = Math.min(1700, Math.max(1100, 620 + (letterCount * 110)));
        const maximumVisibleMs = 4800;
        let hidden = false;

        if (!loader) return;

        const hideLoader = () => {
            if (hidden) return;
            hidden = true;
            loader.classList.add('is-hidden');
            window.setTimeout(() => loader.remove(), 420);
        };

        const scheduleHide = () => {
            const remaining = Math.max(0, minimumVisibleMs - (Date.now() - shownAt));
            window.setTimeout(hideLoader, remaining);
        };

        const watchRoot = () => {
            const root = document.getElementById('root');
            if (!root) return;

            const rootHasContent = () => Array.from(root.childNodes).some((node) => {
                if (node.nodeType === Node.TEXT_NODE) {
                    return Boolean(node.textContent && node.textContent.trim());
                }

                return true;
            });

            if (rootHasContent()) {
                scheduleHide();
                return;
            }

            const observer = new MutationObserver(() => {
                if (!rootHasContent()) return;
                observer.disconnect();
                scheduleHide();
            });

            observer.observe(root, { childList: true, subtree: true, characterData: true });
            window.setTimeout(() => observer.disconnect(), maximumVisibleMs);
        };

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', watchRoot, { once: true });
        } else {
            watchRoot();
        }

        window.setTimeout(hideLoader, maximumVisibleMs);
        window.__dismissEditorLoader = hideLoader;
    })();
</script>
HTML;

        return str_replace(
            ['__WORDMARK__', '__CONTEXT__'],
            [$wordmark, e($contextLabel)],
            $markup,
        );
    }

    private function editorBaseHref(Request $request, string $path): string
    {
        $routePath = trim($request->path(), '/');

        if (Str::endsWith($routePath, '/index.html')) {
            $routePath = Str::beforeLast($routePath, '/index.html');
        }

        if ($routePath === '') {
            $routePath = trim($path === 'index.html' ? 'editor' : dirname($path), '/');
        }

        if ($routePath === '') {
            return rtrim(url('/'), '/').'/';
        }

        return rtrim(url('/'.$routePath), '/').'/';
    }

    /**
     * @param  array<string, mixed>  $seedData
     */
    private function rewriteBundleSeedData(string $bundle, array $seedData): string
    {
        $startMarker = '// ---------- Seed data ----------';
        $endMarker = '// ---------- Icon set ----------';

        $start = strpos($bundle, $startMarker);
        $end = strpos($bundle, $endMarker);

        if ($start === false || $end === false || $end <= $start) {
            return $bundle;
        }

        $seedBlock = implode("\n", [
            $startMarker,
            'const uid = (() => { let i = 0; return (p="id") => `${p}_${++i}_${Math.random().toString(36).slice(2,6)}`; })();',
            '',
            'const SPACES = '.$this->encodeJavaScript($seedData['spaces']).';',
            '',
            'const ACTIVE_SPACE_ID = '.$this->encodeJavaScript($seedData['activeSpaceId']).';',
            '',
            'const PAGES = '.$this->encodeJavaScript($seedData['pages']).';',
            '',
            'const ACTIVE_PAGE_ID = '.$this->encodeJavaScript($seedData['activePageId']).';',
            '',
            'const PAGE_CONTENT = '.$this->encodeJavaScript($seedData['pageContent']).';',
            '',
            'const COMMENTS = '.$this->encodeJavaScript($seedData['comments']).';',
            '',
            'const HISTORY = '.$this->encodeJavaScript($seedData['history']).';',
            '',
            'const MEDIA_ASSETS = '.$this->encodeJavaScript($seedData['mediaAssets'] ?? []).';',
            '',
            'Object.assign(window, { uid, SPACES, PAGES, ACTIVE_SPACE_ID, ACTIVE_PAGE_ID, PAGE_CONTENT, COMMENTS, HISTORY, MEDIA_ASSETS });',
        ]);

        return substr($bundle, 0, $start).$seedBlock."\n".substr($bundle, $end);
    }

    private function rewriteBundleRefreshIcon(string $bundle): string
    {
        if (str_contains($bundle, 'refresh: <g><path d="M20 5v5h-5"/><path d="M4 19v-5h5"/><path d="M20 10a8 8 0 0 0-14-3"/><path d="M4 14a8 8 0 0 0 14 3"/></g>,')) {
            return $bundle;
        }

        $historyIcon = 'history: <g><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><polyline points="3 3 3 8 8 8"/><polyline points="12 7 12 12 15 14"/></g>,';
        $refreshIcon = $historyIcon."\n    ".'refresh: <g><path d="M20 5v5h-5"/><path d="M4 19v-5h5"/><path d="M20 10a8 8 0 0 0-14-3"/><path d="M4 14a8 8 0 0 0 14 3"/></g>,';

        return str_contains($bundle, $historyIcon)
            ? str_replace($historyIcon, $refreshIcon, $bundle)
            : $bundle;
    }

    private function rewriteBundleMediaLibrary(string $bundle): string
    {
        $originalBundle = $bundle;

        $rightPaneReplacement = <<<'JS'
const formatMediaAssetBytes = (value) => {
    const size = Number(value || 0);
    if (!Number.isFinite(size) || size <= 0) return "0 B";

    const units = ["B", "KB", "MB", "GB"];
    const exponent = Math.min(Math.floor(Math.log(size) / Math.log(1024)), units.length - 1);
    const scaled = size / 1024 ** exponent;

    return `${scaled.toFixed(scaled >= 10 || exponent === 0 ? 0 : 1)} ${units[exponent]}`;
};

const AssetLibrary = ({ assets, setAssets, siteName, siteSlug }) => {
    const imageCount = assets.filter((asset) => asset.isImage).length;
    const videoCount = assets.filter((asset) => asset.isVideo || String(asset.mimeType || "").startsWith("video/")).length;
    const [uploading, setUploading] = React.useState(false);
    const [refreshing, setRefreshing] = React.useState(false);
    const fileInputRef = React.useRef(null);

    const isVideoAsset = (asset) => asset && (asset.isVideo || String(asset.mimeType || "").startsWith("video/"));
    const assetKind = (asset) => {
        if (asset.isImage) return "Image";
        if (isVideoAsset(asset)) return "Video";
        if (asset.mimeType === "application/pdf") return "PDF";
        if (asset.mimeType === "application/zip" || asset.mimeType === "application/x-zip-compressed") return "ZIP";
        if (String(asset.mimeType || "").startsWith("text/")) return "Text";
        return "File";
    };
    const insertLabel = (asset) => {
        if (asset.isImage) return "Insert image";
        if (isVideoAsset(asset)) return "Insert video";
        return "Insert asset";
    };

    const getSiteId = () => {
        const bs = window.__LARAVEL_BOOTSTRAP__;
        return bs && bs.site ? bs.site.id : null;
    };

    const refreshAssets = () => {
        const config = getEditorConfig();
        const siteId = getSiteId();
        if (!config || !siteId || typeof config.mediaAssetsUrlTemplate !== "string") return;
        setRefreshing(true);
        const url = config.mediaAssetsUrlTemplate.replace("__SITE__", String(siteId));
        fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest", "Accept": "application/json" } })
            .then((r) => r.ok ? r.json() : Promise.reject(r))
            .then((data) => { if (Array.isArray(data.assets)) setAssets(data.assets); })
            .catch((err) => console.error("Failed to refresh assets", err))
            .finally(() => setRefreshing(false));
    };

    const handleFileChange = (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        e.target.value = "";
        const config = getEditorConfig();
        const siteId = getSiteId();
        if (!config || !siteId || typeof config.uploadMediaUrlTemplate !== "string") return;
        setUploading(true);
        const url = config.uploadMediaUrlTemplate.replace("__SITE__", String(siteId));
        const form = new FormData();
        form.append("file", file);
        form.append("_token", config.csrfToken || "");
        fetch(url, { method: "POST", body: form, headers: { "X-Requested-With": "XMLHttpRequest", "Accept": "application/json" } })
            .then((r) => r.ok ? r.json() : r.json().then((d) => Promise.reject(d)))
            .then((data) => {
                if (data.asset) setAssets((prev) => [data.asset, ...prev]);
            })
            .catch((err) => console.error("Upload failed", err))
            .finally(() => setUploading(false));
    };

    return (
        <div style={{ display: "grid", gap: 12 }}>
            <div style={{ display: "grid", gap: 6, padding: "12px 12px 10px", borderBottom: "1px solid var(--border)" }}>
                <div style={{ fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--text-faint)" }}>Site folder</div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{siteName}</div>
                <div style={{ color: "var(--text-muted)", fontSize: 12 }}>{`/${siteSlug}`} · {assets.length} files · {imageCount} images · {videoCount} videos</div>
                <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                    <button
                        type="button"
                        disabled={uploading}
                        onClick={() => fileInputRef.current && fileInputRef.current.click()}
                        style={{ flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 5, height: 30, padding: "0 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--accent-soft)", color: "var(--accent-ink)", fontSize: 12.5, cursor: uploading ? "not-allowed" : "pointer", opacity: uploading ? 0.6 : 1 }}
                    >
                        <Icon name="plus" size={12} /> {uploading ? "Uploading…" : "Upload asset"}
                    </button>
                    <button
                        type="button"
                        disabled={refreshing}
                        onClick={refreshAssets}
                        style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: 30, width: 30, borderRadius: 8, border: "1px solid var(--border)", background: "var(--bg)", color: "var(--text-muted)", fontSize: 12, cursor: refreshing ? "not-allowed" : "pointer", opacity: refreshing ? 0.6 : 1 }}
                        title="Refresh assets"
                    >
                        <Icon name="refresh" size={13} />
                    </button>
                    <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/gif,image/webp,image/svg+xml,video/mp4,video/webm,video/ogg,application/pdf,application/zip,application/x-zip-compressed,text/plain" style={{ display: "none" }} onChange={handleFileChange} />
                </div>
            </div>

            {assets.length === 0 ? (
                <div style={{ margin: 12, padding: 14, border: "1px dashed var(--border-strong)", borderRadius: 10, color: "var(--text-faint)", fontSize: 12.5 }}>
                    No site assets yet. Upload a file above.
                </div>
            ) : (
                <div style={{ display: "grid", gap: 10, padding: "0 12px 12px" }}>
                    {assets.map((asset) => (
                        <div key={asset.id} style={{ display: "grid", gap: 10, padding: 10, border: "1px solid var(--border)", borderRadius: 12, background: "var(--panel)" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "flex-start" }}>
                                <div style={{ minWidth: 0 }}>
                                    <div style={{ fontWeight: 600, fontSize: 13, overflowWrap: "anywhere" }}>{asset.name}</div>
                                    <div style={{ marginTop: 4, color: "var(--text-muted)", fontSize: 12 }}>{asset.mimeType}</div>
                                </div>
                                <div style={{ padding: "3px 8px", borderRadius: 999, background: "var(--bg-soft)", color: "var(--text-faint)", fontSize: 11 }}>
                                    {assetKind(asset)}
                                </div>
                            </div>

                            {asset.isImage ? (
                                <img src={asset.url} alt={asset.name} style={{ width: "100%", height: 112, objectFit: "cover", borderRadius: 10, border: "1px solid var(--border)", background: "var(--bg-soft)" }} />
                            ) : isVideoAsset(asset) ? (
                                <video src={asset.url} controls preload="metadata" playsInline style={{ width: "100%", height: 112, objectFit: "cover", borderRadius: 10, border: "1px solid var(--border)", background: "var(--bg-soft)" }} />
                            ) : (
                                <div style={{ height: 72, display: "grid", placeItems: "center", borderRadius: 10, border: "1px dashed var(--border)", color: "var(--text-faint)", fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                                    {String(asset.name || "file").split(".").pop() || "file"}
                                </div>
                            )}

                            <div style={{ color: "var(--text-muted)", fontSize: 12 }}>
                                {formatMediaAssetBytes(asset.sizeBytes)}
                                {asset.width && asset.height ? ` · ${asset.width}x${asset.height}` : ""}
                                {asset.uploadedBy ? ` · ${asset.uploadedBy}` : ""}
                            </div>

                            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                                <a href={asset.url} target="_blank" rel="noreferrer" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: 28, padding: "0 10px", borderRadius: 8, border: "1px solid var(--border)", color: "var(--text)", textDecoration: "none", fontSize: 12.5 }}>
                                    Open asset
                                </a>
                                <button
                                    type="button"
                                    onClick={() => {
                                        if (typeof window.__editorInsertAsset === "function") {
                                            window.__editorInsertAsset(asset);
                                        }
                                    }}
                                    style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: 28, padding: "0 10px", borderRadius: 8, border: "1px solid var(--border)", color: "var(--text)", background: "var(--bg)", fontSize: 12.5, cursor: "pointer" }}
                                >
                                    {insertLabel(asset)}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const normalizePageLinkUrl = (value) => {
    const raw = String(value || "").trim();
    if (!raw) return "";
    if (/^(https?:\/\/|mailto:|tel:)/i.test(raw)) return raw;
    if (raw.startsWith("#") || raw.startsWith("/")) return raw;
    return `https://${raw}`;
};

const collectPageLinks = (blocks) => {
    const items = [];
    const seen = new Set();

    const pushLink = (link) => {
        if (!link || !link.rawHref) return;

        const key = `${String(link.blockId || "")}|${String(link.kind || "")}|${String(link.rawHref)}`;
        if (seen.has(key)) return;

        seen.add(key);
        items.push({
            ...link,
            href: normalizePageLinkUrl(link.rawHref),
        });
    };

    (Array.isArray(blocks) ? blocks : []).forEach((block, blockIndex) => {
        const blockId = block && block.id ? block.id : `block-${blockIndex}`;

        if (typeof block.html === "string" && block.html.includes("href=") && typeof DOMParser === "function") {
            try {
                const doc = new DOMParser().parseFromString(`<div>${block.html}</div>`, "text/html");

                Array.from(doc.querySelectorAll("a[href]")).forEach((anchor, linkIndex) => {
                    const rawHref = String(anchor.getAttribute("href") || "").trim();
                    const label = String(anchor.textContent || rawHref).replace(/\s+/g, " ").trim() || rawHref;

                    pushLink({
                        id: `${blockId}-link-${linkIndex}`,
                        blockId,
                        kind: "link",
                        source: "Text link",
                        rawHref,
                        label,
                    });
                });
            } catch {}
        }

        if (block && block.kind === "embed" && block.url) {
            pushLink({
                id: `${blockId}-embed`,
                blockId,
                kind: "embed",
                source: block.source || "Embed",
                rawHref: String(block.url).trim(),
                label: String(block.title || block.url).trim() || String(block.url).trim(),
            });
        }
    });

    return items;
};

const LinksPanel = ({ links, onJumpTo }) => {
    if (links.length === 0) {
        return (
            <div style={{ margin: 12, padding: 14, border: "1px dashed var(--border-strong)", borderRadius: 10, color: "var(--text-faint)", fontSize: 12.5 }}>
                No links in this page yet. Add a text link or embed URL to see it here.
            </div>
        );
    }

    return (
        <div style={{ display: "grid", gap: 10, padding: "12px" }}>
            {links.map((link) => {
                const opensInNewTab = !String(link.href || "").startsWith("#");

                return (
                    <div key={link.id} style={{ display: "grid", gap: 10, padding: 10, border: "1px solid var(--border)", borderRadius: 12, background: "var(--panel)" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "flex-start" }}>
                            <div style={{ minWidth: 0 }}>
                                <div style={{ fontWeight: 600, fontSize: 13, overflowWrap: "anywhere" }}>{link.label || link.rawHref}</div>
                                <div style={{ marginTop: 4, color: "var(--text-muted)", fontSize: 12, overflowWrap: "anywhere" }}>{link.rawHref}</div>
                            </div>
                            <div style={{ padding: "3px 8px", borderRadius: 999, background: "var(--bg-soft)", color: "var(--text-faint)", fontSize: 11 }}>
                                {link.kind === "embed" ? "Embed" : "Link"}
                            </div>
                        </div>

                        <div style={{ color: "var(--text-faint)", fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase" }}>{link.source || "Link"}</div>

                        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                            <a
                                href={link.href}
                                target={opensInNewTab ? "_blank" : undefined}
                                rel={opensInNewTab ? "noreferrer" : undefined}
                                style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: 28, padding: "0 10px", borderRadius: 8, border: "1px solid var(--border)", color: "var(--text)", textDecoration: "none", fontSize: 12.5 }}
                            >
                                Open link
                            </a>
                            {link.blockId ? (
                                <button
                                    type="button"
                                    onClick={() => onJumpTo && onJumpTo(link.blockId)}
                                    style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: 28, padding: "0 10px", borderRadius: 8, border: "1px solid var(--border)", color: "var(--text)", background: "var(--bg)", fontSize: 12.5, cursor: "pointer" }}
                                >
                                    Go to block
                                </button>
                            ) : null}
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

const RightPane = ({ page, comments, setComments, history, mediaAssets, setMediaAssets, siteName, siteSlug, openTab, setOpenTab, activeHeadingId, onJumpTo }) => {
    const openCount = comments.filter((c) => !c.resolved).length;
    const pageLinks = React.useMemo(() => collectPageLinks(page && page.blocks), [page && page.blocks]);
    return (
        <aside className="rightpane">
            <div className="rp-tabs">
                <button className={`rp-tab ${openTab === "outline" ? "active" : ""}`} onClick={() => setOpenTab("outline")}>
                    <Icon name="menu" size={13} /> Outline
                </button>
                <button className={`rp-tab ${openTab === "comments" ? "active" : ""}`} onClick={() => setOpenTab("comments")}>
                    <Icon name="comment" size={13} /> Comments
                    {openCount > 0 && <span className="count">{openCount}</span>}
                </button>
                <button className={`rp-tab ${openTab === "assets" ? "active" : ""}`} onClick={() => setOpenTab("assets")}>
                    <Icon name="globe" size={13} /> Assets
                    {mediaAssets.length > 0 && <span className="count">{mediaAssets.length}</span>}
                </button>
                <button className={`rp-tab ${openTab === "links" ? "active" : ""}`} onClick={() => setOpenTab("links")}>
                    <Icon name="link" size={13} /> Links
                    {pageLinks.length > 0 && <span className="count">{pageLinks.length}</span>}
                </button>
                <button className={`rp-tab rp-tab-history ${openTab === "history" ? "active" : ""}`} onClick={() => setOpenTab("history")}>
                    <Icon name="history" size={13} /> History
                </button>
            </div>
            <div className="rp-body">
                {openTab === "outline" && <Outline blocks={page.blocks} activeId={activeHeadingId} onJump={onJumpTo} />}
                {openTab === "comments" && <Comments comments={comments} setComments={setComments} />}
                {openTab === "assets" && <AssetLibrary assets={mediaAssets} setAssets={setMediaAssets} siteName={siteName} siteSlug={siteSlug} />}
                {openTab === "links" && <LinksPanel links={pageLinks} onJumpTo={onJumpTo} />}
                {openTab === "history" && <History groups={history} />}
            </div>
        </aside>
    );
};

window.RightPane = RightPane;
JS;

        $bundle = preg_replace(
            '/const RightPane = \(\{ page, comments, setComments, history, openTab, setOpenTab, activeHeadingId, onJumpTo \}\) => \{\R.*?\R\};\R\Rwindow\.RightPane = RightPane;/s',
            $rightPaneReplacement,
            $bundle,
            1,
            $rightPaneCount,
        );
        if (! is_string($bundle) || $rightPaneCount !== 1) {
            return $originalBundle;
        }

        // Switch to stateful mediaAssets (useState) instead of the static MEDIA_ASSETS constant
        $bundle = str_replace(
            '  const [comments, setComments] = useState(COMMENTS);',
            '  const [comments, setComments] = useState(COMMENTS);'."\n".'  const [mediaAssets, setMediaAssets] = useState(MEDIA_ASSETS);',
            $bundle,
            $mediaStateCount,
        );
        if (! is_string($bundle) || $mediaStateCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '            history={historyItems}',
            '            history={historyItems}'."\n".'            mediaAssets={mediaAssets}'."\n".'            setMediaAssets={setMediaAssets}'."\n".'            siteName={siteBootstrap().name || "Product Docs"}'."\n".'            siteSlug={siteBootstrap().slug || "product-docs"}',
            $bundle,
            $rightPanePropCount,
        );
        if (! is_string($bundle) || $rightPanePropCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace(
            '/      setUrl\(payload\.asset\.url\);\R      setAlt\(\(prev\) => prev \|\| payload\.asset\.name \|\| ""\);/',
            '      if (payload.asset && typeof window.__editorRegisterAsset === "function") {'."\n".'        window.__editorRegisterAsset(payload.asset);'."\n".'      }'."\n".'      setUrl(payload.asset.url);'."\n".'      setAlt((prev) => prev || payload.asset.name || "");',
            $bundle,
            1,
            $inlineUploadRegisterCount,
        );
        if (! is_string($bundle) || $inlineUploadRegisterCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace(
            '/    window\.__editorRestoreRevision = restoreRevision;\R    window\.__editorInsertAsset = insertAssetIntoPage;/',
            '    window.__editorRestoreRevision = restoreRevision;'."\n".'    window.__editorInsertAsset = insertAssetIntoPage;'."\n".'    window.__editorRegisterAsset = (asset) => {'."\n".'        if (!asset || !asset.url) return;'."\n".'        setMediaAssets((current) => {'."\n".'            const remaining = current.filter((item) => String(item.id) !== String(asset.id));'."\n".'            return [asset, ...remaining];'."\n".'        });'."\n".'    };',
            $bundle,
            1,
            $registerAssetBridgeCount,
        );
        if (! is_string($bundle) || $registerAssetBridgeCount !== 1) {
            return $originalBundle;
        }

        return $bundle;
    }

    private function rewriteBundleOutlineTimeline(string $bundle): string
    {
        $originalBundle = $bundle;
        $replacement = <<<'JS'
const Outline = ({ blocks, activeId, onJump }) => {
    const headings = blocks
        .filter((b) => ["h1","h2","h3"].includes(b.kind))
        .map((b) => ({ id: b.id, level: parseInt(b.kind.slice(1), 10), text: (b.text || "").replace(/<[^>]*>/g,"") || "Untitled heading" }));

    if (headings.length === 0) {
        return (
            <div className="outline outline-v2">
                <div className="outline-label">On this page</div>
                <div style={{ padding: "6px 10px", fontSize: 12, color: "var(--text-faint)" }}>No headings yet.</div>
            </div>
        );
    }

    const minLevel = Math.min(...headings.map(h => h.level));
    const activeIndex = Math.max(0, headings.findIndex(h => h.id === activeId));
    const outlineProgressPercent = headings.length <= 1 ? 0 : Math.round((activeIndex / (headings.length - 1)) * 100);

    return (
        <div className="outline outline-v2">
            <div className="outline-label">On this page</div>
            <div className="otl-list" style={{ "--otl-progress": `${outlineProgressPercent}%` }}>
                <div className="otl-rail" aria-hidden="true" />
                {headings.map((h, i) => {
                    const isActive = h.id === activeId;
                    const isParent = h.level === minLevel;
                    const isSeen = i < activeIndex;
                    return (
                        <button
                            key={h.id}
                            className={`otl-item level-${h.level} ${isParent ? "parent" : "child"} ${isSeen ? "seen" : ""} ${isActive ? "active" : ""}`}
                            onClick={() => onJump(h.id)}
                            title={h.text}
                        >
                            {isActive && <span className="otl-dot" />}
                            <span className="otl-text">{h.text}</span>
                        </button>
                    );
                })}
            </div>
        </div>
    );
};
JS;

        $bundle = preg_replace(
            '/const Outline = \(\{ blocks, activeId, onJump \}\) => \{\R.*?\R\};(?=\R\Rconst (?:Comment|ThreadComment|Comments))/s',
            $replacement,
            $bundle,
            1,
            $count,
        );

        return is_string($bundle) && $count === 1 ? $bundle : $originalBundle;
    }

        private function rewriteBundleChecklistEnhancements(string $bundle): string
        {
                $originalBundle = $bundle;
                $replacement = <<<'JS'
const ChecklistBlock = ({ block, update }) => {
    const focusChecklistItem = (itemId) => {
        requestAnimationFrame(() => {
            const editable = document.querySelector(`[data-checklist-item-id="${itemId}"]`);
            if (!editable) return;
            editable.focus();
            const selection = window.getSelection();
            if (!selection || typeof document.createRange !== "function") return;
            const range = document.createRange();
            range.selectNodeContents(editable);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
        });
    };

    const insertChecklistItemAfter = (index) => {
        const nextItem = { id: uid("c"), text: "", done: false };
        const items = [...(block.items || [])];
        items.splice(index + 1, 0, nextItem);
        update({ items });
        focusChecklistItem(nextItem.id);
    };

    const removeChecklistItemAt = (index) => {
        const items = [...(block.items || [])];
        if (items.length <= 1) return;

        const nextFocusItemId = items[index - 1]?.id || items[index + 1]?.id || null;
        items.splice(index, 1);
        update({ items });

        if (nextFocusItemId) {
            focusChecklistItem(nextFocusItemId);
        }
    };

    return (
        <div className="blk-checklist">
            {(block.items || []).map((item, i) => (
                <div key={item.id} className={`check-row ${item.done ? "done" : ""}`}>
                    <div className={`check-box ${item.done ? "done" : ""}`}
                        onClick={() => {
                            const items = block.items.map((it, idx) => idx === i ? { ...it, done: !it.done } : it);
                            update({ items });
                        }}>
                        {item.done && <Icon name="check" size={11} strokeWidth={3} />}
                    </div>
                    <Editable
                        tag="div"
                        className="check-text blk-content"
                        html={item.text}
                        placeholder="List item"
                        data-checklist-item-id={item.id}
                        onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                e.stopPropagation();
                                insertChecklistItemAfter(i);
                                return;
                            }

                            if (e.key !== "Backspace") return;

                            const currentText = (e.currentTarget.textContent || "").replace(/\u00a0/g, " ").trim();
                            if (currentText !== "") return;

                            e.preventDefault();
                            e.stopPropagation();
                            removeChecklistItemAt(i);
                        }}
                        onChange={(h) => {
                            const items = block.items.map((it, idx) => idx === i ? { ...it, text: h } : it);
                            update({ items });
                        }}
                    />
                </div>
            ))}
        </div>
    );
};
JS;

                $bundle = preg_replace(
                        '/const ChecklistBlock = \(\{ block, update \}\) => \(\R.*?\R\);(?=\R\R\/\/ Registry for slash menu)/s',
                        $replacement,
                        $bundle,
                        1,
                        $count,
                );

                return is_string($bundle) && $count === 1 ? $bundle : $originalBundle;
        }

        private function rewriteBundleHistoryRestore(string $bundle): string
        {
                $originalBundle = $bundle;
                $historyReplacement = <<<'JS'
const History = ({ groups }) => {
    const [restoringRevisionId, setRestoringRevisionId] = React.useState(null);

    const restoreHistoryItem = (item) => {
        if (!item?.canRestore || !item?.revisionId || typeof window.__editorRestoreRevision !== "function" || restoringRevisionId !== null) return;

        setRestoringRevisionId(item.revisionId);

        Promise.resolve()
            .then(() => window.__editorRestoreRevision(item.revisionId))
            .finally(() => {
                setRestoringRevisionId((current) => current === item.revisionId ? null : current);
            });
    };

    return (
        <div className="history-list">
            {groups.map((g) => (
                <React.Fragment key={g.day}>
                    <div className="history-day">{g.day}</div>
                    {g.items.map((it) => {
                        const canRestore = !!it.canRestore && !!it.revisionId && typeof window.__editorRestoreRevision === "function";
                        const isRestoring = restoringRevisionId === it.revisionId;

                        return (
                            <div key={it.id} className={`history-item ${it.current ? "current" : ""}`}>
                                <div className="history-dot" />
                                <div style={{ minWidth: 0 }}>
                                    <div className="history-name" style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                        <span>{it.name}</span>
                                        {it.current && (
                                            <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase", color: "var(--accent)" }}>
                                                Current
                                            </span>
                                        )}
                                    </div>
                                    <div className="history-meta">{it.meta} · {it.who}</div>
                                    {it.msg && <div className="history-msg">{it.msg}</div>}
                                    {canRestore && (
                                        <div style={{ marginTop: 8 }}>
                                            <button
                                                type="button"
                                                className="tb-btn"
                                                onClick={() => restoreHistoryItem(it)}
                                                disabled={restoringRevisionId !== null}
                                            >
                                                {isRestoring ? "Restoring..." : "Restore"}
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </React.Fragment>
            ))}
        </div>
    );
};
JS;

                $bundle = preg_replace(
                        '/const History = \(\{ groups \}\) => \(\R.*?\R\);(?=\R\Rconst RightPane)/s',
                        $historyReplacement,
                        $bundle,
                        1,
                        $historyCount,
                );

                if (! is_string($bundle) || $historyCount !== 1) {
                        return $originalBundle;
                }

                return $bundle;
        }

    private function rewriteBundleAutosaveBridge(string $bundle): string
    {
        $originalBundle = $bundle;

        $clipboardReplacement = <<<'JS'
    const [selectedBlocks, setSelectedBlocks] = useState([]);
    const [clipboard, setClipboard] = useState(null);
    const autosaveTimeoutRef = React.useRef(null);
    const autosaveAbortRef = React.useRef(null);
    const autosavePageIdRef = React.useRef(null);
    const autosaveRequestRef = React.useRef(null);
    const dirtyPageIdsRef = React.useRef(new Set());
    const creatingSpaceNamesRef = React.useRef(new Set());

    React.useEffect(() => {
        return () => {
            if (autosaveTimeoutRef.current) window.clearTimeout(autosaveTimeoutRef.current);
            if (autosaveAbortRef.current) autosaveAbortRef.current.abort();
        };
    }, []);

    const getEditorConfig = () => window.__LARAVEL_EDITOR_CONFIG__ || null;

    const extractDbPageId = (pageId) => {
        const match = String(pageId || "").match(/^p_(\d+)$/);
        return match ? match[1] : null;
    };

    const extractDbSpaceId = (spaceId) => {
        const match = String(spaceId || "").match(/^sp_(\d+)$/);
        return match ? match[1] : null;
    };

    const requestEditorJson = (url, options = {}) => {
        const config = getEditorConfig();
        if (!config || typeof url !== "string" || !url) return Promise.resolve(null);

        const headers = {
            "Accept": "application/json",
            "X-CSRF-TOKEN": config.csrfToken,
            ...(options.headers || {}),
        };

        if (options.body !== undefined && headers["Content-Type"] === undefined) {
            headers["Content-Type"] = "application/json";
        }

        return fetch(url, {
            ...options,
            headers,
            credentials: "same-origin",
        }).then(async (response) => {
            if (response.ok) {
                return response.json();
            }

            const payload = await response.json().catch(() => null);
            const error = new Error(payload && payload.message ? payload.message : "Editor request failed");
            error.payload = payload;
            throw error;
        });
    };

    const replacePageIdInTree = (list, fromId, nextId) =>
        list.map((n) => {
            if (n.id === fromId) return { ...n, id: nextId };
            if (n.children) return { ...n, children: replacePageIdInTree(n.children, fromId, nextId) };
            return n;
        });

    const reconcileCreatedSpace = (tempSpaceId, savedSpace) => {
        if (!savedSpace || !savedSpace.id) return;

        setSpaces((items) => items.map((space) => space.id === tempSpaceId ? { ...space, ...savedSpace } : space));
        setActiveSpaceId((current) => current === tempSpaceId ? savedSpace.id : current);
    };

    const reconcileCreatedPage = (tempPageId, savedPage) => {
        if (!savedPage || !savedPage.id) return;

        setPages((pp) => replacePageIdInTree(pp, tempPageId, savedPage.id));
        setContentMap((m) => {
            const next = { ...m };
            const draft = next[tempPageId] ? { ...next[tempPageId] } : {};
            delete next[tempPageId];
            next[savedPage.id] = { ...(savedPage.content || {}), ...draft };
            return next;
        });
        setActivePageId((current) => current === tempPageId ? savedPage.id : current);

        if (dirtyPageIdsRef.current.has(tempPageId)) {
            dirtyPageIdsRef.current.delete(tempPageId);
            dirtyPageIdsRef.current.add(savedPage.id);
        }
    };

    const markPageDirty = (pageId) => {
        if (!pageId) return;
        dirtyPageIdsRef.current.add(pageId);
    };

    const markPageClean = (pageId) => {
        if (!pageId) return;
        dirtyPageIdsRef.current.delete(pageId);
    };

    const pageHasPendingAutosave = (pageId) =>
        autosavePageIdRef.current === pageId && (!!autosaveTimeoutRef.current || !!autosaveRequestRef.current);

    const shouldPersistPageBeforePublish = (pageId) =>
        dirtyPageIdsRef.current.has(pageId) || pageHasPendingAutosave(pageId);

    const scheduleAutosave = (pageId, nextPage) => {
        markPageDirty(pageId);

        const config = getEditorConfig();
        if (!config || typeof config.autosavePageUrlTemplate !== "string") return;

        const match = String(pageId || "").match(/^p_(\d+)$/);
        if (!match) return;

        if (autosaveTimeoutRef.current) window.clearTimeout(autosaveTimeoutRef.current);
        autosavePageIdRef.current = pageId;

        autosaveTimeoutRef.current = window.setTimeout(() => {
            const payload = {
                title: nextPage && nextPage.title !== undefined ? nextPage.title : "",
                subtitle: nextPage && nextPage.subtitle !== undefined ? nextPage.subtitle : "",
                blocks: nextPage && Array.isArray(nextPage.blocks) ? nextPage.blocks : [],
                editorMeta: {
                    readTime: nextPage && nextPage.readTime !== undefined ? nextPage.readTime : null,
                    updated: nextPage && nextPage.updated !== undefined ? nextPage.updated : null,
                    viewCount: nextPage && nextPage.viewCount !== undefined ? nextPage.viewCount : null,
                },
            };

            const url = config.autosavePageUrlTemplate.replace("__PAGE__", match[1]);

            if (autosaveAbortRef.current) autosaveAbortRef.current.abort();
            autosaveAbortRef.current = new AbortController();

            const autosaveRequest = requestEditorJson(url, {
                method: "POST",
                signal: autosaveAbortRef.current.signal,
                body: JSON.stringify(payload),
            })
                .then((response) => {
                    const savedPage = response && response.saved && response.saved.page ? response.saved.page : null;

                    if (savedPage) {
                        setContentMap((m) => m[pageId] ? ({
                            ...m,
                            [pageId]: {
                                ...m[pageId],
                                title: savedPage.title !== undefined ? savedPage.title : m[pageId].title,
                                subtitle: savedPage.subtitle !== undefined ? savedPage.subtitle : m[pageId].subtitle,
                                slug: savedPage.slug !== undefined ? savedPage.slug : m[pageId].slug,
                                path: savedPage.path !== undefined ? savedPage.path : m[pageId].path,
                                updated: savedPage.updated !== undefined ? savedPage.updated : m[pageId].updated,
                                readTime: savedPage.readTime !== undefined ? savedPage.readTime : m[pageId].readTime,
                            },
                        }) : m);

                        if (pageId === activePageId && savedPage.slug) {
                            const activeSpace = spaces.find((item) => item.id === activeSpaceId);
                            const editorRoot = activeSpace && activeSpace.editorUrl
                                ? String(activeSpace.editorUrl).replace(/\/+$/, "")
                                : "";
                            const target = editorRoot
                                ? `${editorRoot}/${encodeURIComponent(String(savedPage.slug))}`
                                : "";

                            if (target && window.location.pathname !== target) {
                                window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
                            }
                        }
                    }

                    markPageClean(pageId);

                    if (autosavePageIdRef.current === pageId) {
                        autosavePageIdRef.current = null;
                    }

                    return response || null;
                })
                .catch((error) => {
                    if (error && error.name === "AbortError") return;
                    console.error(error);
                })
                .finally(() => {
                    if (autosaveTimeoutRef.current) {
                        window.clearTimeout(autosaveTimeoutRef.current);
                        autosaveTimeoutRef.current = null;
                    }
                    if (autosaveRequestRef.current === autosaveRequest) {
                        autosaveRequestRef.current = null;
                    }
                });

            autosaveRequestRef.current = autosaveRequest;
        }, 900);
    };
JS;

        $publishReplacement = <<<'JS'
    const siteBootstrap = () => (window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.site) || {};

    const joinEditorUrl = (root, path) => {
                const cleanRoot = String(root || "").replace(/\/+$/, "");
                const cleanPath = String(path || "").replace(/^\/+/, "");
                return cleanPath ? `${cleanRoot}/${cleanPath}` : cleanRoot;
        };

    const absoluteEditorUrl = (url) => {
                const value = String(url || "");
                if (/^https?:\/\//i.test(value)) return value;
                return `${window.location.origin}${value.startsWith("/") ? "" : "/"}${value}`;
        };

    const rootEditorUrl = (templateName, fallback) => {
                const config = getEditorConfig();
                const site = siteBootstrap();
                const template = config && typeof config[templateName] === "string" ? config[templateName] : fallback;

                return String(template || "")
                        .replace("__SITE__", String(site.id || ""))
                        .replace("__SITE_SLUG__", encodeURIComponent(site.slug || ""));
        };

    const currentPagePath = () => {
                const bootstrapPage = window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.page
                        ? window.__LARAVEL_BOOTSTRAP__.page
                        : {};

                return (page && page.path) || bootstrapPage.path || "";
        };

    const previewSiteUrl = () => absoluteEditorUrl(joinEditorUrl(
                rootEditorUrl("previewSiteUrlTemplate", `/preview/sites/${siteBootstrap().id || ""}`),
                currentPagePath(),
        ));

    const publishedSiteUrl = () => absoluteEditorUrl(joinEditorUrl(
                rootEditorUrl("publishedSiteUrlTemplate", `/docs/${siteBootstrap().slug || "product-docs"}`),
                currentPagePath(),
        ));

    const nextReleaseVersionAfter = (version) => {
                const match = String(version || "").match(/^v(\d+)\.(\d+)\.(\d+)$/);
                if (!match) return "next release";

                return `v${match[1]}.${match[2]}.${Number(match[3]) + 1}`;
        };

    const publishVersionLabel = () => {
                const site = siteBootstrap();
                if (site.nextReleaseVersion) return site.nextReleaseVersion;

                const releaseCount = Number(site.releaseCount);
                return Number.isFinite(releaseCount) ? `v1.0.${releaseCount}` : "next release";
        };

    const openPreviewSite = () => {
                window.open(previewSiteUrl(), "_blank", "noopener,noreferrer");
        };

        const persistCurrentPageBeforePublish = () => {
            if (!shouldPersistPageBeforePublish(activePageId)) {
                return Promise.resolve(null);
            }

            if (autosavePageIdRef.current === activePageId && autosaveRequestRef.current && !autosaveTimeoutRef.current) {
                return autosaveRequestRef.current;
            }

            const config = getEditorConfig();
            const dbPageId = extractDbPageId(activePageId);

            if (!config || !dbPageId || typeof config.autosavePageUrlTemplate !== "string") {
                return Promise.resolve(null);
            }

            if (autosaveTimeoutRef.current && autosavePageIdRef.current === activePageId) {
                window.clearTimeout(autosaveTimeoutRef.current);
                autosaveTimeoutRef.current = null;
            }

            if (autosaveAbortRef.current) autosaveAbortRef.current.abort();
            autosaveAbortRef.current = new AbortController();
            autosavePageIdRef.current = activePageId;

            const payload = {
                title: page && page.title !== undefined ? page.title : "",
                subtitle: page && page.subtitle !== undefined ? page.subtitle : "",
                blocks: page && Array.isArray(page.blocks) ? page.blocks : [],
                editorMeta: {
                    readTime: page && page.readTime !== undefined ? page.readTime : null,
                    updated: page && page.updated !== undefined ? page.updated : null,
                    viewCount: page && page.viewCount !== undefined ? page.viewCount : null,
                },
            };

            const autosaveRequest = requestEditorJson(config.autosavePageUrlTemplate.replace("__PAGE__", dbPageId), {
                method: "POST",
                signal: autosaveAbortRef.current.signal,
                body: JSON.stringify(payload),
            })
                .then((response) => {
                    const savedPage = response && response.saved && response.saved.page ? response.saved.page : null;

                    if (savedPage) {
                        setContentMap((m) => m[activePageId] ? ({
                            ...m,
                            [activePageId]: {
                                ...m[activePageId],
                                title: savedPage.title !== undefined ? savedPage.title : m[activePageId].title,
                                subtitle: savedPage.subtitle !== undefined ? savedPage.subtitle : m[activePageId].subtitle,
                                slug: savedPage.slug !== undefined ? savedPage.slug : m[activePageId].slug,
                                path: savedPage.path !== undefined ? savedPage.path : m[activePageId].path,
                                updated: savedPage.updated !== undefined ? savedPage.updated : m[activePageId].updated,
                                readTime: savedPage.readTime !== undefined ? savedPage.readTime : m[activePageId].readTime,
                            },
                        }) : m);

                        if (savedPage.slug) {
                            const activeSpace = spaces.find((item) => item.id === activeSpaceId);
                            const editorRoot = activeSpace && activeSpace.editorUrl
                                ? String(activeSpace.editorUrl).replace(/\/+$/, "")
                                : "";
                            const target = editorRoot
                                ? `${editorRoot}/${encodeURIComponent(String(savedPage.slug))}`
                                : "";

                            if (target && window.location.pathname !== target) {
                                window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
                            }
                        }
                    }

                    markPageClean(activePageId);

                    if (autosavePageIdRef.current === activePageId) {
                        autosavePageIdRef.current = null;
                    }

                    return response || null;
                })
                .finally(() => {
                    if (autosaveRequestRef.current === autosaveRequest) {
                        autosaveRequestRef.current = null;
                    }
                });

            autosaveRequestRef.current = autosaveRequest;

            return autosaveRequest;
        };

    const onPublish = (options = {}) => {
        const config = getEditorConfig();
        const siteId = window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.site
            ? window.__LARAVEL_BOOTSTRAP__.site.id
            : null;
                const nextPublishedUrl = publishedSiteUrl();

        if (!config || !siteId || typeof config.publishSiteUrlTemplate !== "string") {
            setPublishing(true);
            setTimeout(() => {
                setPublishing(false);
                                setToast(`Published to ${nextPublishedUrl}`);
                setTimeout(() => setToast(null), 2400);
            }, 1600);
            return;
        }

        setPublishing(true);

        persistCurrentPageBeforePublish()
            .then(() => requestEditorJson(config.publishSiteUrlTemplate.replace("__SITE__", String(siteId)), {
                method: "POST",
                body: JSON.stringify({
                    environment: options.environment || "production",
                    message: options.message || "",
                }),
            }))
            .then((response) => {
                const published = response && response.published ? response.published : {};
                if (published.release && published.release.version) {
                    const site = siteBootstrap();
                    const releaseCount = Number(site.releaseCount);
                    site.currentReleaseId = published.release.id || site.currentReleaseId;
                    site.currentReleaseVersion = published.release.version;
                    site.nextReleaseVersion = nextReleaseVersionAfter(published.release.version);
                    site.releaseCount = Number.isFinite(releaseCount) ? releaseCount + 1 : site.releaseCount;
                    site.status = (published.site && published.site.status) || "published";
                }
                setPublishing(false);
                const publishedRoot = published.publishedUrl || rootEditorUrl("publishedSiteUrlTemplate", `/docs/${siteBootstrap().slug || "product-docs"}`);
                const publishedPath = currentPagePath() || published.publishedPath || "";
                setToast(`Published to ${absoluteEditorUrl(joinEditorUrl(publishedRoot, publishedPath))}`);
                setTimeout(() => setToast(null), 2400);
            })
            .catch((error) => {
                setPublishing(false);
                setToast("Publish failed");
                setTimeout(() => setToast(null), 2400);
                console.error(error);
            });
    };

    const copyTextToClipboard = (value) => {
        const text = String(value || "");

        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(text);
        }

        return new Promise((resolve, reject) => {
            const textarea = document.createElement("textarea");
            textarea.value = text;
            textarea.setAttribute("readonly", "");
            textarea.style.position = "fixed";
            textarea.style.left = "-9999px";
            document.body.appendChild(textarea);
            textarea.select();

            try {
                const copied = document.execCommand("copy");
                document.body.removeChild(textarea);
                copied ? resolve() : reject(new Error("Clipboard copy failed"));
            } catch (error) {
                document.body.removeChild(textarea);
                reject(error);
            }
        });
    };

    const onShareSite = () => {
        const url = previewSiteUrl();

        copyTextToClipboard(url)
            .then(() => setToast(`Share link copied: ${url}`))
            .catch(() => setToast(`Share link: ${url}`))
            .finally(() => setTimeout(() => setToast(null), 2600));
    };

    const settingsSiteUrl = () => absoluteEditorUrl(rootEditorUrl(
        "settingsUrlTemplate",
        `/dashboard/settings?site=${siteBootstrap().id || ""}`,
    ));

    const onOpenSettings = () => {
        window.location.assign(settingsSiteUrl());
    };
JS;

        $editableReplacement = <<<'JS'
const Editable = ({ html, onChange, className, placeholder, tag="div", ...rest }) => {
    const ref = React.useRef(null);
    const last = React.useRef(html || "");
    const composingRef = React.useRef(false);
    const Tag = tag;
    const safeHtml = html || "";
    const isEmpty = !safeHtml || safeHtml === "<br>" || safeHtml.replace(/<[^>]*>/g,"").trim() === "";

    React.useLayoutEffect(() => {
        if (!ref.current || composingRef.current) return;
        if (document.activeElement === ref.current && last.current === safeHtml) return;
        if (ref.current.innerHTML !== safeHtml) {
            ref.current.innerHTML = safeHtml;
        }
        last.current = safeHtml;
    }, [safeHtml]);

    return (
        <Tag
            ref={ref}
            className={className}
            contentEditable
            suppressContentEditableWarning
            data-empty={isEmpty ? "true" : "false"}
            data-placeholder={placeholder}
            onCompositionStart={() => { composingRef.current = true; }}
            onCompositionEnd={(e) => {
                composingRef.current = false;
                last.current = e.currentTarget.innerHTML;
                onChange && onChange(e.currentTarget.innerHTML);
            }}
            onInput={(e) => {
                last.current = e.currentTarget.innerHTML;
                if (!composingRef.current) {
                    onChange && onChange(e.currentTarget.innerHTML);
                }
            }}
            {...rest}
        />
    );
};
JS;

        $setPageReplacement = <<<'JS'
    const syncTreeTitle = (pageId, next) => {
        const nextTreeTitle = String(next && next.title !== undefined ? next.title : "")
            .replace(/<[^>]*>/g, "")
            .trim() || "Untitled";

        setPages((pp) => updateNode(pp, pageId, (node) => (
            node.title === nextTreeTitle ? node : { ...node, title: nextTreeTitle }
        )));
    };

    const setPageSilently = (next) => {
        const pageId = activePageId;

        setContentMap((m) => ({ ...m, [pageId]: next }));
        syncTreeTitle(pageId, next);
    };

    const setPage = (next) => {
        const pageId = activePageId;

        setContentMap((m) => {
            if (skipHistoryRef.current) { skipHistoryRef.current = false; return { ...m, [pageId]: next }; }
            pushHistory(m);
            return { ...m, [pageId]: next };
        });

        syncTreeTitle(pageId, next);
        scheduleAutosave(pageId, next);
    };
JS;

        $addPageAndPersistenceReplacement = <<<'JS'
    const onAddPage = (parentId) => {
        const newId = uid("p");
        const newPage = { id: newId, title: "Untitled", icon: "page", spaceId: activeSpaceId };
        if (parentId === null) {
            setPages((pp) => [...pp, newPage]);
        } else {
            setPages((pp) => updateNode(pp, parentId, (n) => ({
                ...n, expanded: true, children: [...(n.children || []), newPage],
            })));
        }
        setContentMap((m) => ({ ...m, [newId]: {
            title: "Untitled",
            subtitle: "",
            updated: "just now", readTime: "1 min",
            viewCount: 0,
            commentCount: 0,
            stats: { views: 0, comments: 0 },
            author: { name: "You", role: "Editor", initials: "YO", color: "oklch(55% 0.14 255)" },
            collaborators: [{ name: "You", initials: "YO", color: "oklch(55% 0.14 255)" }],
            blocks: [{ id: uid("b"), kind: "p", html: "" }],
        } }));
        setActivePageId(newId);
        return newId;
    };

    const persistRenamePage = (id, title) => {
        onRenamePage(id, title);

        const config = getEditorConfig();
        const dbPageId = extractDbPageId(id);
        if (!config || !dbPageId || typeof config.updatePageUrlTemplate !== "string") return;

        requestEditorJson(config.updatePageUrlTemplate.replace("__PAGE__", dbPageId), {
            method: "PATCH",
            body: JSON.stringify({ title }),
        })
            .then((response) => {
                const savedPage = response && response.page ? response.page : null;
                if (!savedPage) return;

                setPages((pp) => updateNode(pp, id, (n) => ({
                    ...n,
                    title: savedPage.title !== undefined ? savedPage.title : n.title,
                })));
                setContentMap((m) => m[id] ? ({
                    ...m,
                    [id]: {
                        ...m[id],
                        title: savedPage.title !== undefined ? savedPage.title : m[id].title,
                        path: savedPage.path !== undefined ? savedPage.path : m[id].path,
                    },
                }) : m);
            })
            .catch((error) => console.error(error));
    };

    const persistDeletePage = (id) => {
        let pendingAutosave = null;

        if (autosavePageIdRef.current === id) {
            if (autosaveTimeoutRef.current) {
                window.clearTimeout(autosaveTimeoutRef.current);
                autosaveTimeoutRef.current = null;
            }
            pendingAutosave = autosaveRequestRef.current;
            autosavePageIdRef.current = null;
        }

        markPageClean(id);

        onDeletePage(id);

        const config = getEditorConfig();
        const dbPageId = extractDbPageId(id);
        if (!config || !dbPageId || typeof config.deletePageUrlTemplate !== "string") return;

        const sendDeleteRequest = () => requestEditorJson(config.deletePageUrlTemplate.replace("__PAGE__", dbPageId), {
            method: "DELETE",
        }).catch((error) => console.error(error));

        if (pendingAutosave) {
            pendingAutosave.finally(sendDeleteRequest);
            return;
        }

        sendDeleteRequest();
    };

    const persistMovePage = (fromId, toId, pos) => {
        onMovePage(fromId, toId, pos);

        const config = getEditorConfig();
        const fromDbPageId = extractDbPageId(fromId);
        const toDbPageId = extractDbPageId(toId);
        if (!config || !fromDbPageId || !toDbPageId || typeof config.movePageUrlTemplate !== "string") return;

        requestEditorJson(config.movePageUrlTemplate.replace("__PAGE__", fromDbPageId), {
            method: "POST",
            body: JSON.stringify({ targetPageId: Number(toDbPageId), position: pos }),
        }).catch((error) => console.error(error));
    };

    const persistAddPage = (parentId) => {
        const tempPageId = onAddPage(parentId);

        const config = getEditorConfig();
        const siteId = window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.site
            ? window.__LARAVEL_BOOTSTRAP__.site.id
            : null;

        if (!config || !siteId || typeof config.createPageUrlTemplate !== "string") return tempPageId;

        const parentDbPageId = extractDbPageId(parentId);

        const activeDbSpaceId = extractDbSpaceId(activeSpaceId);

        requestEditorJson(config.createPageUrlTemplate.replace("__SITE__", String(siteId)), {
            method: "POST",
            body: JSON.stringify({
                parentPageId: parentDbPageId ? Number(parentDbPageId) : null,
                spaceId: !parentDbPageId && activeDbSpaceId ? Number(activeDbSpaceId) : null,
            }),
        })
            .then((response) => {
                const savedPage = response && response.page ? response.page : null;
                if (!savedPage) return;
                reconcileCreatedPage(tempPageId, savedPage);
            })
            .catch((error) => console.error(error));

        return tempPageId;
    };
JS;

        $spacePersistenceReplacement = <<<'JS'
    const onAddSpace = (name) => {
        const clean = (name || "").trim();
        if (!clean) return null;
        const palette = [
            "oklch(55% 0.14 255)", "oklch(52% 0.15 155)", "oklch(55% 0.15 25)",
            "oklch(58% 0.14 305)", "oklch(60% 0.14 70)", "oklch(55% 0.13 205)",
        ];
        const newSp = {
            id: uid("sp"),
            name: clean,
            color: palette[spaces.length % palette.length],
            count: 0,
            icon: clean[0].toUpperCase(),
        };
        setSpaces((arr) => [...arr, newSp]);
        setActiveSpaceId(newSp.id);
        setToast(`Created space "${clean}"`);
        setTimeout(() => setToast(null), 2000);

        return newSp.id;
    };

    const editorPageUrlFor = (space, pageMeta) => {
        if (!space || !space.editorUrl) return null;

        const slug = pageMeta && pageMeta.slug ? String(pageMeta.slug) : "";
        const root = String(space.editorUrl || "").replace(/\/+$/, "");

        return slug ? `${root}/${encodeURIComponent(slug)}` : root;
    };

    const replaceEditorUrl = (spaceId, pageId) => {
        const space = spaces.find((item) => item.id === spaceId);
        const meta = contentMap[pageId];
        const target = editorPageUrlFor(space, meta);
        if (target && window.location.pathname !== target) {
            window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
        }
    };

    const stateUrlForSpace = (space) => {
        const config = getEditorConfig();
        const site = siteBootstrap();
        if (!config || typeof config.spaceStateUrlTemplate !== "string" || !site.uuid || !space || !space.uuid) {
            return null;
        }

        return config.spaceStateUrlTemplate
            .replace("__SITE__", encodeURIComponent(site.uuid))
            .replace("__SPACE__", encodeURIComponent(space.uuid));
    };

    const applyEditorState = (payload, fallbackSpace) => {
        const state = payload && payload.state ? payload.state : payload;
        if (!state) return false;

        if (payload && payload.bootstrap) {
            window.__LARAVEL_BOOTSTRAP__ = {
                ...(window.__LARAVEL_BOOTSTRAP__ || {}),
                ...payload.bootstrap,
            };
        }

        const nextSpaces = Array.isArray(state.spaces) ? state.spaces : spaces;
        const nextPages = Array.isArray(state.pages) ? state.pages : [];
        const nextContent = state.pageContent && typeof state.pageContent === "object" ? state.pageContent : {};
        const nextComments = Array.isArray(state.comments) ? state.comments : [];
        const nextHistory = Array.isArray(state.history) ? state.history : [];
        const nextSpaceId = state.activeSpaceId || (fallbackSpace && fallbackSpace.id) || activeSpaceId;
        const nextPageId = state.activePageId || (nextPages[0] && nextPages[0].id) || null;

        setSpaces(nextSpaces);
        setPages(nextPages);
        setContentMap(nextContent);
        setComments(nextComments);
        setHistoryItems(nextHistory);
        historyRef.current = { past: [], future: [] };
        dirtyPageIdsRef.current = new Set();
        setActiveSpaceId(nextSpaceId);
        if (nextPageId) setActivePageId(nextPageId);

        const nextSpace = nextSpaces.find((item) => item.id === nextSpaceId) || fallbackSpace;
        const nextPage = nextPageId ? nextContent[nextPageId] : null;
        const target = editorPageUrlFor(nextSpace, nextPage);
        if (target && window.location.pathname !== target) {
            window.history.replaceState(null, "", `${target}${window.location.hash || ""}`);
        }

        return true;
    };

    const loadEditorState = (space) => {
        const url = stateUrlForSpace(space);
        if (!url) return Promise.resolve(false);

        return requestEditorJson(url)
            .then((payload) => applyEditorState(payload, space))
            .catch((error) => {
                setToast("Space switch failed");
                setTimeout(() => setToast(null), 2200);
                console.error(error);
                return false;
            });
    };

    const restoreRevision = (revisionId) => {
        const config = getEditorConfig();
        const dbPageId = extractDbPageId(activePageId);

        if (!config || !dbPageId || !revisionId || typeof config.restoreRevisionUrlTemplate !== "string") {
            return Promise.resolve(false);
        }

        setToast("Restoring revision...");

        const url = config.restoreRevisionUrlTemplate
            .replace("__PAGE__", String(dbPageId))
            .replace("__REVISION__", String(revisionId));

        return requestEditorJson(url, { method: "POST" })
            .then(() => {
                const currentSpace = spaces.find((space) => space.id === activeSpaceId);
                if (!currentSpace) return false;
                return loadEditorState(currentSpace);
            })
            .then(() => {
                setToast("Revision restored");
                setTimeout(() => setToast(null), 2200);
                return true;
            })
            .catch((error) => {
                setToast("Revision restore failed");
                setTimeout(() => setToast(null), 2600);
                console.error(error);
                return false;
            });
    };

    React.useEffect(() => {
        if (typeof document === "undefined") return undefined;

        const validBlockIds = new Set((page.blocks || []).map((item) => String(item.id)));

        const resolveBlockIdFromNode = (node) => {
            if (!node) return null;

            const element = node.nodeType === 1 ? node : node.parentElement;
            if (!element || typeof element.closest !== "function") return null;

            const row = element.closest("[data-block-id]");
            if (!row) return null;

            const blockId = row.getAttribute("data-block-id");

            return blockId && validBlockIds.has(String(blockId)) ? blockId : null;
        };

        const hasActiveBlock = typeof window !== "undefined"
            && window.__editorActiveBlockId
            && validBlockIds.has(String(window.__editorActiveBlockId));

        if (!hasActiveBlock) {
            window.__editorActiveBlockId = page.blocks[0] ? page.blocks[0].id : null;
        }

        const syncActiveBlock = () => {
            const selection = typeof window.getSelection === "function" ? window.getSelection() : null;
            const selectionBlockId = selection && selection.rangeCount
                ? resolveBlockIdFromNode(selection.getRangeAt(0).commonAncestorContainer)
                : null;
            const focusedBlockId = resolveBlockIdFromNode(document.activeElement);
            const nextBlockId = selectionBlockId || focusedBlockId;

            if (nextBlockId) {
                window.__editorActiveBlockId = nextBlockId;
            }
        };

        const onSelectionChange = () => syncActiveBlock();
        const onFocusIn = (event) => {
            const blockId = resolveBlockIdFromNode(event.target);

            if (blockId) {
                window.__editorActiveBlockId = blockId;
            }
        };

        syncActiveBlock();
        document.addEventListener("selectionchange", onSelectionChange);
        document.addEventListener("focusin", onFocusIn);

        return () => {
            document.removeEventListener("selectionchange", onSelectionChange);
            document.removeEventListener("focusin", onFocusIn);
        };
    }, [activePageId, page.blocks]);

    const resolveInsertAnchorId = () => {
        const activeBlockId = typeof window !== "undefined" ? window.__editorActiveBlockId : null;

        if (activeBlockId && page.blocks.some((item) => String(item.id) === String(activeBlockId))) {
            return activeBlockId;
        }

        if (selectedBlocks && selectedBlocks.length) {
            return selectedBlocks[selectedBlocks.length - 1];
        }

        return page.blocks.length ? page.blocks[page.blocks.length - 1].id : null;
    };

    const insertAssetIntoPage = (asset) => {
        if (!asset || !asset.url) return;

        const isVideoAsset = asset.isVideo || String(asset.mimeType || "").startsWith("video/");
        const isImageAsset = !!asset.isImage;
        const block = isImageAsset
            ? {
                id: uid("b"),
                kind: "figure",
                src: asset.url,
                alt: asset.name || "",
                caption: asset.name || "",
            }
            : {
                id: uid("b"),
                kind: "embed",
                source: isVideoAsset ? "Video" : asset.mimeType === "application/pdf" ? "PDF" : "File",
                title: asset.name || (isVideoAsset ? "Video asset" : "Embedded asset"),
                url: asset.url,
                mimeType: asset.mimeType || "",
            };

        const anchorId = resolveInsertAnchorId();
        const anchorIndex = anchorId ? page.blocks.findIndex((item) => item.id === anchorId) : -1;
        const blocks = [...page.blocks];

        if (anchorIndex >= 0) {
            blocks.splice(anchorIndex + 1, 0, block);
        } else {
            blocks.push(block);
        }

        window.__editorActiveBlockId = block.id;
        setPage({ ...page, blocks });
        setToast(`Inserted ${isImageAsset ? "image" : isVideoAsset ? "video" : "asset"}: ${asset.name || "asset"}`);
        setTimeout(() => setToast(null), 1800);
    };

    window.__editorRestoreRevision = restoreRevision;
    window.__editorInsertAsset = insertAssetIntoPage;

    const selectPage = (id) => {
        setActivePageId(id);
        if (typeof window !== "undefined" && window.innerWidth <= 760) {
            setSidebarCollapsed(true);
            if (tweaks.rightPanel) {
                applyTweak({ rightPanel: false });
            }
        }
        replaceEditorUrl(activeSpaceId, id);
    };

    const persistAddSpace = (name) => {
        const clean = (name || "").trim();
        if (!clean) return null;

        const pendingKey = clean.toLowerCase();
        if (creatingSpaceNamesRef.current.has(pendingKey)) return null;
        creatingSpaceNamesRef.current.add(pendingKey);

        const tempSpaceId = onAddSpace(clean);
        if (!tempSpaceId) {
            creatingSpaceNamesRef.current.delete(pendingKey);
            return null;
        }

        const config = getEditorConfig();
        const siteId = window.__LARAVEL_BOOTSTRAP__ && window.__LARAVEL_BOOTSTRAP__.site
                ? window.__LARAVEL_BOOTSTRAP__.site.id
                : null;

        if (!config || !siteId || typeof config.createSpaceUrlTemplate !== "string") {
            creatingSpaceNamesRef.current.delete(pendingKey);
            return tempSpaceId;
        }

        requestEditorJson(config.createSpaceUrlTemplate.replace("__SITE__", String(siteId)), {
            method: "POST",
            body: JSON.stringify({ name: clean }),
        })
            .then((response) => {
                const savedSpace = response && response.space ? response.space : null;
                if (!savedSpace) return;
                reconcileCreatedSpace(tempSpaceId, savedSpace);
                return loadEditorState(savedSpace).then((loaded) => {
                    if (!loaded) setActiveSpaceId(savedSpace.id);
                    setToast(`Created space "${savedSpace.name}"`);
                    setTimeout(() => setToast(null), 2000);
                });
            })
            .catch((error) => {
                setSpaces((arr) => arr.filter((space) => space.id !== tempSpaceId));
                setActiveSpaceId((current) => current === tempSpaceId ? (SPACES[0] ? SPACES[0].id : current) : current);
                setToast("Space creation failed");
                setTimeout(() => setToast(null), 2400);
                console.error(error);
            })
            .finally(() => {
                creatingSpaceNamesRef.current.delete(pendingKey);
            });

        return tempSpaceId;
    };

    const activateSpace = (spaceId) => {
        const nextSpace = spaces.find((space) => space.id === spaceId);
        if (!nextSpace) return;

        if (spaceId === activeSpaceId) return;

        loadEditorState(nextSpace).then((loaded) => {
            if (loaded) return;
            setActiveSpaceId(spaceId);
            replaceEditorUrl(spaceId, activePageId);
        });
    };
JS;

        $clipboardPattern = '/  const \[selectedBlocks, setSelectedBlocks\] = useState\(\[\]\);\R  const \[clipboard, setClipboard\] = useState\(null\);/';
        $setPagePattern = '/  const setPage = \(next\) => \{\R    setContentMap\(\(m\) => \{\R      if \(skipHistoryRef\.current\) \{ skipHistoryRef\.current = false; return \{ \.\.\.m, \[activePageId\]: next \}; \}\R      pushHistory\(m\);\R      return \{ \.\.\.m, \[activePageId\]: next \};\R    \}\);\R  \};/';
        $editablePattern = '/const Editable = \(\{ html, onChange, className, placeholder, tag="div", \.\.\.rest \}\) => \{\R.*?\R\};\R\R\/\/ Small icon button used in many editors/s';
        $addPagePattern = '/  const onAddPage = \(parentId\) => \{\R.*?\R  \};\R\R  \/\/ Cmd\+K, undo\/redo/s';
        $spacePattern = '/  const onAddSpace = \(name\) => \{\R.*?\R  \};\R\R  const onAddComment/s';
        $publishPattern = '/  const onPublish = \(\) => \{\R    setPublishing\(true\);\R    setTimeout\(\(\) => \{\R      setPublishing\(false\);\R      setToast\("Published to lexicon\.page\/handbook\/quickstart"\);\R      setTimeout\(\(\) => setToast\(null\), 2400\);\R    \}, 1600\);\R  \};/';
        $canonicalUrlPattern = '/  \/\/ Canonicalize the URL so it always reflects \/editor\/\{spaceUuid\}\/\{pageSlug\}\R  useEffect\(\(\) => \{\R    try \{\R      const sp = spaces\.find\(\(s\) => s\.id === activeSpaceId\);\R      const meta = contentMap\[activePageId\];\R      const slug = meta\?\.slug;\R      if \(!sp\?\.uuid \|\| !slug\) return;\R      const target = `\/editor\/\$\{sp\.uuid\}\/\$\{slug\}`;\R      if \(window\.location\.pathname !== target\) \{\R        window\.history\.replaceState\(null, "", target\);\R      \}\R    \} catch \(e\) \{ \/\* no-op \*\/ \}\R  \}, \[activeSpaceId, activePageId, contentMap, spaces\]\);/';

        $bundle = preg_replace($clipboardPattern, $clipboardReplacement, $bundle, 1, $clipboardCount);
        if (! is_string($bundle) || $clipboardCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($setPagePattern, $setPageReplacement, $bundle, 1, $setPageCount);
        if (! is_string($bundle) || $setPageCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($editablePattern, $editableReplacement."\n\n// Small icon button used in many editors", $bundle, 1, $editableCount);
        if (! is_string($bundle) || $editableCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($addPagePattern, $addPageAndPersistenceReplacement."\n\n  // Cmd+K, undo/redo", $bundle, 1, $addPageCount);
        if (! is_string($bundle) || $addPageCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($publishPattern, $publishReplacement, $bundle, 1, $publishCount);
        if (! is_string($bundle) || $publishCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($spacePattern, $spacePersistenceReplacement."\n\n  const onAddComment", $bundle, 1, $spaceCount);
        if (! is_string($bundle) || $spaceCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace($canonicalUrlPattern, '  // Canonical URLs are handled by replaceEditorUrl so site and space UUIDs stay in sync.', $bundle, 1, $canonicalUrlCount);
        if (! is_string($bundle)) {
            return $originalBundle;
        }

        $bundle = str_replace('          onSelectPage={setActivePageId}', '          onSelectPage={selectPage}', $bundle, $selectPageCount);
        if (! is_string($bundle) || $selectPageCount !== 1) {
            return $originalBundle;
        }

        $sidebarSignature = 'const Sidebar = ({ spaces, activeSpaceId, onSpace, onAddSpace, pages, activePageId, onSelectPage, onAddPage, onRenamePage, onDeletePage, onMovePage }) => {';
        $sidebarSignatureReplacement = 'const Sidebar = ({ spaces, activeSpaceId, onSpace, onAddSpace, pages, activePageId, onSelectPage, onAddPage, onRenamePage, onDeletePage, onMovePage, onShareSite = () => {}, onOpenSettings = () => {} }) => {';

        $bundle = str_replace($sidebarSignature, $sidebarSignatureReplacement, $bundle, $sidebarSignatureCount);
        if ($sidebarSignatureCount !== 1) {
            return $originalBundle;
        }

        $sidebarFooterRowsReplacement = <<<'JS'
                <div
                    className="sf-row"
                    role="button"
                    tabIndex={0}
                    onClick={onShareSite}
                    onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onShareSite(); } }}
                    title="Copy draft preview link"
                >
                    <Icon name="globe" size={14} /><span>Share site</span>
                </div>
                <div
                    className="sf-row"
                    role="button"
                    tabIndex={0}
                    onClick={onOpenSettings}
                    onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpenSettings(); } }}
                    title="Open site settings"
                >
                    <Icon name="settings" size={14} /><span>Settings</span>
                </div>
JS;

        $bundle = preg_replace(
            '/        <div className="sf-row"><Icon name="globe" size=\{14\} \/><span>Share site<\/span><\/div>\R        <div className="sf-row"><Icon name="settings" size=\{14\} \/><span>Settings<\/span><\/div>/',
            $sidebarFooterRowsReplacement,
            $bundle,
            1,
            $sidebarFooterRowsCount,
        );
        if (! is_string($bundle) || $sidebarFooterRowsCount !== 1) {
            return $originalBundle;
        }

        $sidebarPropReplacements = [
            '          onAddSpace={onAddSpace}' => '          onAddSpace={persistAddSpace}',
            '          onAddPage={onAddPage}' => '          onAddPage={persistAddPage}',
            '          onRenamePage={onRenamePage}' => '          onRenamePage={persistRenamePage}',
            '          onDeletePage={onDeletePage}' => '          onDeletePage={persistDeletePage}',
            '          onMovePage={onMovePage}' => '          onMovePage={persistMovePage}',
        ];

        foreach ($sidebarPropReplacements as $search => $replace) {
            $bundle = str_replace($search, $replace, $bundle, $sidebarPropCount);

            if ($sidebarPropCount !== 1) {
                return $originalBundle;
            }
        }

        $bundle = str_replace('    if (id === "new-page") onAddPage(null);', '    if (id === "new-page") persistAddPage(null);', $bundle, $paletteActionCount);
        if (! is_string($bundle) || $paletteActionCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace('    if (id === "share") { setToast("Public link copied to clipboard"); setTimeout(() => setToast(null), 2000); }', '    if (id === "share") onShareSite();', $bundle, $paletteShareActionCount);
        if (! is_string($bundle) || $paletteShareActionCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace('  const [activeSpaceId, setActiveSpaceId] = useState(SPACES[0].id);', '  const [activeSpaceId, setActiveSpaceId] = useState(ACTIVE_SPACE_ID || SPACES[0].id);', $bundle, $activeSpaceStateCount);
        if (! is_string($bundle) || $activeSpaceStateCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace('  const [comments, setComments] = useState(COMMENTS);', '  const [comments, setComments] = useState(COMMENTS);'."\n".'  const [historyItems, setHistoryItems] = useState(HISTORY);', $bundle, $historyStateCount);
        if (! is_string($bundle) || $historyStateCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace('            history={HISTORY}', '            history={historyItems}', $bundle, $historyPropCount);
        if (! is_string($bundle) || $historyPropCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace('          onSpace={setActiveSpaceId}', '          onSpace={activateSpace}', $bundle, $activateSpacePropCount);
        if (! is_string($bundle) || $activateSpacePropCount !== 1) {
            return $originalBundle;
        }

        $bylineStatReplacements = [
            '<div className="item"><Icon name="eye" size={12} /> 1,284</div>' => '<div className="item"><Icon name="eye" size={12} /> {Number(page.viewCount ?? page.stats?.views ?? 0).toLocaleString()}</div>',
            '<div className="item"><Icon name="comment" size={12} /> 3</div>' => '<div className="item"><Icon name="comment" size={12} /> {Number(page.commentCount ?? page.stats?.comments ?? 0).toLocaleString()}</div>',
        ];

        foreach ($bylineStatReplacements as $search => $replace) {
            $bundle = str_replace($search, $replace, $bundle, $bylineStatCount);

            if (! is_string($bundle) || $bylineStatCount !== 1) {
                return $originalBundle;
            }
        }

        $bundle = str_replace('          if (!inFormField && inContent && e.shiftKey) {', '          if (!inFormField && inContent && !e.shiftKey) {', $bundle, $enterCreatesParagraphCount);
        if (! is_string($bundle) || $enterCreatesParagraphCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '          onMovePage={persistMovePage}',
            '          onMovePage={persistMovePage}'."\n".'          onShareSite={onShareSite}'."\n".'          onOpenSettings={onOpenSettings}',
            $bundle,
            $sidebarFooterPropCount,
        );
        if (! is_string($bundle) || $sidebarFooterPropCount !== 1) {
            return $originalBundle;
        }

        return strtr($bundle, $this->prototypeTextNormalizationMap());
    }

    private function rewriteBundleAiWriterBridge(string $bundle): string
    {
        $originalBundle = $bundle;

        $aiHelpers = <<<'JS'
    const aiScopeFromMode = (mode) => {
        switch (mode) {
            case "selection":
            case "title":
            case "description":
            case "content":
            case "text":
                return mode;
            default:
                return "page";
        }
    };

    const aiIntentForMode = (mode, intent) => {
        if (intent) return intent;

        switch (mode) {
            case "selection":
                return "rewrite";
            case "title":
            case "description":
                return "derive";
            case "text":
                return "rewrite";
            case "content":
                return "generate";
            default:
                return "generate";
        }
    };

    const aiModalCopy = (mode, intent, selectedCount = 0) => {
        const resolvedIntent = aiIntentForMode(mode, intent);

        switch (mode) {
            case "selection":
                return {
                    title: "AI Section Writer",
                    actionLabel: "Rewrite section",
                    promptLabel: "How should the selected section change?",
                    placeholder: "Example: Tighten this section, add sharper steps, and make the tone more direct.",
                    badgeLabel: `${selectedCount} block${selectedCount === 1 ? "" : "s"} selected`,
                    progressToast: "AI is rewriting the selected section...",
                    successToast: "AI section updated",
                };
            case "title":
                return resolvedIntent === "rewrite"
                    ? {
                        title: "AI Title Writer",
                        actionLabel: "Rewrite title",
                        promptLabel: "How should the title change?",
                        placeholder: "Example: Make the title sharper, clearer, and more outcome-driven.",
                        badgeLabel: "Title",
                        progressToast: "AI is rewriting the title...",
                        successToast: "AI title updated",
                    }
                    : {
                        title: "AI Title Writer",
                        actionLabel: "Generate title",
                        promptLabel: "What should the title emphasize?",
                        placeholder: "Example: Generate a concise title from the current content with a clearer outcome.",
                        badgeLabel: "Title",
                        progressToast: "AI is drafting the title...",
                        successToast: "AI title updated",
                    };
            case "description":
                return resolvedIntent === "rewrite"
                    ? {
                        title: "AI Description Writer",
                        actionLabel: "Rewrite description",
                        promptLabel: "How should the description change?",
                        placeholder: "Example: Make the description shorter, more confident, and more specific.",
                        badgeLabel: "Description",
                        progressToast: "AI is rewriting the description...",
                        successToast: "AI description updated",
                    }
                    : {
                        title: "AI Description Writer",
                        actionLabel: "Generate description",
                        promptLabel: "What should the description highlight?",
                        placeholder: "Example: Generate a short description from the current content for new readers.",
                        badgeLabel: "Description",
                        progressToast: "AI is drafting the description...",
                        successToast: "AI description updated",
                    };
            case "text":
                return {
                    title: "AI Text Writer",
                    actionLabel: "Rewrite text",
                    promptLabel: "How should this text be rewritten?",
                    placeholder: "Example: Make this clearer, shorter, and more direct.",
                    badgeLabel: "Text selection",
                    progressToast: "AI is rewriting the text...",
                    successToast: "AI text updated",
                };
            case "content":
                return resolvedIntent === "expand"
                    ? {
                        title: "AI Content Writer",
                        actionLabel: "Expand content",
                        promptLabel: "How should this content expand?",
                        placeholder: "Example: Add clearer steps, one caveat, and a more useful example.",
                        badgeLabel: `${selectedCount || 1} block${(selectedCount || 1) === 1 ? "" : "s"}`,
                        progressToast: "AI is expanding the content...",
                        successToast: "AI content expanded",
                    }
                    : resolvedIntent === "rewrite"
                        ? {
                            title: "AI Content Writer",
                            actionLabel: "Rewrite content",
                            promptLabel: "How should this content change?",
                            placeholder: "Example: Rewrite this content to be shorter, clearer, and more actionable.",
                            badgeLabel: `${selectedCount || 1} block${(selectedCount || 1) === 1 ? "" : "s"}`,
                            progressToast: "AI is rewriting the content...",
                            successToast: "AI content updated",
                        }
                        : {
                            title: "AI Content Writer",
                            actionLabel: "Generate content",
                            promptLabel: "What content should be added here?",
                            placeholder: "Example: Add a short setup checklist with common mistakes to avoid.",
                            badgeLabel: "Insert content",
                            progressToast: "AI is generating content...",
                            successToast: "AI content added",
                        };
            default:
                return {
                    title: "AI Writer",
                    actionLabel: "Generate page",
                    promptLabel: "What should this page cover?",
                    placeholder: "Example: Write a quickstart that explains setup, first publish, and rollback.",
                    badgeLabel: "Full page",
                    progressToast: "AI is drafting the page...",
                    successToast: "AI draft added",
                };
        }
    };

    const defaultAiPrompt = (mode, intent) => {
        const resolvedIntent = aiIntentForMode(mode, intent);

        switch (mode) {
            case "selection":
                return "Rewrite this section to be clearer, tighter, and more actionable.";
            case "title":
                return resolvedIntent === "rewrite"
                    ? "Rewrite the title to be sharper, clearer, and more specific."
                    : "Generate a concise, product-quality title from the current content.";
            case "description":
                return resolvedIntent === "rewrite"
                    ? "Rewrite the description to be clearer, shorter, and more compelling."
                    : "Generate a short description from the current content.";
            case "text":
                return "Rewrite the selected text to be clearer, tighter, and more useful.";
            case "content":
                return resolvedIntent === "expand"
                    ? "Expand this content with clearer details and useful next steps."
                    : resolvedIntent === "rewrite"
                        ? "Rewrite this content to be clearer, tighter, and more actionable."
                        : "Generate a useful documentation section to insert here.";
            default:
                return "Draft a complete documentation page for this topic.";
        }
    };

    const openAiWriterModal = (mode, options = {}) => {
        if (aiWriting) return;

        const selectionIds = Array.isArray(options.selectionIds) ? options.selectionIds : [];
        if (mode === "selection" && selectionIds.length === 0) {
            setToast("Select a section first");
            setTimeout(() => setToast(null), 1800);
            return;
        }

        const intent = aiIntentForMode(mode, options.intent);
        if (mode === "content" && ["rewrite", "expand"].includes(intent) && selectionIds.length === 0) {
            setToast("Select content first");
            setTimeout(() => setToast(null), 1800);
            return;
        }

        const nextPrompt = typeof options.prompt === "string" && options.prompt.trim()
            ? options.prompt
            : defaultAiPrompt(mode, intent);

        setAiPrompt(nextPrompt);
        setAiModal({
            open: true,
            mode,
            intent,
            selectionIds,
            insertAfterBlockId: options.insertAfterBlockId || null,
            blockId: options.blockId || null,
            selectedText: options.selectedText || "",
            range: options.range || null,
        });
    };

    const closeAiWriterModal = () => {
        if (aiWriting) return;
        setAiModal((current) => ({ ...current, open: false }));
    };

    const stripAiHtml = (value) => String(value || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
    const waitForAiFrame = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

    const animateAiFieldPatch = async (field, value) => {
        const finalValue = String(value || "");
        const previewText = stripAiHtml(finalValue);

        if (!previewText) {
            throw new Error(field === "title" ? "AI writer returned no title" : "AI writer returned no description");
        }

        lastPushAtRef.current = 0;
        pushHistory(contentMap);

        let workingPage = { ...page };
        setPageSilently(workingPage);

        const step = Math.max(1, Math.ceil(previewText.length / 28));
        for (let cursor = step; cursor < previewText.length; cursor += step) {
            workingPage = { ...workingPage, [field]: previewText.slice(0, cursor) };
            setPageSilently(workingPage);
            await waitForAiFrame(20);
        }

        workingPage = { ...workingPage, [field]: finalValue };
        setPageSilently(workingPage);
        scheduleAutosave(activePageId, workingPage);
    };

    const materializeAiBlock = (block) => {
        const next = { ...block, id: uid("b") };
        if (Array.isArray(next.items)) {
            next.items = next.items.map((item) => ({ id: uid("c"), text: item.text || "", done: !!item.done }));
        }
        return next;
    };

    const aiBlockPreviewText = (block) => {
        switch (block.kind) {
            case "h2":
            case "h3":
                return stripAiHtml(block.text);
            case "p":
            case "quote":
                return stripAiHtml(block.html);
            case "callout":
                return stripAiHtml(block.text);
            case "code":
                return String(block.code || "");
            default:
                return "";
        }
    };

    const buildAiPreviewBlock = (block, text) => {
        if (block.kind === "h2" || block.kind === "h3") {
            return { ...block, text };
        }
        if (block.kind === "p" || block.kind === "quote") {
            return { ...block, html: text };
        }
        if (block.kind === "callout") {
            return { ...block, text };
        }
        if (block.kind === "code") {
            return { ...block, code: text };
        }
        return block;
    };

    const replaceSelectedBlocksWithDraft = (sourceBlocks, selectionIds, replacementBlocks) => {
        const selected = new Set(selectionIds || []);
        const firstIndex = sourceBlocks.findIndex((block) => selected.has(block.id));
        if (firstIndex === -1) return sourceBlocks;

        const before = sourceBlocks.slice(0, firstIndex).filter((block) => !selected.has(block.id));
        const after = sourceBlocks.slice(firstIndex).filter((block) => !selected.has(block.id));

        return [...before, ...replacementBlocks, ...after];
    };

    const insertBlocksAfterTarget = (sourceBlocks, targetBlockId, insertedBlocks, fallback = "end") => {
        if (!targetBlockId) {
            return fallback === "start" ? [...insertedBlocks, ...sourceBlocks] : [...sourceBlocks, ...insertedBlocks];
        }

        const targetIndex = sourceBlocks.findIndex((block) => block.id === targetBlockId);
        if (targetIndex === -1) {
            return fallback === "start" ? [...insertedBlocks, ...sourceBlocks] : [...sourceBlocks, ...insertedBlocks];
        }

        return [
            ...sourceBlocks.slice(0, targetIndex + 1),
            ...insertedBlocks,
            ...sourceBlocks.slice(targetIndex + 1),
        ];
    };

    const replaceAiBlockById = (sourceBlocks, blockId, replacementBlock) => sourceBlocks.map((block) => block.id === blockId ? replacementBlock : block);

    const findAiBlockContentElement = (blockId) => {
        const row = Array.from(document.querySelectorAll(".block-row")).find((element) => element.getAttribute("data-block-id") === blockId);
        return row ? row.querySelector(".blk-content") : null;
    };

    const updateBlockFromAiEditable = (block, editable) => {
        if (!editable) return block;

        if (["p", "quote"].includes(block.kind)) {
            return { ...block, html: editable.innerHTML };
        }

        if (["h1", "h2", "h3"].includes(block.kind)) {
            return { ...block, text: editable.textContent || "" };
        }

        if (block.kind === "callout") {
            return { ...block, text: editable.innerHTML };
        }

        return block;
    };

    const previousBlockIdBeforeSelection = (sourceBlocks, selectionIds) => {
        const selected = new Set(selectionIds || []);
        const firstIndex = sourceBlocks.findIndex((block) => selected.has(block.id));
        if (firstIndex <= 0) return null;

        for (let index = firstIndex - 1; index >= 0; index -= 1) {
            if (!selected.has(sourceBlocks[index].id)) return sourceBlocks[index].id;
        }

        return null;
    };

    const animateAiBlockPatch = async (generation, selectionIds = []) => {
        const patch = generation && generation.patch ? generation.patch : {};
        const sourceBlocks = Array.isArray(patch.blocks) ? patch.blocks : generation.blocks;
        const finalBlocks = (Array.isArray(sourceBlocks) ? sourceBlocks : []).map(materializeAiBlock);

        if (finalBlocks.length === 0) {
            throw new Error("AI writer returned no blocks");
        }

        lastPushAtRef.current = 0;
        pushHistory(contentMap);

        const replacesLocalBlocks = aiModal.mode === "selection" || (aiModal.mode === "content" && ["rewrite", "expand"].includes(aiModal.intent));
        const insertsContent = aiModal.mode === "content" && aiModal.intent === "generate";
        let insertionAnchorId = insertsContent ? aiModal.insertAfterBlockId : (replacesLocalBlocks ? previousBlockIdBeforeSelection(page.blocks, selectionIds) : null);
        const insertionFallback = replacesLocalBlocks && !insertionAnchorId ? "start" : "end";

        const basePage = {
            ...page,
            title: patch.title !== undefined ? patch.title : (generation.title !== undefined ? generation.title : page.title),
            subtitle: patch.subtitle !== undefined ? patch.subtitle : (generation.subtitle !== undefined ? generation.subtitle : page.subtitle),
            blocks: replacesLocalBlocks
                ? replaceSelectedBlocksWithDraft(page.blocks, selectionIds, [])
                : insertsContent
                    ? page.blocks
                    : [],
        };

        let workingPage = basePage;
        setPageSilently(workingPage);

        for (const block of finalBlocks) {
            const previewText = aiBlockPreviewText(block);

            if (!previewText) {
                workingPage = {
                    ...workingPage,
                    blocks: insertsContent || replacesLocalBlocks
                        ? insertBlocksAfterTarget(workingPage.blocks, insertionAnchorId, [block], insertionFallback)
                        : [...workingPage.blocks, block],
                };
                setPageSilently(workingPage);
                insertionAnchorId = block.id;
                await waitForAiFrame(90);
                continue;
            }

            let stagedBlock = buildAiPreviewBlock(block, "");
            workingPage = {
                ...workingPage,
                blocks: insertsContent || replacesLocalBlocks
                    ? insertBlocksAfterTarget(workingPage.blocks, insertionAnchorId, [stagedBlock], insertionFallback)
                    : [...workingPage.blocks, stagedBlock],
            };
            setPageSilently(workingPage);

            const step = Math.max(2, Math.ceil(previewText.length / 24));

            for (let cursor = step; cursor < previewText.length; cursor += step) {
                stagedBlock = buildAiPreviewBlock(block, previewText.slice(0, cursor));
                workingPage = {
                    ...workingPage,
                    blocks: replaceAiBlockById(workingPage.blocks, block.id, stagedBlock),
                };
                setPageSilently(workingPage);
                await waitForAiFrame(24);
            }

            workingPage = {
                ...workingPage,
                blocks: replaceAiBlockById(workingPage.blocks, block.id, block),
            };
            setPageSilently(workingPage);
            insertionAnchorId = block.id;
            await waitForAiFrame(70);
        }

        scheduleAutosave(activePageId, workingPage);
    };

    const animateAiDraft = async (generation, selectionIds = []) => {
        const scope = generation && generation.scope ? generation.scope : aiScopeFromMode(aiModal.mode);
        const patch = generation && generation.patch ? generation.patch : {};

        if (scope === "title") {
            await animateAiFieldPatch("title", patch.title !== undefined ? patch.title : generation.title);
            return;
        }

        if (scope === "description") {
            await animateAiFieldPatch("subtitle", patch.subtitle !== undefined ? patch.subtitle : generation.subtitle);
            return;
        }

        if (scope === "text") {
            const finalText = String(patch.text !== undefined ? patch.text : (generation.text || "")).trim();
            if (!finalText) throw new Error("AI writer returned no text");
            if (!aiModal.range || !aiModal.blockId) throw new Error("Text selection is no longer available");

            lastPushAtRef.current = 0;
            pushHistory(contentMap);

            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(aiModal.range);
            document.execCommand("insertText", false, finalText);

            const editable = findAiBlockContentElement(aiModal.blockId);
            if (editable) {
                editable.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: finalText }));
            }

            const workingPage = {
                ...page,
                blocks: page.blocks.map((block) => block.id === aiModal.blockId ? updateBlockFromAiEditable(block, editable) : block),
            };

            setPageSilently(workingPage);
            scheduleAutosave(activePageId, workingPage);
            return;
        }

        await animateAiBlockPatch(generation, selectionIds);
    };

    const buildAiRequestPayload = (mode, intent, selectionIds, prompt) => {
        const payload = {
            scope: aiScopeFromMode(mode),
            intent: aiIntentForMode(mode, intent),
            prompt,
            document: {
                title: page.title,
                subtitle: page.subtitle,
                blocks: page.blocks,
            },
        };

        if (mode === "full-page") {
            payload.mode = "full-page";
            return payload;
        }

        if (mode === "selection") {
            payload.mode = "selection";
            payload.selection = {
                blockIds: selectionIds,
                blocks: page.blocks.filter((block) => selectionIds.includes(block.id)),
            };
        }

        if (mode === "content") {
            payload.target = {
                insertAfterBlockId: aiModal.insertAfterBlockId || null,
                blockIds: selectionIds,
                blocks: page.blocks.filter((block) => selectionIds.includes(block.id)),
            };
        }

        if (mode === "text") {
            payload.target = {
                blockId: aiModal.blockId || null,
                selectedText: aiModal.selectedText || "",
                blockIds: aiModal.blockId ? [aiModal.blockId] : [],
                blocks: page.blocks.filter((block) => block.id === aiModal.blockId),
            };
        }

        return payload;
    };

    const submitAiWriter = async () => {
        const prompt = aiPrompt.trim();
        if (!prompt || aiWriting) return;

        const config = getEditorConfig();
        const dbPageId = extractDbPageId(activePageId);
        const selectionIds = aiModal.mode === "selection"
            ? (aiModal.selectionIds || []).filter((id) => page.blocks.some((block) => block.id === id))
            : aiModal.mode === "content" && ["rewrite", "expand"].includes(aiModal.intent)
                ? (aiModal.selectionIds || []).filter((id) => page.blocks.some((block) => block.id === id))
            : [];

        if (!config || !dbPageId || typeof config.aiWritePageUrlTemplate !== "string") {
            setToast("AI writer is unavailable for this page");
            setTimeout(() => setToast(null), 2200);
            return;
        }

        if (aiModal.mode === "selection" && selectionIds.length === 0) {
            setToast("Select a section first");
            setTimeout(() => setToast(null), 1800);
            return;
        }

        if (aiModal.mode === "content" && ["rewrite", "expand"].includes(aiModal.intent) && selectionIds.length === 0) {
            setToast("Select content first");
            setTimeout(() => setToast(null), 1800);
            return;
        }

        const copy = aiModalCopy(aiModal.mode, aiModal.intent, selectionIds.length);

        setAiWriting(true);
        setAiModal((current) => ({ ...current, open: false }));
        setToast(copy.progressToast);

        try {
            const response = await requestEditorJson(config.aiWritePageUrlTemplate.replace("__PAGE__", dbPageId), {
                method: "POST",
                body: JSON.stringify(buildAiRequestPayload(aiModal.mode, aiModal.intent, selectionIds, prompt)),
            });

            const generation = response && response.generation ? response.generation : null;
            if (!generation) throw new Error("AI writer returned no draft");

            await animateAiDraft(generation, selectionIds);

            if (aiModal.mode === "selection" || (aiModal.mode === "content" && ["rewrite", "expand"].includes(aiModal.intent))) {
                setSelectedBlocks([]);
            }

            setToast(copy.successToast);
            setTimeout(() => setToast(null), 2200);
        } catch (error) {
            const message = error && error.message ? error.message : "AI writer failed";
            setToast(message);
            setTimeout(() => setToast(null), 2600);
            console.error(error);
        } finally {
            setAiWriting(false);
        }
    };
JS;

        $aiModalComponent = <<<'JS'
const AiInlineActions = ({ label, onGenerate, onRewrite, busy }) => (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10, marginBottom: 4 }}>
        <button className="btn" type="button" onClick={onGenerate} disabled={busy}><Icon name="bolt" size={12} /> {busy ? "Writing..." : `Generate ${label}`}</button>
        <button className="btn" type="button" onClick={onRewrite} disabled={busy}><Icon name="paintbrush" size={12} /> Rewrite {label}</button>
    </div>
);

const AiWriterModal = ({ open, mode, intent, prompt, setPrompt, onClose, onSubmit, busy, selectedCount }) => {
    if (!open) return null;

    const resolvedIntent = intent || (mode === "selection" ? "rewrite" : (mode === "title" || mode === "description" ? "derive" : "generate"));
    const copy = (() => {
        switch (mode) {
            case "selection":
                return {
                    title: "AI Section Writer",
                    actionLabel: "Rewrite section",
                    promptLabel: "How should the selected section change?",
                    placeholder: "Example: Tighten this section, add sharper steps, and make the tone more direct.",
                    badgeLabel: `${selectedCount} block${selectedCount === 1 ? "" : "s"} selected`,
                };
            case "title":
                return resolvedIntent === "rewrite"
                    ? {
                        title: "AI Title Writer",
                        actionLabel: "Rewrite title",
                        promptLabel: "How should the title change?",
                        placeholder: "Example: Make the title sharper, clearer, and more outcome-driven.",
                        badgeLabel: "Title",
                    }
                    : {
                        title: "AI Title Writer",
                        actionLabel: "Generate title",
                        promptLabel: "What should the title emphasize?",
                        placeholder: "Example: Generate a concise title from the current content with a clearer outcome.",
                        badgeLabel: "Title",
                    };
            case "description":
                return resolvedIntent === "rewrite"
                    ? {
                        title: "AI Description Writer",
                        actionLabel: "Rewrite description",
                        promptLabel: "How should the description change?",
                        placeholder: "Example: Make the description shorter, more confident, and more specific.",
                        badgeLabel: "Description",
                    }
                    : {
                        title: "AI Description Writer",
                        actionLabel: "Generate description",
                        promptLabel: "What should the description highlight?",
                        placeholder: "Example: Generate a short description from the current content for new readers.",
                        badgeLabel: "Description",
                    };
            case "text":
                return {
                    title: "AI Text Writer",
                    actionLabel: "Rewrite text",
                    promptLabel: "How should this text be rewritten?",
                    placeholder: "Example: Make this clearer, shorter, and more direct.",
                    badgeLabel: "Text selection",
                };
            case "content":
                return resolvedIntent === "expand"
                    ? {
                        title: "AI Content Writer",
                        actionLabel: "Expand content",
                        promptLabel: "How should this content expand?",
                        placeholder: "Example: Add clearer steps, one caveat, and a more useful example.",
                        badgeLabel: `${selectedCount || 1} block${(selectedCount || 1) === 1 ? "" : "s"}`,
                    }
                    : resolvedIntent === "rewrite"
                        ? {
                            title: "AI Content Writer",
                            actionLabel: "Rewrite content",
                            promptLabel: "How should this content change?",
                            placeholder: "Example: Rewrite this content to be shorter, clearer, and more actionable.",
                            badgeLabel: `${selectedCount || 1} block${(selectedCount || 1) === 1 ? "" : "s"}`,
                        }
                        : {
                            title: "AI Content Writer",
                            actionLabel: "Generate content",
                            promptLabel: "What content should be added here?",
                            placeholder: "Example: Add a short setup checklist with common mistakes to avoid.",
                            badgeLabel: "Insert content",
                        };
            default:
                return {
                    title: "AI Writer",
                    actionLabel: "Generate page",
                    promptLabel: "What should this page cover?",
                    placeholder: "Example: Write a quickstart that explains setup, first publish, and rollback.",
                    badgeLabel: "Full page",
                };
        }
    })();

    return (
        <div className="lx-modal-bg" onClick={busy ? undefined : onClose}>
            <div className="lx-modal" role="dialog" aria-modal="true" aria-labelledby="ai-writer-title" onClick={(e) => e.stopPropagation()}>
                <div className="lx-modal-head">
                    <h3 id="ai-writer-title">{copy.title}</h3>
                    <button className="lx-modal-close" onClick={onClose} disabled={busy}>x</button>
                </div>

                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
                    <span style={{ fontSize: 12, padding: "5px 8px", borderRadius: 999, background: "var(--accent-soft)", color: "var(--accent-ink)", fontWeight: 600 }}>
                        {copy.badgeLabel}
                    </span>
                </div>

                <div className="lx-field">
                    <label htmlFor="ai-writer-prompt">{copy.promptLabel}</label>
                    <textarea
                        id="ai-writer-prompt"
                        autoFocus
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={copy.placeholder}
                        style={{
                            width: "100%",
                            minHeight: 136,
                            resize: "vertical",
                            background: "var(--bg-subtle)",
                            border: "1px solid var(--border)",
                            borderRadius: 6,
                            padding: "10px 12px",
                            fontSize: 13,
                            lineHeight: 1.55,
                            color: "var(--text)",
                            outline: "none",
                            fontFamily: "inherit",
                        }}
                    />
                </div>

                <div style={{ fontSize: 12.5, color: "var(--text-muted)", marginTop: 10 }}>
                    The generated draft streams back into the editor so you can keep the same UI and continue editing immediately.
                </div>

                <div className="lx-modal-foot">
                    <button className="btn" onClick={onClose} disabled={busy}>Cancel</button>
                    <button className="btn primary" onClick={onSubmit} disabled={busy || !prompt.trim()}>{busy ? "Thinking..." : copy.actionLabel}</button>
                </div>
            </div>
        </div>
    );
};
JS;

        $heroTitleInsert = <<<'JS'
        <AiInlineActions
          label="title"
          busy={aiWriting}
          onGenerate={() => onAiWriteTitle && onAiWriteTitle("derive")}
          onRewrite={() => onAiWriteTitle && onAiWriteTitle("rewrite")}
        />
JS;

        $heroSubtitleInsert = <<<'JS'
        <AiInlineActions
          label="description"
          busy={aiWriting}
          onGenerate={() => onAiWriteDescription && onAiWriteDescription("derive")}
          onRewrite={() => onAiWriteDescription && onAiWriteDescription("rewrite")}
        />
JS;

        $publishRowsReplacement = <<<'JS'
<div className="row"><span>Space</span><span className="val">{spaceName || "Documentation"}</span></div>
                    <div className="row"><span>Preview</span><a className="val publish-action-link" href={previewUrl} target="_blank" rel="noreferrer">Open preview</a></div>
                    <div className="row"><span>Published</span><a className="val publish-action-link" href={publishedUrl} target="_blank" rel="noreferrer">Open published</a></div>
                    <div className="row"><span>Version</span><span className="val">{publishVersion || "next release"}</span></div>
                    <div className="row"><span>Changes</span><span className="val">{publishChangesLabel}</span></div>
JS;

        $publishTextareaReplacement = <<<'JS'
<textarea
                                value={publishMessage}
                                onChange={(e) => setPublishMessage(e.target.value)}
                    placeholder={publishMessagePlaceholder}
JS;

        $publishButtonsReplacement = <<<'JS'
<button className="primary" onClick={() => { setPublishOpen(false); onPublish({ environment: "production", message: publishMessage }); }}>
                                Publish to production
                            </button>
JS;

        $publishStateReplacement = <<<'JS'
    const [publishOpen, setPublishOpen] = React.useState(false);
    const [publishMessage, setPublishMessage] = React.useState("");
    const shortPublishUrl = (value) => {
        const raw = String(value || "");
        try {
            const parsed = new URL(raw, window.location.origin);
            return parsed.origin === window.location.origin
                ? `${parsed.pathname}${parsed.search}${parsed.hash}`.replace(/\/$/, "")
                : raw.replace(/^https?:\/\//, "").replace(/\/$/, "");
        } catch (error) {
            return raw.replace(/^https?:\/\//, "").replace(/\/$/, "");
        }
    };
    const stripPublishHtml = (value) => {
        const holder = document.createElement("div");
        holder.innerHTML = String(value || "");
        return holder.textContent || holder.innerText || "";
    };
    const blockPublishText = (block) => {
        if (!block || typeof block !== "object") return "";
        const parts = [];
        ["text", "html", "title", "caption", "desc", "body", "url", "path"].forEach((field) => {
            if (block[field] !== undefined) parts.push(stripPublishHtml(block[field]));
        });
        ["headers", "items"].forEach((field) => {
            if (Array.isArray(block[field])) {
                block[field].forEach((item) => parts.push(stripPublishHtml(Array.isArray(item) ? item.join(" ") : item)));
            }
        });
        if (Array.isArray(block.rows)) {
            block.rows.forEach((row) => {
                if (Array.isArray(row)) parts.push(stripPublishHtml(row.join(" ")));
            });
        }
        return parts.join(" ");
    };
    const publishTokensFor = (source) => {
        const blocks = Array.isArray(source && source.blocks) ? source.blocks : [];
        const text = [source && source.title, source && source.subtitle, ...blocks.map(blockPublishText)]
            .join(" ")
            .toLowerCase();
        return text.split(/[^a-z0-9]+/).filter(Boolean);
    };
    const tokenCounts = (tokens) => tokens.reduce((counts, token) => {
        counts[token] = (counts[token] || 0) + 1;
        return counts;
    }, {});
    const publishChangesForPage = (sourcePage) => {
        const currentTokens = publishTokensFor(sourcePage || {});
        const publishedSnapshot = sourcePage && sourcePage.publishedSnapshot ? sourcePage.publishedSnapshot : null;
        if (!publishedSnapshot) {
            return { added: currentTokens.length, removed: 0, status: currentTokens.length ? "unpublished" : "empty" };
        }

        const currentCounts = tokenCounts(currentTokens);
        const publishedCounts = tokenCounts(publishTokensFor(publishedSnapshot));
        let added = 0;
        let removed = 0;
        Object.keys(currentCounts).forEach((token) => { added += Math.max(0, currentCounts[token] - (publishedCounts[token] || 0)); });
        Object.keys(publishedCounts).forEach((token) => { removed += Math.max(0, publishedCounts[token] - (currentCounts[token] || 0)); });
        return { added, removed, status: added || removed ? "changed" : "unchanged" };
    };
    const publishChanges = publishChangesForPage(page);
    const publishChangesLabel = publishChanges.status === "unchanged"
        ? "No draft changes"
        : `+${Number(publishChanges.added || 0).toLocaleString()} / -${Number(publishChanges.removed || 0).toLocaleString()}`;
    const publishMessagePlaceholder = publishChanges.status === "unpublished"
        ? "Initial published draft"
        : (publishChanges.status === "unchanged" ? "No draft changes since the last release" : "Summarize what changed in this release");
        const pageCollaboratorsForTopbar = (Array.isArray(page?.collaborators) && page.collaborators.length
                ? page.collaborators
                : [page?.author].filter(Boolean)
        ).slice(0, 4);
JS;

        $topbarAvatarsReplacement = <<<'JS'
                <div className="avatars" style={{ marginLeft: 4, marginRight: 4 }}>
                    {pageCollaboratorsForTopbar.map((collaborator, index) => (
                        <div
                            key={`${collaborator.initials || "U"}-${index}`}
                            className="avatar"
                            title={collaborator.name || collaborator.initials || "Collaborator"}
                            style={{ background: collaborator.color || "oklch(55% 0.14 255)" }}
                        >
                            {collaborator.initials || "U"}
                        </div>
                    ))}
                </div>
JS;

        $aiSlashSpecReplacement = <<<'JS'
const BLOCK_SPECS = [
    { kind: "ai-writer", group: "AI", title: "AI Writer", desc: "Generate content at this position", icon: "bolt", kbd: "/ai", make: () => null },
JS;

        $slashMenuRefsReplacement = <<<'JS'
    const inputRef = React.useRef(null);
    const menuRef = React.useRef(null);

    React.useEffect(() => { inputRef.current?.focus(); }, []);

    React.useEffect(() => {
        if (!position) return;

        const onDocMouseDown = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                onClose();
            }
        };

        document.addEventListener("mousedown", onDocMouseDown);
        return () => document.removeEventListener("mousedown", onDocMouseDown);
    }, [position, onClose]);
JS;

        $pickBlockReplacement = <<<'JS'
    const onPickBlock = (spec) => {
        if (!slash) return;

        if (spec.kind === "ai-writer") {
            const anchorId = slash.blockId;
            setSlash(null);

            if (onAiGenerateContent) {
                onAiGenerateContent(anchorId);
            } else {
                setToast && setToast("AI writer is unavailable");
                setTimeout(() => setToast && setToast(null), 1800);
            }

            return;
        }

        const newBlock = spec.make();
        if (slash.below) addAfter(slash.blockId, newBlock);
        else replaceBlock(slash.blockId, newBlock);
        setSlash(null);
    };
JS;

        $slashPatterns = [
            '/const BLOCK_SPECS = \[/' => $aiSlashSpecReplacement,
            '/  const inputRef = React\.useRef\(null\);\R\R  React\.useEffect\(\(\) => \{ inputRef\.current\?\.focus\(\); \}, \[\]\);/' => $slashMenuRefsReplacement,
            '/    <div className="slash-menu" style=\{\{ left: position\.x, top: position\.y \+ 6 \}\}>/' => '    <div ref={menuRef} className="slash-menu" style={{ left: position.x, top: position.y + 6 }}>',
            '/            flatIdx\+\+;\R            const focused = flatIdx === focus;/' => "            flatIdx++;\n            const itemIndex = flatIdx;\n            const focused = itemIndex === focus;",
            '/                onMouseEnter=\{\(\) => setFocus\(flatIdx\)\}/' => '                onMouseEnter={() => setFocus(itemIndex)}',
            '/  const onPickBlock = \(spec\) => \{\R    if \(!slash\) return;\R    const newBlock = spec\.make\(\);\R    if \(slash\.below\) addAfter\(slash\.blockId, newBlock\);\R    else replaceBlock\(slash\.blockId, newBlock\);\R    setSlash\(null\);\R  \};/' => $pickBlockReplacement,
        ];

        foreach ($slashPatterns as $pattern => $replacement) {
            $bundle = preg_replace($pattern, $replacement, $bundle, 1, $slashPatternCount);

            if (! is_string($bundle) || $slashPatternCount !== 1) {
                return $originalBundle;
            }
        }

        $replacements = [
            [
                '  const [publishing, setPublishing] = useState(false);',
                "  const [publishing, setPublishing] = useState(false);\n  const [aiModal, setAiModal] = useState({ open: false, mode: \"full-page\", intent: \"generate\", selectionIds: [], insertAfterBlockId: null, blockId: null, selectedText: \"\", range: null });\n  const [aiPrompt, setAiPrompt] = useState(\"\");\n  const [aiWriting, setAiWriting] = useState(false);",
            ],
            [
                '  // Page tree operations',
                $aiHelpers."\n\n  // Page tree operations",
            ],
            [
                'const SelectionBar = ({ count, onDuplicate, onDelete, onCopy, onClear, position = null }) => (',
                'const SelectionBar = ({ count, onDuplicate, onDelete, onCopy, onClear, position = null, onAiWrite, onAiExpand, aiWriting }) => (',
            ],
            [
                'const InlineToolbar = ({ position, onClose, onComment, savedRange, setSavedRange }) => {',
                'const InlineToolbar = ({ position, onClose, onComment, savedRange, setSavedRange, onAiRewrite, aiWriting }) => {',
            ],
            [
                '<button className="itb-btn" title="Comment" onClick={onComment}><Icon name="comment" size={13} /></button>',
                '<button className="itb-btn" title="AI rewrite" onClick={() => { saveRange(); const sel = window.getSelection(); const range = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : savedRange; const selectedText = sel?.toString?.() || range?.toString?.() || ""; if (onAiRewrite) onAiRewrite({ selectedText, range }); }} disabled={aiWriting}><Icon name="bolt" size={13} /></button>'."\n".'          <button className="itb-btn" title="Comment" onClick={onComment}><Icon name="comment" size={13} /></button>',
            ],
            [
                '    <button onClick={onDuplicate}><Icon name="duplicate" size={12} /> Duplicate</button>',
                '    <button onClick={onAiWrite} disabled={aiWriting}><Icon name="bolt" size={12} /> {aiWriting ? "Writing..." : "AI write"}</button>'."\n".'    <button onClick={onAiExpand} disabled={aiWriting}><Icon name="paintbrush" size={12} /> AI expand</button>'."\n".'    <button onClick={onDuplicate}><Icon name="duplicate" size={12} /> Duplicate</button>',
            ],
            [
                '  toast, setToast,',
                "  toast, setToast,\n  onAiWriteTitle,\n  onAiWriteDescription,\n  onAiWriteSelection,\n  onAiExpandSelection,\n  onAiGenerateContent,\n  onAiRewriteText,\n  aiWriting,",
            ],
            [
                '  // Keyboard shortcuts for selection / paste',
                "  const requestAiSelection = () => {\n    if (onAiWriteSelection) onAiWriteSelection(selectedBlocks);\n  };\n\n  const requestAiExpandSelection = () => {\n    if (onAiExpandSelection) onAiExpandSelection(selectedBlocks);\n  };\n\n  const requestAiTextRewrite = ({ selectedText, range }) => {\n    const text = String(selectedText || \"\").trim();\n    if (!text || !selection?.blockId) {\n      setToast && setToast(\"Select text first\");\n      setTimeout(() => setToast && setToast(null), 1600);\n      return;\n    }\n    if (range) setSavedRange(range);\n    if (onAiRewriteText) onAiRewriteText({ blockId: selection.blockId, selectedText: text, range });\n    setSelection(null);\n  };\n\n  // Keyboard shortcuts for selection / paste",
            ],
            [
                '          onCopy={copySelected}',
                "          onCopy={copySelected}\n          onAiWrite={requestAiSelection}\n          onAiExpand={requestAiExpandSelection}\n          aiWriting={aiWriting}",
            ],
            [
                '<span style={{ opacity: 0.6 }}>Click to add a block, or press <kbd style={{ fontFamily: "var(--font-mono)", fontSize: 11, border: "1px solid var(--border)", padding: "1px 4px", borderRadius: 3 }}>/</kbd> anywhere</span>',
                '<button className="btn" type="button" onClick={(event) => { event.stopPropagation(); const last = page.blocks[page.blocks.length - 1]; if (last && onAiGenerateContent) onAiGenerateContent(last.id); }} disabled={aiWriting} style={{ marginRight: 10 }}><Icon name="bolt" size={12} /> {aiWriting ? "Writing..." : "AI content"}</button>'."\n".'          <span style={{ opacity: 0.6 }}>Click to add a block, or press <kbd style={{ fontFamily: "var(--font-mono)", fontSize: 11, border: "1px solid var(--border)", padding: "1px 4px", borderRadius: 3 }}>/</kbd> anywhere</span>',
            ],
            [
                '        setSavedRange={setSavedRange}',
                "        setSavedRange={setSavedRange}\n        onAiRewrite={requestAiTextRewrite}\n        aiWriting={aiWriting}",
            ],
            [
                'const TopBar = ({ page, spaceName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks }) => {',
                'const TopBar = ({ page, spaceName, siteName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks, onPreviewSite, previewUrl, publishedUrl, publishVersion, onOpenAiWriter, aiWriting }) => {',
            ],
            [
                '<span className="brand-name">Lexicon</span>',
                '<span className="brand-name">{siteName || "Product Docs"}</span>',
            ],
            [
                '  const [publishOpen, setPublishOpen] = React.useState(false);',
                $publishStateReplacement,
            ],
            [
                '        <div className="avatars" style={{ marginLeft: 4, marginRight: 4 }}>',
                '        <button className="tb-btn" onClick={onOpenAiWriter} title="AI writer" disabled={aiWriting}><Icon name="bolt" size={14} /> {aiWriting ? "Writing..." : "AI Writer"}</button>'."\n\n".'        <div className="avatars" style={{ marginLeft: 4, marginRight: 4 }}>',
            ],
            [
                'window.TopBar = TopBar;',
                $aiModalComponent."\n\nwindow.TopBar = TopBar;",
            ],
            [
                '    { id: "new-page", title: "New page", desc: "Create an untitled page", icon: "plus", kbd: "N" },',
                '    { id: "new-page", title: "New page", desc: "Create an untitled page", icon: "plus", kbd: "N" },'."\n".'    { id: "ai-writer", title: "AI writer", desc: "Generate a full page draft", icon: "bolt" },',
            ],
            [
                '    if (id === "new-page") persistAddPage(null);',
                '    if (id === "new-page") persistAddPage(null);'."\n".'    if (id === "ai-writer") openAiWriterModal("full-page");',
            ],
            [
                '        onToggleTweaks={() => setTweaksOpen((o) => !o)}',
                '        onToggleTweaks={() => setTweaksOpen((o) => !o)}'."\n".'        siteName={siteBootstrap().name || "Product Docs"}'."\n".'        onPreviewSite={openPreviewSite}'."\n".'        previewUrl={previewSiteUrl()}'."\n".'        publishedUrl={publishedSiteUrl()}'."\n".'        publishVersion={publishVersionLabel()}'."\n".'        onOpenAiWriter={() => openAiWriterModal("full-page")}'."\n".'        aiWriting={aiWriting}',
            ],
            [
                '          setToast={setToast}',
                '          setToast={setToast}'."\n".'          onAiWriteTitle={(intent) => openAiWriterModal("title", { intent })}'."\n".'          onAiWriteDescription={(intent) => openAiWriterModal("description", { intent })}'."\n".'          onAiWriteSelection={(blockIds) => openAiWriterModal("selection", { selectionIds: blockIds, intent: "rewrite" })}'."\n".'          onAiExpandSelection={(blockIds) => openAiWriterModal("content", { selectionIds: blockIds, intent: "expand" })}'."\n".'          onAiGenerateContent={(blockId) => openAiWriterModal("content", { insertAfterBlockId: blockId, intent: "generate" })}'."\n".'          onAiRewriteText={(target) => openAiWriterModal("text", { ...target, intent: "rewrite" })}'."\n".'          aiWriting={aiWriting}',
            ],
            [
                '      {tweaksOpen && (',
                '      <AiWriterModal'."\n".'        open={aiModal.open}'."\n".'        mode={aiModal.mode}'."\n".'        intent={aiModal.intent}'."\n".'        prompt={aiPrompt}'."\n".'        setPrompt={setAiPrompt}'."\n".'        onClose={closeAiWriterModal}'."\n".'        onSubmit={submitAiWriter}'."\n".'        busy={aiWriting}'."\n".'        selectedCount={aiModal.selectionIds.length}'."\n".'      />'."\n\n".'      {tweaksOpen && (',
            ],
        ];

        foreach ($replacements as [$search, $replace]) {
            $bundle = str_replace($search, $replace, $bundle, $count);

            if (! is_string($bundle) || $count !== 1) {
                return $originalBundle;
            }
        }

        $bundle = preg_replace(
            '/        <div className="avatars" style=\{\{ marginLeft: 4, marginRight: 4 \}\}>\R          <div className="avatar" style=\{\{ background: "oklch\(60% 0\.14 30\)" \}\}>MO<\/div>\R          <div className="avatar" style=\{\{ background: "oklch\(55% 0\.14 220\)" \}\}>JK<\/div>\R          <div className="avatar" style=\{\{ background: "oklch\(55% 0\.14 155\)" \}\}>RH<\/div>\R        <\/div>/',
            $topbarAvatarsReplacement,
            $bundle,
            1,
            $topbarAvatarsCount,
        );
        if (! is_string($bundle) || $topbarAvatarsCount !== 1) {
            return $originalBundle;
        }

        $publishPatterns = [
            '/<div className="row"><span>Space<\/span><span className="val">handbook<\/span><\/div>\R              <div className="row"><span>URL<\/span><span className="val">lexicon\.page\/handbook\/quickstart<\/span><\/div>\R              <div className="row"><span>Version<\/span><span className="val">v 1\.4\.2<\/span><\/div>\R              <div className="row"><span>Changes<\/span><span className="val">[^<]*<\/span><\/div>/' => $publishRowsReplacement,
            '/<textarea\R                placeholder="Clarified publish pipeline section"/' => $publishTextareaReplacement,
            '/<button className="primary" onClick=\{\(\) => \{ setPublishOpen\(false\); onPublish\(\); \}\}>\R                Publish to production\R              <\/button>\R              <button style=\{\{ width: "100%", marginTop: 6, padding: 8, fontSize: 12, color: "var\(--text-muted\)" \}\}>\R                Publish to staging\R              <\/button>/' => $publishButtonsReplacement,
        ];

        foreach ($publishPatterns as $pattern => $replacement) {
            $bundle = preg_replace_callback($pattern, fn () => $replacement, $bundle, 1, $publishModalCount);

            if (! is_string($bundle) || $publishModalCount !== 1) {
                return $originalBundle;
            }
        }

        $bundle = preg_replace(
            '/(        <Editable\R          tag="h1"\R          className="doc-title"\R          html=\{page\.title\}\R          placeholder="Untitled"\R          onChange=\{\(h\) => onUpdate\(\{ \.\.\.page, title: h \}\)\}\R        \/>)/',
            '$1'."\n".$heroTitleInsert,
            $bundle,
            1,
            $heroTitleCount,
        );

        if (! is_string($bundle) || $heroTitleCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace(
            '/(        <Editable\R          tag="p"\R          className="doc-subtitle"\R          html=\{page\.subtitle\}\R          placeholder="[^"]*"\R          onChange=\{\(h\) => onUpdate\(\{ \.\.\.page, subtitle: h \}\)\}\R        \/>)/',
            '$1'."\n".$heroSubtitleInsert,
            $bundle,
            1,
            $heroSubtitleCount,
        );

        if (! is_string($bundle) || $heroSubtitleCount !== 1) {
            return $originalBundle;
        }

        return $bundle;
    }

    private function rewriteBundleExportBridge(string $bundle): string
    {
        $originalBundle = $bundle;

        $exportHelpers = <<<'JS'

    const exportUrlForFormat = (format) => {
        const config = getEditorConfig();
        const dbPageId = extractDbPageId(activePageId);

        if (!config || !dbPageId || typeof config.exportPageUrlTemplate !== "string") return null;

        return config.exportPageUrlTemplate
            .replace("__PAGE__", String(dbPageId))
            .replace("__FORMAT__", encodeURIComponent(String(format || "markdown")));
    };

    const onExportPage = (format) => {
        const labels = { markdown: "Markdown", md: "Markdown", pdf: "PDF", html: "HTML", json: "JSON" };
        const label = labels[String(format || "").toLowerCase()] || String(format || "file").toUpperCase();
        const url = exportUrlForFormat(format);

        if (!url) {
            setToast("Save the page before exporting");
            setTimeout(() => setToast(null), 2200);
            return;
        }

        const startDownload = () => {
            const link = document.createElement("a");
            link.href = url;
            link.rel = "noopener";
            link.target = "_blank";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            setToast(`Exporting ${label}`);
            setTimeout(() => setToast(null), 2200);
        };

        if (autosaveRequestRef.current) {
            setToast("Saving before export...");
            autosaveRequestRef.current.finally(startDownload);
            return;
        }

        startDownload();
    };
JS;

        $bundle = preg_replace(
            '/    const onOpenSettings = \(\) => \{\R        window\.location\.assign\(settingsSiteUrl\(\)\);\R    \};/',
            '$0'.$exportHelpers,
            $bundle,
            1,
            $exportHelpersCount,
        );
        if (! is_string($bundle) || $exportHelpersCount !== 1) {
            return $originalBundle;
        }

        $replacements = [
            [
                'const TopBar = ({ page, spaceName, siteName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks, onPreviewSite, previewUrl, publishedUrl, publishVersion, onOpenAiWriter, aiWriting }) => {',
                'const TopBar = ({ page, spaceName, siteName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks, onPreviewSite, previewUrl, publishedUrl, publishVersion, onOpenAiWriter, aiWriting, onExportPage = () => {} }) => {',
            ],
            [
                '<button className="primary" onClick={() => { setPublishOpen(false); onPublish({ environment: "production", message: publishMessage }); }}>'."\n".'                                Publish to production'."\n".'                            </button>',
                '<button className="primary" onClick={() => { setPublishOpen(false); onPublish({ environment: "production", message: publishMessage }); }}>'."\n".'                                Publish to production'."\n".'                            </button>'."\n".'                            <div className="export-actions" aria-label="Export page">'."\n".'                                <div className="export-label">Export page</div>'."\n".'                                <div className="export-grid">'."\n".'                                    <button type="button" onClick={() => onExportPage("markdown")}><Icon name="copy" size={12} /> Markdown</button>'."\n".'                                    <button type="button" onClick={() => onExportPage("pdf")}><Icon name="external" size={12} /> PDF</button>'."\n".'                                    <button type="button" onClick={() => onExportPage("html")}><Icon name="code" size={12} /> HTML</button>'."\n".'                                    <button type="button" onClick={() => onExportPage("json")}><Icon name="api" size={12} /> JSON</button>'."\n".'                                </div>'."\n".'                            </div>',
            ],
            [
                '    { id: "share", title: "Share page", desc: "Copy public link", icon: "link" },',
                '    { id: "share", title: "Share page", desc: "Copy public link", icon: "link" },'."\n".'    { id: "export-markdown", title: "Export Markdown", desc: "Download this page as .md", icon: "copy" },'."\n".'    { id: "export-pdf", title: "Export PDF", desc: "Download this page as .pdf", icon: "external" },'."\n".'    { id: "export-html", title: "Export HTML", desc: "Download this page as .html", icon: "code" },'."\n".'    { id: "export-json", title: "Export JSON", desc: "Download this page as .json", icon: "api" },',
            ],
            [
                '    if (id === "share") onShareSite();',
                '    if (id === "share") onShareSite();'."\n".'    if (id === "export-markdown") onExportPage("markdown");'."\n".'    if (id === "export-pdf") onExportPage("pdf");'."\n".'    if (id === "export-html") onExportPage("html");'."\n".'    if (id === "export-json") onExportPage("json");',
            ],
            [
                '        onOpenAiWriter={() => openAiWriterModal("full-page")}'."\n".'        aiWriting={aiWriting}',
                '        onOpenAiWriter={() => openAiWriterModal("full-page")}'."\n".'        aiWriting={aiWriting}'."\n".'        onExportPage={onExportPage}',
            ],
        ];

        foreach ($replacements as [$search, $replace]) {
            $bundle = str_replace($search, $replace, $bundle, $count);

            if (! is_string($bundle) || $count !== 1) {
                return $originalBundle;
            }
        }

        return $bundle;
    }

    private function rewriteBundleMobileEditorUX(string $bundle): string
    {
        $originalBundle = $bundle;

        $mobileToggleMarkup = <<<'JS'
        <div className="tb-mobile-panels" aria-label="Mobile panel toggles">
          <button
            type="button"
            className={`tb-btn tb-mobile-toggle ${!sidebarCollapsed ? "active" : ""}`}
            onClick={onToggleSidebar}
            title={sidebarCollapsed ? "Open navigation panel" : "Close navigation panel"}
            aria-label="Toggle navigation panel"
            aria-pressed={!sidebarCollapsed}
          >
            <Icon name="menu" size={14} />
          </button>
          <button
            type="button"
            className={`tb-btn tb-mobile-toggle ${rightPanelVisible ? "active" : ""}`}
            onClick={onTogglePanel}
            title={rightPanelVisible ? "Close details panel" : "Open details panel"}
            aria-label="Toggle details panel"
            aria-pressed={rightPanelVisible}
          >
            <Icon name="panel" size={14} />
          </button>
        </div>
JS;

        $mobileHelpers = <<<'JS'

    const toggleSidebar = () => {
        const nextCollapsed = !sidebarCollapsed;

        if (mobileViewport && !nextCollapsed && tweaks.rightPanel) {
            applyTweak({ rightPanel: false });
        }

        setSidebarCollapsed(nextCollapsed);
    };

    const toggleRightPanel = () => {
        const nextVisible = !tweaks.rightPanel;

        if (mobileViewport && nextVisible && !sidebarCollapsed) {
            setSidebarCollapsed(true);
        }

        applyTweak({ rightPanel: nextVisible });
    };

    const closeMobilePanels = () => {
        if (sidebarCollapsed && !tweaks.rightPanel) return;

        setSidebarCollapsed(true);

        if (tweaks.rightPanel) {
            applyTweak({ rightPanel: false });
        }
    };
JS;

        $arrowScrollEffect = <<<'JS'

    React.useEffect(() => {
        const onArrowScroll = (event) => {
            if (event.defaultPrevented || !["ArrowDown", "ArrowUp"].includes(event.key)) return;

            const target = event.target;
            const tagName = target?.tagName;
            const inEditorSurface = target === document.body
                || target === document.documentElement
                || !!target?.closest?.(".editor-wrap");

            if (!inEditorSurface) return;

            const editingText = tagName === "INPUT"
                || tagName === "TEXTAREA"
                || !!target?.isContentEditable
                || !!target?.closest?.("[contenteditable=\"true\"], .slash-menu, .palette, .space-menu, .publish-menu, .lx-modal, .selection-bar");

            if (editingText) return;

            const wrap = document.querySelector(".editor-wrap");
            if (!wrap) return;

            event.preventDefault();
            wrap.scrollTop += event.key === "ArrowDown" ? 64 : -64;
        };

        window.addEventListener("keydown", onArrowScroll);
        return () => window.removeEventListener("keydown", onArrowScroll);
    }, []);
JS;

        $bundle = str_replace(
            'const TopBar = ({ page, spaceName, siteName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks, onPreviewSite, previewUrl, publishedUrl, publishVersion, onOpenAiWriter, aiWriting, onExportPage = () => {} }) => {',
            'const TopBar = ({ page, spaceName, siteName, onToggleSidebar, onOpenPalette, onTogglePanel, theme, onToggleTheme, onPublish, publishing, onToggleTweaks, onPreviewSite, previewUrl, publishedUrl, publishVersion, onOpenAiWriter, aiWriting, onExportPage = () => {}, sidebarCollapsed = false, rightPanelVisible = true }) => {',
            $bundle,
            $topBarSignatureCount,
        );
        if (! is_string($bundle) || $topBarSignatureCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        <button className="tb-search" onClick={onOpenPalette}>',
            '        <button className="tb-search" onClick={onOpenPalette} aria-label="Open search" title="Open search">',
            $bundle,
            $searchButtonCount,
        );
        if (! is_string($bundle) || $searchButtonCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        <button className="tb-btn" onClick={onOpenAiWriter} title="AI writer" disabled={aiWriting}><Icon name="bolt" size={14} /> {aiWriting ? "Writing..." : "AI Writer"}</button>',
            '        <button className="tb-btn tb-ai-trigger" onClick={onOpenAiWriter} title="AI writer" aria-label="Open AI writer" disabled={aiWriting}><Icon name="bolt" size={14} /> {aiWriting ? "Writing..." : "AI Writer"}</button>',
            $bundle,
            $aiButtonCount,
        );
        if (! is_string($bundle) || $aiButtonCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '      <div className="topbar-right">',
            '      <div className="topbar-right">'."\n".$mobileToggleMarkup,
            $bundle,
            $mobileToggleCount,
        );
        if (! is_string($bundle) || $mobileToggleCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        <button className="tb-btn" onClick={onTogglePanel} title="Toggle side panel">'."\n".'          <Icon name="panel" size={14} />'."\n".'        </button>',
            '        <button className="tb-btn tb-desktop-panel-toggle" onClick={onTogglePanel} title="Toggle right sidebar" aria-label="Toggle right sidebar">'."\n".'          <Icon name="panel" size={14} />'."\n".'        </button>',
            $bundle,
            $desktopToggleCount,
        );
        if (! is_string($bundle) || $desktopToggleCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '          const inContent = !!target?.closest?.(".blk-content");',
            '          const inContent = !!target?.closest?.(".blk-content");'."\n".'          const activeEditable = target?.closest?.(".blk-content");'."\n\n".'          if (!inFormField && inContent && e.ctrlKey && e.shiftKey) {'."\n".'            e.preventDefault();'."\n".'            if (typeof document.execCommand === "function") {'."\n".'              document.execCommand("insertLineBreak");'."\n".'            } else {'."\n".'              const selection = window.getSelection();'."\n".'              if (selection && selection.rangeCount) {'."\n".'                const range = selection.getRangeAt(0);'."\n".'                range.deleteContents();'."\n".'                const br = document.createElement("br");'."\n".'                range.insertNode(br);'."\n".'                range.setStartAfter(br);'."\n".'                range.collapse(true);'."\n".'                selection.removeAllRanges();'."\n".'                selection.addRange(range);'."\n".'              }'."\n".'            }'."\n".'            if (activeEditable) {'."\n".'              activeEditable.dispatchEvent(new Event("input", { bubbles: true }));'."\n".'            }'."\n".'            return;'."\n".'          }',
            $bundle,
            $lineBreakInsertCount,
        );
        if (! is_string($bundle) || $lineBreakInsertCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '          if (!inFormField && inContent && !e.shiftKey) {',
            '          if (!inFormField && inContent && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {',
            $bundle,
            $enterConditionCount,
        );
        if (! is_string($bundle) || $enterConditionCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '<div className="editor-wrap" ref={wrapRef}',
            '<div className="editor-wrap" ref={wrapRef} tabIndex={0}',
            $bundle,
            $editorWrapFocusCount,
        );
        if (! is_string($bundle) || $editorWrapFocusCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '<div className="editor-wrap" ref={wrapRef} tabIndex={0}'."\n".'      onMouseDown={(e) => {',
            '<div className="editor-wrap" ref={wrapRef} tabIndex={0}'."\n".'      onKeyDown={(e) => {'."\n".'        if (!["ArrowDown", "ArrowUp"].includes(e.key)) return;'."\n".'        const target = e.target;'."\n".'        const tagName = target?.tagName;'."\n".'        const editingText = tagName === "INPUT"'."\n".'          || tagName === "TEXTAREA"'."\n".'          || !!target?.isContentEditable'."\n".'          || !!target?.closest?.("[contenteditable=\"true\"], .selection-bar, .slash-menu, .palette, .space-menu, .publish-menu, .lx-modal");'."\n".'        if (editingText) return;'."\n".'        e.preventDefault();'."\n".'        e.currentTarget.scrollTop += e.key === "ArrowDown" ? 64 : -64;'."\n".'      }}'."\n".'      onMouseDown={(e) => {',
            $bundle,
            $editorWrapArrowCount,
        );
        if (! is_string($bundle) || $editorWrapArrowCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        if (e.target.classList?.contains("editor-wrap") || e.target.classList?.contains("editor-body") || e.target.classList?.contains("editor-hero")) {'."\n".'          if (selectedBlocks.length) setSelectedBlocks([]);'."\n".'        }',
            '        const interactiveTarget = e.target.closest?.("button, a, input, textarea, [contenteditable=\"true\"], .selection-bar, .slash-menu");'."\n".'        if (!interactiveTarget) {'."\n".'          e.currentTarget.focus();'."\n".'        }'."\n".'        if (e.target.classList?.contains("editor-wrap") || e.target.classList?.contains("editor-body") || e.target.classList?.contains("editor-hero")) {'."\n".'          if (selectedBlocks.length) setSelectedBlocks([]);'."\n".'        }',
            $bundle,
            $editorWrapMouseDownCount,
        );
        if (! is_string($bundle) || $editorWrapMouseDownCount !== 1) {
            return $originalBundle;
        }

        $bundle = preg_replace(
            '/    \}, \[activePageId, page\.blocks\]\);\R\R    const resolveInsertAnchorId = \(\) => \{/s',
            '    }, [activePageId, page.blocks]);'.$arrowScrollEffect."\n\n".'    const resolveInsertAnchorId = () => {',
            $bundle,
            1,
            $arrowScrollCount,
        );
        if (! is_string($bundle) || $arrowScrollCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '    window.__editorInsertAsset = insertAssetIntoPage;',
            '    window.__editorInsertAsset = insertAssetIntoPage;'.$mobileHelpers,
            $bundle,
            $mobileHelpersCount,
        );
        if (! is_string($bundle) || $mobileHelpersCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        onToggleSidebar={() => setSidebarCollapsed((c) => !c)}',
            '        onToggleSidebar={toggleSidebar}',
            $bundle,
            $toggleSidebarCount,
        );
        if (! is_string($bundle) || $toggleSidebarCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        onTogglePanel={() => applyTweak({ rightPanel: !tweaks.rightPanel })}',
            '        onTogglePanel={toggleRightPanel}',
            $bundle,
            $togglePanelCount,
        );
        if (! is_string($bundle) || $togglePanelCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '        onExportPage={onExportPage}',
            '        onExportPage={onExportPage}'."\n".'        sidebarCollapsed={sidebarCollapsed}'."\n".'        rightPanelVisible={tweaks.rightPanel}',
            $bundle,
            $topBarPropsCount,
        );
        if (! is_string($bundle) || $topBarPropsCount !== 1) {
            return $originalBundle;
        }

        $bundle = str_replace(
            '      <div className="workspace">',
            '      {mobileViewport && (!sidebarCollapsed || tweaks.rightPanel) && ('."\n".'        <button type="button" className="mobile-panel-backdrop" aria-label="Close open mobile panels" onClick={closeMobilePanels} />'."\n".'      )}'."\n\n".'      <div className="workspace">',
            $bundle,
            $backdropCount,
        );
        if (! is_string($bundle) || $backdropCount !== 1) {
            return $originalBundle;
        }

        return $bundle;
    }

    /**
     * @return array<string, string>
     */
    private function prototypeTextNormalizationMap(): array
    {
        return [
            'â€¦' => '...',
            '…' => '...',
            'Â·' => ' - ',
            '·' => ' - ',
            'â€º' => '>',
            '›' => '>',
            'â€”' => '-',
            '—' => '-',
            'â€“' => '-',
            '–' => '-',
            'â†’' => '->',
            '→' => '->',
            'â†µ' => 'Enter',
            '↵' => 'Enter',
            'â†‘â†“' => 'Up/Down',
            '↑↓' => 'Up/Down',
            'âŒ˜K' => 'Ctrl+K',
            '⌘K' => 'Ctrl+K',
            'â‡§âŒ˜P' => 'Shift+Ctrl+P',
            '⇧⌘P' => 'Shift+Ctrl+P',
            'âŒ˜Z' => 'Ctrl+Z',
            '⌘Z' => 'Ctrl+Z',
            'â‡§âŒ˜Z' => 'Shift+Ctrl+Z',
            '⇧⌘Z' => 'Shift+Ctrl+Z',
            'â‡§D' => 'Shift+D',
            '⇧D' => 'Shift+D',
            'Ã—' => 'x',
            '×' => 'x',
            'âœ•' => 'x',
            '✕' => 'x',
            'âœ“' => 'yes',
            '✓' => 'yes',
            'Â§' => 'Sec',
            '§' => 'Sec',
            'â—€' => 'L',
            '◀' => 'L',
            'â–¶' => 'R',
            '▶' => 'R',
            'âˆ’' => '-',
            '−' => '-',
            'âˆ‘' => 'sum',
            '∑' => 'sum',
            'â€¢' => '*',
            '•' => '*',
            'mcÂ²' => 'mc^2',
            'mc²' => 'mc^2',
        ];
    }

    /**
     * @return array<string, string>
     */
    private function editorRuntimeConfig(): array
    {
        return [
            'csrfToken' => csrf_token(),
            'autosavePageUrlTemplate' => Route::has('editor.pages.autosave')
                    ? route('editor.pages.autosave', ['page' => '__PAGE__'], false)
                    : '/editor/api/pages/__PAGE__/autosave',
            'createPageUrlTemplate' => Route::has('editor.sites.pages.store')
                    ? route('editor.sites.pages.store', ['site' => '__SITE__'], false)
                    : '/editor/api/sites/__SITE__/pages',
            'createSpaceUrlTemplate' => Route::has('editor.sites.spaces.store')
                ? route('editor.sites.spaces.store', ['site' => '__SITE__'], false)
                : '/editor/api/sites/__SITE__/spaces',
            'spaceStateUrlTemplate' => Route::has('editor.sites.spaces.state')
                ? route('editor.sites.spaces.state', ['site' => '__SITE__', 'space' => '__SPACE__'], false)
                : '/editor/api/sites/__SITE__/spaces/__SPACE__/state',
            'updatePageUrlTemplate' => Route::has('editor.pages.tree.update')
                    ? route('editor.pages.tree.update', ['page' => '__PAGE__'], false)
                    : '/editor/api/pages/__PAGE__',
            'movePageUrlTemplate' => Route::has('editor.pages.tree.move')
                    ? route('editor.pages.tree.move', ['page' => '__PAGE__'], false)
                    : '/editor/api/pages/__PAGE__/move',
            'deletePageUrlTemplate' => Route::has('editor.pages.destroy')
                    ? route('editor.pages.destroy', ['page' => '__PAGE__'], false)
                    : '/editor/api/pages/__PAGE__',
            'restoreRevisionUrlTemplate' => Route::has('editor.pages.revisions.restore')
                ? route('editor.pages.revisions.restore', ['page' => '__PAGE__', 'revision' => '__REVISION__'], false)
                : '/editor/api/pages/__PAGE__/revisions/__REVISION__/restore',
            'aiWritePageUrlTemplate' => Route::has('editor.pages.ai-write')
                ? route('editor.pages.ai-write', ['page' => '__PAGE__'], false)
                : '/editor/api/pages/__PAGE__/ai-write',
            'exportPageUrlTemplate' => Route::has('editor.pages.export')
                ? route('editor.pages.export', ['page' => '__PAGE__', 'format' => '__FORMAT__'], false)
                : '/editor/api/pages/__PAGE__/export/__FORMAT__',
            'publishSiteUrlTemplate' => Route::has('editor.sites.publish')
                ? route('editor.sites.publish', ['site' => '__SITE__'], false)
                : '/editor/api/sites/__SITE__/publish',
            'previewSiteUrlTemplate' => Route::has('editor.sites.preview')
                ? route('editor.sites.preview', ['site' => '__SITE__'], false)
                : '/preview/sites/__SITE__',
            'publishedSiteUrlTemplate' => Route::has('docs.index')
                ? route('docs.index', ['siteSlug' => '__SITE_SLUG__'], false)
                : '/docs/__SITE_SLUG__',
            'settingsUrlTemplate' => Route::has('dashboard.settings')
                ? route('dashboard.settings', ['site' => '__SITE__'], false)
                : '/dashboard/settings?site=__SITE__',
            'createCommentUrlTemplate' => Route::has('editor.pages.comments.store')
                ? route('editor.pages.comments.store', ['page' => '__PAGE__'], false)
                : '/editor/api/pages/__PAGE__/comments',
            'resolveCommentUrlTemplate' => Route::has('editor.comments.resolve')
                ? route('editor.comments.resolve', ['comment' => '__COMMENT__'], false)
                : '/editor/api/comments/__COMMENT__/resolve',
            'mediaAssetsUrlTemplate' => Route::has('editor.sites.media.index')
                ? route('editor.sites.media.index', ['site' => '__SITE__'], false)
                : '/editor/api/sites/__SITE__/media',
            'uploadMediaUrlTemplate' => Route::has('editor.sites.media.store')
                ? route('editor.sites.media.store', ['site' => '__SITE__'], false)
                : '/editor/api/sites/__SITE__/media',
            'aiWriterModel' => match ((string) config('services.ai_writer.provider', 'openrouter')) {
                'openai' => (string) config('services.openai.model', 'gpt-4o-mini'),
                'textcortex' => (string) config('services.textcortex.model', 'gemini-2-5-flash'),
                default => (string) config('services.openrouter.model', 'poolside/laguna-m.1:free'),
            },
            'aiWriterEnabled' => match ((string) config('services.ai_writer.provider', 'openrouter')) {
                'openai' => filled(config('services.openai.api_key')),
                'textcortex' => filled(config('services.textcortex.api_key')),
                default => filled(config('services.openrouter.api_key')),
            } || (bool) config('services.ai_writer.fake', (bool) config('services.openrouter.fake')),
        ];
    }

    private function encodeJavaScript(mixed $value): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
    }

    private function rewriteBundleCommentPersistence(string $bundle): string
    {
        $originalBundle = $bundle;
        $count = 0;

        // Normalize line endings so str_replace patterns work on both Windows (CRLF) and Unix (LF) sources
        $bundle = str_replace("\r\n", "\n", $bundle);

        // 1. Add callback props to Comments component signature
        $bundle = str_replace(
            'const Comments = ({ comments, setComments }) => {',
            'const Comments = ({ comments, setComments, onCreateComment = null, onResolveComment = null }) => {',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 2. Make resolve() call the persistence callback (optimistic UI already done via setComments)
        $bundle = str_replace(
            '  const resolve = (id) =>
    setComments((cs) => cs.map((c) => c.id === id ? { ...c, resolved: !c.resolved } : c));',
            '  const resolve = (id) => {
    setComments((cs) => cs.map((c) => c.id === id ? { ...c, resolved: !c.resolved } : c));
    if (onResolveComment) onResolveComment(id);
  };',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 3. Make reply() delegate to onCreateComment when available
        $bundle = str_replace(
            '  const reply = () => {
    if (!draft.trim()) return;
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref: "General",
      body: draft, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setDraft("");
  };',
            '  const reply = () => {
    if (!draft.trim()) return;
    const body = draft;
    setDraft("");
    if (onCreateComment) { onCreateComment(body); return; }
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref: "General",
      body, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
  };',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 4. Update already-replaced RightPane signature (from rewriteBundleMediaLibrary) to accept callbacks
        $bundle = str_replace(
            'const RightPane = ({ page, comments, setComments, history, mediaAssets, setMediaAssets, siteName, siteSlug, openTab, setOpenTab, activeHeadingId, onJumpTo }) => {',
            'const RightPane = ({ page, comments, setComments, history, mediaAssets, setMediaAssets, siteName, siteSlug, openTab, setOpenTab, activeHeadingId, onJumpTo, onCreateComment = null, onResolveComment = null }) => {',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 5. Thread callbacks into <Comments /> in the already-replaced RightPane
        $bundle = str_replace(
            '{openTab === "comments" && <Comments comments={comments} setComments={setComments} />}',
            '{openTab === "comments" && <Comments comments={comments} setComments={setComments} onCreateComment={onCreateComment} onResolveComment={onResolveComment} />}',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 6. Replace onAddComment + add persistNewComment / persistResolveComment alongside it
        $bundle = str_replace(
            '  const onAddComment = (blockId, selectedText = "") => {
    const ref = blockId ? `Block ${blockId}` : "Selection in current page";
    const body = selectedText ? `Comment on: "${selectedText}"` : "New comment - reply below.";
    const newC = {
      id: "c" + Date.now(),
      author: "You", initials: "YO", color: "oklch(55% 0.14 255)",
      time: "just now", ref,
      body, replies: [], resolved: false,
    };
    setComments((cs) => [newC, ...cs]);
    setRightTab("comments");
  };',
            '  const persistNewComment = (body, blockId = null, ref = "Page comment") => {
    const tempId = "c" + Date.now();
    const newC = { id: tempId, author: "You", initials: "YO", color: "oklch(55% 0.14 255)", time: "just now", ref, body, replies: [], resolved: false };
    setComments((cs) => [newC, ...cs]);
    const config = getEditorConfig();
    const dbPageId = extractDbPageId(activePageId);
    if (!config || !dbPageId || typeof config.createCommentUrlTemplate !== "string") return;
    requestEditorJson(config.createCommentUrlTemplate.replace("__PAGE__", String(dbPageId)), {
      method: "POST",
      body: JSON.stringify({ body, block_id: blockId }),
    }).then((response) => {
      const saved = response && response.comment ? response.comment : null;
      if (!saved) return;
      setComments((cs) => cs.map((c) => c.id === tempId ? { ...saved } : c));
    }).catch((error) => {
      setComments((cs) => cs.filter((c) => c.id !== tempId));
      console.error(error);
    });
  };

  const persistResolveComment = (id) => {
    const m = String(id).match(/^c(\d+)$/);
    if (!m) return;
    const config = getEditorConfig();
    if (!config || typeof config.resolveCommentUrlTemplate !== "string") return;
    requestEditorJson(config.resolveCommentUrlTemplate.replace("__COMMENT__", m[1]), {
      method: "PATCH",
    }).catch((error) => {
      setComments((cs) => cs.map((c) => c.id === id ? { ...c, resolved: !c.resolved } : c));
      console.error(error);
    });
  };

  const onAddComment = (blockId, selectedText = "") => {
    const ref = blockId ? `Block ${blockId}` : "Selection in current page";
    const body = selectedText ? `Comment on: "${selectedText}"` : "New comment - reply below.";
    persistNewComment(body, blockId, ref);
    setRightTab("comments");
  };',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        // 7. Add comment callbacks to <RightPane> JSX call (after mediaLibrary added mediaAssets/setMediaAssets/siteName/siteSlug)
        $bundle = str_replace(
            '            siteSlug={siteBootstrap().slug || "product-docs"}',
            '            siteSlug={siteBootstrap().slug || "product-docs"}'."\n".'            onCreateComment={persistNewComment}'."\n".'            onResolveComment={persistResolveComment}',
            $bundle,
            $count,
        );
        if ($count !== 1) {
            return $originalBundle;
        }

        return $bundle;
    }
}
