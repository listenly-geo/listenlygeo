<?php

namespace App\Http\Controllers\Editor;

use App\Http\Controllers\Controller;
use App\Models\MediaAsset;
use App\Models\Site;
use App\Actions\Docs\SyncOrganizationUsageCounter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class PrototypeEditorMediaController extends Controller
{
    public function __construct(
        private readonly SyncOrganizationUsageCounter $syncOrganizationUsageCounter,
    ) {}

    public function index(Request $request, Site $site): JsonResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $assets = $site->mediaAssets()
            ->with('uploader:id,name')
            ->latest('id')
            ->get()
            ->map(fn (MediaAsset $asset) => $this->serializeAsset($asset))
            ->values()
            ->all();

        return response()->json(['assets' => $assets]);
    }

    public function store(Request $request, Site $site): JsonResponse
    {
        $site->loadMissing('organization');
        Gate::authorize('update', $site);

        $validated = $request->validate([
            'file' => [
                'required',
                'file',
                'max:10240',
                'mimetypes:image/png,image/jpeg,image/gif,image/webp,image/svg+xml,video/mp4,video/webm,video/ogg,application/pdf,application/zip,application/x-zip-compressed,text/plain',
            ],
        ]);

        /** @var \Illuminate\Http\UploadedFile $file */
        $file = $validated['file'];
        $mimeType = $file->getMimeType() ?: 'application/octet-stream';
        $extension = Str::lower($file->guessExtension() ?: $file->getClientOriginalExtension() ?: 'bin');
        $directory = 'media/org-'.$site->organization_id.'/site-'.$site->id;
        $filename = (string) Str::ulid().'.'.$extension;
        $path = $file->storeAs($directory, $filename, 'public');

        [$width, $height] = $this->imageDimensions($file, $mimeType);

        $asset = MediaAsset::query()->create([
            'organization_id' => $site->organization_id,
            'site_id' => $site->id,
            'disk' => 'public',
            'path' => $path,
            'original_name' => $file->getClientOriginalName() ?: basename((string) $path),
            'mime_type' => $mimeType,
            'size_bytes' => $file->getSize() ?: 0,
            'width' => $width,
            'height' => $height,
            'uploaded_by' => $request->user()->id,
        ]);

        $asset->load('uploader:id,name');

        ($this->syncOrganizationUsageCounter)($site->organization);

        return response()->json(['asset' => $this->serializeAsset($asset)], 201);
    }

    private function serializeAsset(MediaAsset $asset): array
    {
        return [
            'id' => $asset->id,
            'name' => $asset->original_name ?: basename($asset->path),
            'url' => route('media.assets.show', ['asset' => $asset]),
            'mimeType' => $asset->mime_type,
            'sizeBytes' => $asset->size_bytes,
            'width' => $asset->width,
            'height' => $asset->height,
            'uploadedBy' => $asset->uploader?->name,
            'uploadedAt' => $asset->created_at?->toIso8601String(),
            'isImage' => str_starts_with((string) $asset->mime_type, 'image/'),
            'isVideo' => str_starts_with((string) $asset->mime_type, 'video/'),
        ];
    }

    private function imageDimensions(\Illuminate\Http\UploadedFile $file, string $mimeType): array
    {
        if (! str_starts_with($mimeType, 'image/') || $mimeType === 'image/svg+xml') {
            return [null, null];
        }

        try {
            $size = getimagesize($file->getRealPath());

            return $size ? [$size[0], $size[1]] : [null, null];
        } catch (\Throwable) {
            return [null, null];
        }
    }
}
