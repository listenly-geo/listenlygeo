<?php

namespace App\Http\Controllers;

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Models\Organization;
use App\Models\Site;
use App\Models\SiteDomain;
use App\Models\User;
use App\Support\DocsTheme;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class DashboardSettingsController extends Controller
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
    ) {}

    public function __invoke(Request $request): Response
    {
        $organization = $this->resolveOrganization($request->user());
        $this->authorizeOrganizationView($request->user(), $organization);

        $sites = Site::query()
            ->where('organization_id', $organization->id)
            ->with([
                'currentRelease:id,site_id,version,published_at',
                'domains' => fn ($query) => $query->orderByDesc('is_primary')->orderBy('host'),
            ])
            ->withCount(['domains', 'pages'])
            ->orderBy('id')
            ->get();

        $selectedSite = $sites->firstWhere('id', $request->integer('site'))
            ?? $sites->firstOrFail();

        $settings = $selectedSite->settings_json ?? [];

        return Inertia::render('dashboard/settings', [
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
                'billingEmail' => $organization->billing_email,
            ],
            'permissions' => [
                'canManageSettings' => $this->canManageOrganization($request->user(), $organization),
            ],
            'sites' => $sites->map(fn (Site $site) => [
                'id' => $site->id,
                'name' => $site->name,
                'slug' => $site->slug,
                'status' => $site->status,
                'visibility' => $site->visibility,
                'domainsCount' => $site->domains_count,
                'pagesCount' => $site->pages_count,
                'currentReleaseVersion' => $site->currentRelease?->version,
                'isSelected' => $site->id === $selectedSite->id,
            ])->values()->all(),
            'selectedSite' => [
                'id' => $selectedSite->id,
                'name' => $selectedSite->name,
                'slug' => $selectedSite->slug,
                'status' => $selectedSite->status,
                'visibility' => $selectedSite->visibility,
                'docsUrl' => $selectedSite->currentRelease ? '/docs/'.$selectedSite->slug : null,
                'currentReleaseVersion' => $selectedSite->currentRelease?->version,
                'branding' => [
                    'brandName' => Arr::get($settings, 'branding.name', $selectedSite->name),
                    'logoUrl' => Arr::get($settings, 'branding.logo_path')
                        ? Storage::disk('public')->url(Arr::get($settings, 'branding.logo_path'))
                        : null,
                    'tagline' => Arr::get($settings, 'branding.tagline'),
                ],
                'seo' => [
                    'title' => Arr::get($settings, 'seo.title'),
                    'description' => Arr::get($settings, 'seo.description'),
                ],
                'appearance' => [
                    'docsTheme' => DocsTheme::normalize(Arr::get($settings, 'appearance.docs_theme')),
                    'docsThemeOptions' => DocsTheme::optionsPayload(Arr::get($settings, 'appearance.docs_theme_options')),
                ],
                'domains' => $selectedSite->domains->map(fn (SiteDomain $domain) => [
                    'id' => $domain->id,
                    'host' => $domain->host,
                    'isPrimary' => $domain->is_primary,
                    'status' => $domain->status,
                    'dnsTarget' => $domain->dns_target,
                    'verifiedAt' => $domain->verified_at?->toIso8601String(),
                ])->values()->all(),
            ],
        ]);
    }

    public function updateSiteSettings(Request $request, Site $site): RedirectResponse
    {
        $site->loadMissing('organization');
        $this->authorizeOrganizationMutation($request->user(), $site->organization);

        $validated = $request->validate([
            'brandName' => ['required', 'string', 'max:80'],
            'tagline' => ['nullable', 'string', 'max:160'],
            'seoTitle' => ['nullable', 'string', 'max:120'],
            'seoDescription' => ['nullable', 'string', 'max:180'],
            'docsTheme' => ['nullable', 'string', Rule::in(DocsTheme::ids())],
        ]);

        $existing = $site->settings_json ?? [];
        $docsTheme = $validated['docsTheme'] ?? DocsTheme::normalize(Arr::get($existing, 'appearance.docs_theme'));

        $site->forceFill([
            'settings_json' => [
                ...$existing,
                'branding' => [
                    ...(Arr::get($existing, 'branding', [])),
                    'name' => trim((string) $validated['brandName']),
                    'tagline' => $this->nullableTrim($validated['tagline'] ?? null),
                ],
                'seo' => [
                    ...(Arr::get($existing, 'seo', [])),
                    'title' => $this->nullableTrim($validated['seoTitle'] ?? null),
                    'description' => $this->nullableTrim($validated['seoDescription'] ?? null),
                ],
                'appearance' => [
                    ...(Arr::get($existing, 'appearance', [])),
                    'docs_theme' => $docsTheme,
                ],
            ],
            'updated_by' => $request->user()->id,
        ])->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Site settings updated.']);

        return redirect()->route('dashboard.settings', ['site' => $site->id]);
    }

    public function storeDomain(Request $request, Site $site): RedirectResponse
    {
        $site->loadMissing('organization');
        $this->authorizeOrganizationMutation($request->user(), $site->organization);

        $validated = $request->validate([
            'host' => [
                'required',
                'string',
                'max:255',
                'regex:/^(?=.{1,253}$)(?!-)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i',
                Rule::unique('site_domains', 'host'),
            ],
        ]);

        $host = Str::lower(trim((string) $validated['host']));
        $isPrimary = ! $site->domains()->exists();
        $dnsTarget = parse_url((string) config('app.url'), PHP_URL_HOST) ?: 'docs.docthebuilder.test';

        $site->domains()->create([
            'host' => $host,
            'is_primary' => $isPrimary,
            'status' => 'pending',
            'dns_target' => $dnsTarget,
        ]);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Domain added.']);

        return redirect()->route('dashboard.settings', ['site' => $site->id]);
    }

    public function updatePrimaryDomain(Request $request, SiteDomain $domain): RedirectResponse
    {
        $domain->loadMissing('site.organization');
        $this->authorizeOrganizationMutation($request->user(), $domain->site->organization);

        DB::transaction(function () use ($domain) {
            SiteDomain::query()
                ->where('site_id', $domain->site_id)
                ->update(['is_primary' => false]);

            $domain->forceFill([
                'is_primary' => true,
            ])->save();
        });

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Primary domain updated.']);

        return redirect()->route('dashboard.settings', ['site' => $domain->site_id]);
    }

    private function resolveOrganization(User $user): Organization
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user);

        return Organization::query()->findOrFail($bootstrap['organization']['id']);
    }

    private function authorizeOrganizationView(User $user, Organization $organization): void
    {
        abort_unless(
            $organization->memberships()
                ->where('user_id', $user->id)
                ->where('status', 'active')
                ->exists(),
            403,
        );
    }

    private function authorizeOrganizationMutation(User $user, Organization $organization): void
    {
        abort_unless($this->canManageOrganization($user, $organization), 403);
    }

    private function canManageOrganization(User $user, Organization $organization): bool
    {
        return $organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->whereIn('role', ['owner', 'admin'])
            ->exists();
    }

    private function nullableTrim(?string $value): ?string
    {
        $trimmed = trim((string) $value);

        return $trimmed === '' ? null : $trimmed;
    }
}
