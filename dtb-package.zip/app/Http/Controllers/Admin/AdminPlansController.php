<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPlan;
use App\Services\Billing\StripeBillingService;
use Illuminate\Http\Client\RequestException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;
use Throwable;

class AdminPlansController extends Controller
{
    public function __construct(
        private readonly StripeBillingService $stripeBilling,
    ) {}

    public function __invoke(Request $request): Response
    {
        $plans = SubscriptionPlan::query()
            ->withCount('organizationSubscriptions')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->map(fn (SubscriptionPlan $plan) => [
                'id' => $plan->id,
                'slug' => $plan->slug,
                'label' => $plan->label,
                'description' => $plan->description,
                'status' => $plan->status,
                'monthlyPriceCents' => $plan->monthly_price_cents,
                'annualPriceCents' => $plan->annual_price_cents,
                'includedSites' => $plan->included_sites,
                'includedMembers' => $plan->included_members,
                'includedPublishedPages' => $plan->included_published_pages,
                'includedStorageBytes' => $plan->included_storage_bytes,
                'sortOrder' => $plan->sort_order,
                'isFeatured' => $plan->is_featured,
                'stripeProductId' => $plan->stripe_product_id,
                'stripeMonthlyPriceId' => $plan->stripe_monthly_price_id,
                'stripeAnnualPriceId' => $plan->stripe_annual_price_id,
                'stripeSyncedAt' => $plan->stripe_synced_at?->toIso8601String(),
                'subscriberCount' => $plan->organization_subscriptions_count,
                'updatedAt' => $plan->updated_at?->toIso8601String(),
            ])
            ->values()
            ->all();

        return Inertia::render('admin/plans/index', [
            'plans' => $plans,
            'statuses' => [
                ['key' => 'draft', 'label' => 'Draft'],
                ['key' => 'active', 'label' => 'Active'],
                ['key' => 'archived', 'label' => 'Archived'],
            ],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validatePlan($request);

        $plan = SubscriptionPlan::query()->create($validated);

        $syncResult = $this->syncPlanToStripe($plan);

        Inertia::flash('toast', ['type' => $syncResult['type'], 'message' => $syncResult['message']]);

        return redirect()->route('admin.plans');
    }

    public function update(Request $request, SubscriptionPlan $subscriptionPlan): RedirectResponse
    {
        $validated = $this->validatePlan($request, $subscriptionPlan);

        $subscriptionPlan->fill($validated)->save();

        $syncResult = $this->syncPlanToStripe($subscriptionPlan);

        Inertia::flash('toast', ['type' => $syncResult['type'], 'message' => $syncResult['message']]);

        return redirect()->route('admin.plans');
    }

    public function sync(Request $request, SubscriptionPlan $subscriptionPlan): RedirectResponse
    {
        $syncResult = $this->syncPlanToStripe($subscriptionPlan, true);

        Inertia::flash('toast', ['type' => $syncResult['type'], 'message' => $syncResult['message']]);

        return redirect()->route('admin.plans');
    }

    /**
     * @return array<string, mixed>
     */
    private function validatePlan(Request $request, ?SubscriptionPlan $plan = null): array
    {
        return $request->validate([
            'slug' => [
                'required',
                'string',
                'max:80',
                'alpha_dash',
                Rule::unique('subscription_plans', 'slug')->ignore($plan?->id),
            ],
            'label' => ['required', 'string', 'max:120'],
            'description' => ['required', 'string', 'max:500'],
            'status' => ['required', Rule::in(['draft', 'active', 'archived'])],
            'monthly_price_cents' => ['required', 'integer', 'min:0'],
            'annual_price_cents' => ['required', 'integer', 'min:0'],
            'included_sites' => ['required', 'integer', 'min:1'],
            'included_members' => ['required', 'integer', 'min:1'],
            'included_published_pages' => ['required', 'integer', 'min:1'],
            'included_storage_bytes' => ['required', 'integer', 'min:1'],
            'sort_order' => ['required', 'integer', 'min:0'],
            'is_featured' => ['required', 'boolean'],
        ]);
    }

    /**
     * @return array{type: string, message: string}
     */
    private function syncPlanToStripe(SubscriptionPlan $plan, bool $manual = false): array
    {
        if (! $this->stripeBilling->isConfigured()) {
            return [
                'type' => $manual ? 'error' : 'warning',
                'message' => 'Plan saved locally. Add STRIPE_SECRET, then use Sync with Stripe.',
            ];
        }

        try {
            $this->stripeBilling->syncPlan($plan);
        } catch (Throwable $exception) {
            report($exception);

            $stripeMessage = $exception instanceof RequestException
                ? (data_get($exception->response?->json(), 'error.message') ?: $exception->getMessage())
                : $exception->getMessage();

            return [
                'type' => 'error',
                'message' => 'Plan saved, but Stripe sync failed: '.$stripeMessage,
            ];
        }

        return [
            'type' => 'success',
            'message' => 'Plan saved and synced with Stripe.',
        ];
    }
}
