<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Addons\InstallAddon;
use App\Http\Controllers\Controller;
use App\Models\Addon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class AdminAddonsController extends Controller
{
    public function index(): Response
    {
        $addons = Addon::query()
            ->orderBy('name')
            ->get()
            ->map(fn (Addon $addon) => [
                'id' => $addon->id,
                'slug' => $addon->slug,
                'name' => $addon->name,
                'enabled' => $addon->isVerifiedEnabled(),
                'installedAt' => $addon->installed_at?->toIso8601String(),
                'requiredFiles' => $addon->required_files,
            ])
            ->values();

        return Inertia::render('settings/addons', [
            'addons' => $addons,
        ]);
    }

    public function install(Request $request, Addon $addon, InstallAddon $action): RedirectResponse
    {
        $request->validate([
            'zip_file' => ['required', 'file', 'mimes:zip', 'max:51200'], // 50 MB max
        ]);

        try {
            $action->handle($addon, $request->file('zip_file'));
        } catch (\InvalidArgumentException $e) {
            throw ValidationException::withMessages([
                'zip_file' => $e->getMessage(),
            ]);
        } catch (\RuntimeException $e) {
            throw ValidationException::withMessages([
                'zip_file' => 'Failed to process the addon ZIP: '.$e->getMessage(),
            ]);
        }

        return back()->with('success', "\"{$addon->name}\" addon installed successfully.");
    }

    public function uninstall(Addon $addon): RedirectResponse
    {
        $addon->update([
            'enabled' => false,
            'token' => null,
            'installed_at' => null,
        ]);

        return back()->with('success', "\"{$addon->name}\" addon has been disabled.");
    }
}
