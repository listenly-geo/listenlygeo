<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\OrganizationSubscription;
use App\Models\SubscriptionPlan;
use Inertia\Inertia;
use Inertia\Response;

class AdminReportsController extends Controller
{
    public function __invoke(): Response
    {
        $planCatalog = SubscriptionPlan::query()->get()->keyBy('slug');

        $planBreakdown = OrganizationSubscription::query()
            ->get()
            ->groupBy('plan')
            ->map(function ($subscriptions, string $planSlug) use ($planCatalog) {
                $plan = $planCatalog->get($planSlug);

                return [
                    'plan' => $plan?->label ?? str($planSlug)->headline()->toString(),
                    'slug' => $planSlug,
                    'customers' => $subscriptions->count(),
                    'activeCustomers' => $subscriptions->whereIn('status', ['trialing', 'active'])->count(),
                    'pastDueCustomers' => $subscriptions->where('status', 'past_due')->count(),
                ];
            })
            ->values()
            ->all();

        $customerRows = Organization::query()
            ->with(['subscription'])
            ->latest('id')
            ->limit(20)
            ->get()
            ->map(function (Organization $organization) use ($planCatalog) {
                $subscription = $organization->subscription;
                $plan = $planCatalog->get($subscription?->plan);

                return [
                    'name' => $organization->name,
                    'billingEmail' => $organization->billing_email,
                    'plan' => $plan?->label ?? str($subscription?->plan ?? 'free')->headline()->toString(),
                    'status' => $subscription?->status ?? 'active',
                    'createdAt' => $organization->created_at?->toIso8601String(),
                ];
            })
            ->values()
            ->all();

        return Inertia::render('admin/reports/index', [
            'summary' => [
                'customerCount' => Organization::query()->count(),
                'subscriptionCount' => OrganizationSubscription::query()->count(),
                'planCount' => SubscriptionPlan::query()->count(),
            ],
            'planBreakdown' => $planBreakdown,
            'customerRows' => $customerRows,
        ]);
    }
}
