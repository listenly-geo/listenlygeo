<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Inertia\Inertia;
use Inertia\Response;

class AdminUsersController extends Controller
{
    public function __invoke(): Response
    {
        $platformAdmins = User::query()
            ->where('is_platform_admin', true)
            ->withCount('organizationMemberships')
            ->orderBy('name')
            ->get()
            ->map(fn (User $user) => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'membershipCount' => $user->organization_memberships_count,
                'createdAt' => $user->created_at?->toIso8601String(),
            ])
            ->values()
            ->all();

        $recentUsers = User::query()
            ->where('is_platform_admin', false)
            ->withCount('organizationMemberships')
            ->latest('id')
            ->limit(20)
            ->get()
            ->map(fn (User $user) => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'membershipCount' => $user->organization_memberships_count,
                'verifiedAt' => $user->email_verified_at?->toIso8601String(),
                'createdAt' => $user->created_at?->toIso8601String(),
            ])
            ->values()
            ->all();

        return Inertia::render('admin/users/index', [
            'summary' => [
                'platformAdminCount' => count($platformAdmins),
                'customerUserCount' => User::query()->where('is_platform_admin', false)->count(),
                'verifiedUserCount' => User::query()->whereNotNull('email_verified_at')->count(),
            ],
            'platformAdmins' => $platformAdmins,
            'recentUsers' => $recentUsers,
        ]);
    }
}
