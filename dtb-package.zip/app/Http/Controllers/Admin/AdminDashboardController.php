<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\OrganizationSubscription;
use App\Models\Page;
use App\Models\PlatformBillingSetting;
use App\Models\Release;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class AdminDashboardController extends Controller
{
    public function __invoke(Request $request): Response
    {
        $plans = SubscriptionPlan::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->keyBy('slug');

        $subscriptions = OrganizationSubscription::query()->get();
        $activeStatuses = ['trialing', 'active'];

        $monthlyRecurringRevenue = $subscriptions->sum(function (OrganizationSubscription $subscription) use ($plans) {
            if (! in_array($subscription->status, ['trialing', 'active'], true)) {
                return 0;
            }

            $plan = $plans->get($subscription->plan);

            if (! $plan) {
                return 0;
            }

            return $subscription->interval === 'annual'
                ? (int) round($plan->annual_price_cents / 12)
                : (int) $plan->monthly_price_cents;
        });

        $recentOrganizations = Organization::query()
            ->with(['owner:id,name,email', 'subscription'])
            ->latest('id')
            ->limit(6)
            ->get()
            ->map(function (Organization $organization) use ($plans) {
                $plan = $plans->get($organization->subscription?->plan);

                return [
                    'id' => $organization->id,
                    'name' => $organization->name,
                    'slug' => $organization->slug,
                    'ownerName' => $organization->owner?->name,
                    'ownerEmail' => $organization->owner?->email,
                    'billingEmail' => $organization->billing_email,
                    'planLabel' => $plan?->label ?? str($organization->subscription?->plan ?? 'free')->headline()->toString(),
                    'status' => $organization->subscription?->status ?? 'active',
                    'createdAt' => $organization->created_at?->toIso8601String(),
                ];
            })
            ->values()
            ->all();

        $statusBreakdown = collect(['active', 'trialing', 'past_due', 'incomplete', 'canceled'])
            ->map(fn (string $status) => [
                'label' => str($status)->replace('_', ' ')->title()->toString(),
                'value' => $subscriptions->where('status', $status)->count(),
            ])
            ->values()
            ->all();

        $planBreakdown = $plans
            ->map(function (SubscriptionPlan $plan) use ($subscriptions, $activeStatuses) {
                $matching = $subscriptions->where('plan', $plan->slug);
                $activeCount = $matching->whereIn('status', $activeStatuses)->count();
                $mrr = $matching->sum(function (OrganizationSubscription $subscription) use ($plan, $activeStatuses) {
                    if (! in_array($subscription->status, $activeStatuses, true)) {
                        return 0;
                    }

                    return $subscription->interval === 'annual'
                        ? (int) round($plan->annual_price_cents / 12)
                        : (int) $plan->monthly_price_cents;
                });

                return [
                    'slug' => $plan->slug,
                    'label' => $plan->label,
                    'status' => $plan->status,
                    'subscribers' => $activeCount,
                    'monthlyRecurringRevenueCents' => $mrr,
                    'monthlyPriceCents' => (int) $plan->monthly_price_cents,
                    'annualPriceCents' => (int) $plan->annual_price_cents,
                ];
            })
            ->sortByDesc('monthlyRecurringRevenueCents')
            ->values()
            ->all();

        $months = collect(range(5, 0))->map(fn (int $offset) => now()->startOfMonth()->subMonths($offset));

        $customerGrowth = $months->map(function ($month) {
            $start = $month->copy()->startOfMonth();
            $end = $month->copy()->endOfMonth();

            return [
                'label' => $month->format('M'),
                'value' => Organization::query()->whereBetween('created_at', [$start, $end])->count(),
            ];
        })->values()->all();

        $releaseTrend = $months->map(function ($month) {
            $start = $month->copy()->startOfMonth();
            $end = $month->copy()->endOfMonth();

            return [
                'label' => $month->format('M'),
                'value' => Release::query()->whereBetween('published_at', [$start, $end])->count(),
            ];
        })->values()->all();

        $netRevenueTrend = $months->map(function ($month) use ($subscriptions, $plans, $activeStatuses) {
            $start = $month->copy()->startOfMonth();
            $end = $month->copy()->endOfMonth();

            $newRevenueCents = $subscriptions
                ->filter(function (OrganizationSubscription $subscription) use ($start, $end, $activeStatuses) {
                    return $subscription->created_at !== null
                        && $subscription->created_at->betweenIncluded($start, $end)
                        && in_array($subscription->status, $activeStatuses, true);
                })
                ->sum(function (OrganizationSubscription $subscription) use ($plans) {
                    $plan = $plans->get($subscription->plan);

                    if (! $plan) {
                        return 0;
                    }

                    return $subscription->interval === 'annual'
                        ? (int) round($plan->annual_price_cents / 12)
                        : (int) $plan->monthly_price_cents;
                });

            $churnedRevenueCents = $subscriptions
                ->filter(function (OrganizationSubscription $subscription) use ($start, $end) {
                    return $subscription->updated_at !== null
                        && $subscription->updated_at->betweenIncluded($start, $end)
                        && in_array($subscription->status, ['canceled', 'past_due', 'incomplete'], true);
                })
                ->sum(function (OrganizationSubscription $subscription) use ($plans) {
                    $plan = $plans->get($subscription->plan);

                    if (! $plan) {
                        return 0;
                    }

                    return $subscription->interval === 'annual'
                        ? (int) round($plan->annual_price_cents / 12)
                        : (int) $plan->monthly_price_cents;
                });

            return [
                'label' => $month->format('M'),
                'newRevenueCents' => $newRevenueCents,
                'churnedRevenueCents' => $churnedRevenueCents,
                'netRevenueCents' => $newRevenueCents - $churnedRevenueCents,
            ];
        })->values()->all();

        $churnReportTrend = $months->map(function ($month) use ($subscriptions, $activeStatuses) {
            $start = $month->copy()->startOfMonth();
            $end = $month->copy()->endOfMonth();

            $canceled = $subscriptions
                ->filter(function (OrganizationSubscription $subscription) use ($start, $end) {
                    return $subscription->updated_at !== null
                        && $subscription->updated_at->betweenIncluded($start, $end)
                        && $subscription->status === 'canceled';
                })
                ->count();

            $recovered = $subscriptions
                ->filter(function (OrganizationSubscription $subscription) use ($start, $end, $activeStatuses) {
                    return $subscription->updated_at !== null
                        && $subscription->updated_at->betweenIncluded($start, $end)
                        && in_array($subscription->status, $activeStatuses, true)
                        && $subscription->created_at !== null
                        && $subscription->created_at->lt($start);
                })
                ->count();

            return [
                'label' => $month->format('M'),
                'canceled' => $canceled,
                'recovered' => $recovered,
            ];
        })->values()->all();

        $gateway = PlatformBillingSetting::query()->first();

        return Inertia::render('admin/dashboard', [
            'summary' => [
                'planCount' => SubscriptionPlan::query()->count(),
                'activePlanCount' => SubscriptionPlan::query()->where('status', 'active')->count(),
                'customerCount' => Organization::query()->count(),
                'newCustomersLast30Days' => Organization::query()->where('created_at', '>=', now()->subDays(30))->count(),
                'userCount' => User::query()->count(),
                'platformAdminCount' => User::query()->where('is_platform_admin', true)->count(),
                'activeSubscriptionCount' => $subscriptions->whereIn('status', $activeStatuses)->count(),
                'trialingSubscriptionCount' => $subscriptions->where('status', 'trialing')->count(),
                'pastDueCount' => $subscriptions->where('status', 'past_due')->count(),
                'monthlyRecurringRevenueCents' => $monthlyRecurringRevenue,
                'publishedPageCount' => Page::query()->whereNotNull('published_revision_id')->count(),
                'releasesLast30Days' => Release::query()->where('published_at', '>=', now()->subDays(30))->count(),
            ],
            'gateway' => [
                'provider' => $gateway?->provider ?? 'stripe',
                'mode' => $gateway?->mode ?? 'test',
                'status' => $gateway?->status ?? 'setup_required',
            ],
            'subscriptionStatusBreakdown' => $statusBreakdown,
            'planBreakdown' => $planBreakdown,
            'customerGrowth' => $customerGrowth,
            'releaseTrend' => $releaseTrend,
            'netRevenueTrend' => $netRevenueTrend,
            'churnReportTrend' => $churnReportTrend,
            'recentOrganizations' => $recentOrganizations,
        ]);
    }
}
