<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PlatformLandingContent;
use App\Models\PlatformLandingSetting;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class AdminLandingContentController extends Controller
{
    public function index(): Response
    {
        $sections = PlatformLandingContent::query()
            ->orderBy('section')
            ->get()
            ->map(fn ($item) => [
                'id' => $item->id,
                'section' => $item->section,
                'label' => $item->label ?? ucfirst($item->section),
                'kicker' => $item->kicker,
                'title' => $item->title,
                'subtitle' => $item->subtitle,
                'description' => $item->description,
                'data' => $item->data ?? [],
                'is_active' => $item->is_active,
                'updated_at' => $item->updated_at->format('M d, Y H:i'),
            ]);

        return Inertia::render('settings/landing-content', [
            'sections' => $sections,
            'landingSettings' => [
                'copyrightText' => PlatformLandingSetting::query()->first()?->copyright_text ?? '',
                'socialLinks' => PlatformLandingSetting::query()->first()?->social_links ?? [],
            ],
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'section' => 'required|string|unique:platform_landing_contents,section',
            'label' => 'nullable|string',
            'kicker' => 'nullable|string',
            'title' => 'nullable|string',
            'subtitle' => 'nullable|string',
            'description' => 'nullable|string',
            'data' => 'nullable|array',
            'is_active' => 'boolean',
        ]);

        PlatformLandingContent::create($validated);

        return back()->with('success', 'Landing content created successfully.');
    }

    public function update(Request $request, PlatformLandingContent $landingContent)
    {
        $validated = $request->validate([
            'label' => 'nullable|string',
            'kicker' => 'nullable|string',
            'title' => 'nullable|string',
            'subtitle' => 'nullable|string',
            'description' => 'nullable|string',
            'data' => 'nullable|array',
            'is_active' => 'boolean',
        ]);

        $landingContent->update($validated);

        return back()->with('success', 'Landing content updated successfully.');
    }

    public function destroy(PlatformLandingContent $landingContent)
    {
        $landingContent->delete();

        return back()->with('success', 'Landing content deleted successfully.');
    }

    public function updateSettings(Request $request)
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $validated = $request->validate([
            'copyright_text' => ['nullable', 'string', 'max:255'],
            'social_links' => ['nullable', 'array', 'max:15'],
            'social_links.*.platform' => ['required', 'string', 'max:50'],
            'social_links.*.url' => ['required', 'url', 'max:255'],
        ]);

        $settings = PlatformLandingSetting::query()->firstOrNew();
        $settings->copyright_text = $validated['copyright_text'] ?? null;
        $settings->social_links = $validated['social_links'] ?? [];
        $settings->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Footer settings saved.']);

        return back();
    }
}
