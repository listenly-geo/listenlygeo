<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\PageRevision;
use App\Models\Release;
use App\Models\User;
use Inertia\Inertia;
use Inertia\Response;

class AdminAnalyticsController extends Controller
{
    public function __invoke(): Response
    {
        return Inertia::render('admin/analytics', [
            'summary' => [
                'newOrganizations7Days' => Organization::query()->where('created_at', '>=', now()->subDays(7))->count(),
                'newUsers7Days' => User::query()->where('created_at', '>=', now()->subDays(7))->count(),
                'releases30Days' => Release::query()->where('published_at', '>=', now()->subDays(30))->count(),
                'revisions30Days' => PageRevision::query()->where('created_at', '>=', now()->subDays(30))->count(),
            ],
            'windows' => [
                [
                    'label' => 'Last 7 days',
                    'organizations' => Organization::query()->where('created_at', '>=', now()->subDays(7))->count(),
                    'users' => User::query()->where('created_at', '>=', now()->subDays(7))->count(),
                    'releases' => Release::query()->where('published_at', '>=', now()->subDays(7))->count(),
                    'revisions' => PageRevision::query()->where('created_at', '>=', now()->subDays(7))->count(),
                ],
                [
                    'label' => 'Last 30 days',
                    'organizations' => Organization::query()->where('created_at', '>=', now()->subDays(30))->count(),
                    'users' => User::query()->where('created_at', '>=', now()->subDays(30))->count(),
                    'releases' => Release::query()->where('published_at', '>=', now()->subDays(30))->count(),
                    'revisions' => PageRevision::query()->where('created_at', '>=', now()->subDays(30))->count(),
                ],
                [
                    'label' => 'All time',
                    'organizations' => Organization::query()->count(),
                    'users' => User::query()->count(),
                    'releases' => Release::query()->count(),
                    'revisions' => PageRevision::query()->count(),
                ],
            ],
        ]);
    }
}
