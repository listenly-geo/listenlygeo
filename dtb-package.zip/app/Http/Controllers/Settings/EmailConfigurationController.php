<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\PlatformEmailSetting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Inertia\Inertia;
use Inertia\Response;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;
use Throwable;

class EmailConfigurationController extends Controller
{
    public function edit(Request $request): Response
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $settings = PlatformEmailSetting::query()->first();

        return Inertia::render('settings/email-configuration', [
            'emailConfiguration' => [
                'provider' => $settings?->provider ?? 'smtp',
                'host' => $settings?->host ?? '',
                'port' => $settings?->port ?? 587,
                'encryption' => $settings?->encryption ?? 'tls',
                'username' => $settings?->username ?? '',
                'passwordConfigured' => filled($settings?->password),
                'fromAddress' => $settings?->from_address ?? '',
                'fromName' => $settings?->from_name ?? '',
                'timeout' => $settings?->timeout ?? 10,
            ],
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $settings = PlatformEmailSetting::query()->firstOrNew();

        $validated = $request->validate([
            'host' => ['required', 'string', 'max:255'],
            'port' => ['required', 'integer', 'min:1', 'max:65535'],
            'encryption' => ['nullable', 'in:tls,ssl,none'],
            'username' => ['required', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:255'],
            'fromAddress' => ['required', 'email:rfc', 'max:255'],
            'fromName' => ['required', 'string', 'max:255'],
            'timeout' => ['required', 'integer', 'min:1', 'max:120'],
        ]);

        $settings->forceFill([
            'provider' => 'smtp',
            'host' => trim((string) $validated['host']),
            'port' => (int) $validated['port'],
            'encryption' => ($validated['encryption'] ?? 'none') === 'none' ? null : $validated['encryption'],
            'username' => trim((string) $validated['username']),
            'from_address' => trim((string) $validated['fromAddress']),
            'from_name' => trim((string) $validated['fromName']),
            'timeout' => (int) $validated['timeout'],
        ]);

        if (filled($validated['password'] ?? null)) {
            $settings->password = (string) $validated['password'];
        }

        $settings->save();

        $this->syncMailSettingsToEnv($settings);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Email configuration saved.']);

        return redirect()->route('settings.email-configuration.edit');
    }

    public function test(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $settings = PlatformEmailSetting::query()->first();

        $validated = $request->validate([
            'host' => ['required', 'string', 'max:255'],
            'port' => ['required', 'integer', 'min:1', 'max:65535'],
            'encryption' => ['nullable', 'in:tls,ssl,none'],
            'username' => ['required', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:255'],
            'timeout' => ['required', 'integer', 'min:1', 'max:120'],
        ]);

        $password = filled($validated['password'] ?? null)
            ? (string) $validated['password']
            : (string) ($settings?->password ?? '');

        if ($password === '') {
            Inertia::flash('toast', ['type' => 'error', 'message' => 'SMTP password is required to test connection.']);

            return redirect()->route('settings.email-configuration.edit');
        }

        try {
            $transport = new EsmtpTransport(
                (string) $validated['host'],
                (int) $validated['port'],
                ($validated['encryption'] ?? 'none') === 'none' ? null : (string) $validated['encryption'],
            );
            $transport->setUsername((string) $validated['username']);
            $transport->setPassword($password);

            $stream = $transport->getStream();
            $stream->setTimeout((float) $validated['timeout']);

            $transport->start();
            $transport->stop();
        } catch (Throwable $exception) {
            report($exception);

            Inertia::flash('toast', [
                'type' => 'error',
                'message' => 'SMTP connection failed: '.$exception->getMessage(),
            ]);

            return redirect()->route('settings.email-configuration.edit');
        }

        Inertia::flash('toast', ['type' => 'success', 'message' => 'SMTP connection successful.']);

        return redirect()->route('settings.email-configuration.edit');
    }

    private function syncMailSettingsToEnv(PlatformEmailSetting $settings): void
    {
        $envPath = base_path('.env');

        if (! File::exists($envPath)) {
            return;
        }

        $contents = File::get($envPath);

        $values = [
            'MAIL_MAILER' => 'smtp',
            'MAIL_SCHEME' => $settings->encryption ?? 'null',
            'MAIL_HOST' => $settings->host ?? 'null',
            'MAIL_PORT' => (string) ($settings->port ?? 2525),
            'MAIL_USERNAME' => $settings->username ?? 'null',
            'MAIL_PASSWORD' => $settings->password ?? 'null',
            'MAIL_FROM_ADDRESS' => $settings->from_address ?? 'null',
            'MAIL_FROM_NAME' => $settings->from_name ?? 'null',
        ];

        foreach ($values as $key => $value) {
            $lineValue = $this->formatEnvValue($value, in_array($key, ['MAIL_FROM_ADDRESS', 'MAIL_FROM_NAME'], true));
            $pattern = '/^'.preg_quote($key, '/').'=.*$/m';

            if (preg_match($pattern, $contents) === 1) {
                $contents = (string) preg_replace($pattern, $key.'='.$lineValue, $contents);

                continue;
            }

            if ($contents !== '' && ! str_ends_with($contents, PHP_EOL)) {
                $contents .= PHP_EOL;
            }

            $contents .= $key.'='.$lineValue.PHP_EOL;
        }

        File::put($envPath, $contents);
    }

    private function formatEnvValue(string $value, bool $alwaysQuote = false): string
    {
        if ($value === '') {
            return 'null';
        }

        $normalized = trim($value);

        if ($normalized === '' || strtolower($normalized) === 'null') {
            return 'null';
        }

        if ($alwaysQuote) {
            return '"'.str_replace('"', '\\"', $normalized).'"';
        }

        return $normalized;
    }
}
