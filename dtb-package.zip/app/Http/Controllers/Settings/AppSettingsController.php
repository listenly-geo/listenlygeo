<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\PlatformAppSetting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class AppSettingsController extends Controller
{
    public function edit(Request $request): Response
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $settings = PlatformAppSetting::query()->first();

        return Inertia::render('settings/application', [
            'appSettings' => [
                'appName' => $settings?->app_name ?? config('app.name', ''),
                'logoUrl' => $settings?->logo_path ? Storage::url($settings->logo_path) : null,
                'faviconUrl' => $settings?->favicon_path ? Storage::url($settings->favicon_path) : null,
            ],
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->is_platform_admin === true, 403);

        $validated = $request->validate([
            'app_name' => ['required', 'string', 'max:80'],
            'logo' => ['nullable', 'file', 'mimes:png,jpg,jpeg,svg,webp', 'max:2048'],
            'favicon' => ['nullable', 'file', 'mimes:png,jpg,jpeg,ico,svg', 'max:512'],
            'use_logo_as_favicon' => ['nullable', 'boolean'],
        ]);

        $settings = PlatformAppSetting::query()->firstOrNew();
        $settings->app_name = $validated['app_name'];

        if ($request->hasFile('logo')) {
            if ($settings->logo_path) {
                Storage::disk('public')->delete($settings->logo_path);
            }
            $settings->logo_path = $request->file('logo')->store('branding', 'public');
        }

        if ($request->boolean('use_logo_as_favicon') && $settings->logo_path) {
            // re-use logo as favicon
            $settings->favicon_path = $settings->logo_path;
        } elseif ($request->hasFile('favicon')) {
            if ($settings->favicon_path && $settings->favicon_path !== $settings->logo_path) {
                Storage::disk('public')->delete($settings->favicon_path);
            }
            $settings->favicon_path = $request->file('favicon')->store('branding', 'public');
        }

        $settings->save();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Application settings saved.']);

        return redirect()->route('settings.application.edit');
    }
}
