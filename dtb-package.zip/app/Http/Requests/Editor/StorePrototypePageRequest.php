<?php

namespace App\Http\Requests\Editor;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StorePrototypePageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'parentPageId' => ['nullable', 'integer', 'exists:pages,id'],
            'spaceId' => ['nullable', 'integer', 'exists:spaces,id'],
        ];
    }
}
