<?php

namespace App\Http\Requests\Editor;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class AiWriteRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    protected function prepareForValidation(): void
    {
        $scope = $this->input('scope');
        $mode = $this->input('mode');
        $intent = $this->input('intent');

        if ((! is_string($scope) || trim($scope) === '') && is_string($mode)) {
            $scope = match ($mode) {
                'full-page' => 'page',
                'selection' => 'selection',
                default => $scope,
            };
        }

        if ((! is_string($mode) || trim($mode) === '') && is_string($scope)) {
            $mode = match ($scope) {
                'page' => 'full-page',
                'selection' => 'selection',
                default => null,
            };
        }

        if ((! is_string($intent) || trim($intent) === '') && is_string($scope)) {
            $intent = match ($scope) {
                'selection' => 'rewrite',
                'title', 'description' => 'derive',
                'text' => 'rewrite',
                'content' => 'generate',
                default => 'generate',
            };
        }

        $merge = [];

        if (is_string($scope) && trim($scope) !== '') {
            $merge['scope'] = $scope;
        }

        if (is_string($mode) && trim($mode) !== '') {
            $merge['mode'] = $mode;
        }

        if (is_string($intent) && trim($intent) !== '') {
            $merge['intent'] = $intent;
        }

        if ($merge !== []) {
            $this->merge($merge);
        }
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'mode' => ['nullable', 'string', Rule::in(['full-page', 'selection'])],
            'scope' => ['required', 'string', Rule::in(['page', 'selection', 'title', 'description', 'content', 'text'])],
            'intent' => ['required', 'string', Rule::in(['generate', 'rewrite', 'derive', 'expand'])],
            'prompt' => ['required', 'string', 'max:4000'],
            'document' => ['required', 'array'],
            'document.title' => ['required', 'string', 'max:1000'],
            'document.subtitle' => ['nullable', 'string'],
            'document.blocks' => ['required', 'array'],
            'document.blocks.*' => ['array'],
            'target' => ['nullable', 'array'],
            'target.blockId' => ['nullable', 'string', 'max:255'],
            'target.insertAfterBlockId' => ['nullable', 'string', 'max:255'],
            'target.selectedText' => ['nullable', 'string', 'max:4000'],
            'target.blockIds' => ['nullable', 'array'],
            'target.blockIds.*' => ['string', 'max:255'],
            'target.blocks' => ['nullable', 'array'],
            'target.blocks.*' => ['array'],
            'selection' => ['nullable', 'array'],
            'selection.blockIds' => ['nullable', 'array'],
            'selection.blockIds.*' => ['string', 'max:255'],
            'selection.blocks' => ['nullable', 'array'],
            'selection.blocks.*' => ['array'],
        ];
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator): void {
            $scope = $this->string('scope')->toString();
            $intent = $this->string('intent')->toString();

            $allowedIntents = match ($scope) {
                'page' => ['generate', 'rewrite'],
                'selection' => ['rewrite'],
                'title', 'description' => ['derive', 'rewrite'],
                'content' => ['generate', 'rewrite', 'expand'],
                'text' => ['rewrite'],
                default => [],
            };

            if ($allowedIntents !== [] && ! in_array($intent, $allowedIntents, true)) {
                $validator->errors()->add('intent', 'The selected AI intent is invalid for this scope.');
            }

            if ($scope !== 'selection') {
                if ($scope === 'content' && in_array($intent, ['rewrite', 'expand'], true)) {
                    $targetBlocks = $this->input('target.blocks', []);

                    if (! is_array($targetBlocks) || $targetBlocks === []) {
                        $validator->errors()->add('target.blocks', 'Select at least one block for content AI writing.');
                    }
                }

                if ($scope === 'text') {
                    $selectedText = trim((string) $this->input('target.selectedText', ''));

                    if ($selectedText === '') {
                        $validator->errors()->add('target.selectedText', 'Select text before using AI rewrite.');
                    }
                }

                return;
            }

            $selectionBlocks = $this->input('selection.blocks', []);

            if (! is_array($selectionBlocks) || $selectionBlocks === []) {
                $validator->errors()->add('selection.blocks', 'Select at least one block for section AI writing.');
            }
        });
    }
}
