<?php

namespace App\Http\Requests\Editor;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class AutosavePageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:1000'],
            'subtitle' => ['nullable', 'string'],
            'blocks' => ['required', 'array'],
            'blocks.*' => ['array'],
            'editorMeta' => ['nullable', 'array'],
            'editorMeta.readTime' => ['nullable', 'string', 'max:64'],
            'editorMeta.updated' => ['nullable', 'string', 'max:128'],
            'editorMeta.viewCount' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
