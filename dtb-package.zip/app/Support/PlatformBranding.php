<?php

namespace App\Support;

use App\Models\OrganizationSubscription;
use App\Models\PlatformAppSetting;
use Illuminate\Support\Facades\Storage;

final class PlatformBranding
{
    public static function shouldShow(?OrganizationSubscription $subscription): bool
    {
        return ($subscription?->plan ?? 'free') === 'free';
    }

    /**
     * @return array{enabled: bool, name: string, logoUrl: string|null, url: string}
     */
    public static function payload(bool $enabled): array
    {
        $settings = PlatformAppSetting::query()->first();
        $logoPath = $settings?->logo_path;

        return [
            'enabled' => $enabled,
            'name' => $settings?->app_name ?: (string) config('app.name', 'DocTheBuilder'),
            'logoUrl' => $logoPath ? Storage::disk('public')->url($logoPath) : null,
            'url' => rtrim((string) config('app.url'), '/'),
        ];
    }
}
