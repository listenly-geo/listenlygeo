<?php

namespace App\Actions\Docs;

use App\Models\MediaAsset;
use App\Models\Page;
use App\Models\PageComment;
use App\Models\PageRevision;
use App\Models\Site;
use App\Models\Space;
use App\Models\User;
use Carbon\CarbonInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;

class BuildPrototypeSeedData
{
    public function __construct(
        private readonly EnsureEditorWorkspace $ensureEditorWorkspace,
    ) {}

    /**
     * Build the prototype-compatible seed payload from the current site state.
     *
     * @return array<string, mixed>
     */
    public function __invoke(User $user, ?Space $activeSpace = null, ?string $activePageSlug = null): array
    {
        $bootstrap = ($this->ensureEditorWorkspace)($user, $activeSpace, $activePageSlug);

        $bootstrapSpaceId = (int) $bootstrap['space']['id'];

        $site = Site::query()
            ->with([
                'spaces' => fn ($query) => $query->orderBy('position')->orderBy('id'),
                'pages' => fn ($query) => $query
                    ->where('space_id', $bootstrapSpaceId)
                    ->orderBy('position')
                    ->orderBy('id'),
                'pages.currentRevision.author',
                'pages.publishedRevision',
                'pages.creator',
                'pages.comments.author',
                'pages.comments.replies.author',
                'pages.revisions' => fn ($query) => $query->orderByDesc('version_number'),
                'pages.revisions.author',
                'mediaAssets' => fn ($query) => $query->with('uploader:id,name')->latest('id'),
            ])
            ->findOrFail($bootstrap['site']['id']);

        $activePageId = $this->pageKey((int) $bootstrap['page']['id']);
        $activeSpaceId = $this->spaceKey($bootstrapSpaceId);
        $pages = $site->pages;
        $pagesByParent = $pages->groupBy('parent_id');

        // Per-space totals (computed independently of the active-space page filter above).
        $spaceCounts = Page::query()
            ->where('site_id', $site->id)
            ->selectRaw('space_id, COUNT(*) as total')
            ->groupBy('space_id')
            ->pluck('total', 'space_id');

        $spaces = $site->spaces->map(function ($space) use ($site, $spaceCounts) {
            return [
                'id' => $this->spaceKey((int) $space->id),
                'uuid' => $space->uuid,
                'editorUrl' => route('editor.space', ['site' => $site->uuid, 'space' => $space->uuid], false),
                'name' => $space->name,
                'color' => $space->color ?: $this->colorForValue((string) $space->id),
                'count' => (int) ($spaceCounts[$space->id] ?? 0),
                'icon' => strtoupper(substr($space->name, 0, 1)) ?: 'D',
            ];
        })->values()->all();

        $tree = $this->buildTree($pagesByParent, null);

        $contentMap = [];
        foreach ($pages as $page) {
            $revision = $page->currentRevision;
            $publishedRevision = $page->publishedRevision;
            $author = $revision?->author ?: $page->creator ?: $user;
            $viewCount = $this->viewCountFor($revision?->editor_meta_json ?? []);
            $commentCount = $page->comments->count();
            $contentMap[$this->pageKey((int) $page->id)] = [
                'currentRevisionId' => $page->current_revision_id,
                'publishedRevisionId' => $page->published_revision_id,
                'title' => $revision?->title ?: $page->title,
                'subtitle' => $revision?->subtitle ?: '',
                'slug' => $page->slug,
                'path' => $page->path,
                'updated' => ($revision?->updated_at ?: $page->updated_at)?->format('M j, Y'),
                'readTime' => $revision?->editor_meta_json['readTime'] ?? '1 min',
                'viewCount' => $viewCount,
                'commentCount' => $commentCount,
                'stats' => [
                    'views' => $viewCount,
                    'comments' => $commentCount,
                ],
                'publishedSnapshot' => $this->revisionSnapshot($publishedRevision),
                'publishChanges' => $this->publishChangesFor($revision, $publishedRevision),
                'author' => [
                    'name' => $author->name,
                    'role' => 'Editor',
                    'initials' => $this->initials($author->name),
                    'color' => $this->colorForValue((string) $author->id),
                ],
                'collaborators' => $this->collaboratorsForPage($page, $author),
                'blocks' => $revision?->blocks_json ?: [[
                    'id' => 'b_empty_'.$page->id,
                    'kind' => 'p',
                    'html' => 'Start writing, or press <code>/</code> to insert a block.',
                ]],
            ];
        }

        $activePage = $pages->firstWhere('id', $bootstrap['page']['id']);

        $comments = $activePage
            ? $activePage->comments
                ->sortByDesc('id')
                ->map(fn (PageComment $comment) => $this->mapComment($comment))
                ->values()
                ->all()
            : [];

        $history = $activePage
            ? $this->buildHistory($activePage->revisions, $activePage->current_revision_id)
            : [];

        $mediaAssets = $site->mediaAssets
            ->map(fn (MediaAsset $asset) => [
                'id' => $asset->id,
                'name' => $asset->original_name ?: basename($asset->path),
                'url' => route('media.assets.show', ['asset' => $asset]),
                'mimeType' => $asset->mime_type,
                'sizeBytes' => $asset->size_bytes,
                'width' => $asset->width,
                'height' => $asset->height,
                'uploadedBy' => $asset->uploader?->name,
                'uploadedAt' => $asset->created_at?->toIso8601String(),
                'isImage' => str_starts_with($asset->mime_type, 'image/'),
                'isVideo' => str_starts_with($asset->mime_type, 'video/'),
            ])
            ->values()
            ->all();

        return [
            'spaces' => $spaces,
            'pages' => $tree,
            'activeSpaceId' => $activeSpaceId,
            'activePageId' => $activePageId,
            'pageContent' => $contentMap,
            'comments' => $comments,
            'history' => $history,
            'mediaAssets' => $mediaAssets,
        ];
    }

    /**
     * @param  Collection<int|string, Collection<int, Page>>  $pagesByParent
     * @return array<int, array<string, mixed>>
     */
    private function buildTree(Collection $pagesByParent, ?int $parentId): array
    {
        return ($pagesByParent->get($parentId) ?? collect())
            ->map(function (Page $page) use ($pagesByParent) {
                $children = $this->buildTree($pagesByParent, $page->id);

                return array_filter([
                    'id' => $this->pageKey((int) $page->id),
                    'spaceId' => $this->spaceKey((int) $page->space_id),
                    'slug' => $page->slug,
                    'title' => $page->title,
                    'path' => $page->path,
                    'icon' => $page->icon ?: 'page',
                    'expanded' => ! empty($children),
                    'children' => $children ?: null,
                ], static fn ($value) => $value !== null);
            })
            ->values()
            ->all();
    }

    private function mapComment(PageComment $comment): array
    {
        $author = $comment->author;

        return [
            'id' => 'c'.$comment->id,
            'author' => $author?->name ?: 'Unknown',
            'initials' => $this->initials($author?->name ?: 'Unknown'),
            'color' => $this->colorForValue((string) ($author?->id ?? $comment->id)),
            'time' => $comment->created_at?->diffForHumans() ?: 'just now',
            'ref' => $comment->block_id ? 'Block '.$comment->block_id : 'Page comment',
            'body' => $comment->body,
            'replies' => $comment->replies->map(function ($reply) {
                $author = $reply->author;

                return [
                    'author' => $author?->name ?: 'Unknown',
                    'initials' => $this->initials($author?->name ?: 'Unknown'),
                    'color' => $this->colorForValue((string) ($author?->id ?? $reply->id)),
                    'time' => $reply->created_at?->diffForHumans() ?: 'just now',
                    'body' => $reply->body,
                ];
            })->values()->all(),
            'resolved' => $comment->resolved_at !== null,
        ];
    }

    /**
     * @param  Collection<int, PageRevision>  $revisions
     * @return array<int, array<string, mixed>>
     */
    private function buildHistory(Collection $revisions, ?int $currentRevisionId): array
    {
        return $revisions
            ->groupBy(fn (PageRevision $revision) => $this->historyDayLabel($revision->created_at ?: now()))
            ->map(function (Collection $group, string $day) use ($currentRevisionId) {
                return [
                    'day' => $day,
                    'items' => $group->values()->map(function (PageRevision $revision, int $index) use ($currentRevisionId) {
                        $author = $revision->author;
                        $isCurrent = (int) $revision->id === (int) $currentRevisionId;

                        return [
                            'id' => 'v'.$revision->id,
                            'revisionId' => $revision->id,
                            'name' => $isCurrent ? 'Current draft' : 'Revision '.$revision->version_number,
                            'meta' => ($revision->created_at ?: now())->format('H:i').' · '.$revision->save_type,
                            'msg' => $revision->change_message ?: 'Saved editor changes',
                            'who' => $author?->name ?: 'Unknown',
                            'current' => $isCurrent,
                            'canRestore' => ! $isCurrent,
                        ];
                    })->all(),
                ];
            })
            ->values()
            ->all();
    }

    private function historyDayLabel(CarbonInterface $date): string
    {
        if ($date->isToday()) {
            return 'Today';
        }

        if ($date->isYesterday()) {
            return 'Yesterday';
        }

        return $date->format('M j, Y');
    }

    /**
     * @return array{title: string, subtitle: string, blocks: array<int, mixed>}|null
     */
    private function revisionSnapshot(?PageRevision $revision): ?array
    {
        if (! $revision) {
            return null;
        }

        return [
            'title' => $revision->title,
            'subtitle' => $revision->subtitle ?: '',
            'blocks' => $revision->blocks_json ?: [],
        ];
    }

    /**
     * @return array{added: int, removed: int, status: string}
     */
    private function publishChangesFor(?PageRevision $currentRevision, ?PageRevision $publishedRevision): array
    {
        $currentTokens = $this->documentTokens($currentRevision);

        if (! $publishedRevision) {
            return [
                'added' => count($currentTokens),
                'removed' => 0,
                'status' => $currentTokens === [] ? 'empty' : 'unpublished',
            ];
        }

        $publishedTokens = $this->documentTokens($publishedRevision);
        $currentCounts = array_count_values($currentTokens);
        $publishedCounts = array_count_values($publishedTokens);
        $added = 0;
        $removed = 0;

        foreach ($currentCounts as $token => $count) {
            $added += max(0, $count - ($publishedCounts[$token] ?? 0));
        }

        foreach ($publishedCounts as $token => $count) {
            $removed += max(0, $count - ($currentCounts[$token] ?? 0));
        }

        return [
            'added' => $added,
            'removed' => $removed,
            'status' => ($added > 0 || $removed > 0) ? 'changed' : 'unchanged',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function documentTokens(?PageRevision $revision): array
    {
        if (! $revision) {
            return [];
        }

        $parts = [$revision->title, (string) $revision->subtitle];

        foreach ($revision->blocks_json ?: [] as $block) {
            if (is_array($block)) {
                $parts[] = $this->blockText($block);
            }
        }

        $text = strtolower(trim(strip_tags(implode(' ', $parts))));
        $tokens = preg_split('/[^a-z0-9]+/', $text) ?: [];

        return array_values(array_filter($tokens, fn (string $token) => $token !== ''));
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockText(array $block): string
    {
        $parts = [];

        foreach (['text', 'html', 'title', 'caption', 'desc', 'body', 'url', 'path'] as $field) {
            if (isset($block[$field])) {
                $parts[] = (string) $block[$field];
            }
        }

        foreach (['headers', 'items'] as $listField) {
            if (isset($block[$listField]) && is_array($block[$listField])) {
                foreach ($block[$listField] as $item) {
                    $parts[] = is_array($item) ? implode(' ', array_map('strval', $item)) : (string) $item;
                }
            }
        }

        if (isset($block['rows']) && is_array($block['rows'])) {
            foreach ($block['rows'] as $row) {
                if (is_array($row)) {
                    $parts[] = implode(' ', array_map('strval', $row));
                }
            }
        }

        return implode(' ', $parts);
    }

    /**
     * @return array<int, array{name: string, initials: string, color: string}>
     */
    private function collaboratorsForPage(Page $page, User $fallbackAuthor): array
    {
        return collect([$fallbackAuthor])
            ->merge($page->revisions->pluck('author'))
            ->merge($page->comments->pluck('author'))
            ->merge($page->comments->flatMap(fn (PageComment $comment) => $comment->replies->pluck('author')))
            ->filter()
            ->unique(fn (User $user) => $user->id)
            ->take(4)
            ->map(fn (User $user) => [
                'name' => $user->name,
                'initials' => $this->initials($user->name),
                'color' => $this->colorForValue((string) $user->id),
            ])
            ->values()
            ->all();
    }

    /**
     * @param  array<string, mixed>  $editorMeta
     */
    private function viewCountFor(array $editorMeta): int
    {
        $value = Arr::get($editorMeta, 'viewCount')
            ?? Arr::get($editorMeta, 'views')
            ?? Arr::get($editorMeta, 'pageViews')
            ?? Arr::get($editorMeta, 'analytics.views')
            ?? 0;

        if (is_string($value)) {
            $value = preg_replace('/[^0-9]/', '', $value) ?: 0;
        }

        return max(0, (int) $value);
    }

    private function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $letters = collect($parts)
            ->filter()
            ->take(2)
            ->map(fn (string $part) => strtoupper(substr($part, 0, 1)));

        return $letters->implode('') ?: 'NA';
    }

    private function colorForValue(string $value): string
    {
        $palette = [
            'oklch(55% 0.14 255)',
            'oklch(52% 0.15 155)',
            'oklch(55% 0.15 30)',
            'oklch(58% 0.14 305)',
            'oklch(60% 0.14 70)',
            'oklch(55% 0.13 205)',
        ];

        return $palette[abs(crc32($value)) % count($palette)];
    }

    private function spaceKey(int $id): string
    {
        return 'sp_'.$id;
    }

    private function pageKey(int $id): string
    {
        return 'p_'.$id;
    }
}
