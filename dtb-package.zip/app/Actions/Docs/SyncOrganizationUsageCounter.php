<?php

namespace App\Actions\Docs;

use App\Models\Organization;
use App\Models\OrganizationUsageCounter;
use App\Models\Page;

class SyncOrganizationUsageCounter
{
    public function __invoke(Organization $organization): void
    {
        OrganizationUsageCounter::query()->updateOrCreate(
            ['organization_id' => $organization->id],
            [
                'site_count' => $organization->sites()->count(),
                'member_count' => $organization->memberships()->where('status', 'active')->count(),
                'published_page_count' => Page::query()
                    ->whereIn('site_id', $organization->sites()->select('id'))
                    ->whereNotNull('published_revision_id')
                    ->count(),
                'storage_bytes' => $organization->mediaAssets()->sum('size_bytes'),
            ],
        );
    }
}
