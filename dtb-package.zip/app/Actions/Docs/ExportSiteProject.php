<?php

namespace App\Actions\Docs;

use App\Models\ReleasePage;
use App\Models\Site;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;
use ZipArchive;

class ExportSiteProject
{
    public function __construct(
        private readonly BuildPublishedSitePayload $buildPublishedSitePayload,
        private readonly Kernel $kernel,
    ) {}

    /**
     * @return array{path: string, filename: string, contentType: string}
     */
    public function __invoke(Site $site, string $format): array
    {
        $normalizedFormat = $this->normalizeFormat($format);

        $site->loadMissing([
            'currentRelease.pages' => fn ($query) => $query->orderBy('position')->orderBy('path')->orderBy('id'),
        ]);

        $release = $site->currentRelease;
        abort_unless($release !== null, 404, 'This site has no published release to export.');

        $releasePages = $release->pages;
        abort_unless($releasePages->isNotEmpty(), 404, 'The current release has no pages to export.');

        $tmpDirectory = storage_path('app/tmp/site-exports');

        if (! is_dir($tmpDirectory) && ! @mkdir($tmpDirectory, 0755, true) && ! is_dir($tmpDirectory)) {
            throw new RuntimeException('Failed to prepare temporary export directory.');
        }

        $archiveFilename = sprintf('%s-%s-%s.zip', Str::slug($site->slug ?: $site->name ?: 'docs-site') ?: 'docs-site', $normalizedFormat, now()->format('Ymd-His'));
        $archivePath = $tmpDirectory.DIRECTORY_SEPARATOR.(string) Str::uuid().'.zip';

        $zip = new ZipArchive();
        $openResult = $zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        if ($openResult !== true) {
            throw new RuntimeException('Failed to initialize site export archive (ZipArchive error: '.$openResult.').');
        }

        try {
            if ($normalizedFormat === 'html-themed') {
                $this->buildHtmlExport($zip, $site, $releasePages->all());
            } elseif ($normalizedFormat === 'html-plain') {
                $this->buildPlainHtmlExport($zip, $site, $releasePages->all());
            } else {
                $this->buildPdfExport($zip, $site, $releasePages->all());
            }
        } catch (\Throwable $exception) {
            $zip->close();
            @unlink($archivePath);

            throw $exception;
        }

        $zip->close();

        return [
            'path' => $archivePath,
            'filename' => $archiveFilename,
            'contentType' => 'application/zip',
        ];
    }

    private function normalizeFormat(string $format): string
    {
        $format = Str::lower(trim($format));

        return match ($format) {
            'html' => 'html-themed',
            'plain-html' => 'html-plain',
            'pdf' => 'pdf',
            default => throw new InvalidArgumentException('Unsupported site export format.'),
        };
    }

    /**
     * @param  array<int, ReleasePage>  $releasePages
     */
    private function buildHtmlExport(ZipArchive $zip, Site $site, array $releasePages): void
    {
        $rootPath = 'docs/'.$site->slug;
        $assetPaths = [];

        foreach ($releasePages as $releasePage) {
            $routePath = route('docs.show', ['siteSlug' => $site->slug, 'path' => $releasePage->path], false);
            $html = $this->renderPath($routePath);

            $assetPaths = array_merge($assetPaths, $this->extractLocalAssetPaths($html));

            $safePagePath = trim((string) $releasePage->path, '/');
            $zipPath = $safePagePath === ''
                ? $rootPath.'/index.html'
                : $rootPath.'/'.$safePagePath.'/index.html';

            $zip->addFromString($zipPath, $html);
        }

        $entry = ($this->buildPublishedSitePayload)($site);
        $entryPath = trim((string) data_get($entry, 'page.path', ''), '/');
        $entryIndexPath = $entryPath === '' ? 'index.html' : $entryPath.'/index.html';

        $zip->addFromString(
            'index.html',
            $this->rootRedirectHtml($rootPath.'/'.$entryIndexPath)
        );

        if ($entryPath !== '') {
            $zip->addFromString(
                $rootPath.'/index.html',
                $this->rootRedirectHtml($entryIndexPath)
            );
        }

        $this->addPublicAssets($zip, array_values(array_unique($assetPaths)));

        $zip->addFromString(
            'manifest.json',
            json_encode([
                'site' => [
                    'id' => $site->id,
                    'slug' => $site->slug,
                    'name' => $site->name,
                ],
                'format' => 'html-themed',
                'description' => 'Themed published docs export with frontend assets.',
                'exportedAt' => now()->toIso8601String(),
                'pageCount' => count($releasePages),
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)
        );
    }

    /**
     * @param  array<int, ReleasePage>  $releasePages
     */
    private function buildPlainHtmlExport(ZipArchive $zip, Site $site, array $releasePages): void
    {
        $rootPath = 'docs/'.$site->slug;
        $orderedPages = collect($releasePages)
            ->sortBy(fn (ReleasePage $page) => [(int) $page->position, (string) $page->path, (int) $page->id])
            ->values();

        $navigation = $orderedPages
            ->map(fn (ReleasePage $page) => [
                'path' => trim((string) $page->path, '/'),
                'title' => trim((string) $page->title) !== '' ? (string) $page->title : Str::headline((string) $page->path),
            ])
            ->all();

        foreach ($orderedPages as $releasePage) {
            $safePath = trim((string) $releasePage->path, '/');
            $zipPath = $safePath === '' ? $rootPath.'/index.html' : $rootPath.'/'.$safePath.'/index.html';

            $zip->addFromString(
                $zipPath,
                $this->plainHtmlPage($site->name, $navigation, $releasePage)
            );
        }

        $entryPath = data_get($navigation, '0.path', '');
        $entryIndexPath = $entryPath === '' ? 'index.html' : $entryPath.'/index.html';

        $zip->addFromString(
            'index.html',
            $this->rootRedirectHtml($rootPath.'/'.$entryIndexPath)
        );

        if ($entryPath !== '') {
            $zip->addFromString(
                $rootPath.'/index.html',
                $this->rootRedirectHtml($entryIndexPath)
            );
        }

        $zip->addFromString(
            'manifest.json',
            json_encode([
                'site' => [
                    'id' => $site->id,
                    'slug' => $site->slug,
                    'name' => $site->name,
                ],
                'format' => 'html-plain',
                'description' => 'Plain static HTML export without JS runtime dependencies.',
                'exportedAt' => now()->toIso8601String(),
                'pageCount' => count($releasePages),
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)
        );
    }

    /**
     * @param  array<int, ReleasePage>  $releasePages
     */
    private function buildPdfExport(ZipArchive $zip, Site $site, array $releasePages): void
    {
        $lines = [];

        foreach ($releasePages as $releasePage) {
            $title = trim((string) $releasePage->title) !== '' ? (string) $releasePage->title : (string) $releasePage->path;
            $lines[] = '## '.$title;
            $lines[] = 'PATH /'.$releasePage->path;

            $content = trim($this->blocksToText(is_array($releasePage->blocks_json) ? $releasePage->blocks_json : []));
            if ($content !== '') {
                $lines[] = $content;
            }

            $lines[] = '';
            $lines[] = '';
        }

        $pdf = $this->buildPdf($site->name.' Documentation', $this->wrapPdfLines(trim(implode("\n", $lines)), 90));

        $zip->addFromString('site-export.pdf', $pdf);
        $zip->addFromString('site-export.txt', trim(implode("\n", $lines))."\n");
        $zip->addFromString(
            'manifest.json',
            json_encode([
                'site' => [
                    'id' => $site->id,
                    'slug' => $site->slug,
                    'name' => $site->name,
                ],
                'format' => 'pdf',
                'exportedAt' => now()->toIso8601String(),
                'pageCount' => count($releasePages),
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)
        );
    }

    private function rootRedirectHtml(string $targetPath): string
    {
        $escaped = e($targetPath);

        return <<<HTML
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="0;url={$escaped}">
    <title>Doc Export</title>
</head>
<body>
    <p>Redirecting to <a href="{$escaped}">{$escaped}</a>...</p>
</body>
</html>
HTML;
    }

    /**
     * @param  array<int, array{path: string, title: string}>  $navigation
     */
    private function plainHtmlPage(string $siteName, array $navigation, ReleasePage $page): string
    {
        $title = trim((string) $page->title) !== '' ? (string) $page->title : Str::headline((string) $page->path);
        $subtitle = trim((string) ($page->subtitle ?? ''));
        $currentPath = trim((string) $page->path, '/');
        $escapedTitle = e($title);
        $escapedSiteName = e($siteName);

        $navMarkup = collect($navigation)
            ->map(function (array $item) use ($currentPath): string {
                $targetPath = trim((string) $item['path'], '/');
                $href = $this->relativePageHref($currentPath, $targetPath);
                $isCurrent = $targetPath === $currentPath;

                return '<a href="'.e($href).'"'.($isCurrent ? ' aria-current="page"' : '').'>'.e($item['title']).'</a>';
            })
            ->implode('');

        $blocksMarkup = collect(is_array($page->blocks_json) ? $page->blocks_json : [])
            ->filter(fn ($block) => is_array($block))
            ->map(fn ($block) => $this->blockToPlainHtml(is_array($block) ? $block : []))
            ->filter(fn (string $html) => trim($html) !== '')
            ->implode("\n");

        $subtitleMarkup = $subtitle !== '' ? '<p class="subtitle">'.e($subtitle).'</p>' : '';

        return <<<HTML
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{$escapedTitle} · {$escapedSiteName}</title>
    <style>
        :root { color-scheme: light; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: ui-sans-serif, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; color: #111827; background: #ffffff; }
        .layout { display: grid; grid-template-columns: 260px minmax(0, 1fr); min-height: 100vh; }
        .nav { border-right: 1px solid #e5e7eb; padding: 24px 18px; background: #f9fafb; }
        .nav h1 { margin: 0 0 16px; font-size: 15px; font-weight: 700; color: #0f172a; }
        .nav a { display: block; padding: 8px 10px; margin: 4px 0; border-radius: 8px; text-decoration: none; color: #334155; }
        .nav a[aria-current="page"] { background: #e2e8f0; color: #0f172a; font-weight: 600; }
        .content { padding: 34px 42px; max-width: 980px; }
        .content h1 { margin: 0 0 12px; font-size: 2rem; }
        .subtitle { margin: 0 0 22px; color: #64748b; }
        .block { margin: 16px 0; }
        .callout { border-left: 4px solid #2563eb; background: #eff6ff; padding: 12px 14px; border-radius: 8px; }
        .embed-card { border: 1px solid #cbd5e1; border-radius: 12px; padding: 14px 16px; background: #f8fafc; }
        .embed-card strong { display: block; font-size: 1rem; }
        .embed-card a { color: #2563eb; word-break: break-word; }
        .embed-frame { overflow: hidden; border-radius: 12px; border: 1px solid #cbd5e1; background: #0f172a; }
        .embed-frame iframe, .embed-frame video { display: block; width: 100%; border: 0; }
        pre { background: #0f172a; color: #e2e8f0; padding: 14px; border-radius: 8px; overflow: auto; }
        code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
        figure { margin: 16px 0; }
        img { max-width: 100%; height: auto; border-radius: 8px; }
        figcaption { color: #64748b; font-size: 0.9rem; margin-top: 6px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; vertical-align: top; }
        th { background: #f8fafc; }
        @media (max-width: 900px) {
            .layout { grid-template-columns: 1fr; }
            .nav { border-right: none; border-bottom: 1px solid #e5e7eb; }
            .content { padding: 22px 16px; }
        }
    </style>
</head>
<body>
    <div class="layout">
        <aside class="nav">
            <h1>{$escapedSiteName}</h1>
            {$navMarkup}
        </aside>
        <main class="content">
            <h1>{$escapedTitle}</h1>
            {$subtitleMarkup}
            {$blocksMarkup}
        </main>
    </div>
</body>
</html>
HTML;
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockToPlainHtml(array $block): string
    {
        $kind = (string) ($block['kind'] ?? 'p');

        return match ($kind) {
            'h1', 'h2', 'h3' => '<div class="block"><'.$kind.'>'.e($this->plainText($block['text'] ?? '')).'</'.$kind.'></div>',
            'quote' => '<blockquote class="block">'.e($this->plainText($block['html'] ?? '')).'</blockquote>',
            'divider' => '<hr class="block">',
            'code' => '<pre class="block"><code>'.e((string) ($block['code'] ?? '')).'</code></pre>',
            'callout' => '<div class="block callout"><strong>'.e($this->plainText($block['title'] ?? 'Note')).'</strong><p>'.e($this->plainText($block['text'] ?? '')).'</p></div>',
            'figure' => $this->plainFigureHtml($block),
            'table' => $this->plainTableHtml($block),
            'embed' => $this->plainEmbedHtml($block),
            default => '<p class="block">'.e($this->plainText($block['html'] ?? $block['text'] ?? $block['body'] ?? '')).'</p>',
        };
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function plainFigureHtml(array $block): string
    {
        $src = trim((string) ($block['src'] ?? ''));
        $caption = trim((string) ($block['caption'] ?? ''));

        if ($src === '') {
            return '';
        }

        $captionHtml = $caption !== '' ? '<figcaption>'.e($this->plainText($caption)).'</figcaption>' : '';

        return '<figure class="block"><img src="'.e($src).'" alt="'.e($this->plainText($block['alt'] ?? '')).'">'.$captionHtml.'</figure>';
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function plainEmbedHtml(array $block): string
    {
        $url = trim((string) ($block['url'] ?? ''));

        if ($url === '') {
            return '';
        }

        $title = $this->plainText($block['title'] ?? 'Embedded content');
        $title = $title !== '' ? $title : 'Embedded content';
        $youtubeId = $this->youtubeEmbedId($url);

        if ($youtubeId !== null) {
            return '<div class="block embed-frame"><iframe src="https://www.youtube.com/embed/'.e($youtubeId).'" title="'.e($title).'" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="aspect-ratio: 16 / 9;"></iframe></div>';
        }

        if ($this->isVideoEmbed($block, $url)) {
            return '<div class="block embed-frame"><video src="'.e($url).'" controls preload="metadata" playsinline style="max-height: 420px; background: #020617;"></video></div>';
        }

        if ($this->isPdfEmbed($block, $url)) {
            return '<div class="block embed-frame"><iframe src="'.e($url).'" title="'.e($title).'" style="min-height: 420px;"></iframe></div>';
        }

        return '<div class="block embed-card"><strong>'.e($title).'</strong><a href="'.e($url).'">'.e($url).'</a></div>';
    }

    private function relativePageHref(string $fromPath, string $toPath): string
    {
        $from = $fromPath === '' ? [] : explode('/', $fromPath);
        $to = $toPath === '' ? [] : explode('/', $toPath);

        while ($from !== [] && $to !== [] && $from[0] === $to[0]) {
            array_shift($from);
            array_shift($to);
        }

        $up = array_fill(0, count($from), '..');
        $down = $to;
        $segments = [...$up, ...$down, 'index.html'];

        return implode('/', $segments === [] ? ['index.html'] : $segments);
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function plainTableHtml(array $block): string
    {
        $headers = is_array($block['headers'] ?? null) ? $block['headers'] : [];
        $rows = is_array($block['rows'] ?? null) ? $block['rows'] : [];

        if ($headers === [] && $rows === []) {
            return '';
        }

        $head = collect($headers)->map(fn ($header) => '<th>'.e($this->plainText($header)).'</th>')->implode('');
        $body = collect($rows)
            ->filter(fn ($row) => is_array($row))
            ->map(function ($row) {
                return '<tr>'.collect($row)->map(fn ($cell) => '<td>'.e($this->plainText($cell)).'</td>')->implode('').'</tr>';
            })
            ->implode('');

        return '<div class="block"><table><thead><tr>'.$head.'</tr></thead><tbody>'.$body.'</tbody></table></div>';
    }

    private function renderPath(string $path): string
    {
        $request = Request::create($path, 'GET');
        $response = $this->kernel->handle($request);

        if ($response->getStatusCode() !== 200) {
            throw new RuntimeException('Failed to render published docs page for export: '.$path);
        }

        $content = $response->getContent();
        $this->kernel->terminate($request, $response);

        if (! is_string($content)) {
            throw new RuntimeException('Rendered docs response did not return string content: '.$path);
        }

        return $content;
    }

    /**
     * @return array<int, string>
     */
    private function extractLocalAssetPaths(string $html): array
    {
        $paths = [];

        if (preg_match_all('/(?:src|href)="(\/[^"#?]+(?:\?[^"#]*)?)"/i', $html, $matches) !== false) {
            foreach ($matches[1] as $rawPath) {
                $path = (string) parse_url((string) $rawPath, PHP_URL_PATH);

                if ($path === '' || str_starts_with($path, '/docs/')) {
                    continue;
                }

                if (str_starts_with($path, '/build/') || str_starts_with($path, '/favicon')) {
                    $paths[] = $path;
                }
            }
        }

        return $paths;
    }

    /**
     * @param  array<int, string>  $assetPaths
     */
    private function addPublicAssets(ZipArchive $zip, array $assetPaths): void
    {
        foreach ($assetPaths as $publicPath) {
            $relative = ltrim($publicPath, '/');
            $absolute = public_path($relative);

            if (! is_file($absolute)) {
                continue;
            }

            $zip->addFile($absolute, $relative);
        }

        $manifest = public_path('build/manifest.json');

        if (is_file($manifest)) {
            $zip->addFile($manifest, 'build/manifest.json');
        }
    }

    /**
     * @param  array<int, array<string, mixed>>  $blocks
     */
    private function blocksToText(array $blocks): string
    {
        $lines = [];

        foreach ($blocks as $block) {
            if (! is_array($block)) {
                continue;
            }

            $lines[] = $this->plainText(implode(' ', array_filter([
                Arr::get($block, 'source'),
                Arr::get($block, 'title'),
                Arr::get($block, 'text'),
                Arr::get($block, 'html'),
                Arr::get($block, 'desc'),
                Arr::get($block, 'body'),
                Arr::get($block, 'caption'),
                Arr::get($block, 'path'),
                Arr::get($block, 'url'),
            ])));
        }

        return trim(implode("\n\n", array_filter($lines)));
    }

    private function plainText(mixed $value): string
    {
        $value = (string) $value;
        $value = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $value) ?? $value;
        $value = strip_tags($value);
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace("/\r\n|\r/", "\n", $value) ?? $value;
        $value = preg_replace('/[ \t]+/', ' ', $value) ?? $value;
        $value = preg_replace('/\n{3,}/', "\n\n", $value) ?? $value;

        return trim($value);
    }

    private function youtubeEmbedId(string $url): ?string
    {
        $normalizedUrl = preg_match('#^https?://#i', $url) === 1 ? $url : 'https://'.$url;

        try {
            $parsed = parse_url($normalizedUrl);
            if (! is_array($parsed)) {
                return null;
            }

            $host = Str::lower((string) ($parsed['host'] ?? ''));
            $host = preg_replace('/^www\./i', '', $host) ?? $host;
            $path = (string) ($parsed['path'] ?? '');

            if ($host === 'youtu.be') {
                return trim($path, '/') ?: null;
            }

            if ($host === 'youtube.com' || $host === 'm.youtube.com') {
                parse_str((string) ($parsed['query'] ?? ''), $query);
                if (! empty($query['v'])) {
                    return (string) $query['v'];
                }

                if (preg_match('#^/embed/([^/?]+)#', $path, $matches) === 1) {
                    return $matches[1];
                }

                if (preg_match('#^/shorts/([^/?]+)#', $path, $matches) === 1) {
                    return $matches[1];
                }
            }
        } catch (\Throwable) {
            return null;
        }

        return null;
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function isVideoEmbed(array $block, string $url): bool
    {
        if (str_starts_with((string) ($block['mimeType'] ?? ''), 'video/')) {
            return true;
        }

        $path = (string) parse_url($url, PHP_URL_PATH);

        return (bool) preg_match('/\.(mp4|webm|ogg)$/i', $path);
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function isPdfEmbed(array $block, string $url): bool
    {
        if ((string) ($block['mimeType'] ?? '') === 'application/pdf') {
            return true;
        }

        $path = (string) parse_url($url, PHP_URL_PATH);

        return (bool) preg_match('/\.pdf$/i', $path);
    }

    /**
     * @return list<string>
     */
    private function wrapPdfLines(string $text, int $width): array
    {
        if ($text === '') {
            return [];
        }

        $lines = [];

        foreach (explode("\n", $text) as $line) {
            $wrapped = wordwrap($line, $width, "\n", true);
            array_push($lines, ...explode("\n", $wrapped));
        }

        return $lines;
    }

    /**
     * @param  list<string>  $lines
     */
    private function buildPdf(string $title, array $lines): string
    {
        $objects = [
            1 => '<< /Type /Catalog /Pages 2 0 R >>',
            3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
            4 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
        ];
        $pageObjectIds = [];
        $pages = array_chunk($lines, 44);

        if ($pages === []) {
            $pages = [[]];
        }

        $nextObject = 5;
        $totalPages = count($pages);

        foreach ($pages as $index => $pageLines) {
            $pageObject = $nextObject++;
            $contentObject = $nextObject++;
            $pageObjectIds[] = $pageObject.' 0 R';
            $stream = $this->pdfStream($title, $pageLines, $index + 1, $totalPages);
            $objects[$pageObject] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '.$contentObject.' 0 R >>';
            $objects[$contentObject] = '<< /Length '.strlen($stream)." >>\nstream\n{$stream}\nendstream";
        }

        $objects[2] = '<< /Type /Pages /Kids ['.implode(' ', $pageObjectIds).'] /Count '.count($pageObjectIds).' >>';
        ksort($objects);

        $pdf = "%PDF-1.4\n";
        $offsets = [];

        foreach ($objects as $number => $body) {
            $offsets[$number] = strlen($pdf);
            $pdf .= $number." 0 obj\n".$body."\nendobj\n";
        }

        $xrefStart = strlen($pdf);
        $maxObject = max(array_keys($objects));
        $pdf .= "xref\n0 ".($maxObject + 1)."\n";
        $pdf .= "0000000000 65535 f \n";

        for ($number = 1; $number <= $maxObject; $number++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$number] ?? 0);
        }

        $pdf .= "trailer\n<< /Size ".($maxObject + 1)." /Root 1 0 R >>\nstartxref\n{$xrefStart}\n%%EOF";

        return $pdf;
    }

    /**
     * @param  list<string>  $lines
     */
    private function pdfStream(string $title, array $lines, int $pageNumber, int $totalPages): string
    {
        $printedAt = now()->format('Y-m-d H:i');
        $pageLabel = 'Page '.$pageNumber.' of '.$totalPages;

        $commands = [
            'BT',
            '/F2 20 Tf',
            '1 0 0 1 54 754 Tm',
            '('.$this->pdfText($title).') Tj',
            '/F1 10 Tf',
            '1 0 0 1 54 736 Tm',
            '(Exported '.$this->pdfText($printedAt).') Tj',
            '/F1 10 Tf',
            '1 0 0 1 470 754 Tm',
            '('.$this->pdfText($pageLabel).') Tj',
            '/F1 11 Tf',
            '1 0 0 1 54 704 Tm',
        ];

        foreach ($lines as $line) {
            $trimmed = trim($line);

            if ($trimmed === '') {
                $commands[] = '0 -10 Td';

                continue;
            }

            if (str_starts_with($trimmed, '## ')) {
                $commands[] = '/F2 14 Tf';
                $commands[] = '('.$this->pdfText(Str::after($trimmed, '## ')).') Tj';
                $commands[] = '/F1 11 Tf';
                $commands[] = '0 -18 Td';

                continue;
            }

            if (str_starts_with($trimmed, 'PATH ')) {
                $commands[] = '/F1 9 Tf';
                $commands[] = '('.$this->pdfText(Str::replaceFirst('PATH ', '', $trimmed)).') Tj';
                $commands[] = '/F1 11 Tf';
                $commands[] = '0 -14 Td';

                continue;
            }

            $commands[] = '('.$this->pdfText($line).') Tj';
            $commands[] = '0 -14 Td';
        }

        $commands[] = 'ET';

        return implode("\n", $commands);
    }

    private function pdfText(string $value): string
    {
        $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
        $value = preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value) ?? $value;

        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', ' ', ' '], $value);
    }
}
