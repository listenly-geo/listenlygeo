<?php

namespace App\Actions\Docs;

use App\Models\Page;
use App\Models\PageRevision;
use Illuminate\Support\Str;
use InvalidArgumentException;

class ExportPageDocument
{
    /**
     * @return array{content: string, filename: string, contentType: string, format: string}
     */
    public function __invoke(Page $page, string $format): array
    {
        $format = $this->normalizeFormat($format);
        $revision = $page->currentRevision;

        abort_unless($revision instanceof PageRevision, 404, 'The page has no saved revision to export.');

        $baseFilename = Str::slug($revision->title ?: $page->title ?: 'page') ?: 'page';

        return match ($format) {
            'markdown' => [
                'content' => $this->toMarkdown($page, $revision),
                'filename' => $baseFilename.'.md',
                'contentType' => 'text/markdown; charset=UTF-8',
                'format' => $format,
            ],
            'html' => [
                'content' => $this->toHtml($page, $revision),
                'filename' => $baseFilename.'.html',
                'contentType' => 'text/html; charset=UTF-8',
                'format' => $format,
            ],
            'json' => [
                'content' => json_encode($this->payload($page, $revision), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                'filename' => $baseFilename.'.json',
                'contentType' => 'application/json; charset=UTF-8',
                'format' => $format,
            ],
            'pdf' => [
                'content' => $this->toPdf($page, $revision),
                'filename' => $baseFilename.'.pdf',
                'contentType' => 'application/pdf',
                'format' => $format,
            ],
        };
    }

    public function normalizeFormat(string $format): string
    {
        $format = Str::lower(trim($format));

        return match ($format) {
            'md', 'markdown' => 'markdown',
            'html' => 'html',
            'json' => 'json',
            'pdf' => 'pdf',
            default => throw new InvalidArgumentException('Unsupported export format.'),
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function payload(Page $page, PageRevision $revision): array
    {
        return [
            'page' => [
                'id' => $page->id,
                'title' => $revision->title ?: $page->title,
                'subtitle' => $revision->subtitle,
                'slug' => $page->slug,
                'path' => $page->path,
                'status' => $page->status,
            ],
            'site' => [
                'id' => $page->site?->id,
                'name' => $page->site?->name,
                'slug' => $page->site?->slug,
            ],
            'space' => [
                'id' => $page->space?->id,
                'name' => $page->space?->name,
                'slug' => $page->space?->slug,
            ],
            'revision' => [
                'id' => $revision->id,
                'version' => $revision->version_number,
                'createdAt' => $revision->created_at?->toJSON(),
            ],
            'blocks' => $revision->blocks_json ?? [],
            'exportedAt' => now()->toJSON(),
        ];
    }

    private function toMarkdown(Page $page, PageRevision $revision): string
    {
        $lines = ['# '.$this->plainText($revision->title ?: $page->title ?: 'Untitled')];

        if (filled($revision->subtitle)) {
            $lines[] = '';
            $lines[] = $this->plainText($revision->subtitle);
        }

        foreach ($this->blocks($revision) as $block) {
            $markdown = $this->blockToMarkdown($block);

            if ($markdown === '') {
                continue;
            }

            $lines[] = '';
            array_push($lines, ...explode("\n", $markdown));
        }

        return rtrim(implode("\n", $lines))."\n";
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockToMarkdown(array $block): string
    {
        $kind = (string) ($block['kind'] ?? 'p');

        return match ($kind) {
            'h1', 'h2', 'h3' => str_repeat('#', (int) substr($kind, 1)).' '.$this->inlineMarkdown($block['text'] ?? ''),
            'p' => $this->inlineMarkdown($block['html'] ?? ''),
            'quote' => $this->quoteMarkdown($block['html'] ?? ''),
            'divider' => '---',
            'code' => $this->codeMarkdown($block),
            'callout' => $this->calloutMarkdown($block),
            'figure' => $this->figureMarkdown($block),
            'table' => $this->tableMarkdown($block),
            'tabs' => $this->tabsMarkdown($block),
            'expand' => $this->expandMarkdown($block),
            'cards' => $this->cardsMarkdown($block),
            'api' => $this->apiMarkdown($block),
            'math' => $this->plainText(data_get($block, 'expr.raw', '')),
            'embed' => $this->embedMarkdown($block),
            'checklist' => $this->checklistMarkdown($block),
            default => $this->plainText(implode(' ', array_filter([
                $block['title'] ?? null,
                $block['text'] ?? null,
                $block['html'] ?? null,
                $block['desc'] ?? null,
                $block['body'] ?? null,
            ]))),
        };
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function codeMarkdown(array $block): string
    {
        $lang = preg_replace('/[^a-z0-9_-]/i', '', (string) ($block['lang'] ?? '')) ?: '';
        $filename = $this->plainText($block['filename'] ?? '');
        $code = str_replace("\r\n", "\n", (string) ($block['code'] ?? ''));

        return ($filename !== '' ? $filename."\n" : '').'```'.$lang."\n".$code."\n```";
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function calloutMarkdown(array $block): string
    {
        $variant = Str::upper((string) ($block['variant'] ?? 'note'));
        $label = match ($variant) {
            'WARN' => 'WARNING',
            'OK' => 'TIP',
            'DANGER' => 'CAUTION',
            default => 'NOTE',
        };

        $parts = array_filter([
            $this->inlineMarkdown($block['title'] ?? ''),
            $this->inlineMarkdown($block['text'] ?? ''),
        ]);

        return '> [!'.$label.']'.(empty($parts) ? '' : "\n> ".implode("\n> ", $parts));
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function figureMarkdown(array $block): string
    {
        $alt = $this->plainText($block['alt'] ?? '');
        $src = trim((string) ($block['src'] ?? ''));
        $caption = $this->inlineMarkdown($block['caption'] ?? '');

        return trim(($src !== '' ? '!['.$alt.']('.$src.')' : $alt).($caption !== '' ? "\n\n_{$caption}_" : ''));
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function tableMarkdown(array $block): string
    {
        $headers = array_values(array_map(fn ($header) => $this->tableCell($header), is_array($block['headers'] ?? null) ? $block['headers'] : []));
        $rows = array_values(array_map(fn ($row) => array_map(fn ($cell) => $this->tableCell($cell), is_array($row) ? $row : []), is_array($block['rows'] ?? null) ? $block['rows'] : []));

        if ($headers === [] && $rows === []) {
            return '';
        }

        $columnCount = max(count($headers), ...array_map('count', $rows ?: [[]]));
        $headers = array_pad($headers, $columnCount, '');

        $lines = [
            '| '.implode(' | ', $headers).' |',
            '| '.implode(' | ', array_fill(0, $columnCount, '---')).' |',
        ];

        foreach ($rows as $row) {
            $lines[] = '| '.implode(' | ', array_pad($row, $columnCount, '')).' |';
        }

        return implode("\n", $lines);
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function tabsMarkdown(array $block): string
    {
        $parts = [];

        foreach (($block['tabs'] ?? []) as $tab) {
            if (! is_array($tab)) {
                continue;
            }

            $label = $this->plainText($tab['label'] ?? 'Tab');
            $lang = preg_replace('/[^a-z0-9_-]/i', '', (string) ($tab['lang'] ?? '')) ?: '';
            $parts[] = '### '.$label."\n\n```{$lang}\n".str_replace("\r\n", "\n", (string) ($tab['code'] ?? ''))."\n```";
        }

        return implode("\n\n", $parts);
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function expandMarkdown(array $block): string
    {
        $title = $this->plainText($block['title'] ?? 'Details');
        $body = $this->inlineMarkdown($block['body'] ?? '');

        return "<details>\n<summary>{$title}</summary>\n\n{$body}\n\n</details>";
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function cardsMarkdown(array $block): string
    {
        return collect($block['items'] ?? [])
            ->filter(fn ($item) => is_array($item))
            ->map(fn ($item) => '- **'.$this->inlineMarkdown($item['title'] ?? 'Card').'**'.(filled($item['desc'] ?? null) ? ': '.$this->inlineMarkdown($item['desc']) : ''))
            ->implode("\n");
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function apiMarkdown(array $block): string
    {
        $lines = ['```http', trim(($block['method'] ?? 'GET').' '.($block['path'] ?? '/')), '```'];
        $desc = $this->inlineMarkdown($block['desc'] ?? '');

        if ($desc !== '') {
            $lines[] = '';
            $lines[] = $desc;
        }

        foreach (($block['params'] ?? []) as $param) {
            if (! is_array($param)) {
                continue;
            }

            $lines[] = '- `'.$this->plainText($param['name'] ?? 'param').'` '.$this->plainText($param['type'] ?? '').': '.$this->inlineMarkdown($param['desc'] ?? '');
        }

        return implode("\n", array_filter($lines, fn ($line) => $line !== null));
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function embedMarkdown(array $block): string
    {
        $title = $this->plainText($block['title'] ?? $block['source'] ?? 'Embed');
        $url = trim((string) ($block['url'] ?? ''));

        return $url !== '' ? '['.$title.']('.$url.')' : $title;
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function checklistMarkdown(array $block): string
    {
        return collect($block['items'] ?? [])
            ->filter(fn ($item) => is_array($item))
            ->map(fn ($item) => '- ['.(! empty($item['done']) ? 'x' : ' ').'] '.$this->inlineMarkdown($item['text'] ?? ''))
            ->implode("\n");
    }

    private function quoteMarkdown(mixed $value): string
    {
        return collect(explode("\n", $this->inlineMarkdown($value)))
            ->map(fn ($line) => '> '.$line)
            ->implode("\n");
    }

    private function toHtml(Page $page, PageRevision $revision): string
    {
        $title = e($revision->title ?: $page->title ?: 'Untitled');
        $subtitle = filled($revision->subtitle) ? '<p class="subtitle">'.$this->inlineHtml($revision->subtitle).'</p>' : '';
        $blocks = collect($this->blocks($revision))->map(fn ($block) => $this->blockToHtml($block))->filter()->implode("\n");

        return <<<HTML
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{$title}</title>
    <style>
        body { font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; line-height: 1.65; color: #1f2937; max-width: 820px; margin: 48px auto; padding: 0 24px; }
        h1, h2, h3 { line-height: 1.22; color: #111827; }
        h1 { font-size: 2.25rem; margin-bottom: 0.3em; }
        h2 { margin-top: 2rem; }
        .subtitle { color: #64748b; font-size: 1.1rem; margin-top: 0; }
        pre { background: #0f172a; color: #e2e8f0; border-radius: 8px; padding: 16px; overflow: auto; }
        code { font-family: "SFMono-Regular", Consolas, monospace; }
        blockquote, .callout { border-left: 4px solid #6366f1; padding-left: 16px; color: #475569; margin-left: 0; }
        table { border-collapse: collapse; width: 100%; margin: 1rem 0; }
        th, td { border: 1px solid #d8dee9; padding: 8px 10px; text-align: left; }
        th { background: #f8fafc; }
        img { max-width: 100%; height: auto; }
        figure { margin: 1.5rem 0; }
        figcaption { color: #64748b; font-size: 0.92rem; }
        .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; }
        .card { border: 1px solid #d8dee9; border-radius: 8px; padding: 14px; }
    </style>
</head>
<body>
    <article>
        <h1>{$title}</h1>
        {$subtitle}
        {$blocks}
    </article>
</body>
</html>
HTML;
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockToHtml(array $block): string
    {
        $kind = (string) ($block['kind'] ?? 'p');

        return match ($kind) {
            'h1', 'h2', 'h3' => '<'.$kind.'>'.$this->inlineHtml($block['text'] ?? '').'</'.$kind.'>',
            'p' => '<p>'.$this->inlineHtml($block['html'] ?? '').'</p>',
            'quote' => '<blockquote>'.$this->inlineHtml($block['html'] ?? '').'</blockquote>',
            'divider' => '<hr>',
            'code' => '<pre><code class="language-'.e((string) ($block['lang'] ?? '')).'">'.e((string) ($block['code'] ?? '')).'</code></pre>',
            'callout' => '<aside class="callout"><strong>'.$this->inlineHtml($block['title'] ?? 'Note').'</strong><p>'.$this->inlineHtml($block['text'] ?? '').'</p></aside>',
            'figure' => $this->figureHtml($block),
            'table' => $this->tableHtml($block),
            'tabs' => $this->tabsHtml($block),
            'expand' => '<details><summary>'.$this->inlineHtml($block['title'] ?? 'Details').'</summary><p>'.$this->inlineHtml($block['body'] ?? '').'</p></details>',
            'cards' => $this->cardsHtml($block),
            'api' => $this->apiHtml($block),
            'math' => '<pre><code>'.e((string) data_get($block, 'expr.raw', '')).'</code></pre>',
            'embed' => '<p><a href="'.e((string) ($block['url'] ?? '#')).'">'.$this->inlineHtml($block['title'] ?? $block['source'] ?? 'Embed').'</a></p>',
            'checklist' => '<ul>'.collect($block['items'] ?? [])->filter(fn ($item) => is_array($item))->map(fn ($item) => '<li>'.(! empty($item['done']) ? '[x] ' : '[ ] ').$this->inlineHtml($item['text'] ?? '').'</li>')->implode('').'</ul>',
            default => '<p>'.$this->inlineHtml($this->plainText(implode(' ', array_filter([$block['title'] ?? null, $block['text'] ?? null, $block['html'] ?? null, $block['desc'] ?? null, $block['body'] ?? null])))).'</p>',
        };
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function figureHtml(array $block): string
    {
        $image = filled($block['src'] ?? null)
            ? '<img src="'.e((string) $block['src']).'" alt="'.e($this->plainText($block['alt'] ?? '')).'">'
            : '';
        $caption = filled($block['caption'] ?? null) ? '<figcaption>'.$this->inlineHtml($block['caption']).'</figcaption>' : '';

        return '<figure>'.$image.$caption.'</figure>';
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function tableHtml(array $block): string
    {
        $headers = collect($block['headers'] ?? [])->map(fn ($header) => '<th>'.$this->inlineHtml($header).'</th>')->implode('');
        $rows = collect($block['rows'] ?? [])->filter(fn ($row) => is_array($row))->map(function ($row) {
            return '<tr>'.collect($row)->map(fn ($cell) => '<td>'.$this->inlineHtml($cell).'</td>')->implode('').'</tr>';
        })->implode('');

        return '<table><thead><tr>'.$headers.'</tr></thead><tbody>'.$rows.'</tbody></table>';
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function tabsHtml(array $block): string
    {
        return collect($block['tabs'] ?? [])->filter(fn ($tab) => is_array($tab))->map(function ($tab) {
            return '<section><h3>'.$this->inlineHtml($tab['label'] ?? 'Tab').'</h3><pre><code class="language-'.e((string) ($tab['lang'] ?? '')).'">'.e((string) ($tab['code'] ?? '')).'</code></pre></section>';
        })->implode('');
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function cardsHtml(array $block): string
    {
        return '<div class="cards">'.collect($block['items'] ?? [])->filter(fn ($item) => is_array($item))->map(function ($item) {
            return '<div class="card"><strong>'.$this->inlineHtml($item['title'] ?? 'Card').'</strong><p>'.$this->inlineHtml($item['desc'] ?? '').'</p></div>';
        })->implode('').'</div>';
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function apiHtml(array $block): string
    {
        $params = collect($block['params'] ?? [])->filter(fn ($param) => is_array($param))->map(function ($param) {
            return '<li><code>'.e($this->plainText($param['name'] ?? 'param')).'</code> '.e($this->plainText($param['type'] ?? '')).' - '.$this->inlineHtml($param['desc'] ?? '').'</li>';
        })->implode('');

        return '<pre><code>'.e(trim(($block['method'] ?? 'GET').' '.($block['path'] ?? '/'))).'</code></pre><p>'.$this->inlineHtml($block['desc'] ?? '').'</p><ul>'.$params.'</ul>';
    }

    private function toPdf(Page $page, PageRevision $revision): string
    {
        $lines = $this->wrapPdfLines($this->plainText($revision->subtitle ?? ''), 86);

        foreach ($this->blocks($revision) as $block) {
            $text = $this->blockToPlainText($block);
            if ($text === '') {
                continue;
            }

            $lines[] = '';
            array_push($lines, ...$this->wrapPdfLines($text, 86));
        }

        return $this->buildPdf($this->plainText($revision->title ?: $page->title ?: 'Untitled'), $lines);
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockToPlainText(array $block): string
    {
        $kind = (string) ($block['kind'] ?? 'p');

        return match ($kind) {
            'h1', 'h2', 'h3' => $this->plainText($block['text'] ?? ''),
            'p', 'quote' => $this->plainText($block['html'] ?? ''),
            'code' => trim(implode("\n", array_filter([$block['filename'] ?? null, $block['code'] ?? null]))),
            'callout' => trim($this->plainText($block['title'] ?? 'Note')."\n".$this->plainText($block['text'] ?? '')),
            'figure' => trim($this->plainText($block['alt'] ?? '')."\n".$this->plainText($block['caption'] ?? '')),
            'table' => collect([$block['headers'] ?? [], ...(is_array($block['rows'] ?? null) ? $block['rows'] : [])])->filter(fn ($row) => is_array($row))->map(fn ($row) => implode(' | ', array_map(fn ($cell) => $this->plainText($cell), $row)))->implode("\n"),
            'tabs' => collect($block['tabs'] ?? [])->filter(fn ($tab) => is_array($tab))->map(fn ($tab) => $this->plainText($tab['label'] ?? 'Tab')."\n".($tab['code'] ?? ''))->implode("\n\n"),
            'expand' => trim($this->plainText($block['title'] ?? 'Details')."\n".$this->plainText($block['body'] ?? '')),
            'cards' => collect($block['items'] ?? [])->filter(fn ($item) => is_array($item))->map(fn ($item) => trim($this->plainText($item['title'] ?? '').': '.$this->plainText($item['desc'] ?? '')))->implode("\n"),
            'api' => trim(($block['method'] ?? 'GET').' '.($block['path'] ?? '/')."\n".$this->plainText($block['desc'] ?? '')),
            'math' => $this->plainText(data_get($block, 'expr.raw', '')),
            'embed' => trim($this->plainText($block['title'] ?? $block['source'] ?? 'Embed').' '.($block['url'] ?? '')),
            'checklist' => collect($block['items'] ?? [])->filter(fn ($item) => is_array($item))->map(fn ($item) => (! empty($item['done']) ? '[x] ' : '[ ] ').$this->plainText($item['text'] ?? ''))->implode("\n"),
            default => $this->plainText(implode(' ', array_filter([$block['title'] ?? null, $block['text'] ?? null, $block['html'] ?? null, $block['desc'] ?? null, $block['body'] ?? null]))),
        };
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function blocks(PageRevision $revision): array
    {
        return array_values(array_filter($revision->blocks_json ?? [], fn ($block) => is_array($block)));
    }

    private function inlineMarkdown(mixed $value): string
    {
        $html = (string) $value;
        $html = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $html) ?? $html;
        $html = preg_replace('/<\s*(strong|b)\b[^>]*>(.*?)<\s*\/\s*\1\s*>/is', '**$2**', $html) ?? $html;
        $html = preg_replace('/<\s*(em|i)\b[^>]*>(.*?)<\s*\/\s*\1\s*>/is', '*$2*', $html) ?? $html;
        $html = preg_replace('/<\s*code\b[^>]*>(.*?)<\s*\/\s*code\s*>/is', '`$1`', $html) ?? $html;
        $html = preg_replace_callback('/<\s*a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\s*\/\s*a\s*>/is', function (array $matches) {
            return '['.$this->plainText($matches[2]).']('.$matches[1].')';
        }, $html) ?? $html;

        return $this->plainText($html);
    }

    private function inlineHtml(mixed $value): string
    {
        $html = (string) $value;
        $html = preg_replace('/<\s*(script|style)\b[^>]*>.*?<\s*\/\s*\1\s*>/is', '', $html) ?? $html;
        $html = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html) ?? $html;
        $html = preg_replace('/javascript\s*:/i', '', $html) ?? $html;

        return strip_tags($html, '<a><strong><b><em><i><code><kbd><br><span><u><s>');
    }

    private function plainText(mixed $value): string
    {
        $value = (string) $value;
        $value = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $value) ?? $value;
        $value = strip_tags($value);
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace("/\r\n|\r/", "\n", $value) ?? $value;
        $value = preg_replace('/[ \t]+/', ' ', $value) ?? $value;
        $value = preg_replace('/\n{3,}/', "\n\n", $value) ?? $value;

        return trim($value);
    }

    private function tableCell(mixed $value): string
    {
        return str_replace('|', '\\|', $this->inlineMarkdown($value));
    }

    /**
     * @return list<string>
     */
    private function wrapPdfLines(string $text, int $width): array
    {
        if ($text === '') {
            return [];
        }

        $lines = [];

        foreach (explode("\n", $text) as $line) {
            $wrapped = wordwrap($line, $width, "\n", true);
            array_push($lines, ...explode("\n", $wrapped));
        }

        return $lines;
    }

    /**
     * @param  list<string>  $lines
     */
    private function buildPdf(string $title, array $lines): string
    {
        $objects = [
            1 => '<< /Type /Catalog /Pages 2 0 R >>',
            3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
        ];
        $pageObjectIds = [];
        $pages = array_chunk($lines, 46);

        if ($pages === []) {
            $pages = [[]];
        }

        $nextObject = 4;

        foreach ($pages as $index => $pageLines) {
            $pageObject = $nextObject++;
            $contentObject = $nextObject++;
            $pageObjectIds[] = $pageObject.' 0 R';
            $stream = $this->pdfStream($index === 0 ? $title : $title.' (continued)', $pageLines);
            $objects[$pageObject] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents '.$contentObject.' 0 R >>';
            $objects[$contentObject] = '<< /Length '.strlen($stream)." >>\nstream\n{$stream}\nendstream";
        }

        $objects[2] = '<< /Type /Pages /Kids ['.implode(' ', $pageObjectIds).'] /Count '.count($pageObjectIds).' >>';
        ksort($objects);

        $pdf = "%PDF-1.4\n";
        $offsets = [];

        foreach ($objects as $number => $body) {
            $offsets[$number] = strlen($pdf);
            $pdf .= $number." 0 obj\n".$body."\nendobj\n";
        }

        $xrefStart = strlen($pdf);
        $maxObject = max(array_keys($objects));
        $pdf .= "xref\n0 ".($maxObject + 1)."\n";
        $pdf .= "0000000000 65535 f \n";

        for ($number = 1; $number <= $maxObject; $number++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$number] ?? 0);
        }

        $pdf .= "trailer\n<< /Size ".($maxObject + 1)." /Root 1 0 R >>\nstartxref\n{$xrefStart}\n%%EOF";

        return $pdf;
    }

    /**
     * @param  list<string>  $lines
     */
    private function pdfStream(string $title, array $lines): string
    {
        $commands = [
            'BT',
            '/F1 18 Tf',
            '54 740 Td',
            '('.$this->pdfText($title).') Tj',
            '/F1 11 Tf',
            '0 -30 Td',
        ];

        foreach ($lines as $line) {
            $commands[] = '('.$this->pdfText($line).') Tj';
            $commands[] = '0 -14 Td';
        }

        $commands[] = 'ET';

        return implode("\n", $commands);
    }

    private function pdfText(string $value): string
    {
        $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
        $value = preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value) ?? $value;

        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', ' ', ' '], $value);
    }
}
