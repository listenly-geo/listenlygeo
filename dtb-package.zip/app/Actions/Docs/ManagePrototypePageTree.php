<?php

namespace App\Actions\Docs;

use App\Models\Page;
use App\Models\Site;
use App\Models\Space;
use App\Models\User;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class ManagePrototypePageTree
{
    public function __construct(
        private readonly AutosavePageRevision $autosavePageRevision,
    ) {}

    /**
     * @return array<string, mixed>
     */
    public function create(Site $site, User $user, ?Page $parentPage = null, ?Space $space = null): array
    {
        return DB::transaction(function () use ($site, $user, $parentPage, $space) {
            $space = $parentPage?->space ?: $space ?: $this->resolveDefaultSpace($site);
            [$slug, $path] = $this->availableSlugAndPath($site->id, $parentPage?->path, 'untitled');

            $page = Page::query()->create([
                'site_id' => $site->id,
                'space_id' => $space->id,
                'parent_id' => $parentPage?->id,
                'title' => 'Untitled',
                'slug' => $slug,
                'path' => $path,
                'icon' => 'page',
                'position' => $this->nextPosition($site->id, $space->id, $parentPage?->id),
                'status' => 'draft',
                'created_by' => $user->id,
                'updated_by' => $user->id,
            ]);

            ($this->autosavePageRevision)($page, $user, [
                'title' => 'Untitled',
                'subtitle' => '',
                'blocks' => $this->defaultBlocks($page),
                'editorMeta' => ['readTime' => '1 min'],
            ]);

            return $this->pagePayload($page->fresh(['currentRevision', 'creator']), $user);
        });
    }

    /**
     * @return array<string, mixed>
     */
    public function rename(Page $page, User $user, string $title): array
    {
        return DB::transaction(function () use ($page, $user, $title) {
            $page->loadMissing(['parent', 'currentRevision', 'creator']);

            $cleanTitle = $this->normalizeTitle($title);
            $currentRevision = $page->currentRevision;

            ($this->autosavePageRevision)($page, $user, [
                'title' => $cleanTitle,
                'subtitle' => $currentRevision?->subtitle ?? '',
                'blocks' => $currentRevision?->blocks_json ?? $this->defaultBlocks($page),
                'editorMeta' => $currentRevision?->editor_meta_json ?? ['readTime' => '1 min'],
            ]);

            $page->refresh()->loadMissing(['parent', 'children', 'currentRevision', 'creator']);

            [$slug, $path] = $this->availableSlugAndPath($page->site_id, $page->parent?->path, $cleanTitle, $page->id);

            $page->forceFill([
                'slug' => $slug,
                'path' => $path,
                'updated_by' => $user->id,
            ])->save();

            $this->syncDescendantPaths($page, $user);

            return $this->pagePayload($page->fresh(['currentRevision', 'creator']), $user);
        });
    }

    /**
     * @return array<string, mixed>
     */
    public function move(Page $page, Page $targetPage, string $position, User $user): array
    {
        return DB::transaction(function () use ($page, $targetPage, $position, $user) {
            if ($page->site_id !== $targetPage->site_id) {
                throw ValidationException::withMessages([
                    'targetPageId' => 'The selected target page is invalid.',
                ]);
            }

            if ($page->id === $targetPage->id) {
                throw ValidationException::withMessages([
                    'targetPageId' => 'A page cannot be moved relative to itself.',
                ]);
            }

            $newParentId = $position === 'inside' ? $targetPage->id : $targetPage->parent_id;
            $newSpaceId = $targetPage->space_id;

            $this->assertNoCycle($page, $newParentId);

            $oldParentId = $page->parent_id;
            $oldSpaceId = $page->space_id;

            $page->forceFill([
                'parent_id' => $newParentId,
                'space_id' => $newSpaceId,
                'updated_by' => $user->id,
            ])->save();

            $orderedIds = Page::query()
                ->where('site_id', $page->site_id)
                ->where('space_id', $newSpaceId)
                ->when(
                    $newParentId === null,
                    fn ($query) => $query->whereNull('parent_id'),
                    fn ($query) => $query->where('parent_id', $newParentId),
                )
                ->where('id', '!=', $page->id)
                ->orderBy('position')
                ->orderBy('id')
                ->pluck('id')
                ->all();

            $insertIndex = count($orderedIds);

            if ($position !== 'inside') {
                $targetIndex = array_search($targetPage->id, $orderedIds, true);

                if ($targetIndex === false) {
                    throw ValidationException::withMessages([
                        'targetPageId' => 'The selected target page is invalid.',
                    ]);
                }

                $insertIndex = $position === 'before' ? $targetIndex : $targetIndex + 1;
            }

            array_splice($orderedIds, $insertIndex, 0, [$page->id]);

            $this->resequenceOrderedIds($orderedIds);

            if ($oldParentId !== $newParentId || $oldSpaceId !== $newSpaceId) {
                $this->resequenceGroup($page->site_id, $oldSpaceId, $oldParentId);
            }

            $page->refresh()->loadMissing(['parent', 'children', 'currentRevision', 'creator']);

            [$slug, $path] = $this->availableSlugAndPath(
                $page->site_id,
                $page->parent?->path,
                $page->slug ?: $page->title,
                $page->id,
            );

            $page->forceFill([
                'slug' => $slug,
                'path' => $path,
            ])->save();

            $this->syncDescendantPaths($page, $user);

            return $this->pagePayload($page->fresh(['currentRevision', 'creator']), $user);
        });
    }

    public function delete(Page $page, User $user): void
    {
        DB::transaction(function () use ($page, $user) {
            $oldParentId = $page->parent_id;
            $oldSpaceId = $page->space_id;

            $pages = Page::query()
                ->where('site_id', $page->site_id)
                ->where(function ($query) use ($page) {
                    $query->where('id', $page->id)
                        ->orWhere('path', 'like', $page->path.'/%');
                })
                ->get()
                ->sortByDesc(fn (Page $candidate) => substr_count($candidate->path, '/'));

            foreach ($pages as $candidate) {
                $candidate->forceFill([
                    'updated_by' => $user->id,
                ])->save();

                $candidate->delete();
            }

            $this->resequenceGroup($page->site_id, $oldSpaceId, $oldParentId);
        });
    }

    /**
     * @return array<string, mixed>
     */
    private function pagePayload(Page $page, User $user): array
    {
        $revision = $page->currentRevision;
        $author = $page->creator ?: $user;
        $viewCount = $this->viewCountFor($revision?->editor_meta_json ?? []);
        $commentCount = $page->comments()->count();

        return [
            'id' => $this->pageKey($page->id),
            'dbId' => $page->id,
            'spaceId' => $this->spaceKey($page->space_id),
            'path' => $page->path,
            'title' => $revision?->title ?: $page->title,
            'icon' => $page->icon ?: 'page',
            'parentId' => $page->parent_id ? $this->pageKey($page->parent_id) : null,
            'content' => [
                'title' => $revision?->title ?: $page->title,
                'subtitle' => $revision?->subtitle ?: '',
                'path' => $page->path,
                'updated' => ($revision?->updated_at ?: $page->updated_at)?->format('M j, Y'),
                'readTime' => Arr::get($revision?->editor_meta_json, 'readTime', '1 min'),
                'viewCount' => $viewCount,
                'commentCount' => $commentCount,
                'stats' => [
                    'views' => $viewCount,
                    'comments' => $commentCount,
                ],
                'publishedSnapshot' => null,
                'publishChanges' => [
                    'added' => 0,
                    'removed' => 0,
                    'status' => 'unpublished',
                ],
                'author' => [
                    'name' => $author->name,
                    'role' => 'Editor',
                    'initials' => $this->initials($author->name),
                    'color' => 'oklch(55% 0.14 255)',
                ],
                'collaborators' => [[
                    'name' => $author->name,
                    'initials' => $this->initials($author->name),
                    'color' => 'oklch(55% 0.14 255)',
                ]],
                'blocks' => $revision?->blocks_json ?? $this->defaultBlocks($page),
            ],
        ];
    }

    private function resolveDefaultSpace(Site $site): Space
    {
        return $site->defaultSpace
            ?: $site->spaces()->orderBy('position')->oldest('id')->firstOrFail();
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function availableSlugAndPath(int $siteId, ?string $parentPath, string $source, ?int $ignorePageId = null): array
    {
        $baseSlug = Str::slug($source) ?: 'untitled';
        $candidateSlug = $baseSlug;
        $suffix = 2;

        while (true) {
            $candidatePath = $parentPath ? $parentPath.'/'.$candidateSlug : $candidateSlug;

            $exists = Page::query()
                ->withTrashed()
                ->where('site_id', $siteId)
                ->where('path', $candidatePath)
                ->when(
                    $ignorePageId !== null,
                    fn ($query) => $query->where('id', '!=', $ignorePageId),
                )
                ->exists();

            if (! $exists) {
                return [$candidateSlug, $candidatePath];
            }

            $candidateSlug = $baseSlug.'-'.$suffix;
            $suffix++;
        }
    }

    private function nextPosition(int $siteId, int $spaceId, ?int $parentId): int
    {
        return (int) Page::query()
            ->where('site_id', $siteId)
            ->where('space_id', $spaceId)
            ->when(
                $parentId === null,
                fn ($query) => $query->whereNull('parent_id'),
                fn ($query) => $query->where('parent_id', $parentId),
            )
            ->max('position') + 1;
    }

    private function resequenceGroup(int $siteId, int $spaceId, ?int $parentId): void
    {
        $orderedIds = Page::query()
            ->where('site_id', $siteId)
            ->where('space_id', $spaceId)
            ->when(
                $parentId === null,
                fn ($query) => $query->whereNull('parent_id'),
                fn ($query) => $query->where('parent_id', $parentId),
            )
            ->orderBy('position')
            ->orderBy('id')
            ->pluck('id')
            ->all();

        $this->resequenceOrderedIds($orderedIds);
    }

    /**
     * @param  array<int, int>  $orderedIds
     */
    private function resequenceOrderedIds(array $orderedIds): void
    {
        foreach ($orderedIds as $index => $pageId) {
            Page::query()->whereKey($pageId)->update(['position' => $index]);
        }
    }

    private function syncDescendantPaths(Page $page, User $user): void
    {
        $children = $page->children()->orderBy('position')->orderBy('id')->get();

        foreach ($children as $child) {
            [$slug, $path] = $this->availableSlugAndPath($child->site_id, $page->path, $child->slug ?: $child->title, $child->id);

            $child->forceFill([
                'slug' => $slug,
                'path' => $path,
                'updated_by' => $user->id,
            ])->save();

            $this->syncDescendantPaths($child, $user);
        }
    }

    private function assertNoCycle(Page $page, ?int $newParentId): void
    {
        $cursorId = $newParentId;

        while ($cursorId !== null) {
            if ($cursorId === $page->id) {
                throw ValidationException::withMessages([
                    'targetPageId' => 'A page cannot be moved inside its own descendant.',
                ]);
            }

            $cursorId = Page::query()->whereKey($cursorId)->value('parent_id');
        }
    }

    /**
     * @return array<int, array<string, string>>
     */
    private function defaultBlocks(Page $page): array
    {
        return [[
            'id' => 'b_'.$page->id.'_1',
            'kind' => 'p',
            'html' => '',
        ]];
    }

    private function normalizeTitle(string $title): string
    {
        $clean = trim(strip_tags($title));

        return $clean !== '' ? $clean : 'Untitled';
    }

    private function pageKey(int $id): string
    {
        return 'p_'.$id;
    }

    private function spaceKey(int $id): string
    {
        return 'sp_'.$id;
    }

    /**
     * @param  array<string, mixed>  $editorMeta
     */
    private function viewCountFor(array $editorMeta): int
    {
        $value = Arr::get($editorMeta, 'viewCount')
            ?? Arr::get($editorMeta, 'views')
            ?? Arr::get($editorMeta, 'pageViews')
            ?? Arr::get($editorMeta, 'analytics.views')
            ?? 0;

        if (is_string($value)) {
            $value = preg_replace('/[^0-9]/', '', $value) ?: 0;
        }

        return max(0, (int) $value);
    }

    private function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $letters = collect($parts)
            ->filter()
            ->take(2)
            ->map(fn (string $part) => strtoupper(substr($part, 0, 1)));

        return $letters->implode('') ?: 'NA';
    }
}
