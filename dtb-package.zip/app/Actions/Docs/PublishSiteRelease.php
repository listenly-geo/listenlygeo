<?php

namespace App\Actions\Docs;

use App\Models\Page;
use App\Models\Release;
use App\Models\Site;
use App\Models\User;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class PublishSiteRelease
{
    public function __construct(
        private readonly SyncOrganizationUsageCounter $syncOrganizationUsageCounter,
    ) {}

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function __invoke(Site $site, User $user, array $payload = []): array
    {
        return DB::transaction(function () use ($site, $user, $payload) {
            $site->loadMissing([
                'organization',
                'pages' => fn ($query) => $query->orderBy('path')->orderBy('id'),
                'pages.currentRevision',
            ]);

            $environment = (string) ($payload['environment'] ?? 'production');
            $pages = $site->pages->filter(fn (Page $page) => $page->currentRevision !== null)->values();
            $release = Release::query()->create([
                'site_id' => $site->id,
                'version' => $this->nextVersion($site),
                'status' => 'published',
                'environment' => $environment,
                'message' => Arr::get($payload, 'message') ?: 'Published from prototype editor',
                'published_by' => $user->id,
                'published_at' => now(),
            ]);

            $createdAt = now();
            $snapshotRows = [];

            foreach ($pages as $page) {
                $revision = $page->currentRevision;

                $snapshotRows[] = [
                    'page_id' => $page->id,
                    'space_id' => $page->space_id,
                    'space_name' => $page->space?->name,
                    'title' => $revision->title,
                    'subtitle' => $revision->subtitle,
                    'path' => $page->path,
                    'parent_path' => $page->parent?->path,
                    'position' => $page->position,
                    'blocks_json' => $revision->blocks_json,
                    'search_document' => $revision->search_document,
                    'created_at' => $createdAt,
                    'updated_at' => $createdAt,
                ];

                $page->forceFill([
                    'published_revision_id' => $page->current_revision_id,
                    'updated_by' => $user->id,
                ])->save();
            }

            if ($snapshotRows !== []) {
                $release->pages()->createMany($snapshotRows);
            }

            $site->forceFill([
                'current_release_id' => $release->id,
                'status' => 'published',
                'updated_by' => $user->id,
            ])->save();

            ($this->syncOrganizationUsageCounter)($site->organization);

            return [
                'release' => [
                    'id' => $release->id,
                    'version' => $release->version,
                    'status' => $release->status,
                    'environment' => $release->environment,
                    'publishedAt' => $release->published_at?->toIso8601String(),
                ],
                'site' => [
                    'id' => $site->id,
                    'currentReleaseId' => $release->id,
                    'status' => 'published',
                ],
                'publishedPageCount' => count($snapshotRows),
                'publishedPath' => $pages->first()?->path ?? '',
                'publishedUrl' => route('docs.index', ['siteSlug' => $site->slug], false),
            ];
        });
    }

    private function nextVersion(Site $site): string
    {
        return 'v1.0.'.$site->releases()->count();
    }
}
