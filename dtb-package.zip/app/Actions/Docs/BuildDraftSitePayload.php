<?php

namespace App\Actions\Docs;

use App\Models\Page;
use App\Models\Site;
use App\Support\DocsTheme;
use App\Support\PlatformBranding;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

class BuildDraftSitePayload
{
    /**
     * @return array<string, mixed>
     */
    public function __invoke(Site $site, ?string $path = null): array
    {
        $site->loadMissing([
            'spaces' => fn ($query) => $query->orderBy('position')->orderBy('id'),
            'domains' => fn ($query) => $query->orderByDesc('is_primary')->orderBy('id'),
            'pages' => fn ($query) => $query->orderBy('position')->orderBy('path')->orderBy('id'),
            'pages.currentRevision.author',
            'pages.parent',
            'pages.space',
            'organization.subscription',
        ]);

        $pages = $site->pages
            ->filter(fn (Page $page) => $page->currentRevision !== null)
            ->values();

        $spacePositions = $site->spaces
            ->mapWithKeys(fn ($space) => [(int) $space->id => (int) $space->position])
            ->all();

        $ordered = $pages
            ->sortBy(fn (Page $page) => $this->sortKey($page, $spacePositions))
            ->values();

        abort_unless($pages->isNotEmpty(), 404);

        $targetPage = $path
            ? $ordered->firstWhere('path', trim($path, '/'))
            : $ordered->first();

        abort_unless($targetPage !== null, 404);

        $currentIndex = $ordered->search(fn (Page $page) => $page->id === $targetPage->id);
        $settings = $site->settings_json ?? [];
        $logoPath = Arr::get($settings, 'branding.logo_path');

        return [
            'site' => [
                'name' => $site->name,
                'slug' => $site->slug,
                'visibility' => $site->visibility,
                'brandName' => Arr::get($settings, 'branding.name', $site->name),
                'logoUrl' => $logoPath ? Storage::disk('public')->url($logoPath) : null,
                'tagline' => Arr::get($settings, 'branding.tagline'),
                'seoTitle' => Arr::get($settings, 'seo.title'),
                'seoDescription' => Arr::get($settings, 'seo.description'),
                'docsTheme' => DocsTheme::normalize(Arr::get($settings, 'appearance.docs_theme')),
                'docsThemeOptions' => DocsTheme::optionsPayload(Arr::get($settings, 'appearance.docs_theme_options')),
                'platformBranding' => PlatformBranding::payload(PlatformBranding::shouldShow($site->organization?->subscription)),
                'primaryDomain' => $site->domains->firstWhere('is_primary', true)?->host,
                'basePath' => route('editor.sites.preview', ['site' => $site], false),
            ],
            'release' => [
                'id' => null,
                'version' => 'Draft preview',
                'environment' => 'preview',
                'publishedAt' => null,
            ],
            'navigation' => $this->buildTree($pages->groupBy('parent_id'), $spacePositions, null),
            'searchIndex' => $ordered
                ->map(fn (Page $page) => $this->mapSearchIndexEntry($page))
                ->values()
                ->all(),
            'page' => $this->mapPage($targetPage),
            'previousPage' => $currentIndex !== false && $currentIndex > 0
                ? $this->mapPageLink($ordered[$currentIndex - 1])
                : null,
            'nextPage' => $currentIndex !== false && $currentIndex < ($ordered->count() - 1)
                ? $this->mapPageLink($ordered[$currentIndex + 1])
                : null,
        ];
    }

    /**
     * @param  Collection<int|string, Collection<int, Page>>  $pagesByParent
     * @return array<int, array<string, mixed>>
     */
    private function buildTree(Collection $pagesByParent, array $spacePositions, ?int $parentId): array
    {
        return ($pagesByParent->get($parentId) ?? collect())
            ->sortBy(fn (Page $page) => $this->sortKey($page, $spacePositions))
            ->values()
            ->map(function (Page $page) use ($pagesByParent, $spacePositions) {
                return [
                    'title' => $page->currentRevision?->title ?: $page->title,
                    'path' => $page->path,
                    'spaceName' => $page->space?->name,
                    'children' => $this->buildTree($pagesByParent, $spacePositions, $page->id),
                ];
            })
            ->all();
    }

    /**
     * @param  array<int, int>  $spacePositions
     * @return array{int, int, string, int}
     */
    private function sortKey(Page $page, array $spacePositions): array
    {
        return [
            $spacePositions[(int) $page->space_id] ?? PHP_INT_MAX,
            (int) $page->position,
            (string) $page->path,
            (int) $page->id,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function mapPage(Page $page): array
    {
        $revision = $page->currentRevision;

        return [
            'title' => $revision?->title ?: $page->title,
            'subtitle' => $revision?->subtitle,
            'path' => $page->path,
            'blocks' => $revision?->blocks_json ?? [],
            'spaceName' => $page->space?->name,
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private function mapPageLink(Page $page): array
    {
        return [
            'title' => $page->currentRevision?->title ?: $page->title,
            'path' => $page->path,
            'spaceName' => $page->space?->name,
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private function mapSearchIndexEntry(Page $page): array
    {
        return [
            'title' => $page->currentRevision?->title ?: $page->title,
            'path' => $page->path,
            'spaceName' => $page->space?->name,
            'searchDocument' => $page->currentRevision?->search_document,
        ];
    }
}
