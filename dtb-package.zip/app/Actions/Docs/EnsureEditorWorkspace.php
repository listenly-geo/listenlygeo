<?php

namespace App\Actions\Docs;

use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\OrganizationSubscription;
use App\Models\Site;
use App\Models\Space;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class EnsureEditorWorkspace
{
    public function __construct(
        private readonly SyncOrganizationUsageCounter $syncOrganizationUsageCounter,
    ) {}

    /**
     * Ensure the authenticated user has a minimum viable docs workspace.
     *
     * @return array<string, mixed>
     */
    public function __invoke(User $user, ?Space $activeSpace = null, ?string $activePageSlug = null): array
    {
        return DB::transaction(function () use ($user, $activeSpace, $activePageSlug) {
            $organization = $user->ownedOrganizations()->first()
                ?? $user->organizations()->first();

            if ($activeSpace) {
                $activeSpace->loadMissing('site.organization');
                $activeOrganization = $activeSpace->site->organization;

                $hasAccess = $activeOrganization->owner_user_id === $user->id
                    || $activeOrganization->memberships()
                        ->where('user_id', $user->id)
                        ->where('status', 'active')
                        ->exists();

                if ($hasAccess) {
                    $organization = $activeOrganization;
                }
            }

            if (! $organization) {
                $organization = Organization::create([
                    'name' => $user->name.' Workspace',
                    'slug' => Str::slug($user->name).'-'.$user->id,
                    'owner_user_id' => $user->id,
                    'billing_email' => $user->email,
                ]);
            }

            OrganizationMembership::query()->firstOrCreate(
                [
                    'organization_id' => $organization->id,
                    'user_id' => $user->id,
                ],
                [
                    'role' => 'owner',
                    'status' => 'active',
                ],
            );

            OrganizationSubscription::query()->firstOrCreate(
                ['organization_id' => $organization->id],
                [
                    'plan' => 'free',
                    'interval' => 'monthly',
                    'status' => 'active',
                    'cancel_at_period_end' => false,
                    'current_period_starts_at' => now(),
                ],
            );

            $site = $activeSpace && $activeSpace->site->organization_id === $organization->id
                ? $activeSpace->site
                : $organization->sites()->oldest('id')->first();

            if (! $site) {
                $site = $organization->sites()->create([
                    'name' => 'Product Docs',
                    'slug' => 'product-docs',
                    'visibility' => 'private',
                    'status' => 'draft',
                    'created_by' => $user->id,
                    'updated_by' => $user->id,
                ]);
            }

            if (! $site->uuid) {
                $site->forceFill([
                    'uuid' => (string) Str::uuid(),
                    'updated_by' => $user->id,
                ])->save();
            }

            $space = $activeSpace && $activeSpace->site_id === $site->id
                ? $activeSpace
                : $site->spaces()->orderBy('position')->oldest('id')->first();

            if (! $space) {
                $space = $site->spaces()->create([
                    'name' => 'Getting Started',
                    'slug' => 'getting-started',
                    'icon' => 'book',
                    'color' => 'oklch(55% 0.14 255)',
                    'position' => 0,
                    'created_by' => $user->id,
                    'updated_by' => $user->id,
                ]);
            }

            if (! $site->default_space_id) {
                $site->forceFill([
                    'default_space_id' => $space->id,
                    'updated_by' => $user->id,
                ])->save();
            }

            if (! $space->uuid) {
                $space->forceFill([
                    'uuid' => (string) Str::uuid(),
                    'updated_by' => $user->id,
                ])->save();
            }

            $page = null;

            if ($activePageSlug !== null && $activePageSlug !== '') {
                $page = $space->pages()->where('slug', $activePageSlug)->first();
            }

            if (! $page) {
                $page = $space->pages()->orderBy('position')->oldest('id')->first();
            }

            if (! $page) {
                [$slug, $path] = $this->availableRootSlugAndPath($site, 'quickstart');

                $page = $space->pages()->create([
                    'site_id' => $site->id,
                    'title' => 'Quickstart',
                    'slug' => $slug,
                    'path' => $path,
                    'icon' => 'bolt',
                    'position' => 0,
                    'status' => 'draft',
                    'created_by' => $user->id,
                    'updated_by' => $user->id,
                ]);
            }

            $revision = $page->currentRevision;

            if (! $revision) {
                $revision = $page->revisions()->create([
                    'version_number' => 1,
                    'title' => $page->title,
                    'subtitle' => 'Go from zero to a published page in under three minutes.',
                    'blocks_json' => [
                        [
                            'id' => 'b_1',
                            'kind' => 'p',
                            'html' => 'Start writing, or press <code>/</code> to insert a block.',
                        ],
                    ],
                    'editor_meta_json' => [
                        'updated' => now()->toIso8601String(),
                        'readTime' => '1 min',
                    ],
                    'save_type' => 'manual',
                    'change_message' => 'Initial page scaffold',
                    'created_by' => $user->id,
                ]);

                $page->forceFill([
                    'current_revision_id' => $revision->id,
                    'updated_by' => $user->id,
                ])->save();
            }

            ($this->syncOrganizationUsageCounter)($organization);

            $revision->refresh();
            $page->refresh();
            $site->refresh();
            $site->load('currentRelease');

            $releaseCount = $site->releases()->count();

            return [
                'organization' => [
                    'id' => $organization->id,
                    'name' => $organization->name,
                    'slug' => $organization->slug,
                ],
                'site' => [
                    'id' => $site->id,
                    'uuid' => $site->uuid,
                    'name' => $site->name,
                    'slug' => $site->slug,
                    'visibility' => $site->visibility,
                    'status' => $site->status,
                    'currentReleaseId' => $site->current_release_id,
                    'currentReleaseVersion' => $site->currentRelease?->version,
                    'nextReleaseVersion' => 'v1.0.'.$releaseCount,
                    'releaseCount' => $releaseCount,
                ],
                'space' => [
                    'id' => $space->id,
                    'uuid' => $space->uuid,
                    'name' => $space->name,
                    'slug' => $space->slug,
                ],
                'page' => [
                    'id' => $page->id,
                    'title' => $page->title,
                    'slug' => $page->slug,
                    'path' => $page->path,
                ],
                'revision' => [
                    'id' => $revision->id,
                    'title' => $revision->title,
                    'subtitle' => $revision->subtitle,
                    'blocks' => $revision->blocks_json,
                    'editorMeta' => $revision->editor_meta_json,
                ],
            ];
        });
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function availableRootSlugAndPath(Site $site, string $title): array
    {
        $baseSlug = Str::slug($title) ?: 'page';
        $candidate = $baseSlug;
        $suffix = 2;

        while ($site->pages()->withTrashed()->where('path', $candidate)->exists()) {
            $candidate = $baseSlug.'-'.$suffix;
            $suffix++;
        }

        return [$candidate, $candidate];
    }
}
