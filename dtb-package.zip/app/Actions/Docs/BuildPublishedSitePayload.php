<?php

namespace App\Actions\Docs;

use App\Models\ReleasePage;
use App\Models\Site;
use App\Support\DocsTheme;
use App\Support\PlatformBranding;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

class BuildPublishedSitePayload
{
    /**
     * @return array<string, mixed>
     */
    public function __invoke(Site $site, ?string $path = null): array
    {
        $site->loadMissing([
            'currentRelease.pages' => fn ($query) => $query->orderBy('position')->orderBy('path')->orderBy('id'),
            'spaces' => fn ($query) => $query->orderBy('position')->orderBy('id'),
            'domains' => fn ($query) => $query->orderByDesc('is_primary')->orderBy('id'),
            'organization.subscription',
        ]);

        $release = $site->currentRelease;
        abort_unless($release !== null, 404);

        $pages = $release->pages;
        abort_unless($pages->isNotEmpty(), 404);

        $spacePositions = $site->spaces
            ->mapWithKeys(fn ($space) => [(int) $space->id => (int) $space->position])
            ->all();

        $ordered = $pages
            ->sortBy(fn (ReleasePage $page) => $this->sortKey($page, $spacePositions))
            ->values();

        $targetPage = $path
            ? $ordered->firstWhere('path', trim($path, '/'))
            : $ordered->first();

        abort_unless($targetPage !== null, 404);

        $tree = $this->buildTree($pages->groupBy(fn (ReleasePage $page) => $page->parent_path), $spacePositions);
        $currentIndex = $ordered->search(fn (ReleasePage $page) => $page->id === $targetPage->id);

        $settings = $site->settings_json ?? [];
        $logoPath = Arr::get($settings, 'branding.logo_path');

        return [
            'site' => [
                'name' => $site->name,
                'slug' => $site->slug,
                'visibility' => $site->visibility,
                'brandName' => Arr::get($settings, 'branding.name', $site->name),
                'logoUrl' => $logoPath ? Storage::disk('public')->url($logoPath) : null,
                'tagline' => Arr::get($settings, 'branding.tagline'),
                'seoTitle' => Arr::get($settings, 'seo.title'),
                'seoDescription' => Arr::get($settings, 'seo.description'),
                'docsTheme' => DocsTheme::normalize(Arr::get($settings, 'appearance.docs_theme')),
                'docsThemeOptions' => DocsTheme::optionsPayload(Arr::get($settings, 'appearance.docs_theme_options')),
                'platformBranding' => PlatformBranding::payload(PlatformBranding::shouldShow($site->organization?->subscription)),
                'primaryDomain' => $site->domains->firstWhere('is_primary', true)?->host,
                'basePath' => route('docs.index', ['siteSlug' => $site->slug], false),
            ],
            'release' => [
                'id' => $release->id,
                'version' => $release->version,
                'environment' => $release->environment,
                'publishedAt' => $release->published_at?->toIso8601String(),
            ],
            'navigation' => $tree,
            'searchIndex' => $ordered
                ->map(fn (ReleasePage $page) => $this->mapSearchIndexEntry($page))
                ->values()
                ->all(),
            'page' => $this->mapPage($targetPage),
            'previousPage' => $currentIndex !== false && $currentIndex > 0
                ? $this->mapPageLink($ordered[$currentIndex - 1])
                : null,
            'nextPage' => $currentIndex !== false && $currentIndex < ($ordered->count() - 1)
                ? $this->mapPageLink($ordered[$currentIndex + 1])
                : null,
        ];
    }

    /**
     * @param  Collection<string|null, Collection<int, ReleasePage>>  $pagesByParent
     * @return array<int, array<string, mixed>>
     */
    private function buildTree(Collection $pagesByParent, array $spacePositions, ?string $parentPath = null): array
    {
        return ($pagesByParent->get($parentPath) ?? collect())
            ->sortBy(fn (ReleasePage $page) => $this->sortKey($page, $spacePositions))
            ->values()
            ->map(function (ReleasePage $page) use ($pagesByParent, $spacePositions) {
                $children = $this->buildTree($pagesByParent, $spacePositions, $page->path);

                return [
                    'title' => $page->title,
                    'path' => $page->path,
                    'spaceName' => $page->space_name,
                    'children' => $children,
                ];
            })
            ->all();
    }

    /**
     * @param  array<int, int>  $spacePositions
     * @return array{int, int, string, int}
     */
    private function sortKey(ReleasePage $page, array $spacePositions): array
    {
        return [
            $spacePositions[(int) $page->space_id] ?? PHP_INT_MAX,
            (int) $page->position,
            (string) $page->path,
            (int) $page->id,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function mapPage(ReleasePage $page): array
    {
        return [
            'title' => $page->title,
            'subtitle' => $page->subtitle,
            'path' => $page->path,
            'blocks' => $page->blocks_json,
            'spaceName' => $page->space_name,
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private function mapPageLink(ReleasePage $page): array
    {
        return [
            'title' => $page->title,
            'path' => $page->path,
            'spaceName' => $page->space_name,
        ];
    }

    /**
     * @return array<string, string|null>
     */
    private function mapSearchIndexEntry(ReleasePage $page): array
    {
        return [
            'title' => $page->title,
            'path' => $page->path,
            'spaceName' => $page->space_name,
            'searchDocument' => $page->search_document,
        ];
    }
}
