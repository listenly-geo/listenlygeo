<?php

namespace App\Actions\Docs;

use App\Models\Page;
use App\Models\User;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

class AutosavePageRevision
{
    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function __invoke(Page $page, User $user, array $payload): array
    {
        $title = (string) ($payload['title'] ?? $page->title);
        $subtitle = $payload['subtitle'] ?? null;
        $blocks = Arr::get($payload, 'blocks', []);
        $editorMeta = Arr::get($payload, 'editorMeta', []);

        $currentRevision = $page->currentRevision;
        $revision = $currentRevision && $currentRevision->save_type === 'autosave'
            ? $currentRevision
            : $page->revisions()->create([
                'version_number' => ((int) $page->revisions()->max('version_number')) + 1,
                'title' => $title,
                'subtitle' => $subtitle,
                'blocks_json' => $blocks,
                'editor_meta_json' => [],
                'search_document' => '',
                'save_type' => 'autosave',
                'change_message' => 'Autosaved draft changes',
                'created_by' => $user->id,
            ]);

        $editorMeta['updated'] = Carbon::now()->toIso8601String();
        $editorMeta['readTime'] = $editorMeta['readTime'] ?? $this->estimateReadTime($title, $subtitle, $blocks);

        $revision->forceFill([
            'title' => $title,
            'subtitle' => $subtitle,
            'blocks_json' => $blocks,
            'editor_meta_json' => $editorMeta,
            'search_document' => $this->buildSearchDocument($title, $subtitle, $blocks),
            'save_type' => 'autosave',
            'change_message' => 'Autosaved draft changes',
            'created_by' => $revision->created_by ?? $user->id,
        ])->save();

        $page->forceFill([
            'title' => trim(strip_tags($title)) ?: 'Untitled',
            'current_revision_id' => $revision->id,
            'updated_by' => $user->id,
        ])->save();

        $page->loadMissing('parent');

        [$slug, $path] = $this->availableSlugAndPath(
            $page->site_id,
            $page->parent?->path,
            $page->title,
            $page->id,
        );

        if ($page->slug !== $slug || $page->path !== $path) {
            $page->forceFill([
                'slug' => $slug,
                'path' => $path,
                'updated_by' => $user->id,
            ])->save();

            $this->syncDescendantPaths($page, $user);
        }

        return [
            'revisionId' => $revision->id,
            'page' => [
                'id' => $page->id,
                'slug' => $page->slug,
                'path' => $page->path,
                'updated' => $revision->updated_at?->format('M j, Y') ?? now()->format('M j, Y'),
                'readTime' => $editorMeta['readTime'],
                'title' => $revision->title,
                'subtitle' => $revision->subtitle,
            ],
        ];
    }

    /**
     * @param  array<int, mixed>  $blocks
     */
    private function buildSearchDocument(string $title, mixed $subtitle, array $blocks): string
    {
        $parts = [$this->stripMarkup($title), $this->stripMarkup((string) ($subtitle ?? ''))];

        foreach ($blocks as $block) {
            if (! is_array($block)) {
                continue;
            }

            foreach (['text', 'html', 'title', 'caption', 'desc', 'body', 'url', 'path'] as $field) {
                if (isset($block[$field])) {
                    $parts[] = $this->stripMarkup((string) $block[$field]);
                }
            }

            if (isset($block['headers']) && is_array($block['headers'])) {
                $parts[] = implode(' ', array_map(fn ($value) => $this->stripMarkup((string) $value), $block['headers']));
            }

            if (isset($block['rows']) && is_array($block['rows'])) {
                foreach ($block['rows'] as $row) {
                    if (is_array($row)) {
                        $parts[] = implode(' ', array_map(fn ($value) => $this->stripMarkup((string) $value), $row));
                    }
                }
            }
        }

        return trim(implode(' ', array_filter($parts)));
    }

    /**
     * @param  array<int, mixed>  $blocks
     */
    private function estimateReadTime(string $title, mixed $subtitle, array $blocks): string
    {
        $text = $this->buildSearchDocument($title, $subtitle, $blocks);
        $wordCount = max(1, str_word_count($text));
        $minutes = max(1, (int) ceil($wordCount / 220));

        return $minutes.' min';
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function availableSlugAndPath(int $siteId, ?string $parentPath, string $source, ?int $ignorePageId = null): array
    {
        $baseSlug = Str::slug($source) ?: 'untitled';
        $candidateSlug = $baseSlug;
        $suffix = 2;

        while (true) {
            $candidatePath = $parentPath ? $parentPath.'/'.$candidateSlug : $candidateSlug;

            $exists = Page::query()
                ->withTrashed()
                ->where('site_id', $siteId)
                ->where('path', $candidatePath)
                ->when(
                    $ignorePageId !== null,
                    fn ($query) => $query->where('id', '!=', $ignorePageId),
                )
                ->exists();

            if (! $exists) {
                return [$candidateSlug, $candidatePath];
            }

            $candidateSlug = $baseSlug.'-'.$suffix;
            $suffix++;
        }
    }

    private function syncDescendantPaths(Page $page, User $user): void
    {
        $children = $page->children()->orderBy('position')->orderBy('id')->get();

        foreach ($children as $child) {
            [$slug, $path] = $this->availableSlugAndPath($child->site_id, $page->path, $child->slug ?: $child->title, $child->id);

            $child->forceFill([
                'slug' => $slug,
                'path' => $path,
                'updated_by' => $user->id,
            ])->save();

            $this->syncDescendantPaths($child, $user);
        }
    }

    private function stripMarkup(string $value): string
    {
        return trim(Str::of(strip_tags($value))->replaceMatches('/\s+/', ' ')->toString());
    }
}
