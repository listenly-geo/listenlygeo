<?php

namespace App\Actions\Editor;

use App\Models\Page;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;

class GeneratePrototypeAiDraft
{
    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function __invoke(Page $page, array $payload): array
    {
        $scope = $this->resolveScope($payload);
        $intent = $this->resolveIntent($payload, $scope);
        $provider = $this->configuredProvider();

        $payload = array_merge($payload, array_filter([
            'scope' => $scope,
            'intent' => $intent,
            'mode' => Arr::get($payload, 'mode', $this->legacyModeForScope($scope)),
        ], static fn (mixed $value): bool => $value !== null));

        if ($this->usesFakeResponses()) {
            return $this->fakeGeneration($page, $payload, $provider);
        }

        $apiKey = $this->providerApiKey($provider);

        if ($apiKey === '') {
            throw new RuntimeException($this->missingProviderMessage($provider));
        }

        $completion = $this->requestGeneration($provider, $apiKey, $page, $payload);
        $content = $completion['content'];

        if ($content === '') {
            throw new RuntimeException('AI writer returned an empty response.');
        }

        $generation = $this->normalizeGeneration(
            $this->extractJsonPayload($content),
            $scope,
            $intent,
            Arr::get($payload, 'document', [])
        );

        $generation['meta'] = [
            'model' => $completion['model'],
            'provider' => $provider,
        ];

        return $generation;
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function resolveScope(array $payload): string
    {
        $scope = trim((string) Arr::get($payload, 'scope', ''));

        if ($scope !== '') {
            return $scope;
        }

        return (string) Arr::get($payload, 'mode') === 'selection' ? 'selection' : 'page';
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function resolveIntent(array $payload, string $scope): string
    {
        $intent = trim((string) Arr::get($payload, 'intent', ''));

        if ($intent !== '') {
            return $intent;
        }

        return match ($scope) {
            'selection' => 'rewrite',
            'title', 'description' => 'derive',
            'text' => 'rewrite',
            'content' => 'generate',
            default => 'generate',
        };
    }

    private function legacyModeForScope(string $scope): ?string
    {
        return match ($scope) {
            'page' => 'full-page',
            'selection' => 'selection',
            default => null,
        };
    }

    private function configuredProvider(): string
    {
        $provider = Str::lower(trim((string) config('services.ai_writer.provider', 'openrouter')));

        return in_array($provider, ['openrouter', 'openai', 'textcortex'], true)
            ? $provider
            : 'openrouter';
    }

    private function usesFakeResponses(): bool
    {
        return (bool) config('services.ai_writer.fake', (bool) config('services.openrouter.fake', false));
    }

    private function providerApiKey(string $provider): string
    {
        return trim((string) config("services.{$provider}.api_key", ''));
    }

    private function providerModel(string $provider): string
    {
        return trim((string) config(match ($provider) {
            'openai' => 'services.openai.model',
            'textcortex' => 'services.textcortex.model',
            default => 'services.openrouter.model',
        }, match ($provider) {
            'openai' => 'gpt-4o-mini',
            'textcortex' => 'gemini-2-5-flash',
            default => 'poolside/laguna-m.1:free',
        }));
    }

    private function missingProviderMessage(string $provider): string
    {
        return match ($provider) {
            'openai' => 'AI writer is not configured. Set OPENAI_API_KEY in your local environment.',
            'textcortex' => 'AI writer is not configured. Set TEXTCORTEX_API_KEY in your local environment.',
            default => 'AI writer is not configured. Set OPENROUTER_API_KEY in your local environment.',
        };
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array{content:string,model:string}
     */
    private function requestGeneration(string $provider, string $apiKey, Page $page, array $payload): array
    {
        return match ($provider) {
            'openai', 'openrouter' => $this->requestChatGeneration($provider, $apiKey, $page, $payload),
            'textcortex' => $this->requestTextCortexGeneration($apiKey, $page, $payload),
            default => throw new RuntimeException('Unsupported AI writer provider.'),
        };
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array{content:string,model:string}
     */
    private function requestChatGeneration(string $provider, string $apiKey, Page $page, array $payload): array
    {
        $messages = [
            [
                'role' => 'system',
                'content' => $this->systemPrompt(),
            ],
            [
                'role' => 'user',
                'content' => $this->userPrompt($page, $payload),
            ],
        ];

        $failures = [];

        foreach ($this->configuredModels($provider) as $model) {
            for ($attempt = 1; $attempt <= 2; $attempt++) {
                try {
                    $response = Http::baseUrl((string) config(match ($provider) {
                        'openai' => 'services.openai.base_url',
                        default => 'services.openrouter.base_url',
                    }, match ($provider) {
                        'openai' => 'https://api.openai.com/v1',
                        default => 'https://openrouter.ai/api/v1',
                    }))
                        ->acceptJson()
                        ->withToken($apiKey)
                        ->withHeaders($provider === 'openrouter'
                            ? array_filter([
                                'HTTP-Referer' => (string) config('services.openrouter.site_url', config('app.url')),
                                'X-Title' => (string) config('services.openrouter.app_name', config('app.name')),
                            ])
                            : [])
                        ->timeout(90)
                        ->post('/chat/completions', [
                            'model' => $model,
                            'temperature' => 0.35,
                            'messages' => $messages,
                        ]);
                } catch (ConnectionException $exception) {
                    $failures[] = [
                        'model' => $model,
                        'status' => null,
                        'message' => 'network error',
                    ];

                    if ($attempt < 2) {
                        usleep(250000);

                        continue;
                    }

                    break;
                }

                if ($response->successful()) {
                    return [
                        'content' => (string) data_get($response->json(), 'choices.0.message.content', ''),
                        'model' => (string) data_get($response->json(), 'model', $model),
                    ];
                }

                $failures[] = [
                    'model' => $model,
                    'status' => $response->status(),
                    'message' => $this->upstreamErrorMessage($response),
                ];

                if (! $this->shouldRetryUpstreamFailure($response->status()) || $attempt === 2) {
                    break;
                }

                usleep(250000);
            }
        }

        $lastFailure = Arr::last($failures);

        if ($lastFailure === null) {
            throw new RuntimeException('AI writer request failed.');
        }

        $status = $lastFailure['status'] !== null ? ' '.$lastFailure['status'] : '';
        $message = $lastFailure['message'] !== '' ? ': '.$lastFailure['message'] : '';

        throw new RuntimeException('AI writer request failed via '.$lastFailure['model'].$status.$message);
    }

    /**
     * @return array<int, string>
     */
    private function configuredModels(string $provider): array
    {
        $primary = $this->providerModel($provider);
        $fallbacks = config(match ($provider) {
            'openai' => 'services.openai.fallback_models',
            default => 'services.openrouter.fallback_models',
        }, []);

        if (is_string($fallbacks)) {
            $fallbacks = array_filter(array_map('trim', explode(',', $fallbacks)));
        }

        return array_values(array_unique(array_filter([
            $primary,
            ...Arr::wrap($fallbacks),
        ], static fn (mixed $value): bool => is_string($value) && trim($value) !== '')));
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array{content:string,model:string}
     */
    private function requestTextCortexGeneration(string $apiKey, Page $page, array $payload): array
    {
        $scope = $this->resolveScope($payload);
        $intent = $this->resolveIntent($payload, $scope);
        $endpoint = $intent === 'rewrite' ? '/texts/rewritings' : '/texts/expansions';
        $model = $this->providerModel('textcortex');
        $requestBody = [
            'model' => $model,
            'text' => $this->textCortexPrompt($page, $payload),
            'max_tokens' => 2048,
            'n' => 1,
            'source_lang' => 'en',
            'target_lang' => 'en',
            'temperature' => 0.2,
        ];

        if ($endpoint === '/texts/rewritings') {
            $requestBody['mode'] = 'tone_professional';
        }

        $failures = [];

        for ($attempt = 1; $attempt <= 2; $attempt++) {
            try {
                $response = Http::baseUrl((string) config('services.textcortex.base_url', 'https://api.textcortex.com/v1'))
                    ->acceptJson()
                    ->withToken($apiKey)
                    ->timeout(90)
                    ->post($endpoint, $requestBody);
            } catch (ConnectionException) {
                $failures[] = [
                    'model' => $model,
                    'status' => null,
                    'message' => 'network error',
                ];

                if ($attempt < 2) {
                    usleep(250000);
                    continue;
                }

                break;
            }

            if ($response->successful()) {
                return [
                    'content' => (string) data_get($response->json(), 'data.outputs.0.text', ''),
                    'model' => $model,
                ];
            }

            $failures[] = [
                'model' => $model,
                'status' => $response->status(),
                'message' => $this->upstreamErrorMessage($response),
            ];

            if (! $this->shouldRetryUpstreamFailure($response->status()) || $attempt === 2) {
                break;
            }

            usleep(250000);
        }

        $lastFailure = Arr::last($failures);

        if ($lastFailure === null) {
            throw new RuntimeException('AI writer request failed.');
        }

        $status = $lastFailure['status'] !== null ? ' '.$lastFailure['status'] : '';
        $message = $lastFailure['message'] !== '' ? ': '.$lastFailure['message'] : '';

        throw new RuntimeException('AI writer request failed via '.$lastFailure['model'].$status.$message);
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function textCortexPrompt(Page $page, array $payload): string
    {
        return implode("\n\n", [
            'System instructions:',
            $this->systemPrompt(),
            'User request JSON:',
            $this->userPrompt($page, $payload),
        ]);
    }

    private function shouldRetryUpstreamFailure(int $status): bool
    {
        return in_array($status, [408, 409, 425, 429, 500, 502, 503, 504], true);
    }

    private function upstreamErrorMessage(Response $response): string
    {
        $json = $response->json();

        $message = $this->sanitizeInlineText(
            data_get($json, 'error.message')
            ?? data_get($json, 'message')
            ?? data_get($json, 'error.metadata.raw')
            ?? ''
        );

        if ($message !== '') {
            return Str::limit($message, 180, '');
        }

        return Str::limit($this->sanitizeInlineText($response->body()), 180, '');
    }

    private function systemPrompt(): string
    {
        return implode("\n", [
            'You are an expert technical documentation writer.',
            'Return only JSON.',
            'Use concise, product-quality documentation language.',
            'Do not include markdown fences or commentary.',
            'For page scope return an object with keys: title, subtitle, blocks.',
            'For selection scope return an object with key: blocks. You may also include title or subtitle, but blocks are required.',
            'For title scope return an object with key: title.',
            'For description scope return an object with key: subtitle.',
            'For content scope return an object with key: blocks.',
            'For text scope return an object with key: text.',
            'The blocks array may only contain these block kinds: h2, h3, p, quote, divider, callout, code, checklist.',
            'For h2 and h3 blocks use: {"kind":"h2","text":"..."}.',
            'For p and quote blocks use: {"kind":"p","html":"..."}.',
            'For divider blocks use: {"kind":"divider"}.',
            'For callout blocks use: {"kind":"callout","variant":"info|warn|ok|danger","title":"...","text":"..."}.',
            'For code blocks use: {"kind":"code","lang":"text","filename":"example.txt","code":"..."}.',
            'For checklist blocks use: {"kind":"checklist","items":[{"text":"...","done":false}]}.',
            'Do not generate ids.',
            'Do not include h1 blocks because the page title is returned separately.',
        ]);
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function userPrompt(Page $page, array $payload): string
    {
        $scope = $this->resolveScope($payload);
        $intent = $this->resolveIntent($payload, $scope);
        $document = Arr::get($payload, 'document', []);
        $documentBlocks = Arr::wrap(Arr::get($document, 'blocks', []));
        $selectionBlocks = Arr::get($payload, 'selection.blocks', []);
        $selectionBlockIds = array_values(Arr::wrap(Arr::get($payload, 'selection.blockIds', [])));
        $targetBlocks = Arr::get($payload, 'target.blocks', []);
        $targetBlockIds = array_values(Arr::wrap(Arr::get($payload, 'target.blockIds', [])));
        $targetBlockId = (string) Arr::get($payload, 'target.blockId', '');
        $targetSelectedText = (string) Arr::get($payload, 'target.selectedText', '');
        $insertAfterBlockId = (string) Arr::get($payload, 'target.insertAfterBlockId', '');
        $contentContextBlockIds = $targetBlockIds !== [] ? $targetBlockIds : array_values(array_filter([$insertAfterBlockId]));

        return json_encode([
            'scope' => $scope,
            'intent' => $intent,
            'task' => match ($scope) {
                'selection' => 'Generate replacement content for the selected documentation section.',
                'title' => $intent === 'rewrite'
                    ? 'Rewrite the page title using the prompt and page context.'
                    : 'Derive a concise page title from the current documentation content.',
                'description' => $intent === 'rewrite'
                    ? 'Rewrite the page description using the prompt and page context.'
                    : 'Derive a concise page description from the current documentation content.',
                'text' => 'Rewrite only the selected text using the prompt and local block context.',
                'content' => match ($intent) {
                    'rewrite' => 'Rewrite the targeted documentation content blocks using the prompt and local context.',
                    'expand' => 'Expand the targeted documentation content blocks into richer documentation using the prompt and local context.',
                    default => 'Generate new documentation content to insert into the current page.',
                },
                default => $intent === 'rewrite'
                    ? 'Rewrite the documentation page using the prompt and page context.'
                    : 'Generate a complete documentation page draft.',
            },
            'prompt' => (string) $payload['prompt'],
            'page' => [
                'id' => $page->getKey(),
                'title' => Arr::get($document, 'title', $page->title),
                'subtitle' => Arr::get($document, 'subtitle', ''),
                'outline' => $this->documentOutline($documentBlocks),
                'contentSummary' => $this->documentContentSummary($documentBlocks),
                'blocks' => $scope === 'page' ? $documentBlocks : null,
            ],
            'target' => match ($scope) {
                'title' => [
                    'currentTitle' => Arr::get($document, 'title', $page->title),
                    'currentSubtitle' => Arr::get($document, 'subtitle', ''),
                ],
                'description' => [
                    'currentTitle' => Arr::get($document, 'title', $page->title),
                    'currentSubtitle' => Arr::get($document, 'subtitle', ''),
                ],
                'selection' => [
                    'blockIds' => $selectionBlockIds,
                    'blocks' => $selectionBlocks,
                    'before' => $this->neighboringBlockSummaries($documentBlocks, $selectionBlockIds, 'before'),
                    'after' => $this->neighboringBlockSummaries($documentBlocks, $selectionBlockIds, 'after'),
                ],
                'content' => [
                    'insertAfterBlockId' => $insertAfterBlockId !== '' ? $insertAfterBlockId : null,
                    'blockIds' => $targetBlockIds,
                    'blocks' => $targetBlocks,
                    'before' => $this->neighboringBlockSummaries($documentBlocks, $contentContextBlockIds, 'before'),
                    'after' => $this->neighboringBlockSummaries($documentBlocks, $contentContextBlockIds, 'after'),
                ],
                'text' => [
                    'blockId' => $targetBlockId !== '' ? $targetBlockId : null,
                    'selectedText' => $targetSelectedText,
                    'block' => collect($documentBlocks)->first(fn (mixed $block): bool => is_array($block) && (string) Arr::get($block, 'id', '') === $targetBlockId),
                    'before' => $this->neighboringBlockSummaries($documentBlocks, array_values(array_filter([$targetBlockId])), 'before'),
                    'after' => $this->neighboringBlockSummaries($documentBlocks, array_values(array_filter([$targetBlockId])), 'after'),
                ],
                default => null,
            },
            'requirements' => array_values(array_filter([
                'Preserve the product voice and technical clarity.',
                'Prefer scannable sections and short paragraphs.',
                'Keep output realistic for a product documentation editor.',
                match ($scope) {
                    'selection' => 'Return only replacement blocks for the selected section. Never restate the full page or duplicate untouched sections.',
                    'title' => 'Return only a concise page title. Do not return blocks or a subtitle.',
                    'description' => 'Return only a concise page description in the subtitle field. Do not return blocks or a title.',
                    'text' => 'Return only rewritten text for the selected span. Do not return blocks, title, subtitle, markdown fences, or commentary.',
                    'content' => match ($intent) {
                        'rewrite' => 'Return only replacement blocks for the targeted content. Never restate untouched sections.',
                        'expand' => 'Return only expanded replacement blocks for the targeted content. Keep the result local to that content.',
                        default => 'Return only new blocks to insert into the current page. Do not restate the full page.',
                    },
                    default => 'Draft a cohesive page that stands on its own.',
                },
                $scope === 'page' ? 'When useful, include one checklist or code sample.' : null,
            ], static fn (mixed $value): bool => $value !== null)),
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    /**
     * @param  array<int, mixed>  $blocks
     * @return array<int, array{kind:string,text:string}>
     */
    private function documentOutline(array $blocks): array
    {
        return collect($blocks)
            ->filter(fn (mixed $block): bool => is_array($block) && in_array((string) Arr::get($block, 'kind'), ['h1', 'h2', 'h3'], true))
            ->map(fn (array $block): array => [
                'kind' => (string) Arr::get($block, 'kind', 'h2'),
                'text' => $this->sanitizeInlineText(Arr::get($block, 'text', Arr::get($block, 'html', ''))),
            ])
            ->filter(fn (array $block): bool => $block['text'] !== '')
            ->take(20)
            ->values()
            ->all();
    }

    /**
     * @param  array<int, mixed>  $blocks
     * @param  array<int, string>  $selectionBlockIds
     * @return array<int, array{kind:string,text:string}>
     */
    private function neighboringBlockSummaries(array $blocks, array $selectionBlockIds, string $direction): array
    {
        $selected = array_flip($selectionBlockIds);
        $selectionIndexes = collect($blocks)
            ->map(fn (mixed $block, int $index): ?int => is_array($block) && isset($selected[(string) Arr::get($block, 'id', '')]) ? $index : null)
            ->filter(fn (?int $index): bool => $index !== null)
            ->values();

        if ($selectionIndexes->isEmpty()) {
            return [];
        }

        $indexes = $direction === 'before'
            ? range(max(0, $selectionIndexes->min() - 2), max(0, $selectionIndexes->min() - 1))
            : range($selectionIndexes->max() + 1, min(count($blocks) - 1, $selectionIndexes->max() + 2));

        return collect($indexes)
            ->map(fn (int $index): mixed => $blocks[$index] ?? null)
            ->filter(fn (mixed $block): bool => is_array($block))
            ->map(fn (array $block): array => [
                'kind' => (string) Arr::get($block, 'kind', 'p'),
                'text' => $this->blockSummaryText($block),
            ])
            ->filter(fn (array $block): bool => $block['text'] !== '')
            ->values()
            ->all();
    }

    /**
     * @param  array<int, mixed>  $blocks
     * @return array<int, string>
     */
    private function documentContentSummary(array $blocks): array
    {
        return collect($blocks)
            ->filter(fn (mixed $block): bool => is_array($block))
            ->map(fn (array $block): string => $this->blockSummaryText($block))
            ->filter(fn (string $summary): bool => $summary !== '')
            ->take(10)
            ->values()
            ->all();
    }

    /**
     * @param  array<string, mixed>  $block
     */
    private function blockSummaryText(array $block): string
    {
        $parts = [];

        foreach (['text', 'html', 'title', 'caption', 'desc', 'code', 'filename', 'path', 'url', 'alt'] as $key) {
            $value = Arr::get($block, $key);
            if (is_string($value) && trim($value) !== '') {
                $parts[] = $this->sanitizeInlineText($value);
            }
        }

        if (isset($block['items']) && is_array($block['items'])) {
            foreach ($block['items'] as $item) {
                if (! is_array($item)) {
                    continue;
                }

                foreach (['text', 'title', 'desc'] as $key) {
                    $value = Arr::get($item, $key);
                    if (is_string($value) && trim($value) !== '') {
                        $parts[] = $this->sanitizeInlineText($value);
                    }
                }
            }
        }

        return Str::limit(implode(' ', array_filter($parts)), 220, '');
    }

    /**
     * @param  array<string, mixed>  $decoded
     * @param  array<string, mixed>  $document
     * @return array<string, mixed>
     */
    private function normalizeGeneration(array $decoded, string $scope, string $intent, array $document): array
    {
        $title = $this->sanitizeInlineText(Arr::get($decoded, 'title', Arr::get($document, 'title', 'Untitled')));
        $subtitle = $this->sanitizeInlineHtml(Arr::get($decoded, 'subtitle', Arr::get($decoded, 'description', Arr::get($document, 'subtitle', ''))));

        return match ($scope) {
            'selection' => $this->normalizeSelectionGeneration($decoded, $intent, $document, $title, $subtitle),
            'title' => $this->normalizeTitleGeneration($title, $intent),
            'description' => $this->normalizeDescriptionGeneration($subtitle, $intent),
            'content' => $this->normalizeContentGeneration($decoded, $intent),
            'text' => $this->normalizeTextGeneration($decoded, $intent),
            default => $this->normalizePageGeneration($decoded, $intent, $title, $subtitle),
        };
    }

    /**
     * @param  array<string, mixed>  $decoded
     * @return array<string, mixed>
     */
    private function normalizePageGeneration(array $decoded, string $intent, string $title, string $subtitle): array
    {
        $blocks = $this->normalizeBlocks(Arr::get($decoded, 'blocks', []));

        if ($blocks === []) {
            throw new RuntimeException('AI writer returned no usable blocks.');
        }

        return [
            'scope' => 'page',
            'intent' => $intent,
            'mode' => 'full-page',
            'patch' => [
                'title' => $title === '' ? 'Untitled' : $title,
                'subtitle' => $subtitle,
                'blocks' => $blocks,
            ],
            'title' => $title === '' ? 'Untitled' : $title,
            'subtitle' => $subtitle,
            'blocks' => $blocks,
        ];
    }

    /**
     * @param  array<string, mixed>  $decoded
     * @param  array<string, mixed>  $document
     * @return array<string, mixed>
     */
    private function normalizeSelectionGeneration(array $decoded, string $intent, array $document, string $title, string $subtitle): array
    {
        $blocks = $this->normalizeBlocks(Arr::get($decoded, 'blocks', []));

        if ($blocks === []) {
            throw new RuntimeException('AI writer returned no usable blocks.');
        }

        return [
            'scope' => 'selection',
            'intent' => $intent,
            'mode' => 'selection',
            'patch' => [
                'blocks' => $blocks,
            ],
            'title' => $title === '' ? $this->sanitizeInlineText(Arr::get($document, 'title', 'Untitled')) : $title,
            'subtitle' => $subtitle,
            'blocks' => $blocks,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizeTitleGeneration(string $title, string $intent): array
    {
        if ($title === '') {
            throw new RuntimeException('AI writer returned no usable title.');
        }

        return [
            'scope' => 'title',
            'intent' => $intent,
            'patch' => [
                'title' => $title,
            ],
            'title' => $title,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizeDescriptionGeneration(string $subtitle, string $intent): array
    {
        if ($subtitle === '') {
            throw new RuntimeException('AI writer returned no usable description.');
        }

        return [
            'scope' => 'description',
            'intent' => $intent,
            'patch' => [
                'subtitle' => $subtitle,
            ],
            'subtitle' => $subtitle,
        ];
    }

    /**
     * @param  array<string, mixed>  $decoded
     * @return array<string, mixed>
     */
    private function normalizeContentGeneration(array $decoded, string $intent): array
    {
        $blocks = $this->normalizeBlocks(Arr::get($decoded, 'blocks', []));

        if ($blocks === []) {
            throw new RuntimeException('AI writer returned no usable blocks.');
        }

        return [
            'scope' => 'content',
            'intent' => $intent,
            'patch' => [
                'blocks' => $blocks,
            ],
            'blocks' => $blocks,
        ];
    }

    /**
     * @param  array<string, mixed>  $decoded
     * @return array<string, mixed>
     */
    private function normalizeTextGeneration(array $decoded, string $intent): array
    {
        $text = $this->sanitizeInlineText(Arr::get($decoded, 'text', ''));

        if ($text === '') {
            throw new RuntimeException('AI writer returned no usable text.');
        }

        return [
            'scope' => 'text',
            'intent' => $intent,
            'patch' => [
                'text' => $text,
            ],
            'text' => $text,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function normalizeBlocks(mixed $blocks): array
    {
        if (! is_array($blocks)) {
            return [];
        }

        $normalized = [];

        foreach (array_slice($blocks, 0, 24) as $block) {
            if (! is_array($block)) {
                continue;
            }

            $kind = (string) Arr::get($block, 'kind', '');

            switch ($kind) {
                case 'h2':
                case 'h3':
                    $text = $this->sanitizeInlineText(Arr::get($block, 'text', ''));
                    if ($text !== '') {
                        $normalized[] = ['kind' => $kind, 'text' => $text];
                    }
                    break;

                case 'p':
                case 'quote':
                    $html = $this->sanitizeInlineHtml(Arr::get($block, 'html', ''));
                    if ($html !== '') {
                        $normalized[] = ['kind' => $kind, 'html' => $html];
                    }
                    break;

                case 'divider':
                    $normalized[] = ['kind' => 'divider'];
                    break;

                case 'callout':
                    $text = $this->sanitizeInlineText(Arr::get($block, 'text', ''));
                    if ($text === '') {
                        break;
                    }

                    $variant = (string) Arr::get($block, 'variant', 'info');
                    if (! in_array($variant, ['info', 'warn', 'ok', 'danger'], true)) {
                        $variant = 'info';
                    }

                    $normalized[] = [
                        'kind' => 'callout',
                        'variant' => $variant,
                        'title' => $this->sanitizeInlineText(Arr::get($block, 'title', 'Note')) ?: 'Note',
                        'text' => $text,
                    ];
                    break;

                case 'code':
                    $code = trim((string) Arr::get($block, 'code', ''));
                    if ($code === '') {
                        break;
                    }

                    $normalized[] = [
                        'kind' => 'code',
                        'lang' => Str::limit($this->sanitizeInlineText(Arr::get($block, 'lang', 'text')), 32, ''),
                        'filename' => Str::limit($this->sanitizeInlineText(Arr::get($block, 'filename', 'example.txt')), 96, ''),
                        'code' => $code,
                    ];
                    break;

                case 'checklist':
                    $items = collect(Arr::wrap(Arr::get($block, 'items', [])))
                        ->filter(fn (mixed $item): bool => is_array($item))
                        ->map(function (array $item): array {
                            return [
                                'text' => $this->sanitizeInlineText(Arr::get($item, 'text', '')),
                                'done' => (bool) Arr::get($item, 'done', false),
                            ];
                        })
                        ->filter(fn (array $item): bool => $item['text'] !== '')
                        ->take(8)
                        ->values()
                        ->all();

                    if ($items !== []) {
                        $normalized[] = [
                            'kind' => 'checklist',
                            'items' => $items,
                        ];
                    }
                    break;
            }
        }

        return $normalized;
    }

    /**
     * @return array<string, mixed>
     */
    private function extractJsonPayload(string $content): array
    {
        $trimmed = trim($content);

        if (preg_match('/```(?:json)?\s*(\{.*\})\s*```/is', $trimmed, $matches) === 1) {
            $trimmed = $matches[1];
        } elseif (($start = strpos($trimmed, '{')) !== false && ($end = strrpos($trimmed, '}')) !== false && $end > $start) {
            $trimmed = substr($trimmed, $start, $end - $start + 1);
        }

        try {
            $decoded = json_decode($trimmed, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $exception) {
            throw new RuntimeException('AI writer returned invalid JSON.');
        }

        if (! is_array($decoded)) {
            throw new RuntimeException('AI writer returned an unexpected payload.');
        }

        return $decoded;
    }

    private function sanitizeInlineText(mixed $value): string
    {
        return trim(preg_replace('/\s+/u', ' ', strip_tags((string) $value)) ?? '');
    }

    private function sanitizeInlineHtml(mixed $value): string
    {
        $html = strip_tags((string) $value, '<strong><b><em><i><code><a><br>');

        return trim(preg_replace('/\s+/u', ' ', $html) ?? '');
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    private function fakeGeneration(Page $page, array $payload, string $provider): array
    {
        $scope = $this->resolveScope($payload);
        $intent = $this->resolveIntent($payload, $scope);
        $mode = (string) Arr::get($payload, 'mode', $this->legacyModeForScope($scope));
        $prompt = $this->sanitizeInlineText($payload['prompt'] ?? '');
        $documentTitle = $this->sanitizeInlineText(Arr::get($payload, 'document.title', $page->title));
        $documentSubtitle = $this->sanitizeInlineHtml(Arr::get($payload, 'document.subtitle', ''));

        if ($scope === 'title') {
            $title = Str::limit(Str::headline($prompt !== '' ? $prompt : ($documentTitle !== '' ? $documentTitle : 'AI title suggestion')), 90, '');

            return [
                'scope' => 'title',
                'intent' => $intent,
                'patch' => [
                    'title' => $title,
                ],
                'title' => $title,
                'meta' => [
                    'model' => $this->providerModel($provider),
                    'provider' => $provider.'-fake',
                ],
            ];
        }

        if ($scope === 'description') {
            $subtitle = 'AI description for '.$this->escapeHtmlText($prompt !== '' ? $prompt : ($documentTitle !== '' ? $documentTitle : 'this page')).'.';

            return [
                'scope' => 'description',
                'intent' => $intent,
                'patch' => [
                    'subtitle' => $subtitle,
                ],
                'subtitle' => $subtitle,
                'meta' => [
                    'model' => $this->providerModel($provider),
                    'provider' => $provider.'-fake',
                ],
            ];
        }

        if ($scope === 'text') {
            $text = 'AI rewritten text for '.$this->escapeHtmlText($prompt ?: 'the selected text').'.';

            return [
                'scope' => 'text',
                'intent' => $intent,
                'patch' => [
                    'text' => $text,
                ],
                'text' => $text,
                'meta' => [
                    'model' => $this->providerModel($provider),
                    'provider' => $provider.'-fake',
                ],
            ];
        }

        if ($scope === 'content') {
            $label = $this->escapeHtmlText($prompt ?: $documentTitle ?: 'this content');
            $heading = $intent === 'expand' ? 'AI expanded content' : ($intent === 'rewrite' ? 'AI rewritten content' : 'AI generated content');
            $verb = $intent === 'expand' ? 'expanded' : ($intent === 'rewrite' ? 'rewritten' : 'generated');
            $blocks = [
                ['kind' => 'h3', 'text' => $heading],
                ['kind' => 'p', 'html' => 'AI '.$verb.' content about '.$label.'.'],
            ];

            return [
                'scope' => 'content',
                'intent' => $intent,
                'patch' => [
                    'blocks' => $blocks,
                ],
                'blocks' => $blocks,
                'meta' => [
                    'model' => $this->providerModel($provider),
                    'provider' => $provider.'-fake',
                ],
            ];
        }

        $blocks = $mode === 'full-page'
            ? [
                ['kind' => 'h2', 'text' => 'Overview'],
                ['kind' => 'p', 'html' => 'AI generated draft for '.$this->escapeHtmlText($prompt ?: $documentTitle).'.'],
                ['kind' => 'callout', 'variant' => 'info', 'title' => 'What changed', 'text' => 'This draft was created from the AI writer prompt and is ready for edits.'],
                ['kind' => 'checklist', 'items' => [
                    ['text' => 'Review the generated summary', 'done' => false],
                    ['text' => 'Adjust examples for your product', 'done' => false],
                ]],
            ]
            : [
                ['kind' => 'h3', 'text' => 'AI refined section'],
                ['kind' => 'p', 'html' => 'AI generated section about '.$this->escapeHtmlText($prompt ?: $documentTitle).'.'],
            ];

        return [
            'scope' => $scope,
            'intent' => $intent,
            'mode' => $mode,
            'patch' => $mode === 'full-page'
                ? [
                    'title' => $documentTitle === '' ? 'AI draft' : $documentTitle,
                    'subtitle' => 'Generated with the '.Str::headline($provider).' AI writer.',
                    'blocks' => $blocks,
                ]
                : [
                    'blocks' => $blocks,
                ],
            'title' => $mode === 'full-page' ? ($documentTitle === '' ? 'AI draft' : $documentTitle) : $documentTitle,
            'subtitle' => $mode === 'full-page'
                ? 'Generated with the '.Str::headline($provider).' AI writer.'
                : $documentSubtitle,
            'blocks' => $blocks,
            'meta' => [
                'model' => $this->providerModel($provider),
                'provider' => $provider.'-fake',
            ],
        ];
    }

    private function escapeHtmlText(string $value): string
    {
        return e($value);
    }
}
