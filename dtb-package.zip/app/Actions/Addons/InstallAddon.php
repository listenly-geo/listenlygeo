<?php

namespace App\Actions\Addons;

use App\Models\Addon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use ZipArchive;

class InstallAddon
{
    /**
     * Validate and install an addon ZIP for the given addon slug.
     *
     * Security guarantees:
     *  - The ZIP is extracted to a temp directory that is always deleted afterwards.
     *  - The required_files list is read from the DB (set by us, not by the ZIP).
     *  - The stored token is an HMAC signed with ADDON_SIGNING_KEY; re-verified on every request.
     *  - A manual DB `enabled = true` without a matching token will NOT pass isVerifiedEnabled().
     *
     * @throws \InvalidArgumentException when the ZIP is missing required files.
     * @throws \RuntimeException         on extraction failure.
     */
    public function handle(Addon $addon, UploadedFile $file): void
    {
        $zip = new ZipArchive();
        $tempDir = sys_get_temp_dir().DIRECTORY_SEPARATOR.'addon_'.bin2hex(random_bytes(8));

        try {
            $openResult = $zip->open($file->getRealPath());

            if ($openResult !== true) {
                throw new \RuntimeException('Could not open the uploaded ZIP file (ZipArchive error: '.$openResult.').');
            }

            if (! mkdir($tempDir, 0700, true)) {
                $zip->close();
                throw new \RuntimeException('Failed to create temporary extraction directory.');
            }

            if (! $zip->extractTo($tempDir)) {
                $zip->close();
                throw new \RuntimeException('Failed to extract the ZIP file.');
            }

            $zip->close();

            // Verify every required file exists in the extracted tree.
            $missing = [];
            foreach ($addon->required_files as $relativePath) {
                $fullPath = $tempDir.DIRECTORY_SEPARATOR.ltrim($relativePath, '/\\');
                if (! file_exists($fullPath)) {
                    $missing[] = $relativePath;
                }
            }

            if (! empty($missing)) {
                throw new \InvalidArgumentException(
                    'Addon validation failed. Missing required files: '.implode(', ', $missing)
                );
            }

            // Identity check: if the ZIP contains a theme.json, its "id" must match the addon slug.
            $themeJsonPath = $tempDir.DIRECTORY_SEPARATOR.'theme.json';
            if (file_exists($themeJsonPath)) {
                $raw = file_get_contents($themeJsonPath);
                $data = json_decode($raw, true);

                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new \InvalidArgumentException(
                        'Addon validation failed. theme.json contains invalid JSON: '.json_last_error_msg()
                    );
                }

                $themeId = $data['id'] ?? null;
                if ($themeId !== $addon->slug) {
                    throw new \InvalidArgumentException(
                        'Addon validation failed. theme.json id "'.($themeId ?? 'missing').'" does not match addon slug "'.$addon->slug.'".'
                    );
                }
            }

            // All required files present and identity verified — generate and store the signed token, then enable.
            $token = Addon::generateToken($addon->slug, $addon->name);

            $addon->update([
                'enabled' => true,
                'token' => $token,
                'installed_at' => now(),
            ]);

        } finally {
            // Always clean up the temp directory.
            if (is_dir($tempDir)) {
                self::deleteDirectory($tempDir);
            }
        }
    }

    private static function deleteDirectory(string $dir): void
    {
        try {
            $items = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::CHILD_FIRST
            );

            foreach ($items as $item) {
                $item->isDir() ? rmdir($item->getRealPath()) : unlink($item->getRealPath());
            }

            rmdir($dir);
        } catch (\Throwable $e) {
            Log::warning('Addon temp cleanup failed: '.$e->getMessage());
        }
    }
}
