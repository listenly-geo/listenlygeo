<?php

namespace App\Services\Billing;

use App\Models\Organization;
use App\Models\OrganizationSubscription;
use App\Models\PlatformBillingSetting;
use App\Models\SubscriptionPlan;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;

class StripeBillingService
{
    private const WEBHOOK_EVENTS = [
        'checkout.session.completed',
        'customer.subscription.created',
        'customer.subscription.updated',
        'customer.subscription.deleted',
    ];

    public function isConfigured(): bool
    {
        return filled($this->secretKey());
    }

    public function webhookSecret(): ?string
    {
        $settings = PlatformBillingSetting::query()->first();

        return filled($settings?->webhook_secret)
            ? $settings->webhook_secret
            : config('services.stripe.webhook_secret');
    }

    /**
     * @return array{created: bool, endpoint_id: string|null}
     */
    public function syncWebhookEndpoint(PlatformBillingSetting $settings): array
    {
        if (! $this->isConfigured()) {
            throw new RuntimeException('Stripe is not configured.');
        }

        $webhookEndpoint = $settings->webhook_endpoint ?: route('stripe.webhook');
        $metadata = $settings->metadata_json ?? [];
        $existingEndpointId = data_get($metadata, 'stripe_webhook_endpoint_id');

        if ($existingEndpointId && filled($settings->webhook_secret)) {
            $response = $this->post('/webhook_endpoints/'.$existingEndpointId, [
                'url' => $webhookEndpoint,
                'enabled_events' => self::WEBHOOK_EVENTS,
                'metadata' => ['source' => 'docthebuilder'],
            ]);

            if ($response->successful()) {
                $settings->forceFill([
                    'webhook_endpoint' => $webhookEndpoint,
                    'metadata_json' => [
                        ...$metadata,
                        'stripe_webhook_endpoint_id' => $existingEndpointId,
                        'stripe_webhook_synced_at' => now()->toIso8601String(),
                    ],
                ])->save();

                return ['created' => false, 'endpoint_id' => $existingEndpointId];
            }
        }

        $webhook = $this->post('/webhook_endpoints', [
            'url' => $webhookEndpoint,
            'enabled_events' => self::WEBHOOK_EVENTS,
            'metadata' => ['source' => 'docthebuilder'],
        ])->throw()->json();

        $settings->forceFill([
            'webhook_endpoint' => $webhookEndpoint,
            'webhook_secret' => $webhook['secret'] ?? null,
            'metadata_json' => [
                ...$metadata,
                'stripe_webhook_endpoint_id' => $webhook['id'] ?? null,
                'stripe_webhook_synced_at' => now()->toIso8601String(),
            ],
        ])->save();

        return ['created' => true, 'endpoint_id' => $webhook['id'] ?? null];
    }

    /**
     * @return array{synced: bool, skipped: bool, product_id: string|null}
     */
    public function syncPlan(SubscriptionPlan $plan): array
    {
        if (! $this->isConfigured()) {
            return ['synced' => false, 'skipped' => true, 'product_id' => $plan->stripe_product_id];
        }

        $product = $this->resolveProduct($plan);

        if (($product['id'] ?? null) !== $plan->stripe_product_id) {
            $plan->forceFill([
                'stripe_product_id' => $product['id'] ?? null,
            ])->save();
        }

        $monthlyPrice = $this->resolvePrice($plan, $product['id'], 'month');
        $annualPrice = $this->resolvePrice($plan, $product['id'], 'year');

        $plan->forceFill([
            'stripe_product_id' => $product['id'],
            'stripe_monthly_price_id' => $monthlyPrice['id'],
            'stripe_annual_price_id' => $annualPrice['id'],
            'stripe_synced_at' => now(),
        ])->save();

        return ['synced' => true, 'skipped' => false, 'product_id' => $product['id']];
    }

    public function ensureCustomer(Organization $organization): string
    {
        if (! $this->isConfigured()) {
            throw new RuntimeException('Stripe is not configured.');
        }

        if (filled($organization->stripe_customer_id)) {
            return $organization->stripe_customer_id;
        }

        $customer = $this->post('/customers', [
            'name' => $organization->name,
            'email' => $organization->billing_email,
            'metadata' => [
                'organization_id' => (string) $organization->id,
                'organization_slug' => $organization->slug,
            ],
        ])->throw()->json();

        $organization->forceFill(['stripe_customer_id' => $customer['id']])->save();

        return $customer['id'];
    }

    public function createCheckoutSession(Organization $organization, SubscriptionPlan $plan, string $interval, string $successUrl, string $cancelUrl): string
    {
        $this->syncPlan($plan);

        $priceId = $this->priceIdFor($plan->fresh(), $interval);

        if (! $priceId) {
            throw new RuntimeException('Stripe price is missing for this plan.');
        }

        $session = $this->post('/checkout/sessions', [
            'mode' => 'subscription',
            'customer' => $this->ensureCustomer($organization),
            'client_reference_id' => (string) $organization->id,
            'line_items' => [
                ['price' => $priceId, 'quantity' => 1],
            ],
            'success_url' => $successUrl,
            'cancel_url' => $cancelUrl,
            'metadata' => [
                'organization_id' => (string) $organization->id,
                'plan' => $plan->slug,
                'interval' => $interval,
            ],
            'subscription_data' => [
                'metadata' => [
                    'organization_id' => (string) $organization->id,
                    'plan' => $plan->slug,
                    'interval' => $interval,
                ],
            ],
        ])->throw()->json();

        OrganizationSubscription::query()->updateOrCreate(
            ['organization_id' => $organization->id],
            [
                'plan' => $plan->slug,
                'interval' => $interval,
                'status' => 'incomplete',
                'stripe_price_id' => $priceId,
                'stripe_checkout_session_id' => $session['id'] ?? null,
                'cancel_at_period_end' => false,
                'stripe_synced_at' => now(),
            ],
        );

        return $session['url'] ?? throw new RuntimeException('Stripe did not return a checkout URL.');
    }

    public function updateSubscriptionPlan(Organization $organization, SubscriptionPlan $plan, string $interval): void
    {
        $subscription = $organization->subscription;

        if (! $subscription?->stripe_subscription_id) {
            throw new RuntimeException('This organization does not have an active Stripe subscription.');
        }

        $this->syncPlan($plan);
        $priceId = $this->priceIdFor($plan->fresh(), $interval);

        if (! $priceId) {
            throw new RuntimeException('Stripe price is missing for this plan.');
        }

        $stripeSubscription = $this->get('/subscriptions/'.$subscription->stripe_subscription_id)->throw()->json();
        $itemId = data_get($stripeSubscription, 'items.data.0.id');

        if (! $itemId) {
            throw new RuntimeException('Stripe subscription does not have an editable item.');
        }

        $updated = $this->post('/subscriptions/'.$subscription->stripe_subscription_id, [
            'cancel_at_period_end' => false,
            'proration_behavior' => 'create_prorations',
            'items' => [
                ['id' => $itemId, 'price' => $priceId],
            ],
            'metadata' => [
                'organization_id' => (string) $organization->id,
                'plan' => $plan->slug,
                'interval' => $interval,
            ],
        ])->throw()->json();

        $this->applySubscriptionPayload($organization, $updated, $plan->slug, $interval, $priceId);
    }

    public function cancelAtPeriodEnd(Organization $organization): void
    {
        $subscription = $organization->subscription;

        if (! $subscription?->stripe_subscription_id) {
            $subscription?->forceFill([
                // Keep the current state while marking scheduled cancellation.
                'status' => $subscription->status ?: 'active',
                'cancel_at_period_end' => true,
                'stripe_synced_at' => now(),
            ])->save();

            return;
        }

        $updated = $this->post('/subscriptions/'.$subscription->stripe_subscription_id, [
            'cancel_at_period_end' => true,
        ])->throw()->json();

        $this->applySubscriptionPayload($organization, $updated, $subscription->plan, $subscription->interval, $subscription->stripe_price_id);
    }

    public function resumeSubscription(Organization $organization): void
    {
        $subscription = $organization->subscription;

        if (! $subscription) {
            throw new RuntimeException('This organization does not have a subscription to resume.');
        }

        if (! $subscription->stripe_subscription_id) {
            $subscription->forceFill([
                'status' => 'active',
                'cancel_at_period_end' => false,
                'stripe_synced_at' => now(),
            ])->save();

            return;
        }

        $updated = $this->post('/subscriptions/'.$subscription->stripe_subscription_id, [
            'cancel_at_period_end' => false,
        ])->throw()->json();

        $this->applySubscriptionPayload($organization, $updated, $subscription->plan, $subscription->interval, $subscription->stripe_price_id);
    }

    public function createBillingPortalSession(Organization $organization, string $returnUrl): string
    {
        $session = $this->post('/billing_portal/sessions', [
            'customer' => $this->ensureCustomer($organization),
            'return_url' => $returnUrl,
        ])->throw()->json();

        return $session['url'] ?? throw new RuntimeException('Stripe did not return a billing portal URL.');
    }

    public function reconcileOrganizationSubscription(Organization $organization): void
    {
        if (! $this->isConfigured()) {
            return;
        }

        $subscription = $organization->subscription;

        if (! $subscription) {
            return;
        }

        if (filled($subscription->stripe_subscription_id)) {
            $stripeSubscription = $this->get('/subscriptions/'.$subscription->stripe_subscription_id)->throw()->json();

            $this->applySubscriptionEvent($stripeSubscription);

            return;
        }

        if (! filled($subscription->stripe_checkout_session_id)) {
            return;
        }

        $checkoutSession = $this->get('/checkout/sessions/'.$subscription->stripe_checkout_session_id, [
            'expand' => ['subscription'],
        ])->throw()->json();

        $resolvedSubscription = data_get($checkoutSession, 'subscription');

        if (is_array($resolvedSubscription)) {
            $this->applySubscriptionEvent($resolvedSubscription);

            return;
        }

        if (is_string($resolvedSubscription) && $resolvedSubscription !== '') {
            $stripeSubscription = $this->get('/subscriptions/'.$resolvedSubscription)->throw()->json();
            $this->applySubscriptionEvent($stripeSubscription);

            return;
        }

        if (data_get($checkoutSession, 'status') === 'complete' && data_get($checkoutSession, 'payment_status') === 'paid') {
            $this->applyCheckoutSession($checkoutSession);
        }
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    public function applySubscriptionEvent(array $payload): void
    {
        $organizationId = (int) data_get($payload, 'metadata.organization_id');

        if (! $organizationId) {
            return;
        }

        $organization = Organization::query()->find($organizationId);

        if (! $organization) {
            return;
        }

        $priceId = data_get($payload, 'items.data.0.price.id');
        $matchedPlan = $priceId ? SubscriptionPlan::query()
            ->where('stripe_monthly_price_id', $priceId)
            ->orWhere('stripe_annual_price_id', $priceId)
            ->first() : null;
        $plan = $matchedPlan?->slug ?? (string) (data_get($payload, 'metadata.plan') ?: 'free');
        $interval = match (data_get($payload, 'items.data.0.price.recurring.interval')) {
            'year' => 'annual',
            'month' => 'monthly',
            default => (string) (data_get($payload, 'metadata.interval') ?: 'monthly'),
        };

        $this->applySubscriptionPayload($organization, $payload, $plan, $interval, $priceId);
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    public function applyCheckoutSession(array $payload): void
    {
        $organizationId = (int) data_get($payload, 'metadata.organization_id', data_get($payload, 'client_reference_id'));

        if (! $organizationId) {
            return;
        }

        $organization = Organization::query()->find($organizationId);

        if (! $organization) {
            return;
        }

        $subscriptionId = data_get($payload, 'subscription');
        $plan = (string) data_get($payload, 'metadata.plan', 'free');
        $interval = (string) data_get($payload, 'metadata.interval', 'monthly');

        OrganizationSubscription::query()->updateOrCreate(
            ['organization_id' => $organization->id],
            [
                'plan' => $plan,
                'interval' => $interval,
                'status' => 'active',
                'stripe_subscription_id' => $subscriptionId,
                'stripe_checkout_session_id' => data_get($payload, 'id'),
                'cancel_at_period_end' => false,
                'current_period_starts_at' => now(),
                'current_period_ends_at' => $interval === 'annual' ? now()->addYear() : now()->addMonth(),
                'stripe_synced_at' => now(),
            ],
        );
    }

    /**
     * @return array<string, mixed>
     */
    private function resolveProduct(SubscriptionPlan $plan): array
    {
        if (filled($plan->stripe_product_id)) {
            $response = $this->get('/products/'.$plan->stripe_product_id);

            if ($response->successful()) {
                $product = $response->json();

                return $this->post('/products/'.$product['id'], $this->productPayload($plan))->throw()->json();
            }
        }

        $existing = collect($this->get('/products', ['active' => true, 'limit' => 100])->throw()->json('data') ?? [])
            ->first(fn (array $product) => data_get($product, 'metadata.plan_slug') === $plan->slug);

        if ($existing) {
            return $this->post('/products/'.$existing['id'], $this->productPayload($plan))->throw()->json();
        }

        return $this->post('/products', $this->productPayload($plan))->throw()->json();
    }

    /**
     * @return array<string, mixed>
     */
    private function resolvePrice(SubscriptionPlan $plan, string $productId, string $interval): array
    {
        $priceId = $interval === 'year' ? $plan->stripe_annual_price_id : $plan->stripe_monthly_price_id;
        $amount = $interval === 'year' ? $plan->annual_price_cents : $plan->monthly_price_cents;

        if (filled($priceId)) {
            $response = $this->get('/prices/'.$priceId);

            if ($response->successful()) {
                $price = $response->json();

                if ((int) $price['unit_amount'] === (int) $amount && data_get($price, 'recurring.interval') === $interval) {
                    return $price;
                }
            }
        }

        return $this->post('/prices', [
            'product' => $productId,
            'unit_amount' => $amount,
            'currency' => config('services.stripe.currency', 'usd'),
            'nickname' => $plan->label.' '.Str::title($interval),
            'recurring' => ['interval' => $interval],
            'metadata' => [
                'plan_slug' => $plan->slug,
                'billing_interval' => $interval,
            ],
        ])->throw()->json();
    }

    /**
     * @return array<string, mixed>
     */
    private function productPayload(SubscriptionPlan $plan): array
    {
        return [
            'name' => $plan->label,
            'description' => $plan->description,
            'active' => $plan->status === 'active',
            'metadata' => [
                'plan_slug' => $plan->slug,
                'local_plan_id' => (string) $plan->id,
            ],
        ];
    }

    private function priceIdFor(SubscriptionPlan $plan, string $interval): ?string
    {
        return $interval === 'annual'
            ? $plan->stripe_annual_price_id
            : $plan->stripe_monthly_price_id;
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function applySubscriptionPayload(Organization $organization, array $payload, string $plan, string $interval, ?string $priceId): void
    {
        OrganizationSubscription::query()->updateOrCreate(
            ['organization_id' => $organization->id],
            [
                'plan' => $plan,
                'interval' => $interval,
                'status' => $this->normalizeSubscriptionStatus((string) data_get($payload, 'status', 'active')),
                'stripe_subscription_id' => data_get($payload, 'id'),
                'stripe_price_id' => $priceId,
                'cancel_at_period_end' => (bool) data_get($payload, 'cancel_at_period_end', false),
                'current_period_starts_at' => $this->timestampToDate(data_get($payload, 'current_period_start')),
                'current_period_ends_at' => $this->timestampToDate(data_get($payload, 'current_period_end')),
                'stripe_synced_at' => now(),
            ],
        );
    }

    private function normalizeSubscriptionStatus(string $status): string
    {
        return match ($status) {
            'active', 'trialing', 'past_due', 'canceled', 'incomplete' => $status,
            'unpaid', 'incomplete_expired' => 'past_due',
            default => 'active',
        };
    }

    private function timestampToDate(mixed $timestamp): mixed
    {
        return $timestamp ? Carbon::createFromTimestamp((int) $timestamp) : null;
    }

    private function request(): PendingRequest
    {
        return Http::baseUrl(rtrim((string) config('services.stripe.api_base'), '/'))
            ->withToken($this->secretKey())
            ->asForm()
            ->acceptJson();
    }

    /**
     * @param  array<string, mixed>  $query
     */
    private function get(string $uri, array $query = []): Response
    {
        return $this->request()->get($uri, $this->normalizeStripePayload($query));
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function post(string $uri, array $payload = []): Response
    {
        return $this->request()->post($uri, $this->normalizeStripePayload($payload));
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    private function normalizeStripePayload(array $payload): array
    {
        $normalized = [];

        foreach ($payload as $key => $value) {
            if (is_array($value)) {
                $normalized[$key] = $this->normalizeStripePayload($value);

                continue;
            }

            if (is_bool($value)) {
                $normalized[$key] = $value ? 'true' : 'false';

                continue;
            }

            $normalized[$key] = $value;
        }

        return $normalized;
    }

    private function secretKey(): string
    {
        $settings = PlatformBillingSetting::query()->first();

        return (string) (filled($settings?->secret_key)
            ? $settings->secret_key
            : config('services.stripe.secret'));
    }
}
