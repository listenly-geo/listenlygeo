<?php

namespace App\Policies;

use App\Models\Site;
use App\Models\User;

class SitePolicy
{
    public function view(User $user, Site $site): bool
    {
        return $this->hasActiveMembership($user, $site);
    }

    public function update(User $user, Site $site): bool
    {
        return $site->organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->whereIn('role', ['owner', 'admin', 'editor'])
            ->exists();
    }

    public function configure(User $user, Site $site): bool
    {
        return $site->organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->whereIn('role', ['owner', 'admin'])
            ->exists();
    }

    private function hasActiveMembership(User $user, Site $site): bool
    {
        return $site->organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->exists();
    }
}
