<?php

namespace App\Policies;

use App\Models\Page;
use App\Models\User;

class PagePolicy
{
    public function view(User $user, Page $page): bool
    {
        return $this->hasActiveMembership($user, $page);
    }

    public function update(User $user, Page $page): bool
    {
        return $page->site->organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->whereIn('role', ['owner', 'admin', 'editor'])
            ->exists();
    }

    private function hasActiveMembership(User $user, Page $page): bool
    {
        return $page->site->organization->memberships()
            ->where('user_id', $user->id)
            ->where('status', 'active')
            ->exists();
    }
}
