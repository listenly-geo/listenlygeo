<?php

use App\Actions\Docs\EnsureEditorWorkspace;
use App\Actions\Docs\PublishSiteRelease;
use App\Models\OrganizationMembership;
use App\Models\Page;
use App\Models\Site;
use App\Models\User;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('e2e:prepare', function (EnsureEditorWorkspace $ensureEditorWorkspace, PublishSiteRelease $publishSiteRelease) {
    $owner = User::query()->updateOrCreate(
        ['email' => 'e2e-owner@example.com'],
        [
            'name' => 'E2E Owner',
            'password' => 'password',
            'email_verified_at' => now(),
        ],
    );

    $workspace = $ensureEditorWorkspace($owner);
    $site = Site::query()->findOrFail($workspace['site']['id']);

    $page = Page::query()->with('currentRevision')->findOrFail($workspace['page']['id']);
    $currentRevision = $page->currentRevision;

    if ($currentRevision && $page->revisions()->count() < 2) {
        $seededRevision = $page->revisions()->create([
            'version_number' => ((int) $page->revisions()->max('version_number')) + 1,
            'title' => $currentRevision->title,
            'subtitle' => $currentRevision->subtitle,
            'blocks_json' => $currentRevision->blocks_json,
            'editor_meta_json' => $currentRevision->editor_meta_json,
            'search_document' => $currentRevision->search_document,
            'save_type' => 'manual',
            'change_message' => 'Prepared restore baseline',
            'created_by' => $owner->id,
        ]);

        $page->forceFill([
            'current_revision_id' => $seededRevision->id,
            'updated_by' => $owner->id,
        ])->save();
    }

    $roleAccounts = [
        'admin' => 'e2e-admin@example.com',
        'editor' => 'e2e-editor@example.com',
        'viewer' => 'e2e-viewer@example.com',
    ];

    foreach ($roleAccounts as $role => $email) {
        $user = User::query()->updateOrCreate(
            ['email' => $email],
            [
                'name' => 'E2E '.ucfirst($role),
                'password' => 'password',
                'email_verified_at' => now(),
            ],
        );

        OrganizationMembership::query()->updateOrCreate(
            [
                'organization_id' => $site->organization_id,
                'user_id' => $user->id,
            ],
            [
                'role' => $role,
                'status' => 'active',
            ],
        );
    }

    if ($site->fresh()->releases()->count() === 0) {
        $publishSiteRelease($site->fresh(), $owner, [
            'environment' => 'production',
            'message' => 'Initial E2E release',
        ]);
    }

    $this->components->info('Prepared E2E fixtures for owner, admin, editor, and viewer accounts.');
})->purpose('Prepare deterministic browser E2E fixtures.');
