<?php

use App\Http\Controllers\Settings\AppSettingsController;
use App\Http\Controllers\Settings\EmailConfigurationController;
use App\Http\Controllers\Settings\ProfileController;
use App\Http\Controllers\Settings\SecurityController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth'])->group(function () {
    Route::redirect('settings', '/settings/profile');

    Route::get('settings/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('settings/profile', [ProfileController::class, 'update'])->name('profile.update');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::delete('settings/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('settings/security', [SecurityController::class, 'edit'])->name('security.edit');

    Route::put('settings/password', [SecurityController::class, 'update'])
        ->middleware('throttle:6,1')
        ->name('user-password.update');

    Route::inertia('settings/appearance', 'settings/appearance')->name('appearance.edit');
});

Route::middleware(['auth', 'verified', 'platform.admin'])->group(function () {
    Route::get('settings/email-configuration', [EmailConfigurationController::class, 'edit'])->name('settings.email-configuration.edit');
    Route::patch('settings/email-configuration', [EmailConfigurationController::class, 'update'])->name('settings.email-configuration.update');
    Route::post('settings/email-configuration/test', [EmailConfigurationController::class, 'test'])->name('settings.email-configuration.test');

    Route::get('settings/application', [AppSettingsController::class, 'edit'])->name('settings.application.edit');
    Route::post('settings/application', [AppSettingsController::class, 'update'])->name('settings.application.update');
});
