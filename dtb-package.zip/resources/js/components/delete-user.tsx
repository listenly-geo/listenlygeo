import { Form } from '@inertiajs/react';
import { useRef } from 'react';
import ProfileController from '@/actions/App/Http/Controllers/Settings/ProfileController';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import PasswordInput from '@/components/password-input';
import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog';

export default function DeleteUser() {
    const passwordInput = useRef<HTMLInputElement>(null);

    return (
        <section className="admin-surface settings-danger-surface">
            <AdminCardHeader label="Danger zone" title="Delete account" />
            <div className="settings-danger-panel">
                <div>
                    <strong>Warning</strong>
                    <p>
                        Please proceed with caution, this cannot be undone.
                    </p>
                </div>

                <Dialog>
                    <DialogTrigger asChild>
                        <button
                            type="button"
                            className="admin-button settings-danger-button"
                            data-test="delete-user-button"
                        >
                            Delete account
                        </button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogTitle>
                            Are you sure you want to delete your account?
                        </DialogTitle>
                        <DialogDescription>
                            Once your account is deleted, all of its resources
                            and data will also be permanently deleted. Please
                            enter your password to confirm you would like to
                            permanently delete your account.
                        </DialogDescription>

                        <Form
                            {...ProfileController.destroy.form()}
                            options={{
                                preserveScroll: true,
                            }}
                            onError={() => passwordInput.current?.focus()}
                            resetOnSuccess
                            className="settings-dialog-form"
                        >
                            {({ resetAndClearErrors, processing, errors }) => (
                                <>
                                    <label className="admin-field" htmlFor="password">
                                        <span>Password</span>

                                        <PasswordInput
                                            id="password"
                                            name="password"
                                            ref={passwordInput}
                                            className="admin-text-input"
                                            placeholder="Password"
                                            autoComplete="current-password"
                                        />

                                        <InputError message={errors.password} />
                                    </label>

                                    <DialogFooter className="gap-2">
                                        <DialogClose asChild>
                                            <button
                                                type="button"
                                                className="admin-button admin-button-secondary"
                                                onClick={() =>
                                                    resetAndClearErrors()
                                                }
                                            >
                                                Cancel
                                            </button>
                                        </DialogClose>

                                        <button
                                            type="submit"
                                            className="admin-button settings-danger-button"
                                            disabled={processing}
                                            data-test="confirm-delete-user-button"
                                        >
                                            Delete account
                                        </button>
                                    </DialogFooter>
                                </>
                            )}
                        </Form>
                    </DialogContent>
                </Dialog>
            </div>
        </section>
    );
}
