import { usePage } from '@inertiajs/react';
import AppLogoIcon from '@/components/app-logo-icon';

export default function AppLogo() {
    const page = usePage<{ name?: string; appBranding?: { appName: string; logoUrl: string | null } }>();
    const appName = (page.props.appBranding?.appName || page.props.name)?.trim() || 'App';
    const logoUrl = page.props.appBranding?.logoUrl ?? null;

    return (
        <>
            <div className="flex aspect-square size-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground overflow-hidden">
                {logoUrl ? (
                    <img src={logoUrl} alt={appName} className="size-full object-contain" />
                ) : (
                    <AppLogoIcon className="size-5 fill-current text-white dark:text-black" />
                )}
            </div>
            <div className="ml-1 grid flex-1 text-left text-sm">
                <span className="mb-0.5 truncate leading-tight font-semibold">{appName}</span>
            </div>
        </>
    );
}
