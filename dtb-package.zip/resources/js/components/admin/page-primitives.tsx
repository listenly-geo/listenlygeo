import type { ReactNode } from 'react';

type AdminPageHeroProps = {
    eyebrow: string;
    title: string;
    description: ReactNode;
    actions?: ReactNode;
    accent?: boolean;
};

type AdminStatGridProps = {
    children: ReactNode;
    ariaLabel?: string;
};

type AdminStatCardProps = {
    label: string;
    value: ReactNode;
    meta: ReactNode;
};

type AdminCardHeaderProps = {
    label: string;
    title: ReactNode;
    action?: ReactNode;
};

type AdminEmptyStateProps = {
    icon?: ReactNode;
    children: ReactNode;
};

export function AdminPageHero({ eyebrow, title, description, actions, accent = true }: AdminPageHeroProps) {
    return (
        <section className={accent ? 'admin-surface admin-surface-accent' : 'admin-surface'}>
            <div className="admin-hero">
                <div>
                    <div className="admin-eyebrow">{eyebrow}</div>
                    <h1 className="admin-page-title">{title}</h1>
                    <p className="admin-page-copy">{description}</p>
                </div>

                {actions ? <div className="admin-hero-actions">{actions}</div> : null}
            </div>
        </section>
    );
}

export function AdminStatGrid({ children, ariaLabel }: AdminStatGridProps) {
    return (
        <section className="admin-stat-grid" aria-label={ariaLabel}>
            {children}
        </section>
    );
}

export function AdminStatCard({ label, value, meta }: AdminStatCardProps) {
    return (
        <article className="admin-surface admin-stat-card">
            <div className="admin-stat-label">{label}</div>
            <div className="admin-stat-value">{value}</div>
            <div className="admin-stat-meta">{meta}</div>
        </article>
    );
}

export function AdminCardHeader({ label, title, action }: AdminCardHeaderProps) {
    return (
        <div className="admin-card-header">
            <div>
                <div className="admin-card-label">{label}</div>
                <h2>{title}</h2>
            </div>

            {action ? action : null}
        </div>
    );
}

export function AdminEmptyState({ icon, children }: AdminEmptyStateProps) {
    return (
        <div className="admin-empty-state">
            {icon ? icon : null}
            <span>{children}</span>
        </div>
    );
}