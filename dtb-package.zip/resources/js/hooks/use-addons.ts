import { usePage } from '@inertiajs/react';

/**
 * Returns a map of addon slug → boolean where true means the addon is installed
 * and its HMAC token was verified server-side.
 *
 * Usage:
 *   const addons = useAddons();
 *   if (addons['docs-theme-dark']) { ... }
 *
 * Or with the helper:
 *   const isEnabled = useAddon('docs-theme-dark');
 */
export function useAddons(): Record<string, boolean> {
    const props = usePage<{ addons?: Record<string, boolean> }>().props;

    return props.addons ?? {};
}

/**
 * Convenience helper for a single addon slug.
 */
export function useAddon(slug: string): boolean {
    return useAddons()[slug] ?? false;
}
