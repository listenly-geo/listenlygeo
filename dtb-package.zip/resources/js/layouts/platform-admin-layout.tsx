import { Link, router, usePage } from '@inertiajs/react';
import {
    Activity,
    ChevronRight,
    CreditCard,
    LayoutDashboard,
    LineChart,
    LogOut,
    MoonStar,
    PanelLeftClose,
    PanelLeftOpen,
    ScrollText,
    Settings,
    ShieldCheck,
    SunMedium,
    Users,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import { logout } from '@/routes';
import type { Auth } from '@/types/auth';

type PlatformAdminLayoutProps = {
    children: React.ReactNode;
};

type NavItem = {
    title: string;
    description: string;
    icon: LucideIcon;
    href: string;
    current: boolean;
};

export default function PlatformAdminLayout({ children }: PlatformAdminLayoutProps) {
    const page = usePage<{ auth: Auth; name: string; appBranding: { appName: string; logoUrl: string | null } }>();
    const { auth, appBranding } = page.props;
    const [theme, setTheme] = useState<'light' | 'dark'>('light');
    const [collapsed, setCollapsed] = useState(false);
    const [accountOpen, setAccountOpen] = useState(false);
    const user = auth.user;
    const currentComponent = page.component;
    const dashboardHref = '/admin';

    const currentMeta = {
        'admin/dashboard': {
            section: 'Overview',
            message: 'platform-wide customers, revenue, and operations',
        },
        'admin/plans/index': {
            section: 'Plan Management',
            message: 'create and edit the live subscription catalog',
        },
        'admin/users/index': {
            section: 'User Management',
            message: 'review platform admins and customer accounts',
        },
        'admin/reports/index': {
            section: 'Reports',
            message: 'subscription posture and customer billing snapshots',
        },
        'admin/analytics': {
            section: 'Analytics',
            message: 'platform growth and documentation activity',
        },
        'admin/commerce': {
            section: 'Commerce',
            message: 'customer subscriptions, invoices, and gateway controls',
        },
    }[currentComponent] ?? {
        section: 'Platform Admin',
        message: 'same product language, separate admin surface',
    };
    const appName = appBranding?.appName?.trim() || 'App';
    const logoUrl = appBranding?.logoUrl ?? null;
    const brandMark = appName.charAt(0).toUpperCase() || 'A';

    const navigation = useMemo<NavItem[]>(
        () => [
            {
                title: 'Overview',
                description: 'Platform pulse',
                icon: LayoutDashboard,
                href: '/admin',
                current: currentComponent === 'admin/dashboard',
            },
            {
                title: 'Plans',
                description: 'Catalog and pricing',
                icon: CreditCard,
                href: '/admin/plans',
                current: currentComponent === 'admin/plans/index',
            },
            {
                title: 'Users',
                description: 'Admins and customers',
                icon: Users,
                href: '/admin/users',
                current: currentComponent === 'admin/users/index',
            },
            {
                title: 'Reports',
                description: 'Operational reporting',
                icon: ScrollText,
                href: '/admin/reports',
                current: currentComponent === 'admin/reports/index',
            },
            {
                title: 'Analytics',
                description: 'Growth and activity',
                icon: LineChart,
                href: '/admin/analytics',
                current: currentComponent === 'admin/analytics',
            },
            {
                title: 'Commerce',
                description: 'Subscriptions and gateway',
                icon: Activity,
                href: '/admin/commerce',
                current: currentComponent === 'admin/commerce',
            },
        ],
        [currentComponent],
    );

    const initials = (user?.name ?? 'User')
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((part) => part[0]?.toUpperCase())
        .join('') || 'NA';

    const handleLogoutClick = () => {
        setAccountOpen(false);
        router.flushAll();
    };

    return (
        <div className={`admin-shell ${theme === 'dark' ? 'theme-dark' : 'theme-light'} ${collapsed ? 'admin-shell-collapsed' : ''}`}>
            <header className="admin-topbar">
                <div className="admin-brand">
                    {logoUrl ? (
                        <img src={logoUrl} alt={appName} className="admin-brand-logo" />
                    ) : (
                        <div className="admin-brand-mark">{brandMark}</div>
                    )}
                    <span className="admin-brand-name">{appName}</span>
                    <span className="admin-brand-divider">/</span>
                    <span className="admin-brand-space">Platform Admin</span>
                </div>

                <div className="admin-crumbs">
                    <span>Platform</span>
                    <span className="sep">&gt;</span>
                    <span className="cur">{currentMeta.section}</span>
                    <span className="saved">{currentMeta.message}</span>
                </div>

                <div className="admin-topbar-right">
                    <button
                        type="button"
                        className="admin-icon-btn"
                        title={collapsed ? 'Expand navigation' : 'Collapse navigation'}
                        onClick={() => setCollapsed((value) => !value)}
                    >
                        {collapsed ? <PanelLeftOpen size={14} /> : <PanelLeftClose size={14} />}
                    </button>

                    <button
                        type="button"
                        className="admin-icon-btn"
                        title="Toggle theme"
                        onClick={() => setTheme((value) => (value === 'light' ? 'dark' : 'light'))}
                    >
                        {theme === 'light' ? <MoonStar size={14} /> : <SunMedium size={14} />}
                    </button>

                    <div
                        className="admin-account-menu"
                        onKeyDown={(event) => {
                            if (event.key === 'Escape') {
                                setAccountOpen(false);
                            }
                        }}
                    >
                        <button
                            type="button"
                            className="admin-avatar-trigger"
                            aria-haspopup="menu"
                            aria-expanded={accountOpen}
                            title="Account menu"
                            onClick={() => setAccountOpen((value) => !value)}
                        >
                            <span className="admin-avatar admin-avatar-primary">{initials}</span>
                        </button>

                        {accountOpen ? (
                            <div className="admin-account-dropdown" role="menu">
                                <div className="admin-account-card">
                                    <span className="admin-account-icon">
                                        <ShieldCheck size={15} />
                                    </span>
                                    <div>
                                        <strong>{user?.name ?? 'User'}</strong>
                                        <small>{user?.email ?? 'Signed in'}</small>
                                    </div>
                                </div>
                                <Link href={dashboardHref} className="admin-account-action" role="menuitem" onClick={() => setAccountOpen(false)}>
                                    <LayoutDashboard size={14} />
                                    Dashboard
                                </Link>
                                <Link href="/settings/profile" className="admin-account-action" role="menuitem" onClick={() => setAccountOpen(false)}>
                                    <Settings size={14} />
                                    Settings
                                </Link>
                                <Link
                                    href={logout()}
                                    as="button"
                                    className="admin-account-action admin-account-logout"
                                    role="menuitem"
                                    onClick={handleLogoutClick}
                                    data-test="admin-logout-button"
                                >
                                    <LogOut size={14} />
                                    Log out
                                </Link>
                            </div>
                        ) : null}
                    </div>
                </div>
            </header>

            <div className="admin-shell-body">
                <aside className="admin-sidebar">
                    <div className="admin-sidebar-section">
                        <nav className="admin-nav-list" aria-label="Platform admin navigation">
                            {navigation.map((item) => {
                                const Icon = item.icon;

                                return (
                                    <Link key={item.title} href={item.href} className={`admin-nav-item ${item.current ? 'is-current' : ''}`}>
                                        <div className="admin-nav-icon">
                                            <Icon size={14} />
                                        </div>
                                        <div className="admin-nav-copy">
                                            <span>{item.title}</span>
                                            <small>{item.description}</small>
                                        </div>
                                        <ChevronRight className="admin-nav-chevron" size={14} />
                                    </Link>
                                );
                            })}
                        </nav>
                    </div>
                </aside>

                <main className="admin-main">{children}</main>
            </div>
        </div>
    );
}