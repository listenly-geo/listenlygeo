import { Link, router, usePage } from '@inertiajs/react';
import {
    Activity,
    BookOpenText,
    ChevronRight,
    CreditCard,
    FolderKanban,
    Image,
    LayoutDashboard,
    LogOut,
    MoonStar,
    PanelLeftClose,
    PanelLeftOpen,
    Rocket,
    Settings,
    ShieldCheck,
    SunMedium,
    UserRound,
    Users,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import { dashboard, logout } from '@/routes';
import type { Auth } from '@/types/auth';

type AdminDashboardLayoutProps = {
    children: React.ReactNode;
};

type NavItem = {
    title: string;
    description: string;
    icon: LucideIcon;
    href?: string;
    current?: boolean;
    soon?: boolean;
};

export default function AdminDashboardLayout({ children }: AdminDashboardLayoutProps) {
    const page = usePage<{ auth: Auth; name: string; appBranding: { appName: string; logoUrl: string | null } }>();
    const { auth, appBranding } = page.props;
    const [theme, setTheme] = useState<'light' | 'dark'>('light');
    const [collapsed, setCollapsed] = useState(false);
    const [accountOpen, setAccountOpen] = useState(false);
    const user = auth.user;
    const isPlatformAdmin = Boolean(user?.isPlatformAdmin ?? user?.is_platform_admin);
    const currentComponent = page.component;
    const currentMeta = {
        dashboard: {
            section: 'Dashboard',
            message: 'same editor language, admin surface',
        },
        'dashboard/sites': {
            section: 'Sites',
            message: 'open site editors and inspect details',
        },
        'dashboard/team': {
            section: 'Team & Roles',
            message: 'shape access, roles, and collaborator handoff',
        },
        'dashboard/releases': {
            section: 'Releases',
            message: 'publish immutable snapshots and track release cadence',
        },
        'dashboard/analytics': {
            section: 'Analytics',
            message: 'inspect revision volume, publish cadence, and recent document activity',
        },
        'dashboard/billing': {
            section: isPlatformAdmin ? 'Commerce' : 'Plans & Billing',
            message: isPlatformAdmin ? 'manage plans, customer bills, and payment gateways' : 'manage your plan, billing contact, and usage posture',
        },
        'dashboard/commerce': {
            section: 'Commerce',
            message: 'legacy entrypoint redirecting to platform admin commerce',
        },
        'dashboard/media': {
            section: 'Media Library',
            message: 'upload assets, inspect file usage, and curate shared docs media',
        },
        'dashboard/settings': {
            section: 'Settings',
            message: 'configure domains, seo, and public brand framing',
        },
        'settings/profile': {
            section: 'Profile',
            message: 'manage your account identity and email address',
        },
        'settings/security': {
            section: 'Security',
            message: 'manage password and two-factor protection',
        },
        'settings/appearance': {
            section: 'Appearance',
            message: 'tune your personal interface preference',
        },
    }[currentComponent] ?? {
        section: 'Dashboard',
        message: 'same editor language, admin surface',
    };
    const appName = appBranding?.appName?.trim() || 'App';
    const logoUrl = appBranding?.logoUrl ?? null;
    const brandMark = appName.charAt(0).toUpperCase() || 'A';
    const dashboardHref = isPlatformAdmin ? '/admin' : dashboard().url;

    const navigation = useMemo<NavItem[]>(
        () => {
            if (isPlatformAdmin) {
                return [
                    {
                        title: 'Overview',
                        description: 'Platform dashboard',
                        icon: LayoutDashboard,
                        href: '/admin',
                        current: false,
                    },
                    {
                        title: 'Plans',
                        description: 'Catalog and pricing',
                        icon: CreditCard,
                        href: '/admin/plans',
                        current: false,
                    },
                    {
                        title: 'Users',
                        description: 'Admins and customers',
                        icon: Users,
                        href: '/admin/users',
                        current: false,
                    },
                    {
                        title: 'Reports',
                        description: 'Operational reporting',
                        icon: Rocket,
                        href: '/admin/reports',
                        current: false,
                    },
                    {
                        title: 'Analytics',
                        description: 'Growth and activity',
                        icon: Activity,
                        href: '/admin/analytics',
                        current: false,
                    },
                    {
                        title: 'Commerce',
                        description: 'Plans, bills, gateways',
                        icon: CreditCard,
                        href: '/admin/commerce',
                        current: false,
                    },
                ];
            }

            return [
                {
                    title: 'Overview',
                    description: 'Workspace pulse',
                    icon: LayoutDashboard,
                    href: dashboardHref,
                    current: currentComponent === 'dashboard',
                },
                {
                    title: 'Sites',
                    description: 'List, editor, details',
                    icon: FolderKanban,
                    href: '/dashboard/sites',
                    current: currentComponent === 'dashboard/sites',
                },
                {
                    title: 'Team & Roles',
                    description: 'Members and invites',
                    icon: Users,
                    href: '/dashboard/team',
                    current: currentComponent === 'dashboard/team',
                },
                {
                    title: 'Releases',
                    description: 'Publish history and environments',
                    icon: Rocket,
                    href: '/dashboard/releases',
                    current: currentComponent === 'dashboard/releases',
                },
                {
                    title: 'Analytics',
                    description: 'Revision and release activity',
                    icon: Activity,
                    href: '/dashboard/analytics',
                    current: currentComponent === 'dashboard/analytics',
                },
                {
                    title: 'Plans & Billing',
                    description: 'Plans and subscriptions',
                    icon: CreditCard,
                    href: '/dashboard/billing',
                    current: currentComponent === 'dashboard/billing',
                },
                {
                    title: 'Media Library',
                    description: 'Uploads and shared assets',
                    icon: Image,
                    href: '/dashboard/media',
                    current: currentComponent === 'dashboard/media',
                },
                {
                    title: 'Settings',
                    description: 'Domains, SEO, branding',
                    icon: Settings,
                    href: '/dashboard/settings',
                    current: currentComponent === 'dashboard/settings',
                },
            ];
        },
        [currentComponent, dashboardHref, isPlatformAdmin],
    );

    const initials = (user?.name ?? 'User')
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((part) => part[0]?.toUpperCase())
        .join('') || 'NA';

    const handleLogoutClick = () => {
        setAccountOpen(false);
        router.flushAll();
    };

    return (
        <div className={`admin-shell ${theme === 'dark' ? 'theme-dark' : 'theme-light'} ${collapsed ? 'admin-shell-collapsed' : ''}`}>
            <header className="admin-topbar">
                <div className="admin-brand">
                    {logoUrl ? (
                        <img src={logoUrl} alt={appName} className="admin-brand-logo" />
                    ) : (
                        <div className="admin-brand-mark">{brandMark}</div>
                    )}
                    <span className="admin-brand-name">{appName}</span>
                    <span className="admin-brand-divider">/</span>
                    <span className="admin-brand-space">{isPlatformAdmin ? 'Platform Admin' : 'Customer Workspace'}</span>
                </div>

                <div className="admin-crumbs">
                    <span>{isPlatformAdmin ? 'Platform' : 'Workspace'}</span>
                    <span className="sep">&gt;</span>
                    <span className="cur">{currentMeta.section}</span>
                    <span className="saved">{currentMeta.message}</span>
                </div>

                <div className="admin-topbar-right">
                    {isPlatformAdmin ? null : (
                        <Link href="/dashboard/sites" className="admin-search-link">
                            <BookOpenText size={13} />
                            <span>Choose editor site</span>
                            <span className="kbd">pick</span>
                        </Link>
                    )}

                    <button
                        type="button"
                        className="admin-icon-btn"
                        title={collapsed ? 'Expand navigation' : 'Collapse navigation'}
                        onClick={() => setCollapsed((value) => !value)}
                    >
                        {collapsed ? <PanelLeftOpen size={14} /> : <PanelLeftClose size={14} />}
                    </button>

                    <button
                        type="button"
                        className="admin-icon-btn"
                        title="Toggle theme"
                        onClick={() => setTheme((value) => (value === 'light' ? 'dark' : 'light'))}
                    >
                        {theme === 'light' ? <MoonStar size={14} /> : <SunMedium size={14} />}
                    </button>

                    <div
                        className="admin-account-menu"
                        onKeyDown={(event) => {
                            if (event.key === 'Escape') {
                                setAccountOpen(false);
                            }
                        }}
                    >
                        <button
                            type="button"
                            className="admin-avatar-trigger"
                            aria-haspopup="menu"
                            aria-expanded={accountOpen}
                            title="Account menu"
                            onClick={() => setAccountOpen((value) => !value)}
                        >
                            <span className="admin-avatar admin-avatar-primary">{initials}</span>
                        </button>

                        {accountOpen ? (
                            <div className="admin-account-dropdown" role="menu">
                                <div className="admin-account-card">
                                    <span className="admin-account-icon">
                                        {isPlatformAdmin ? <ShieldCheck size={15} /> : <UserRound size={15} />}
                                    </span>
                                    <div>
                                        <strong>{user?.name ?? 'User'}</strong>
                                        <small>{user?.email ?? 'Signed in'}</small>
                                    </div>
                                </div>
                                <Link href={dashboardHref} className="admin-account-action" role="menuitem" onClick={() => setAccountOpen(false)}>
                                    <LayoutDashboard size={14} />
                                    Dashboard
                                </Link>
                                <Link href="/settings/profile" className="admin-account-action" role="menuitem" onClick={() => setAccountOpen(false)}>
                                    <Settings size={14} />
                                    Settings
                                </Link>
                                <Link
                                    href={logout()}
                                    as="button"
                                    className="admin-account-action admin-account-logout"
                                    role="menuitem"
                                    onClick={handleLogoutClick}
                                    data-test="admin-logout-button"
                                >
                                    <LogOut size={14} />
                                    Log out
                                </Link>
                            </div>
                        ) : null}
                    </div>
                </div>
            </header>

            <div className="admin-shell-body">
                <aside className="admin-sidebar">
                    <div className="admin-sidebar-section">
                        <nav className="admin-nav-list" aria-label="Dashboard navigation">
                            {navigation.map((item) => {
                                const Icon = item.icon;

                                if (item.href) {
                                    if (item.href === '/editor') {
                                        return (
                                            <a key={item.title} href={item.href} className={`admin-nav-item ${item.current ? 'is-current' : ''}`}>
                                                <div className="admin-nav-icon">
                                                    <Icon size={14} />
                                                </div>
                                                <div className="admin-nav-copy">
                                                    <span>{item.title}</span>
                                                    <small>{item.description}</small>
                                                </div>
                                                <ChevronRight className="admin-nav-chevron" size={14} />
                                            </a>
                                        );
                                    }

                                    return (
                                        <Link key={item.title} href={item.href} className={`admin-nav-item ${item.current ? 'is-current' : ''}`}>
                                            <div className="admin-nav-icon">
                                                <Icon size={14} />
                                            </div>
                                            <div className="admin-nav-copy">
                                                <span>{item.title}</span>
                                                <small>{item.description}</small>
                                            </div>
                                            <ChevronRight className="admin-nav-chevron" size={14} />
                                        </Link>
                                    );
                                }

                                return (
                                    <div key={item.title} className="admin-nav-item is-soon" aria-disabled="true">
                                        <div className="admin-nav-icon">
                                            <Icon size={14} />
                                        </div>
                                        <div className="admin-nav-copy">
                                            <span>{item.title}</span>
                                            <small>{item.description}</small>
                                        </div>
                                        <span className="admin-soon-pill">soon</span>
                                    </div>
                                );
                            })}
                        </nav>
                    </div>
                </aside>

                <main className="admin-content">{children}</main>
            </div>
        </div>
    );
}