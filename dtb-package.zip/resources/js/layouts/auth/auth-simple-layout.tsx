import { Link } from '@inertiajs/react';
import { usePage } from '@inertiajs/react';
import { Layers3, ShieldCheck, Sparkles } from 'lucide-react';
import { home } from '@/routes';
import type { AuthLayoutProps } from '@/types';

export default function AuthSimpleLayout({
    children,
    title,
    description,
}: AuthLayoutProps) {
    const page = usePage<{ name?: string; appBranding?: { appName: string; logoUrl: string | null } }>();
    const appName = (page.props.appBranding?.appName || page.props.name)?.trim() || 'App';
    const logoUrl = page.props.appBranding?.logoUrl ?? null;
    const brandMark = appName.charAt(0).toUpperCase();

    return (
        <div className="relative min-h-svh overflow-hidden bg-[radial-gradient(circle_at_8%_10%,rgba(44,132,102,0.14),transparent_36%),radial-gradient(circle_at_92%_88%,rgba(218,132,72,0.16),transparent_34%),linear-gradient(160deg,#f4f4ef,#f7f8fb_46%,#f1f5fb)] px-4 py-8 sm:px-6 md:px-10 md:py-12">
            <div className="pointer-events-none absolute inset-0 opacity-50 [background-image:linear-gradient(rgba(26,35,31,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(26,35,31,0.05)_1px,transparent_1px)] [background-size:44px_44px]" />

            <div className="relative mx-auto grid w-full max-w-5xl overflow-hidden rounded-2xl border border-black/10 bg-white/85 shadow-[0_30px_80px_rgba(20,28,24,0.14)] backdrop-blur md:grid-cols-[1.1fr_1fr]">
                <section className="relative hidden min-h-full flex-col justify-between bg-[linear-gradient(150deg,#17332d_2%,#20493e_58%,#1a3c33_100%)] p-10 text-white md:flex">
                    <div className="absolute -left-12 top-16 h-36 w-36 rounded-full bg-amber-300/20 blur-2xl" />
                    <div className="absolute -right-10 bottom-20 h-40 w-40 rounded-full bg-emerald-300/20 blur-2xl" />

                    <div className="relative space-y-8">
                        <div className="inline-flex items-center gap-3 rounded-xl border border-white/20 bg-white/10 px-3 py-2">
                            {logoUrl ? (
                                <img src={logoUrl} alt={appName} className="h-9 w-9 rounded-lg object-contain" />
                            ) : (
                                <span className="grid h-9 w-9 place-items-center rounded-lg bg-white/15 font-bold text-white text-sm">
                                    {brandMark}
                                </span>
                            )}
                            <strong className="text-sm tracking-wide uppercase">{appName}</strong>
                        </div>

                        <div className="space-y-3">
                            <p className="text-xs tracking-[0.24em] text-white/70 uppercase">Workspace Access</p>
                            <h2 className="max-w-sm text-3xl leading-tight font-semibold">Secure publishing workflows with team-ready controls.</h2>
                            <p className="max-w-sm text-sm leading-6 text-white/78">One place for docs, releases, and collaboration with clear control over every environment.</p>
                        </div>
                    </div>

                    <div className="relative space-y-3">
                        <div className="flex items-center gap-3 rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-sm">
                            <ShieldCheck className="size-4" />
                            Verified sessions and protected account flows
                        </div>
                        <div className="flex items-center gap-3 rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-sm">
                            <Layers3 className="size-4" />
                            Site, space, and page context in one workspace
                        </div>
                        <div className="flex items-center gap-3 rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-sm">
                            <Sparkles className="size-4" />
                            Fast onboarding with modern editor-ready UX
                        </div>
                    </div>
                </section>

                <section className="flex min-h-[640px] items-center justify-center p-6 sm:p-10">
                    <div className="w-full max-w-sm space-y-7">
                        <div className="flex flex-col items-center gap-4 text-center">
                            <Link
                                href={home()}
                                className="inline-flex items-center gap-3 rounded-xl border border-black/10 bg-white px-3 py-2 font-medium text-neutral-900 shadow-sm transition hover:bg-neutral-50"
                            >
                                {logoUrl ? (
                                    <img src={logoUrl} alt={appName} className="h-8 w-8 rounded-lg object-contain" />
                                ) : (
                                    <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#1f4c40] font-bold text-white text-xs">
                                        {brandMark}
                                    </span>
                                )}
                                <span className="text-sm font-semibold tracking-wide uppercase">{appName}</span>
                            </Link>

                            <div className="space-y-2">
                                <h1 className="text-2xl leading-tight font-semibold tracking-tight text-neutral-900">{title}</h1>
                                <p className="text-sm leading-6 text-neutral-600">
                                    {description}
                                </p>
                            </div>
                        </div>

                        <div className="rounded-2xl border border-black/8 bg-white p-5 shadow-[0_14px_40px_rgba(20,28,24,0.08)] sm:p-6">
                            {children}
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
}
