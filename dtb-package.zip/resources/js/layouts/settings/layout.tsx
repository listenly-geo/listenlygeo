import { Link, usePage } from '@inertiajs/react';
import { AppWindow, FileText, Mail, MonitorCog, Package, ShieldCheck, UserRound } from 'lucide-react';
import type { PropsWithChildren } from 'react';
import { AdminCardHeader, AdminPageHero } from '@/components/admin/page-primitives';
import { useCurrentUrl } from '@/hooks/use-current-url';
import { edit as editAppearance } from '@/routes/appearance';
import { edit } from '@/routes/profile';
import { edit as editSecurity } from '@/routes/security';
import type { NavItem } from '@/types';
import type { Auth } from '@/types/auth';

const baseSidebarNavItems: NavItem[] = [
    {
        title: 'Profile',
        href: edit(),
        icon: UserRound,
    },
    {
        title: 'Security',
        href: editSecurity(),
        icon: ShieldCheck,
    },
    {
        title: 'Appearance',
        href: editAppearance(),
        icon: MonitorCog,
    },
];

export default function SettingsLayout({ children }: PropsWithChildren) {
    const page = usePage<{ auth: Auth }>();
    const isPlatformAdmin = Boolean(page.props.auth.user?.isPlatformAdmin ?? page.props.auth.user?.is_platform_admin);
    const { isCurrentOrParentUrl } = useCurrentUrl();
    const sidebarNavItems = [
        ...baseSidebarNavItems,
        ...(isPlatformAdmin
            ? [
                {
                    title: 'Email Configuration',
                    href: '/settings/email-configuration',
                    icon: Mail,
                },
                {
                    title: 'Landing Content',
                    href: '/admin/landing-content',
                    icon: FileText,
                },
                {
                    title: 'Application',
                    href: '/settings/application',
                    icon: AppWindow,
                },
                {
                    title: 'Addons',
                    href: '/admin/addons',
                    icon: Package,
                },
              ]
            : []),
    ];

    return (
        <div className="admin-page-wrap settings-admin-page">
            <AdminPageHero
                eyebrow="Account settings"
                title="Manage your profile and security."
                description="Update personal account details, password protection, two-factor access, and interface preferences from the same admin workspace."
            />

            <section className="settings-admin-grid">
                <aside className="admin-surface settings-admin-nav-surface">
                    <AdminCardHeader label="Account" title="Personal controls" />

                    <nav className="admin-nav-list settings-admin-nav" aria-label="Settings">
                        {sidebarNavItems.map((item) => {
                            const Icon = item.icon;

                            return (
                                <Link
                                    key={item.title}
                                    href={item.href}
                                    className={`admin-nav-item ${isCurrentOrParentUrl(item.href) ? 'is-current' : ''}`}
                                >
                                    <div className="admin-nav-icon">
                                        {Icon ? <Icon size={14} /> : null}
                                    </div>
                                    <div className="admin-nav-copy">
                                        <span>{item.title}</span>
                                        <small>
                                            {item.title === 'Profile'
                                                ? 'Name and email'
                                                : item.title === 'Security'
                                                    ? 'Password and 2FA'
                                                    : item.title === 'Email Configuration'
                                                        ? 'SMTP and connection test'
                                                        : item.title === 'Landing Content'
                                                            ? 'Homepage CMS'
                                                            : item.title === 'Application'
                                                                ? 'Branding and identity'
                                                                : item.title === 'Addons'
                                                                    ? 'Feature activation'
                                                                    : 'Theme preference'}
                                        </small>
                                    </div>
                                </Link>
                            );
                        })}
                    </nav>
                </aside>

                <div className="settings-admin-content">{children}</div>
            </section>
        </div>
    );
}
