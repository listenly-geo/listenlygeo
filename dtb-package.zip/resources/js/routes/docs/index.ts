import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
export const index = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/docs/{siteSlug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
index.url = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { siteSlug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    siteSlug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        siteSlug: args.siteSlug,
                }

    return index.definition.url
            .replace('{siteSlug}', parsedArgs.siteSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
index.get = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
index.head = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
    const indexForm = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
        indexForm.get = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
        indexForm.head = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
export const show = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/docs/{siteSlug}/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
show.url = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    siteSlug: args[0],
                    path: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        siteSlug: args.siteSlug,
                                path: args.path,
                }

    return show.definition.url
            .replace('{siteSlug}', parsedArgs.siteSlug.toString())
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
show.get = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
show.head = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
    const showForm = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
        showForm.get = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
        showForm.head = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const docs = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default docs