import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import revisions from './revisions'
import tree from './tree'
import comments from './comments'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
export const autosave = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: autosave.url(args, options),
    method: 'post',
})

autosave.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/autosave',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
autosave.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return autosave.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
autosave.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: autosave.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
    const autosaveForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: autosave.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
        autosaveForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: autosave.url(args, options),
            method: 'post',
        })
    
    autosave.form = autosaveForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
export const aiWrite = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: aiWrite.url(args, options),
    method: 'post',
})

aiWrite.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/ai-write',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
aiWrite.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return aiWrite.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
aiWrite.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: aiWrite.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
    const aiWriteForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: aiWrite.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
        aiWriteForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: aiWrite.url(args, options),
            method: 'post',
        })
    
    aiWrite.form = aiWriteForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
export const exportMethod = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/editor/api/pages/{page}/export/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
exportMethod.url = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                    format: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                                format: args.format,
                }

    return exportMethod.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
exportMethod.get = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
exportMethod.head = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
    const exportMethodForm = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
        exportMethodForm.get = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
        exportMethodForm.head = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::destroy
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:96
 * @route '/editor/api/pages/{page}'
 */
export const destroy = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/editor/api/pages/{page}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::destroy
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:96
 * @route '/editor/api/pages/{page}'
 */
destroy.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return destroy.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::destroy
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:96
 * @route '/editor/api/pages/{page}'
 */
destroy.delete = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::destroy
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:96
 * @route '/editor/api/pages/{page}'
 */
    const destroyForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::destroy
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:96
 * @route '/editor/api/pages/{page}'
 */
        destroyForm.delete = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const pages = {
    autosave: Object.assign(autosave, autosave),
revisions: Object.assign(revisions, revisions),
aiWrite: Object.assign(aiWrite, aiWrite),
export: Object.assign(exportMethod, exportMethod),
tree: Object.assign(tree, tree),
destroy: Object.assign(destroy, destroy),
comments: Object.assign(comments, comments),
}

export default pages