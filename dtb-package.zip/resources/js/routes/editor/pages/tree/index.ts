import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::update
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:53
 * @route '/editor/api/pages/{page}'
 */
export const update = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/editor/api/pages/{page}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::update
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:53
 * @route '/editor/api/pages/{page}'
 */
update.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return update.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::update
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:53
 * @route '/editor/api/pages/{page}'
 */
update.patch = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::update
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:53
 * @route '/editor/api/pages/{page}'
 */
    const updateForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::update
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:53
 * @route '/editor/api/pages/{page}'
 */
        updateForm.patch = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::move
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:70
 * @route '/editor/api/pages/{page}/move'
 */
export const move = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

move.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/move',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::move
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:70
 * @route '/editor/api/pages/{page}/move'
 */
move.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return move.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::move
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:70
 * @route '/editor/api/pages/{page}/move'
 */
move.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::move
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:70
 * @route '/editor/api/pages/{page}/move'
 */
    const moveForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: move.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPageTreeController::move
 * @see app/Http/Controllers/Editor/PrototypeEditorPageTreeController.php:70
 * @route '/editor/api/pages/{page}/move'
 */
        moveForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: move.url(args, options),
            method: 'post',
        })
    
    move.form = moveForm
const tree = {
    update: Object.assign(update, update),
move: Object.assign(move, move),
}

export default tree