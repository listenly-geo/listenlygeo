import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:14
 * @route '/editor/api/pages/{page}/comments'
 */
export const store = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:14
 * @route '/editor/api/pages/{page}/comments'
 */
store.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return store.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:14
 * @route '/editor/api/pages/{page}/comments'
 */
store.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:14
 * @route '/editor/api/pages/{page}/comments'
 */
    const storeForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:14
 * @route '/editor/api/pages/{page}/comments'
 */
        storeForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const comments = {
    store: Object.assign(store, store),
}

export default comments