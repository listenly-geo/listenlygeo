import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
export const page = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(args, options),
    method: 'get',
})

page.definition = {
    methods: ["get","head"],
    url: '/editor/{site}/{space}/{pageSlug}',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
page.url = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    space: args[1],
                    pageSlug: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.uuid
                : args.site,
                                space: typeof args.space === 'object'
                ? args.space.uuid
                : args.space,
                                pageSlug: args.pageSlug,
                }

    return page.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{space}', parsedArgs.space.toString())
            .replace('{pageSlug}', parsedArgs.pageSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
page.get = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(args, options),
    method: 'get',
})
/**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
page.head = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: page.url(args, options),
    method: 'head',
})

    /**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
    const pageForm = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: page.url(args, options),
        method: 'get',
    })

            /**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
        pageForm.get = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url(args, options),
            method: 'get',
        })
            /**
 * @see routes/web.php:161
 * @route '/editor/{site}/{space}/{pageSlug}'
 */
        pageForm.head = (args: { site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number } | [site: string | { uuid: string }, space: string | { uuid: string }, pageSlug: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    page.form = pageForm
/**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
export const legacy = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: legacy.url(args, options),
    method: 'get',
})

legacy.definition = {
    methods: ["get","head"],
    url: '/editor/{space}',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
legacy.url = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { space: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'uuid' in args) {
            args = { space: args.uuid }
        }
    
    if (Array.isArray(args)) {
        args = {
                    space: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        space: typeof args.space === 'object'
                ? args.space.uuid
                : args.space,
                }

    return legacy.definition.url
            .replace('{space}', parsedArgs.space.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
legacy.get = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: legacy.url(args, options),
    method: 'get',
})
/**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
legacy.head = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: legacy.url(args, options),
    method: 'head',
})

    /**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
    const legacyForm = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: legacy.url(args, options),
        method: 'get',
    })

            /**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
        legacyForm.get = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: legacy.url(args, options),
            method: 'get',
        })
            /**
 * @see routes/web.php:174
 * @route '/editor/{space}'
 */
        legacyForm.head = (args: { space: string | { uuid: string } } | [space: string | { uuid: string } ] | string | { uuid: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: legacy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    legacy.form = legacyForm
const space = {
    legacy: Object.assign(legacy, legacy),
}

export default space