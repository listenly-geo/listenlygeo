import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::resolve
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:47
 * @route '/editor/api/comments/{comment}/resolve'
 */
export const resolve = (args: { comment: number | { id: number } } | [comment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolve.url(args, options),
    method: 'patch',
})

resolve.definition = {
    methods: ["patch"],
    url: '/editor/api/comments/{comment}/resolve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::resolve
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:47
 * @route '/editor/api/comments/{comment}/resolve'
 */
resolve.url = (args: { comment: number | { id: number } } | [comment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { comment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { comment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    comment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return resolve.definition.url
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::resolve
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:47
 * @route '/editor/api/comments/{comment}/resolve'
 */
resolve.patch = (args: { comment: number | { id: number } } | [comment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolve.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::resolve
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:47
 * @route '/editor/api/comments/{comment}/resolve'
 */
    const resolveForm = (args: { comment: number | { id: number } } | [comment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorCommentController::resolve
 * @see app/Http/Controllers/Editor/PrototypeEditorCommentController.php:47
 * @route '/editor/api/comments/{comment}/resolve'
 */
        resolveForm.patch = (args: { comment: number | { id: number } } | [comment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    resolve.form = resolveForm
const comments = {
    resolve: Object.assign(resolve, resolve),
}

export default comments