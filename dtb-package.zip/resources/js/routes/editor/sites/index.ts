import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../../wayfinder'
import pages from './pages'
import spaces from './spaces'
import media from './media'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
export const publish = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/editor/api/sites/{site}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
publish.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return publish.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
publish.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
    const publishForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
        publishForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
export const preview = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/preview/sites/{site}/{path?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
preview.url = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    path: args[1],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "path",
        ])

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                                path: args.path,
                }

    return preview.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{path?}', parsedArgs.path?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
preview.get = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
preview.head = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
    const previewForm = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
        previewForm.get = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
        previewForm.head = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
const sites = {
    publish: Object.assign(publish, publish),
pages: Object.assign(pages, pages),
spaces: Object.assign(spaces, spaces),
preview: Object.assign(preview, preview),
media: Object.assign(media, media),
}

export default sites