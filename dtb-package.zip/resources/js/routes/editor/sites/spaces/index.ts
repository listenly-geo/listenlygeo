import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorSpaceController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorSpaceController.php:15
 * @route '/editor/api/sites/{site}/spaces'
 */
export const store = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/editor/api/sites/{site}/spaces',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorSpaceController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorSpaceController.php:15
 * @route '/editor/api/sites/{site}/spaces'
 */
store.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return store.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorSpaceController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorSpaceController.php:15
 * @route '/editor/api/sites/{site}/spaces'
 */
store.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorSpaceController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorSpaceController.php:15
 * @route '/editor/api/sites/{site}/spaces'
 */
    const storeForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorSpaceController::store
 * @see app/Http/Controllers/Editor/PrototypeEditorSpaceController.php:15
 * @route '/editor/api/sites/{site}/spaces'
 */
        storeForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
export const state = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: state.url(args, options),
    method: 'get',
})

state.definition = {
    methods: ["get","head"],
    url: '/editor/api/sites/{site}/spaces/{space}/state',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.url = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    space: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.uuid
                : args.site,
                                space: typeof args.space === 'object'
                ? args.space.uuid
                : args.space,
                }

    return state.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{space}', parsedArgs.space.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: state.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: state.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
    const stateForm = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: state.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
        stateForm.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: state.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
        stateForm.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: state.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    state.form = stateForm
const spaces = {
    store: Object.assign(store, store),
state: Object.assign(state, state),
}

export default spaces