import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import sites from './sites'
import pages from './pages'
import comments from './comments'
import space4b92a4 from './space'
/**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
export const space = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: space.url(args, options),
    method: 'get',
})

space.definition = {
    methods: ["get","head"],
    url: '/editor/{site}/{space}',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
space.url = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    space: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.uuid
                : args.site,
                                space: typeof args.space === 'object'
                ? args.space.uuid
                : args.space,
                }

    return space.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{space}', parsedArgs.space.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
space.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: space.url(args, options),
    method: 'get',
})
/**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
space.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: space.url(args, options),
    method: 'head',
})

    /**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
    const spaceForm = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: space.url(args, options),
        method: 'get',
    })

            /**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
        spaceForm.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: space.url(args, options),
            method: 'get',
        })
            /**
 * @see routes/web.php:168
 * @route '/editor/{site}/{space}'
 */
        spaceForm.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: space.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    space.form = spaceForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
export const prototype = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prototype.url(args, options),
    method: 'get',
})

prototype.definition = {
    methods: ["get","head"],
    url: '/editor/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
prototype.url = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { path: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    path: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        path: args.path,
                }

    return prototype.definition.url
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
prototype.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prototype.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
prototype.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: prototype.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
    const prototypeForm = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: prototype.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
        prototypeForm.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: prototype.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
        prototypeForm.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: prototype.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    prototype.form = prototypeForm
const editor = {
    sites: Object.assign(sites, sites),
pages: Object.assign(pages, pages),
comments: Object.assign(comments, comments),
prototype: Object.assign(prototype, prototype),
space: Object.assign(space, space4b92a4),
}

export default editor