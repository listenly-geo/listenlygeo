import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import plansDaef78 from './plans'
import commerceEba481 from './commerce'
import landingContentEd9d3c from './landing-content'
import landingSettings from './landing-settings'
import addons from './addons'
/**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminDashboardController::__invoke
 * @see app/Http/Controllers/Admin/AdminDashboardController.php:19
 * @route '/admin'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
export const plans = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})

plans.definition = {
    methods: ["get","head"],
    url: '/admin/plans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
plans.url = (options?: RouteQueryOptions) => {
    return plans.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
plans.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
plans.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: plans.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
    const plansForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: plans.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
        plansForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
        plansForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    plans.form = plansForm
/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
    const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reports.form = reportsForm
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
export const analytics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: analytics.url(options),
    method: 'get',
})

analytics.definition = {
    methods: ["get","head"],
    url: '/admin/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
analytics.url = (options?: RouteQueryOptions) => {
    return analytics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
analytics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: analytics.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
analytics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: analytics.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
    const analyticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: analytics.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
        analyticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: analytics.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
        analyticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: analytics.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    analytics.form = analyticsForm
/**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
export const commerce = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commerce.url(options),
    method: 'get',
})

commerce.definition = {
    methods: ["get","head"],
    url: '/admin/commerce',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
commerce.url = (options?: RouteQueryOptions) => {
    return commerce.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
commerce.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commerce.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
commerce.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: commerce.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
    const commerceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: commerce.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
        commerceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commerce.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardBillingController::commerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
        commerceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commerce.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    commerce.form = commerceForm
/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
export const landingContent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: landingContent.url(options),
    method: 'get',
})

landingContent.definition = {
    methods: ["get","head"],
    url: '/admin/landing-content',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
landingContent.url = (options?: RouteQueryOptions) => {
    return landingContent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
landingContent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: landingContent.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
landingContent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: landingContent.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
    const landingContentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: landingContent.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
        landingContentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: landingContent.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::landingContent
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:14
 * @route '/admin/landing-content'
 */
        landingContentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: landingContent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    landingContent.form = landingContentForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
plans: Object.assign(plans, plansDaef78),
users: Object.assign(users, users),
reports: Object.assign(reports, reports),
analytics: Object.assign(analytics, analytics),
commerce: Object.assign(commerce, commerceEba481),
landingContent: Object.assign(landingContent, landingContentEd9d3c),
landingSettings: Object.assign(landingSettings, landingSettings),
addons: Object.assign(addons, addons),
}

export default admin