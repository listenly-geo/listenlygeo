import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/addons',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::index
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:16
 * @route '/admin/addons'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::install
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:36
 * @route '/admin/addons/{addon}/install'
 */
export const install = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(args, options),
    method: 'post',
})

install.definition = {
    methods: ["post"],
    url: '/admin/addons/{addon}/install',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::install
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:36
 * @route '/admin/addons/{addon}/install'
 */
install.url = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { addon: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { addon: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    addon: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        addon: typeof args.addon === 'object'
                ? args.addon.id
                : args.addon,
                }

    return install.definition.url
            .replace('{addon}', parsedArgs.addon.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::install
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:36
 * @route '/admin/addons/{addon}/install'
 */
install.post = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::install
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:36
 * @route '/admin/addons/{addon}/install'
 */
    const installForm = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: install.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::install
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:36
 * @route '/admin/addons/{addon}/install'
 */
        installForm.post = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: install.url(args, options),
            method: 'post',
        })
    
    install.form = installForm
/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::uninstall
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:57
 * @route '/admin/addons/{addon}/uninstall'
 */
export const uninstall = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uninstall.url(args, options),
    method: 'post',
})

uninstall.definition = {
    methods: ["post"],
    url: '/admin/addons/{addon}/uninstall',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::uninstall
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:57
 * @route '/admin/addons/{addon}/uninstall'
 */
uninstall.url = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { addon: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { addon: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    addon: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        addon: typeof args.addon === 'object'
                ? args.addon.id
                : args.addon,
                }

    return uninstall.definition.url
            .replace('{addon}', parsedArgs.addon.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAddonsController::uninstall
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:57
 * @route '/admin/addons/{addon}/uninstall'
 */
uninstall.post = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uninstall.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::uninstall
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:57
 * @route '/admin/addons/{addon}/uninstall'
 */
    const uninstallForm = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uninstall.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAddonsController::uninstall
 * @see app/Http/Controllers/Admin/AdminAddonsController.php:57
 * @route '/admin/addons/{addon}/uninstall'
 */
        uninstallForm.post = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uninstall.url(args, options),
            method: 'post',
        })
    
    uninstall.form = uninstallForm
const addons = {
    index: Object.assign(index, index),
install: Object.assign(install, install),
uninstall: Object.assign(uninstall, uninstall),
}

export default addons