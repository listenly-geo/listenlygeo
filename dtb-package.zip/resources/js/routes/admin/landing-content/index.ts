import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::store
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:41
 * @route '/admin/landing-content'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/landing-content',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::store
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:41
 * @route '/admin/landing-content'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::store
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:41
 * @route '/admin/landing-content'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::store
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:41
 * @route '/admin/landing-content'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::store
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:41
 * @route '/admin/landing-content'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::update
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:59
 * @route '/admin/landing-content/{landingContent}'
 */
export const update = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/landing-content/{landingContent}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::update
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:59
 * @route '/admin/landing-content/{landingContent}'
 */
update.url = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { landingContent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { landingContent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    landingContent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        landingContent: typeof args.landingContent === 'object'
                ? args.landingContent.id
                : args.landingContent,
                }

    return update.definition.url
            .replace('{landingContent}', parsedArgs.landingContent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::update
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:59
 * @route '/admin/landing-content/{landingContent}'
 */
update.patch = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::update
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:59
 * @route '/admin/landing-content/{landingContent}'
 */
    const updateForm = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::update
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:59
 * @route '/admin/landing-content/{landingContent}'
 */
        updateForm.patch = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::destroy
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:76
 * @route '/admin/landing-content/{landingContent}'
 */
export const destroy = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/landing-content/{landingContent}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::destroy
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:76
 * @route '/admin/landing-content/{landingContent}'
 */
destroy.url = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { landingContent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { landingContent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    landingContent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        landingContent: typeof args.landingContent === 'object'
                ? args.landingContent.id
                : args.landingContent,
                }

    return destroy.definition.url
            .replace('{landingContent}', parsedArgs.landingContent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::destroy
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:76
 * @route '/admin/landing-content/{landingContent}'
 */
destroy.delete = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::destroy
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:76
 * @route '/admin/landing-content/{landingContent}'
 */
    const destroyForm = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminLandingContentController::destroy
 * @see app/Http/Controllers/Admin/AdminLandingContentController.php:76
 * @route '/admin/landing-content/{landingContent}'
 */
        destroyForm.delete = (args: { landingContent: number | { id: number } } | [landingContent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const landingContent = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default landingContent