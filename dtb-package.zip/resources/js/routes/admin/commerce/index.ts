import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import gateway from './gateway'
/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/commerce',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const commerce = {
    update: Object.assign(update, update),
gateway: Object.assign(gateway, gateway),
}

export default commerce