import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/commerce/gateway',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const gateway = {
    update: Object.assign(update, update),
}

export default gateway