import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/plans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
export const update = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/plans/{subscriptionPlan}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
update.url = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscriptionPlan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscriptionPlan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscriptionPlan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscriptionPlan: typeof args.subscriptionPlan === 'object'
                ? args.subscriptionPlan.id
                : args.subscriptionPlan,
                }

    return update.definition.url
            .replace('{subscriptionPlan}', parsedArgs.subscriptionPlan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
update.patch = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
    const updateForm = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
        updateForm.patch = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::stripeSync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
export const stripeSync = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stripeSync.url(args, options),
    method: 'post',
})

stripeSync.definition = {
    methods: ["post"],
    url: '/admin/plans/{subscriptionPlan}/stripe-sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::stripeSync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
stripeSync.url = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscriptionPlan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscriptionPlan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscriptionPlan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscriptionPlan: typeof args.subscriptionPlan === 'object'
                ? args.subscriptionPlan.id
                : args.subscriptionPlan,
                }

    return stripeSync.definition.url
            .replace('{subscriptionPlan}', parsedArgs.subscriptionPlan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::stripeSync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
stripeSync.post = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stripeSync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::stripeSync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
    const stripeSyncForm = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: stripeSync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::stripeSync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
        stripeSyncForm.post = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: stripeSync.url(args, options),
            method: 'post',
        })
    
    stripeSync.form = stripeSyncForm
const plans = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
stripeSync: Object.assign(stripeSync, stripeSync),
}

export default plans