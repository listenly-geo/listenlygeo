import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
 * @see routes/web.php:184
 * @route '/prototype'
 */
export const entry = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entry.url(options),
    method: 'get',
})

entry.definition = {
    methods: ["get","head"],
    url: '/prototype',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:184
 * @route '/prototype'
 */
entry.url = (options?: RouteQueryOptions) => {
    return entry.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:184
 * @route '/prototype'
 */
entry.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entry.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:184
 * @route '/prototype'
 */
entry.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: entry.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:184
 * @route '/prototype'
 */
    const entryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: entry.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:184
 * @route '/prototype'
 */
        entryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: entry.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:184
 * @route '/prototype'
 */
        entryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: entry.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    entry.form = entryForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
export const asset = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: asset.url(args, options),
    method: 'get',
})

asset.definition = {
    methods: ["get","head"],
    url: '/prototype/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
asset.url = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { path: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    path: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        path: args.path,
                }

    return asset.definition.url
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
asset.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: asset.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
asset.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: asset.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
    const assetForm = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: asset.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
        assetForm.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: asset.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
        assetForm.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: asset.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    asset.form = assetForm
const prototype = {
    entry: Object.assign(entry, entry),
asset: Object.assign(asset, asset),
}

export default prototype