import assets from './assets'
const media = {
    assets: Object.assign(assets, assets),
}

export default media