import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
export const store = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/sites/{site}/spaces',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
store.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return store.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
store.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
    const storeForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
        storeForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const spaces = {
    store: Object.assign(store, store),
}

export default spaces