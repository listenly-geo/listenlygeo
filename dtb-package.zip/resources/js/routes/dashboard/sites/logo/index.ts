import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSitesController::update
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
export const update = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/dashboard/sites/{site}/logo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::update
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
update.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return update.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::update
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
update.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::update
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
    const updateForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::update
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
        updateForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
const logo = {
    update: Object.assign(update, update),
}

export default logo