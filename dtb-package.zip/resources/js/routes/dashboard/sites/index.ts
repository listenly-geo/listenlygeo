import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import spaces from './spaces'
import logo from './logo'
import appearance from './appearance'
import defaultSpace from './default-space'
/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
export const show = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites/{site}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return show.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.get = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.head = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
    const showForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
        showForm.get = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
        showForm.head = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
export const exportMethod = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites/{site}/export/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
exportMethod.url = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    format: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                                format: args.format,
                }

    return exportMethod.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
exportMethod.get = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
exportMethod.head = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
    const exportMethodForm = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
        exportMethodForm.get = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
        exportMethodForm.head = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::store
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const sites = {
    show: Object.assign(show, show),
export: Object.assign(exportMethod, exportMethod),
store: Object.assign(store, store),
spaces: Object.assign(spaces, spaces),
logo: Object.assign(logo, logo),
appearance: Object.assign(appearance, appearance),
defaultSpace: Object.assign(defaultSpace, defaultSpace),
}

export default sites