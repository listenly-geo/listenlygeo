import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import billingFfcdcb from './billing'
import media30b75d from './media'
import releasesF8f9a0 from './releases'
import sitesE38ead from './sites'
import settings69f00b from './settings'
import team4b9005 from './team'
/**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
export const commerce = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commerce.url(options),
    method: 'get',
})

commerce.definition = {
    methods: ["get","head"],
    url: '/dashboard/commerce',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
commerce.url = (options?: RouteQueryOptions) => {
    return commerce.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
commerce.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commerce.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
commerce.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: commerce.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
    const commerceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: commerce.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
        commerceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commerce.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:74
 * @route '/dashboard/commerce'
 */
        commerceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commerce.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    commerce.form = commerceForm
/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
export const billing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})

billing.definition = {
    methods: ["get","head"],
    url: '/dashboard/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
billing.url = (options?: RouteQueryOptions) => {
    return billing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
billing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
billing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: billing.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
    const billingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: billing.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
        billingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: billing.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
        billingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: billing.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    billing.form = billingForm
/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
export const media = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: media.url(options),
    method: 'get',
})

media.definition = {
    methods: ["get","head"],
    url: '/dashboard/media',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
media.url = (options?: RouteQueryOptions) => {
    return media.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
media.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: media.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
media.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: media.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
    const mediaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: media.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
        mediaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: media.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
        mediaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: media.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    media.form = mediaForm
/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
export const analytics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: analytics.url(options),
    method: 'get',
})

analytics.definition = {
    methods: ["get","head"],
    url: '/dashboard/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
analytics.url = (options?: RouteQueryOptions) => {
    return analytics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
analytics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: analytics.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
analytics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: analytics.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
    const analyticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: analytics.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
        analyticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: analytics.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
        analyticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: analytics.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    analytics.form = analyticsForm
/**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
export const releases = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: releases.url(options),
    method: 'get',
})

releases.definition = {
    methods: ["get","head"],
    url: '/dashboard/releases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
releases.url = (options?: RouteQueryOptions) => {
    return releases.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
releases.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: releases.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
releases.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: releases.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
    const releasesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: releases.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
        releasesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: releases.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardReleasesController::__invoke
 * @see app/Http/Controllers/DashboardReleasesController.php:25
 * @route '/dashboard/releases'
 */
        releasesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: releases.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    releases.form = releasesForm
/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
export const sites = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
sites.url = (options?: RouteQueryOptions) => {
    return sites.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
sites.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
sites.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
    const sitesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sites.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
        sitesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sites.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
        sitesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sites.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sites.form = sitesForm
/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
export const settings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
settings.url = (options?: RouteQueryOptions) => {
    return settings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
settings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
settings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
    const settingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
        settingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
        settingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
export const team = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: team.url(options),
    method: 'get',
})

team.definition = {
    methods: ["get","head"],
    url: '/dashboard/team',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
team.url = (options?: RouteQueryOptions) => {
    return team.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
team.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: team.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
team.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: team.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
    const teamForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: team.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
        teamForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: team.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
        teamForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: team.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    team.form = teamForm
const dashboard = {
    billing: Object.assign(billing, billingFfcdcb),
media: Object.assign(media, media30b75d),
analytics: Object.assign(analytics, analytics),
releases: Object.assign(releases, releasesF8f9a0),
sites: Object.assign(sites, sitesE38ead),
settings: Object.assign(settings, settings69f00b),
team: Object.assign(team, team4b9005),
}

export default dashboard