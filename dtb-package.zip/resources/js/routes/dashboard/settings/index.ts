import sites from './sites'
import domains from './domains'
const settings = {
    sites: Object.assign(sites, sites),
domains: Object.assign(domains, domains),
}

export default settings