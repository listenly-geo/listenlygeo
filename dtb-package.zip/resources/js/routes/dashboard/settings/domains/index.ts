import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
import primary from './primary'
/**
* @see \App\Http\Controllers\DashboardSettingsController::store
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
export const store = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/settings/sites/{site}/domains',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::store
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
store.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return store.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::store
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
store.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::store
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
    const storeForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::store
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
        storeForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const domains = {
    store: Object.assign(store, store),
primary: Object.assign(primary, primary),
}

export default domains