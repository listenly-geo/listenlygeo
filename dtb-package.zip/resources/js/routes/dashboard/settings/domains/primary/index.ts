import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSettingsController::update
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
export const update = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/dashboard/settings/domains/{domain}/primary',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::update
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
update.url = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { domain: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { domain: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    domain: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        domain: typeof args.domain === 'object'
                ? args.domain.id
                : args.domain,
                }

    return update.definition.url
            .replace('{domain}', parsedArgs.domain.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::update
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
update.patch = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::update
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
    const updateForm = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::update
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
        updateForm.patch = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const primary = {
    update: Object.assign(update, update),
}

export default primary