import invitations from './invitations'
import members from './members'
const team = {
    invitations: Object.assign(invitations, invitations),
members: Object.assign(members, members),
}

export default team