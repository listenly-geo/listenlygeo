import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardTeamController::store
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/team/invitations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardTeamController::store
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardTeamController::store
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardTeamController::store
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardTeamController::store
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const invitations = {
    store: Object.assign(store, store),
}

export default invitations