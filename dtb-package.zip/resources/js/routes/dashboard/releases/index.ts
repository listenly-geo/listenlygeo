import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardReleasesController::publish
 * @see app/Http/Controllers/DashboardReleasesController.php:104
 * @route '/dashboard/releases/sites/{site}/publish'
 */
export const publish = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/dashboard/releases/sites/{site}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardReleasesController::publish
 * @see app/Http/Controllers/DashboardReleasesController.php:104
 * @route '/dashboard/releases/sites/{site}/publish'
 */
publish.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return publish.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardReleasesController::publish
 * @see app/Http/Controllers/DashboardReleasesController.php:104
 * @route '/dashboard/releases/sites/{site}/publish'
 */
publish.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardReleasesController::publish
 * @see app/Http/Controllers/DashboardReleasesController.php:104
 * @route '/dashboard/releases/sites/{site}/publish'
 */
    const publishForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardReleasesController::publish
 * @see app/Http/Controllers/DashboardReleasesController.php:104
 * @route '/dashboard/releases/sites/{site}/publish'
 */
        publishForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
const releases = {
    publish: Object.assign(publish, publish),
}

export default releases