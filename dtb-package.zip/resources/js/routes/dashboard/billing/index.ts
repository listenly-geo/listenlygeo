import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/dashboard/billing',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/dashboard/billing/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
    const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
        checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkout.url(options),
            method: 'post',
        })
    
    checkout.form = checkoutForm
/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
export const portal = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

portal.definition = {
    methods: ["post"],
    url: '/dashboard/billing/portal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
portal.url = (options?: RouteQueryOptions) => {
    return portal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
portal.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
    const portalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: portal.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
        portalForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: portal.url(options),
            method: 'post',
        })
    
    portal.form = portalForm
/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/dashboard/billing/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
export const resume = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/dashboard/billing/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
resume.url = (options?: RouteQueryOptions) => {
    return resume.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
resume.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
    const resumeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
        resumeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(options),
            method: 'post',
        })
    
    resume.form = resumeForm
const billing = {
    update: Object.assign(update, update),
checkout: Object.assign(checkout, checkout),
portal: Object.assign(portal, portal),
cancel: Object.assign(cancel, cancel),
resume: Object.assign(resume, resume),
}

export default billing