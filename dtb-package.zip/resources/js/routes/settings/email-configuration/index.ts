import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/email-configuration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::edit
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:17
 * @route '/settings/email-configuration'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::update
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:38
 * @route '/settings/email-configuration'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/email-configuration',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::update
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:38
 * @route '/settings/email-configuration'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::update
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:38
 * @route '/settings/email-configuration'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::update
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:38
 * @route '/settings/email-configuration'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::update
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:38
 * @route '/settings/email-configuration'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::test
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:79
 * @route '/settings/email-configuration/test'
 */
export const test = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/settings/email-configuration/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::test
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:79
 * @route '/settings/email-configuration/test'
 */
test.url = (options?: RouteQueryOptions) => {
    return test.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::test
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:79
 * @route '/settings/email-configuration/test'
 */
test.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::test
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:79
 * @route '/settings/email-configuration/test'
 */
    const testForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\EmailConfigurationController::test
 * @see app/Http/Controllers/Settings/EmailConfigurationController.php:79
 * @route '/settings/email-configuration/test'
 */
        testForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(options),
            method: 'post',
        })
    
    test.form = testForm
const emailConfiguration = {
    edit: Object.assign(edit, edit),
update: Object.assign(update, update),
test: Object.assign(test, test),
}

export default emailConfiguration