import emailConfiguration from './email-configuration'
import application from './application'
const settings = {
    emailConfiguration: Object.assign(emailConfiguration, emailConfiguration),
application: Object.assign(application, application),
}

export default settings