import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StripeWebhookController::__invoke
 * @see app/Http/Controllers/StripeWebhookController.php:12
 * @route '/webhooks/stripe'
 */
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

webhook.definition = {
    methods: ["post"],
    url: '/webhooks/stripe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StripeWebhookController::__invoke
 * @see app/Http/Controllers/StripeWebhookController.php:12
 * @route '/webhooks/stripe'
 */
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StripeWebhookController::__invoke
 * @see app/Http/Controllers/StripeWebhookController.php:12
 * @route '/webhooks/stripe'
 */
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StripeWebhookController::__invoke
 * @see app/Http/Controllers/StripeWebhookController.php:12
 * @route '/webhooks/stripe'
 */
    const webhookForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: webhook.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StripeWebhookController::__invoke
 * @see app/Http/Controllers/StripeWebhookController.php:12
 * @route '/webhooks/stripe'
 */
        webhookForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: webhook.url(options),
            method: 'post',
        })
    
    webhook.form = webhookForm
const stripe = {
    webhook: Object.assign(webhook, webhook),
}

export default stripe