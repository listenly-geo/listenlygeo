import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
const AdminUsersController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminUsersController.url(options),
    method: 'get',
})

AdminUsersController.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
AdminUsersController.url = (options?: RouteQueryOptions) => {
    return AdminUsersController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
AdminUsersController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminUsersController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
AdminUsersController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: AdminUsersController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
    const AdminUsersControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: AdminUsersController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
        AdminUsersControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminUsersController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminUsersController::__invoke
 * @see app/Http/Controllers/Admin/AdminUsersController.php:12
 * @route '/admin/users'
 */
        AdminUsersControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminUsersController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    AdminUsersController.form = AdminUsersControllerForm
export default AdminUsersController