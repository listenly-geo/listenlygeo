import AdminDashboardController from './AdminDashboardController'
import AdminPlansController from './AdminPlansController'
import AdminUsersController from './AdminUsersController'
import AdminReportsController from './AdminReportsController'
import AdminAnalyticsController from './AdminAnalyticsController'
import AdminLandingContentController from './AdminLandingContentController'
import AdminAddonsController from './AdminAddonsController'
const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminPlansController: Object.assign(AdminPlansController, AdminPlansController),
AdminUsersController: Object.assign(AdminUsersController, AdminUsersController),
AdminReportsController: Object.assign(AdminReportsController, AdminReportsController),
AdminAnalyticsController: Object.assign(AdminAnalyticsController, AdminAnalyticsController),
AdminLandingContentController: Object.assign(AdminLandingContentController, AdminLandingContentController),
AdminAddonsController: Object.assign(AdminAddonsController, AdminAddonsController),
}

export default Admin