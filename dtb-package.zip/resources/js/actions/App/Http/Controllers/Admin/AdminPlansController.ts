import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
const AdminPlansController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminPlansController.url(options),
    method: 'get',
})

AdminPlansController.definition = {
    methods: ["get","head"],
    url: '/admin/plans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
AdminPlansController.url = (options?: RouteQueryOptions) => {
    return AdminPlansController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
AdminPlansController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminPlansController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
AdminPlansController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: AdminPlansController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
    const AdminPlansControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: AdminPlansController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
        AdminPlansControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminPlansController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::__invoke
 * @see app/Http/Controllers/Admin/AdminPlansController.php:22
 * @route '/admin/plans'
 */
        AdminPlansControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminPlansController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    AdminPlansController.form = AdminPlansControllerForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/plans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::store
 * @see app/Http/Controllers/Admin/AdminPlansController.php:63
 * @route '/admin/plans'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
export const update = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/plans/{subscriptionPlan}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
update.url = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscriptionPlan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscriptionPlan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscriptionPlan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscriptionPlan: typeof args.subscriptionPlan === 'object'
                ? args.subscriptionPlan.id
                : args.subscriptionPlan,
                }

    return update.definition.url
            .replace('{subscriptionPlan}', parsedArgs.subscriptionPlan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
update.patch = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
    const updateForm = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::update
 * @see app/Http/Controllers/Admin/AdminPlansController.php:76
 * @route '/admin/plans/{subscriptionPlan}'
 */
        updateForm.patch = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminPlansController::sync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
export const sync = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/admin/plans/{subscriptionPlan}/stripe-sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::sync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
sync.url = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscriptionPlan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscriptionPlan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscriptionPlan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscriptionPlan: typeof args.subscriptionPlan === 'object'
                ? args.subscriptionPlan.id
                : args.subscriptionPlan,
                }

    return sync.definition.url
            .replace('{subscriptionPlan}', parsedArgs.subscriptionPlan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPlansController::sync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
sync.post = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPlansController::sync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
    const syncForm = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPlansController::sync
 * @see app/Http/Controllers/Admin/AdminPlansController.php:89
 * @route '/admin/plans/{subscriptionPlan}/stripe-sync'
 */
        syncForm.post = (args: { subscriptionPlan: number | { id: number } } | [subscriptionPlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
AdminPlansController.store = store
AdminPlansController.update = update
AdminPlansController.sync = sync

export default AdminPlansController