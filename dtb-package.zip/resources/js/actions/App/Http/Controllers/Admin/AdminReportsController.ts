import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
const AdminReportsController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminReportsController.url(options),
    method: 'get',
})

AdminReportsController.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
AdminReportsController.url = (options?: RouteQueryOptions) => {
    return AdminReportsController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
AdminReportsController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminReportsController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
AdminReportsController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: AdminReportsController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
    const AdminReportsControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: AdminReportsController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        AdminReportsControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminReportsController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminReportsController::__invoke
 * @see app/Http/Controllers/Admin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        AdminReportsControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminReportsController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    AdminReportsController.form = AdminReportsControllerForm
export default AdminReportsController