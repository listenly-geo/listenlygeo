import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
const AdminAnalyticsController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminAnalyticsController.url(options),
    method: 'get',
})

AdminAnalyticsController.definition = {
    methods: ["get","head"],
    url: '/admin/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
AdminAnalyticsController.url = (options?: RouteQueryOptions) => {
    return AdminAnalyticsController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
AdminAnalyticsController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: AdminAnalyticsController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
AdminAnalyticsController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: AdminAnalyticsController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
    const AdminAnalyticsControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: AdminAnalyticsController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
        AdminAnalyticsControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminAnalyticsController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::__invoke
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:15
 * @route '/admin/analytics'
 */
        AdminAnalyticsControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: AdminAnalyticsController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    AdminAnalyticsController.form = AdminAnalyticsControllerForm
export default AdminAnalyticsController