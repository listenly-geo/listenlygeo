import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
const DashboardAnalyticsController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardAnalyticsController.url(options),
    method: 'get',
})

DashboardAnalyticsController.definition = {
    methods: ["get","head"],
    url: '/dashboard/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
DashboardAnalyticsController.url = (options?: RouteQueryOptions) => {
    return DashboardAnalyticsController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
DashboardAnalyticsController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardAnalyticsController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
DashboardAnalyticsController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardAnalyticsController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
    const DashboardAnalyticsControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardAnalyticsController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
        DashboardAnalyticsControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardAnalyticsController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardAnalyticsController::__invoke
 * @see app/Http/Controllers/DashboardAnalyticsController.php:22
 * @route '/dashboard/analytics'
 */
        DashboardAnalyticsControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardAnalyticsController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardAnalyticsController.form = DashboardAnalyticsControllerForm
export default DashboardAnalyticsController