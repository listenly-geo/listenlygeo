import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
const PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4 = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, options),
    method: 'get',
})

PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.definition = {
    methods: ["get","head"],
    url: '/docs/{siteSlug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { siteSlug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    siteSlug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        siteSlug: args.siteSlug,
                }

    return PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.definition.url
            .replace('{siteSlug}', parsedArgs.siteSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.get = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.head = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
    const PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4Form = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
        PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4Form.get = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}'
 */
        PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4Form.head = (args: { siteSlug: string | number } | [siteSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4.form = PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4Form
    /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
const PublishedDocsController4f90adca700c730df1517106beb375ae = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, options),
    method: 'get',
})

PublishedDocsController4f90adca700c730df1517106beb375ae.definition = {
    methods: ["get","head"],
    url: '/docs/{siteSlug}/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
PublishedDocsController4f90adca700c730df1517106beb375ae.url = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    siteSlug: args[0],
                    path: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        siteSlug: args.siteSlug,
                                path: args.path,
                }

    return PublishedDocsController4f90adca700c730df1517106beb375ae.definition.url
            .replace('{siteSlug}', parsedArgs.siteSlug.toString())
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
PublishedDocsController4f90adca700c730df1517106beb375ae.get = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
PublishedDocsController4f90adca700c730df1517106beb375ae.head = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
    const PublishedDocsController4f90adca700c730df1517106beb375aeForm = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
        PublishedDocsController4f90adca700c730df1517106beb375aeForm.get = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublishedDocsController::__invoke
 * @see app/Http/Controllers/PublishedDocsController.php:18
 * @route '/docs/{siteSlug}/{path}'
 */
        PublishedDocsController4f90adca700c730df1517106beb375aeForm.head = (args: { siteSlug: string | number, path: string | number } | [siteSlug: string | number, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublishedDocsController4f90adca700c730df1517106beb375ae.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PublishedDocsController4f90adca700c730df1517106beb375ae.form = PublishedDocsController4f90adca700c730df1517106beb375aeForm

const PublishedDocsController = {
    '/docs/{siteSlug}': PublishedDocsControllera2d19483f24fb9e373ae98bcf96f7bb4,
    '/docs/{siteSlug}/{path}': PublishedDocsController4f90adca700c730df1517106beb375ae,
}

export default PublishedDocsController