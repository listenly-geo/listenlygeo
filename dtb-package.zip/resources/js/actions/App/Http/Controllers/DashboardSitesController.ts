import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
const DashboardSitesController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSitesController.url(options),
    method: 'get',
})

DashboardSitesController.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
DashboardSitesController.url = (options?: RouteQueryOptions) => {
    return DashboardSitesController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
DashboardSitesController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSitesController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
DashboardSitesController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardSitesController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
    const DashboardSitesControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardSitesController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
        DashboardSitesControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSitesController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSitesController::__invoke
 * @see app/Http/Controllers/DashboardSitesController.php:31
 * @route '/dashboard/sites'
 */
        DashboardSitesControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSitesController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardSitesController.form = DashboardSitesControllerForm
/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
export const show = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites/{site}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return show.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.get = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
show.head = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
    const showForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
        showForm.get = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSitesController::show
 * @see app/Http/Controllers/DashboardSitesController.php:70
 * @route '/dashboard/sites/{site}'
 */
        showForm.head = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DashboardSitesController::storeSite
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
export const storeSite = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite.url(options),
    method: 'post',
})

storeSite.definition = {
    methods: ["post"],
    url: '/dashboard/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::storeSite
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
storeSite.url = (options?: RouteQueryOptions) => {
    return storeSite.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::storeSite
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
storeSite.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::storeSite
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
    const storeSiteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSite.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::storeSite
 * @see app/Http/Controllers/DashboardSitesController.php:170
 * @route '/dashboard/sites'
 */
        storeSiteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSite.url(options),
            method: 'post',
        })
    
    storeSite.form = storeSiteForm
/**
* @see \App\Http\Controllers\DashboardSitesController::storeSpace
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
export const storeSpace = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSpace.url(args, options),
    method: 'post',
})

storeSpace.definition = {
    methods: ["post"],
    url: '/dashboard/sites/{site}/spaces',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::storeSpace
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
storeSpace.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return storeSpace.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::storeSpace
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
storeSpace.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSpace.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::storeSpace
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
    const storeSpaceForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSpace.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::storeSpace
 * @see app/Http/Controllers/DashboardSitesController.php:255
 * @route '/dashboard/sites/{site}/spaces'
 */
        storeSpaceForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSpace.url(args, options),
            method: 'post',
        })
    
    storeSpace.form = storeSpaceForm
/**
* @see \App\Http\Controllers\DashboardSitesController::updateLogo
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
export const updateLogo = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLogo.url(args, options),
    method: 'post',
})

updateLogo.definition = {
    methods: ["post"],
    url: '/dashboard/sites/{site}/logo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::updateLogo
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
updateLogo.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return updateLogo.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::updateLogo
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
updateLogo.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLogo.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::updateLogo
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
    const updateLogoForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLogo.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::updateLogo
 * @see app/Http/Controllers/DashboardSitesController.php:321
 * @route '/dashboard/sites/{site}/logo'
 */
        updateLogoForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLogo.url(args, options),
            method: 'post',
        })
    
    updateLogo.form = updateLogoForm
/**
* @see \App\Http\Controllers\DashboardSitesController::updateAppearance
 * @see app/Http/Controllers/DashboardSitesController.php:286
 * @route '/dashboard/sites/{site}/appearance'
 */
export const updateAppearance = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAppearance.url(args, options),
    method: 'patch',
})

updateAppearance.definition = {
    methods: ["patch"],
    url: '/dashboard/sites/{site}/appearance',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::updateAppearance
 * @see app/Http/Controllers/DashboardSitesController.php:286
 * @route '/dashboard/sites/{site}/appearance'
 */
updateAppearance.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return updateAppearance.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::updateAppearance
 * @see app/Http/Controllers/DashboardSitesController.php:286
 * @route '/dashboard/sites/{site}/appearance'
 */
updateAppearance.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAppearance.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::updateAppearance
 * @see app/Http/Controllers/DashboardSitesController.php:286
 * @route '/dashboard/sites/{site}/appearance'
 */
    const updateAppearanceForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAppearance.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::updateAppearance
 * @see app/Http/Controllers/DashboardSitesController.php:286
 * @route '/dashboard/sites/{site}/appearance'
 */
        updateAppearanceForm.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAppearance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAppearance.form = updateAppearanceForm
/**
* @see \App\Http\Controllers\DashboardSitesController::updateDefaultSpace
 * @see app/Http/Controllers/DashboardSitesController.php:368
 * @route '/dashboard/sites/{site}/default-space'
 */
export const updateDefaultSpace = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDefaultSpace.url(args, options),
    method: 'patch',
})

updateDefaultSpace.definition = {
    methods: ["patch"],
    url: '/dashboard/sites/{site}/default-space',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardSitesController::updateDefaultSpace
 * @see app/Http/Controllers/DashboardSitesController.php:368
 * @route '/dashboard/sites/{site}/default-space'
 */
updateDefaultSpace.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return updateDefaultSpace.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSitesController::updateDefaultSpace
 * @see app/Http/Controllers/DashboardSitesController.php:368
 * @route '/dashboard/sites/{site}/default-space'
 */
updateDefaultSpace.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDefaultSpace.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardSitesController::updateDefaultSpace
 * @see app/Http/Controllers/DashboardSitesController.php:368
 * @route '/dashboard/sites/{site}/default-space'
 */
    const updateDefaultSpaceForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDefaultSpace.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSitesController::updateDefaultSpace
 * @see app/Http/Controllers/DashboardSitesController.php:368
 * @route '/dashboard/sites/{site}/default-space'
 */
        updateDefaultSpaceForm.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDefaultSpace.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDefaultSpace.form = updateDefaultSpaceForm
DashboardSitesController.show = show
DashboardSitesController.storeSite = storeSite
DashboardSitesController.storeSpace = storeSpace
DashboardSitesController.updateLogo = updateLogo
DashboardSitesController.updateAppearance = updateAppearance
DashboardSitesController.updateDefaultSpace = updateDefaultSpace

export default DashboardSitesController