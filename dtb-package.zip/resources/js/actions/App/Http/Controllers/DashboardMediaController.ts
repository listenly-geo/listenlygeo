import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
export const show = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/media-assets/{asset}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
show.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return show.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
show.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
show.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
    const showForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
        showForm.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardMediaController::show
 * @see app/Http/Controllers/DashboardMediaController.php:183
 * @route '/media-assets/{asset}'
 */
        showForm.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
const DashboardMediaController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardMediaController.url(options),
    method: 'get',
})

DashboardMediaController.definition = {
    methods: ["get","head"],
    url: '/dashboard/media',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
DashboardMediaController.url = (options?: RouteQueryOptions) => {
    return DashboardMediaController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
DashboardMediaController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardMediaController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
DashboardMediaController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardMediaController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
    const DashboardMediaControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardMediaController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
        DashboardMediaControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardMediaController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardMediaController::__invoke
 * @see app/Http/Controllers/DashboardMediaController.php:28
 * @route '/dashboard/media'
 */
        DashboardMediaControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardMediaController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardMediaController.form = DashboardMediaControllerForm
/**
* @see \App\Http\Controllers\DashboardMediaController::store
 * @see app/Http/Controllers/DashboardMediaController.php:120
 * @route '/dashboard/media/sites/{site}/assets'
 */
export const store = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/media/sites/{site}/assets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardMediaController::store
 * @see app/Http/Controllers/DashboardMediaController.php:120
 * @route '/dashboard/media/sites/{site}/assets'
 */
store.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return store.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardMediaController::store
 * @see app/Http/Controllers/DashboardMediaController.php:120
 * @route '/dashboard/media/sites/{site}/assets'
 */
store.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardMediaController::store
 * @see app/Http/Controllers/DashboardMediaController.php:120
 * @route '/dashboard/media/sites/{site}/assets'
 */
    const storeForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardMediaController::store
 * @see app/Http/Controllers/DashboardMediaController.php:120
 * @route '/dashboard/media/sites/{site}/assets'
 */
        storeForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DashboardMediaController::destroy
 * @see app/Http/Controllers/DashboardMediaController.php:164
 * @route '/dashboard/media/assets/{asset}'
 */
export const destroy = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/media/assets/{asset}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DashboardMediaController::destroy
 * @see app/Http/Controllers/DashboardMediaController.php:164
 * @route '/dashboard/media/assets/{asset}'
 */
destroy.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return destroy.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardMediaController::destroy
 * @see app/Http/Controllers/DashboardMediaController.php:164
 * @route '/dashboard/media/assets/{asset}'
 */
destroy.delete = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DashboardMediaController::destroy
 * @see app/Http/Controllers/DashboardMediaController.php:164
 * @route '/dashboard/media/assets/{asset}'
 */
    const destroyForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardMediaController::destroy
 * @see app/Http/Controllers/DashboardMediaController.php:164
 * @route '/dashboard/media/assets/{asset}'
 */
        destroyForm.delete = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
DashboardMediaController.show = show
DashboardMediaController.store = store
DashboardMediaController.destroy = destroy

export default DashboardMediaController