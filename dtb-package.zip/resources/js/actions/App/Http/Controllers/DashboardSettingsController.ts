import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
const DashboardSettingsController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSettingsController.url(options),
    method: 'get',
})

DashboardSettingsController.definition = {
    methods: ["get","head"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
DashboardSettingsController.url = (options?: RouteQueryOptions) => {
    return DashboardSettingsController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
DashboardSettingsController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSettingsController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
DashboardSettingsController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardSettingsController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
    const DashboardSettingsControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardSettingsController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
        DashboardSettingsControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSettingsController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSettingsController::__invoke
 * @see app/Http/Controllers/DashboardSettingsController.php:27
 * @route '/dashboard/settings'
 */
        DashboardSettingsControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSettingsController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardSettingsController.form = DashboardSettingsControllerForm
/**
* @see \App\Http\Controllers\DashboardSettingsController::updateSiteSettings
 * @see app/Http/Controllers/DashboardSettingsController.php:102
 * @route '/dashboard/settings/sites/{site}'
 */
export const updateSiteSettings = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSiteSettings.url(args, options),
    method: 'patch',
})

updateSiteSettings.definition = {
    methods: ["patch"],
    url: '/dashboard/settings/sites/{site}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::updateSiteSettings
 * @see app/Http/Controllers/DashboardSettingsController.php:102
 * @route '/dashboard/settings/sites/{site}'
 */
updateSiteSettings.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return updateSiteSettings.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::updateSiteSettings
 * @see app/Http/Controllers/DashboardSettingsController.php:102
 * @route '/dashboard/settings/sites/{site}'
 */
updateSiteSettings.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSiteSettings.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::updateSiteSettings
 * @see app/Http/Controllers/DashboardSettingsController.php:102
 * @route '/dashboard/settings/sites/{site}'
 */
    const updateSiteSettingsForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSiteSettings.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::updateSiteSettings
 * @see app/Http/Controllers/DashboardSettingsController.php:102
 * @route '/dashboard/settings/sites/{site}'
 */
        updateSiteSettingsForm.patch = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSiteSettings.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSiteSettings.form = updateSiteSettingsForm
/**
* @see \App\Http\Controllers\DashboardSettingsController::storeDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
export const storeDomain = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDomain.url(args, options),
    method: 'post',
})

storeDomain.definition = {
    methods: ["post"],
    url: '/dashboard/settings/sites/{site}/domains',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::storeDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
storeDomain.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return storeDomain.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::storeDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
storeDomain.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDomain.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::storeDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
    const storeDomainForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeDomain.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::storeDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:144
 * @route '/dashboard/settings/sites/{site}/domains'
 */
        storeDomainForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeDomain.url(args, options),
            method: 'post',
        })
    
    storeDomain.form = storeDomainForm
/**
* @see \App\Http\Controllers\DashboardSettingsController::updatePrimaryDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
export const updatePrimaryDomain = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePrimaryDomain.url(args, options),
    method: 'patch',
})

updatePrimaryDomain.definition = {
    methods: ["patch"],
    url: '/dashboard/settings/domains/{domain}/primary',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardSettingsController::updatePrimaryDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
updatePrimaryDomain.url = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { domain: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { domain: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    domain: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        domain: typeof args.domain === 'object'
                ? args.domain.id
                : args.domain,
                }

    return updatePrimaryDomain.definition.url
            .replace('{domain}', parsedArgs.domain.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSettingsController::updatePrimaryDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
updatePrimaryDomain.patch = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePrimaryDomain.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardSettingsController::updatePrimaryDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
    const updatePrimaryDomainForm = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePrimaryDomain.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardSettingsController::updatePrimaryDomain
 * @see app/Http/Controllers/DashboardSettingsController.php:175
 * @route '/dashboard/settings/domains/{domain}/primary'
 */
        updatePrimaryDomainForm.patch = (args: { domain: number | { id: number } } | [domain: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePrimaryDomain.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePrimaryDomain.form = updatePrimaryDomainForm
DashboardSettingsController.updateSiteSettings = updateSiteSettings
DashboardSettingsController.storeDomain = storeDomain
DashboardSettingsController.updatePrimaryDomain = updatePrimaryDomain

export default DashboardSettingsController