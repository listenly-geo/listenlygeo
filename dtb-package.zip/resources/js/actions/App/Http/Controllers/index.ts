import DashboardMediaController from './DashboardMediaController'
import PublishedDocsController from './PublishedDocsController'
import StripeWebhookController from './StripeWebhookController'
import Admin from './Admin'
import DashboardBillingController from './DashboardBillingController'
import DashboardController from './DashboardController'
import DashboardAnalyticsController from './DashboardAnalyticsController'
import DashboardReleasesController from './DashboardReleasesController'
import DashboardSitesController from './DashboardSitesController'
import DashboardSiteExportController from './DashboardSiteExportController'
import DashboardSettingsController from './DashboardSettingsController'
import DashboardTeamController from './DashboardTeamController'
import Editor from './Editor'
import Settings from './Settings'
const Controllers = {
    DashboardMediaController: Object.assign(DashboardMediaController, DashboardMediaController),
PublishedDocsController: Object.assign(PublishedDocsController, PublishedDocsController),
StripeWebhookController: Object.assign(StripeWebhookController, StripeWebhookController),
Admin: Object.assign(Admin, Admin),
DashboardBillingController: Object.assign(DashboardBillingController, DashboardBillingController),
DashboardController: Object.assign(DashboardController, DashboardController),
DashboardAnalyticsController: Object.assign(DashboardAnalyticsController, DashboardAnalyticsController),
DashboardReleasesController: Object.assign(DashboardReleasesController, DashboardReleasesController),
DashboardSitesController: Object.assign(DashboardSitesController, DashboardSitesController),
DashboardSiteExportController: Object.assign(DashboardSiteExportController, DashboardSiteExportController),
DashboardSettingsController: Object.assign(DashboardSettingsController, DashboardSettingsController),
DashboardTeamController: Object.assign(DashboardTeamController, DashboardTeamController),
Editor: Object.assign(Editor, Editor),
Settings: Object.assign(Settings, Settings),
}

export default Controllers