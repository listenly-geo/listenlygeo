import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
const DashboardSiteExportController = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSiteExportController.url(args, options),
    method: 'get',
})

DashboardSiteExportController.definition = {
    methods: ["get","head"],
    url: '/dashboard/sites/{site}/export/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
DashboardSiteExportController.url = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    format: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                                format: args.format,
                }

    return DashboardSiteExportController.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
DashboardSiteExportController.get = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardSiteExportController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
DashboardSiteExportController.head = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardSiteExportController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
    const DashboardSiteExportControllerForm = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardSiteExportController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
        DashboardSiteExportControllerForm.get = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSiteExportController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardSiteExportController::__invoke
 * @see app/Http/Controllers/DashboardSiteExportController.php:18
 * @route '/dashboard/sites/{site}/export/{format}'
 */
        DashboardSiteExportControllerForm.head = (args: { site: number | { id: number }, format: string | number } | [site: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardSiteExportController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardSiteExportController.form = DashboardSiteExportControllerForm
export default DashboardSiteExportController