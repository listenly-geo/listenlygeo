import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
export const adminCommerce = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminCommerce.url(options),
    method: 'get',
})

adminCommerce.definition = {
    methods: ["get","head"],
    url: '/admin/commerce',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
adminCommerce.url = (options?: RouteQueryOptions) => {
    return adminCommerce.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
adminCommerce.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminCommerce.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
adminCommerce.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminCommerce.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
    const adminCommerceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminCommerce.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
        adminCommerceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminCommerce.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardBillingController::adminCommerce
 * @see app/Http/Controllers/DashboardBillingController.php:58
 * @route '/admin/commerce'
 */
        adminCommerceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminCommerce.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminCommerce.form = adminCommerceForm
/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
const updatea77873515a6f1314b5a50a8a44a6dfc4 = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatea77873515a6f1314b5a50a8a44a6dfc4.url(options),
    method: 'patch',
})

updatea77873515a6f1314b5a50a8a44a6dfc4.definition = {
    methods: ["patch"],
    url: '/admin/commerce',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
updatea77873515a6f1314b5a50a8a44a6dfc4.url = (options?: RouteQueryOptions) => {
    return updatea77873515a6f1314b5a50a8a44a6dfc4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
updatea77873515a6f1314b5a50a8a44a6dfc4.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatea77873515a6f1314b5a50a8a44a6dfc4.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
    const updatea77873515a6f1314b5a50a8a44a6dfc4Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatea77873515a6f1314b5a50a8a44a6dfc4.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/admin/commerce'
 */
        updatea77873515a6f1314b5a50a8a44a6dfc4Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatea77873515a6f1314b5a50a8a44a6dfc4.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatea77873515a6f1314b5a50a8a44a6dfc4.form = updatea77873515a6f1314b5a50a8a44a6dfc4Form
    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/commerce'
 */
const update96a02a98d047e647683476ffb33e6eee = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update96a02a98d047e647683476ffb33e6eee.url(options),
    method: 'patch',
})

update96a02a98d047e647683476ffb33e6eee.definition = {
    methods: ["patch"],
    url: '/dashboard/commerce',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/commerce'
 */
update96a02a98d047e647683476ffb33e6eee.url = (options?: RouteQueryOptions) => {
    return update96a02a98d047e647683476ffb33e6eee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/commerce'
 */
update96a02a98d047e647683476ffb33e6eee.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update96a02a98d047e647683476ffb33e6eee.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/commerce'
 */
    const update96a02a98d047e647683476ffb33e6eeeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update96a02a98d047e647683476ffb33e6eee.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/commerce'
 */
        update96a02a98d047e647683476ffb33e6eeeForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update96a02a98d047e647683476ffb33e6eee.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update96a02a98d047e647683476ffb33e6eee.form = update96a02a98d047e647683476ffb33e6eeeForm
    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
const update887dd3c29c1b94b5b5247419153a7b87 = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update887dd3c29c1b94b5b5247419153a7b87.url(options),
    method: 'patch',
})

update887dd3c29c1b94b5b5247419153a7b87.definition = {
    methods: ["patch"],
    url: '/dashboard/billing',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
update887dd3c29c1b94b5b5247419153a7b87.url = (options?: RouteQueryOptions) => {
    return update887dd3c29c1b94b5b5247419153a7b87.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
update887dd3c29c1b94b5b5247419153a7b87.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update887dd3c29c1b94b5b5247419153a7b87.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
    const update887dd3c29c1b94b5b5247419153a7b87Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update887dd3c29c1b94b5b5247419153a7b87.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::update
 * @see app/Http/Controllers/DashboardBillingController.php:159
 * @route '/dashboard/billing'
 */
        update887dd3c29c1b94b5b5247419153a7b87Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update887dd3c29c1b94b5b5247419153a7b87.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update887dd3c29c1b94b5b5247419153a7b87.form = update887dd3c29c1b94b5b5247419153a7b87Form

export const update = {
    '/admin/commerce': updatea77873515a6f1314b5a50a8a44a6dfc4,
    '/dashboard/commerce': update96a02a98d047e647683476ffb33e6eee,
    '/dashboard/billing': update887dd3c29c1b94b5b5247419153a7b87,
}

/**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
const updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819 = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.url(options),
    method: 'patch',
})

updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.definition = {
    methods: ["patch"],
    url: '/admin/commerce/gateway',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.url = (options?: RouteQueryOptions) => {
    return updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
    const updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/admin/commerce/gateway'
 */
        updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819.form = updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819Form
    /**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/dashboard/commerce/gateway'
 */
const updateGateway1784461e8eceb4fdd2b15819497f50c9 = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGateway1784461e8eceb4fdd2b15819497f50c9.url(options),
    method: 'patch',
})

updateGateway1784461e8eceb4fdd2b15819497f50c9.definition = {
    methods: ["patch"],
    url: '/dashboard/commerce/gateway',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/dashboard/commerce/gateway'
 */
updateGateway1784461e8eceb4fdd2b15819497f50c9.url = (options?: RouteQueryOptions) => {
    return updateGateway1784461e8eceb4fdd2b15819497f50c9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/dashboard/commerce/gateway'
 */
updateGateway1784461e8eceb4fdd2b15819497f50c9.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGateway1784461e8eceb4fdd2b15819497f50c9.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/dashboard/commerce/gateway'
 */
    const updateGateway1784461e8eceb4fdd2b15819497f50c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateGateway1784461e8eceb4fdd2b15819497f50c9.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::updateGateway
 * @see app/Http/Controllers/DashboardBillingController.php:413
 * @route '/dashboard/commerce/gateway'
 */
        updateGateway1784461e8eceb4fdd2b15819497f50c9Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateGateway1784461e8eceb4fdd2b15819497f50c9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateGateway1784461e8eceb4fdd2b15819497f50c9.form = updateGateway1784461e8eceb4fdd2b15819497f50c9Form

export const updateGateway = {
    '/admin/commerce/gateway': updateGateway9f9a7de36d6d72b98f5c7a9ea87ed819,
    '/dashboard/commerce/gateway': updateGateway1784461e8eceb4fdd2b15819497f50c9,
}

/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
const DashboardBillingController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardBillingController.url(options),
    method: 'get',
})

DashboardBillingController.definition = {
    methods: ["get","head"],
    url: '/dashboard/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
DashboardBillingController.url = (options?: RouteQueryOptions) => {
    return DashboardBillingController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
DashboardBillingController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardBillingController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
DashboardBillingController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardBillingController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
    const DashboardBillingControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardBillingController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
        DashboardBillingControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardBillingController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardBillingController::__invoke
 * @see app/Http/Controllers/DashboardBillingController.php:42
 * @route '/dashboard/billing'
 */
        DashboardBillingControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardBillingController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardBillingController.form = DashboardBillingControllerForm
/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/dashboard/billing/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
    const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::checkout
 * @see app/Http/Controllers/DashboardBillingController.php:260
 * @route '/dashboard/billing/checkout'
 */
        checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkout.url(options),
            method: 'post',
        })
    
    checkout.form = checkoutForm
/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
export const portal = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

portal.definition = {
    methods: ["post"],
    url: '/dashboard/billing/portal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
portal.url = (options?: RouteQueryOptions) => {
    return portal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
portal.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
    const portalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: portal.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::portal
 * @see app/Http/Controllers/DashboardBillingController.php:348
 * @route '/dashboard/billing/portal'
 */
        portalForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: portal.url(options),
            method: 'post',
        })
    
    portal.form = portalForm
/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/dashboard/billing/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::cancel
 * @see app/Http/Controllers/DashboardBillingController.php:369
 * @route '/dashboard/billing/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
export const resume = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/dashboard/billing/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
resume.url = (options?: RouteQueryOptions) => {
    return resume.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
resume.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
    const resumeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardBillingController::resume
 * @see app/Http/Controllers/DashboardBillingController.php:394
 * @route '/dashboard/billing/resume'
 */
        resumeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(options),
            method: 'post',
        })
    
    resume.form = resumeForm
DashboardBillingController.adminCommerce = adminCommerce
DashboardBillingController.update = update
DashboardBillingController.updateGateway = updateGateway
DashboardBillingController.checkout = checkout
DashboardBillingController.portal = portal
DashboardBillingController.cancel = cancel
DashboardBillingController.resume = resume

export default DashboardBillingController