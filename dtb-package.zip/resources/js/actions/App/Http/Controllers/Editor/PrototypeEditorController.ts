import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
export const state = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: state.url(args, options),
    method: 'get',
})

state.definition = {
    methods: ["get","head"],
    url: '/editor/api/sites/{site}/spaces/{space}/state',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.url = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    space: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.uuid
                : args.site,
                                space: typeof args.space === 'object'
                ? args.space.uuid
                : args.space,
                }

    return state.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{space}', parsedArgs.space.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: state.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
state.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: state.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
    const stateForm = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: state.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
        stateForm.get = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: state.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::state
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:52
 * @route '/editor/api/sites/{site}/spaces/{space}/state'
 */
        stateForm.head = (args: { site: string | { uuid: string }, space: string | { uuid: string } } | [site: string | { uuid: string }, space: string | { uuid: string } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: state.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    state.form = stateForm
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
const PrototypeEditorController002dfe45d254767238837ecd634a0729 = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, options),
    method: 'get',
})

PrototypeEditorController002dfe45d254767238837ecd634a0729.definition = {
    methods: ["get","head"],
    url: '/editor/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
PrototypeEditorController002dfe45d254767238837ecd634a0729.url = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { path: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    path: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        path: args.path,
                }

    return PrototypeEditorController002dfe45d254767238837ecd634a0729.definition.url
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
PrototypeEditorController002dfe45d254767238837ecd634a0729.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
PrototypeEditorController002dfe45d254767238837ecd634a0729.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
    const PrototypeEditorController002dfe45d254767238837ecd634a0729Form = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
        PrototypeEditorController002dfe45d254767238837ecd634a0729Form.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/editor/{path}'
 */
        PrototypeEditorController002dfe45d254767238837ecd634a0729Form.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorController002dfe45d254767238837ecd634a0729.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PrototypeEditorController002dfe45d254767238837ecd634a0729.form = PrototypeEditorController002dfe45d254767238837ecd634a0729Form
    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
const PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, options),
    method: 'get',
})

PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.definition = {
    methods: ["get","head"],
    url: '/prototype/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { path: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    path: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        path: args.path,
                }

    return PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.definition.url
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
    const PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0bForm = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
        PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0bForm.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorController.php:63
 * @route '/prototype/{path}'
 */
        PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0bForm.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b.form = PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0bForm

const PrototypeEditorController = {
    '/editor/{path}': PrototypeEditorController002dfe45d254767238837ecd634a0729,
    '/prototype/{path}': PrototypeEditorControlleredd463340730ca3e0c54f32cfe7f7d0b,
}

PrototypeEditorController.state = state

export default PrototypeEditorController