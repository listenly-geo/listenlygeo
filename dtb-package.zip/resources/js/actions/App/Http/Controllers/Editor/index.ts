import PrototypeEditorPublishController from './PrototypeEditorPublishController'
import PrototypeEditorPageTreeController from './PrototypeEditorPageTreeController'
import PrototypeEditorSpaceController from './PrototypeEditorSpaceController'
import PrototypeEditorController from './PrototypeEditorController'
import DraftDocsPreviewController from './DraftDocsPreviewController'
import PrototypeEditorAutosaveController from './PrototypeEditorAutosaveController'
import PrototypeEditorRevisionRestoreController from './PrototypeEditorRevisionRestoreController'
import PrototypeEditorAiWriterController from './PrototypeEditorAiWriterController'
import PrototypeEditorExportController from './PrototypeEditorExportController'
import PrototypeEditorCommentController from './PrototypeEditorCommentController'
import PrototypeEditorMediaController from './PrototypeEditorMediaController'
const Editor = {
    PrototypeEditorPublishController: Object.assign(PrototypeEditorPublishController, PrototypeEditorPublishController),
PrototypeEditorPageTreeController: Object.assign(PrototypeEditorPageTreeController, PrototypeEditorPageTreeController),
PrototypeEditorSpaceController: Object.assign(PrototypeEditorSpaceController, PrototypeEditorSpaceController),
PrototypeEditorController: Object.assign(PrototypeEditorController, PrototypeEditorController),
DraftDocsPreviewController: Object.assign(DraftDocsPreviewController, DraftDocsPreviewController),
PrototypeEditorAutosaveController: Object.assign(PrototypeEditorAutosaveController, PrototypeEditorAutosaveController),
PrototypeEditorRevisionRestoreController: Object.assign(PrototypeEditorRevisionRestoreController, PrototypeEditorRevisionRestoreController),
PrototypeEditorAiWriterController: Object.assign(PrototypeEditorAiWriterController, PrototypeEditorAiWriterController),
PrototypeEditorExportController: Object.assign(PrototypeEditorExportController, PrototypeEditorExportController),
PrototypeEditorCommentController: Object.assign(PrototypeEditorCommentController, PrototypeEditorCommentController),
PrototypeEditorMediaController: Object.assign(PrototypeEditorMediaController, PrototypeEditorMediaController),
}

export default Editor