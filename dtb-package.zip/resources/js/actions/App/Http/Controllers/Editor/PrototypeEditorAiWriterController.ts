import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
const PrototypeEditorAiWriterController = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorAiWriterController.url(args, options),
    method: 'post',
})

PrototypeEditorAiWriterController.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/ai-write',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
PrototypeEditorAiWriterController.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return PrototypeEditorAiWriterController.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
PrototypeEditorAiWriterController.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorAiWriterController.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
    const PrototypeEditorAiWriterControllerForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: PrototypeEditorAiWriterController.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAiWriterController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAiWriterController.php:19
 * @route '/editor/api/pages/{page}/ai-write'
 */
        PrototypeEditorAiWriterControllerForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: PrototypeEditorAiWriterController.url(args, options),
            method: 'post',
        })
    
    PrototypeEditorAiWriterController.form = PrototypeEditorAiWriterControllerForm
export default PrototypeEditorAiWriterController