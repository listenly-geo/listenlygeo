import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
const PrototypeEditorExportController = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorExportController.url(args, options),
    method: 'get',
})

PrototypeEditorExportController.definition = {
    methods: ["get","head"],
    url: '/editor/api/pages/{page}/export/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
PrototypeEditorExportController.url = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                    format: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                                format: args.format,
                }

    return PrototypeEditorExportController.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
PrototypeEditorExportController.get = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PrototypeEditorExportController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
PrototypeEditorExportController.head = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PrototypeEditorExportController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
    const PrototypeEditorExportControllerForm = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PrototypeEditorExportController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
        PrototypeEditorExportControllerForm.get = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorExportController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorExportController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorExportController.php:19
 * @route '/editor/api/pages/{page}/export/{format}'
 */
        PrototypeEditorExportControllerForm.head = (args: { page: number | { id: number }, format: string | number } | [page: number | { id: number }, format: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PrototypeEditorExportController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PrototypeEditorExportController.form = PrototypeEditorExportControllerForm
export default PrototypeEditorExportController