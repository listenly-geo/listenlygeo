import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
const PrototypeEditorPublishController = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorPublishController.url(args, options),
    method: 'post',
})

PrototypeEditorPublishController.definition = {
    methods: ["post"],
    url: '/editor/api/sites/{site}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
PrototypeEditorPublishController.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return PrototypeEditorPublishController.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
PrototypeEditorPublishController.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorPublishController.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
    const PrototypeEditorPublishControllerForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: PrototypeEditorPublishController.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorPublishController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorPublishController.php:18
 * @route '/editor/api/sites/{site}/publish'
 */
        PrototypeEditorPublishControllerForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: PrototypeEditorPublishController.url(args, options),
            method: 'post',
        })
    
    PrototypeEditorPublishController.form = PrototypeEditorPublishControllerForm
export default PrototypeEditorPublishController