import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorRevisionRestoreController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorRevisionRestoreController.php:13
 * @route '/editor/api/pages/{page}/revisions/{revision}/restore'
 */
const PrototypeEditorRevisionRestoreController = (args: { page: number | { id: number }, revision: number | { id: number } } | [page: number | { id: number }, revision: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorRevisionRestoreController.url(args, options),
    method: 'post',
})

PrototypeEditorRevisionRestoreController.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/revisions/{revision}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorRevisionRestoreController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorRevisionRestoreController.php:13
 * @route '/editor/api/pages/{page}/revisions/{revision}/restore'
 */
PrototypeEditorRevisionRestoreController.url = (args: { page: number | { id: number }, revision: number | { id: number } } | [page: number | { id: number }, revision: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                    revision: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                                revision: typeof args.revision === 'object'
                ? args.revision.id
                : args.revision,
                }

    return PrototypeEditorRevisionRestoreController.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace('{revision}', parsedArgs.revision.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorRevisionRestoreController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorRevisionRestoreController.php:13
 * @route '/editor/api/pages/{page}/revisions/{revision}/restore'
 */
PrototypeEditorRevisionRestoreController.post = (args: { page: number | { id: number }, revision: number | { id: number } } | [page: number | { id: number }, revision: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorRevisionRestoreController.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorRevisionRestoreController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorRevisionRestoreController.php:13
 * @route '/editor/api/pages/{page}/revisions/{revision}/restore'
 */
    const PrototypeEditorRevisionRestoreControllerForm = (args: { page: number | { id: number }, revision: number | { id: number } } | [page: number | { id: number }, revision: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: PrototypeEditorRevisionRestoreController.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorRevisionRestoreController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorRevisionRestoreController.php:13
 * @route '/editor/api/pages/{page}/revisions/{revision}/restore'
 */
        PrototypeEditorRevisionRestoreControllerForm.post = (args: { page: number | { id: number }, revision: number | { id: number } } | [page: number | { id: number }, revision: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: PrototypeEditorRevisionRestoreController.url(args, options),
            method: 'post',
        })
    
    PrototypeEditorRevisionRestoreController.form = PrototypeEditorRevisionRestoreControllerForm
export default PrototypeEditorRevisionRestoreController