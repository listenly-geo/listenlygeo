import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
const PrototypeEditorAutosaveController = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorAutosaveController.url(args, options),
    method: 'post',
})

PrototypeEditorAutosaveController.definition = {
    methods: ["post"],
    url: '/editor/api/pages/{page}/autosave',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
PrototypeEditorAutosaveController.url = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { page: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { page: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    page: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        page: typeof args.page === 'object'
                ? args.page.id
                : args.page,
                }

    return PrototypeEditorAutosaveController.definition.url
            .replace('{page}', parsedArgs.page.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
PrototypeEditorAutosaveController.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PrototypeEditorAutosaveController.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
    const PrototypeEditorAutosaveControllerForm = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: PrototypeEditorAutosaveController.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Editor\PrototypeEditorAutosaveController::__invoke
 * @see app/Http/Controllers/Editor/PrototypeEditorAutosaveController.php:18
 * @route '/editor/api/pages/{page}/autosave'
 */
        PrototypeEditorAutosaveControllerForm.post = (args: { page: number | { id: number } } | [page: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: PrototypeEditorAutosaveController.url(args, options),
            method: 'post',
        })
    
    PrototypeEditorAutosaveController.form = PrototypeEditorAutosaveControllerForm
export default PrototypeEditorAutosaveController