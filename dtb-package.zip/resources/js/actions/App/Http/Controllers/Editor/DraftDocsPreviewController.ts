import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
const DraftDocsPreviewController = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DraftDocsPreviewController.url(args, options),
    method: 'get',
})

DraftDocsPreviewController.definition = {
    methods: ["get","head"],
    url: '/preview/sites/{site}/{path?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
DraftDocsPreviewController.url = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                    path: args[1],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "path",
        ])

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                                path: args.path,
                }

    return DraftDocsPreviewController.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{path?}', parsedArgs.path?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
DraftDocsPreviewController.get = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DraftDocsPreviewController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
DraftDocsPreviewController.head = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DraftDocsPreviewController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
    const DraftDocsPreviewControllerForm = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DraftDocsPreviewController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
        DraftDocsPreviewControllerForm.get = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DraftDocsPreviewController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Editor\DraftDocsPreviewController::__invoke
 * @see app/Http/Controllers/Editor/DraftDocsPreviewController.php:20
 * @route '/preview/sites/{site}/{path?}'
 */
        DraftDocsPreviewControllerForm.head = (args: { site: number | { id: number }, path?: string | number } | [site: number | { id: number }, path: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DraftDocsPreviewController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DraftDocsPreviewController.form = DraftDocsPreviewControllerForm
export default DraftDocsPreviewController