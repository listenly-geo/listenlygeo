import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/application',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\AppSettingsController::edit
 * @see app/Http/Controllers/Settings/AppSettingsController.php:15
 * @route '/settings/application'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\AppSettingsController::update
 * @see app/Http/Controllers/Settings/AppSettingsController.php:30
 * @route '/settings/application'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings/application',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\AppSettingsController::update
 * @see app/Http/Controllers/Settings/AppSettingsController.php:30
 * @route '/settings/application'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\AppSettingsController::update
 * @see app/Http/Controllers/Settings/AppSettingsController.php:30
 * @route '/settings/application'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\AppSettingsController::update
 * @see app/Http/Controllers/Settings/AppSettingsController.php:30
 * @route '/settings/application'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\AppSettingsController::update
 * @see app/Http/Controllers/Settings/AppSettingsController.php:30
 * @route '/settings/application'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const AppSettingsController = { edit, update }

export default AppSettingsController