import ProfileController from './ProfileController'
import SecurityController from './SecurityController'
import EmailConfigurationController from './EmailConfigurationController'
import AppSettingsController from './AppSettingsController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
SecurityController: Object.assign(SecurityController, SecurityController),
EmailConfigurationController: Object.assign(EmailConfigurationController, EmailConfigurationController),
AppSettingsController: Object.assign(AppSettingsController, AppSettingsController),
}

export default Settings