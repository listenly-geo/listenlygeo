import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
const DashboardTeamController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardTeamController.url(options),
    method: 'get',
})

DashboardTeamController.definition = {
    methods: ["get","head"],
    url: '/dashboard/team',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
DashboardTeamController.url = (options?: RouteQueryOptions) => {
    return DashboardTeamController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
DashboardTeamController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardTeamController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
DashboardTeamController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardTeamController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
    const DashboardTeamControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardTeamController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
        DashboardTeamControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardTeamController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardTeamController::__invoke
 * @see app/Http/Controllers/DashboardTeamController.php:24
 * @route '/dashboard/team'
 */
        DashboardTeamControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardTeamController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardTeamController.form = DashboardTeamControllerForm
/**
* @see \App\Http\Controllers\DashboardTeamController::storeInvitation
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
export const storeInvitation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInvitation.url(options),
    method: 'post',
})

storeInvitation.definition = {
    methods: ["post"],
    url: '/dashboard/team/invitations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardTeamController::storeInvitation
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
storeInvitation.url = (options?: RouteQueryOptions) => {
    return storeInvitation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardTeamController::storeInvitation
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
storeInvitation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInvitation.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardTeamController::storeInvitation
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
    const storeInvitationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeInvitation.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardTeamController::storeInvitation
 * @see app/Http/Controllers/DashboardTeamController.php:88
 * @route '/dashboard/team/invitations'
 */
        storeInvitationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeInvitation.url(options),
            method: 'post',
        })
    
    storeInvitation.form = storeInvitationForm
/**
* @see \App\Http\Controllers\DashboardTeamController::updateMembershipRole
 * @see app/Http/Controllers/DashboardTeamController.php:144
 * @route '/dashboard/team/members/{membership}'
 */
export const updateMembershipRole = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMembershipRole.url(args, options),
    method: 'patch',
})

updateMembershipRole.definition = {
    methods: ["patch"],
    url: '/dashboard/team/members/{membership}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DashboardTeamController::updateMembershipRole
 * @see app/Http/Controllers/DashboardTeamController.php:144
 * @route '/dashboard/team/members/{membership}'
 */
updateMembershipRole.url = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { membership: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { membership: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    membership: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        membership: typeof args.membership === 'object'
                ? args.membership.id
                : args.membership,
                }

    return updateMembershipRole.definition.url
            .replace('{membership}', parsedArgs.membership.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardTeamController::updateMembershipRole
 * @see app/Http/Controllers/DashboardTeamController.php:144
 * @route '/dashboard/team/members/{membership}'
 */
updateMembershipRole.patch = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMembershipRole.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DashboardTeamController::updateMembershipRole
 * @see app/Http/Controllers/DashboardTeamController.php:144
 * @route '/dashboard/team/members/{membership}'
 */
    const updateMembershipRoleForm = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMembershipRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardTeamController::updateMembershipRole
 * @see app/Http/Controllers/DashboardTeamController.php:144
 * @route '/dashboard/team/members/{membership}'
 */
        updateMembershipRoleForm.patch = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMembershipRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMembershipRole.form = updateMembershipRoleForm
DashboardTeamController.storeInvitation = storeInvitation
DashboardTeamController.updateMembershipRole = updateMembershipRole

export default DashboardTeamController