import { Head } from '@inertiajs/react';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import AppearanceTabs from '@/components/appearance-tabs';
import { edit as editAppearance } from '@/routes/appearance';

export default function Appearance() {
    return (
        <>
            <Head title="Appearance settings" />

            <h1 className="sr-only">Appearance settings</h1>

            <section className="admin-surface">
                <AdminCardHeader label="Appearance" title="Interface preference" action={<span className="admin-pill">personal</span>} />
                <p className="settings-admin-copy">Choose the interface mode for your account workspace.</p>
                <AppearanceTabs />
            </section>
        </>
    );
}

Appearance.layout = {
    breadcrumbs: [
        {
            title: 'Appearance settings',
            href: editAppearance(),
        },
    ],
};
