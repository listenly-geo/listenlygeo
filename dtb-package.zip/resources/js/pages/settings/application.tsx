import { Head, useForm } from '@inertiajs/react';
import { useEffect, useRef, useState } from 'react';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type Props = {
    appSettings: {
        appName: string;
        logoUrl: string | null;
        faviconUrl: string | null;
    };
};

export default function ApplicationSettings({ appSettings }: Props) {
    const [logoPreviewUrl, setLogoPreviewUrl] = useState<string | null>(null);
    const [faviconPreviewUrl, setFaviconPreviewUrl] = useState<string | null>(null);
    const [useLogoAsFavicon, setUseLogoAsFavicon] = useState(false);

    const logoInputRef = useRef<HTMLInputElement>(null);
    const faviconInputRef = useRef<HTMLInputElement>(null);

    const form = useForm<{
        app_name: string;
        logo: File | null;
        favicon: File | null;
        use_logo_as_favicon: boolean;
    }>({
        app_name: appSettings.appName,
        logo: null,
        favicon: null,
        use_logo_as_favicon: false,
    });

    const logoPreview = logoPreviewUrl ?? appSettings.logoUrl;
    const faviconPreview = useLogoAsFavicon ? logoPreview : (faviconPreviewUrl ?? appSettings.faviconUrl);

    useEffect(() => () => {
        if (logoPreviewUrl) {
            URL.revokeObjectURL(logoPreviewUrl);
        }
    }, [logoPreviewUrl]);

    useEffect(() => () => {
        if (faviconPreviewUrl) {
            URL.revokeObjectURL(faviconPreviewUrl);
        }
    }, [faviconPreviewUrl]);

    const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0] ?? null;
        form.setData('logo', file);
        setLogoPreviewUrl(file ? URL.createObjectURL(file) : null);
    };

    const handleFaviconChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0] ?? null;
        form.setData('favicon', file);
        setFaviconPreviewUrl(file ? URL.createObjectURL(file) : null);
    };

    const handleUseLogoAsFavicon = (checked: boolean) => {
        setUseLogoAsFavicon(checked);
        form.setData('use_logo_as_favicon', checked);
    };

    const saveSettings = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        form.post('/settings/application', {
            preserveScroll: true,
            forceFormData: true,
            onSuccess: () => {
                setLogoPreviewUrl(null);
                setFaviconPreviewUrl(null);
            },
        });
    };

    return (
        <>
            <Head title="Application settings" />

            <h1 className="sr-only">Application settings</h1>

            <section className="admin-surface">
                <AdminCardHeader
                    label="Application"
                    title="Branding and identity"
                    action={<span className="admin-pill">platform admin</span>}
                />
                <p className="settings-admin-copy">
                    Configure the application name, logo, and favicon displayed throughout the platform.
                </p>

                <form className="admin-form-grid" onSubmit={saveSettings} encType="multipart/form-data">
                    {/* App Name */}
                    <label className="admin-field admin-field-full" htmlFor="app_name">
                        <span>Application name</span>
                        <input
                            id="app_name"
                            type="text"
                            className="admin-text-input"
                            value={form.data.app_name}
                            onChange={(event) => form.setData('app_name', event.target.value)}
                            placeholder="My Application"
                            maxLength={80}
                        />
                        <InputError message={form.errors.app_name} />
                    </label>

                    {/* Logo Upload */}
                    <div className="admin-field admin-field-full">
                        <span>Logo</span>
                        <p className="settings-admin-copy" style={{ marginBottom: '8px' }}>
                            Recommended: SVG or PNG, max 2 MB. Displayed in the navigation and branding areas.
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
                            {logoPreview && (
                                <div
                                    style={{
                                        width: 72,
                                        height: 72,
                                        border: '1px solid var(--border)',
                                        borderRadius: '8px',
                                        overflow: 'hidden',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        background: '#f5f5f5',
                                        flexShrink: 0,
                                    }}
                                >
                                    <img
                                        src={logoPreview}
                                        alt="Logo preview"
                                        style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                                    />
                                </div>
                            )}
                            <div>
                                <input
                                    ref={logoInputRef}
                                    type="file"
                                    id="logo"
                                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                                    style={{ display: 'none' }}
                                    onChange={handleLogoChange}
                                />
                                <button
                                    type="button"
                                    className="admin-button admin-button-secondary"
                                    onClick={() => logoInputRef.current?.click()}
                                >
                                    {logoPreview ? 'Change logo' : 'Upload logo'}
                                </button>
                                {logoPreview && (
                                    <span style={{ marginLeft: '8px', fontSize: '12px', color: 'var(--text-muted)' }}>
                                        PNG, JPG, SVG, or WebP
                                    </span>
                                )}
                            </div>
                        </div>
                        <InputError message={form.errors.logo} />
                    </div>

                    {/* Use logo as favicon toggle */}
                    <label
                        className="admin-field admin-field-full"
                        style={{ flexDirection: 'row', alignItems: 'center', gap: '10px', cursor: 'pointer' }}
                        htmlFor="use_logo_as_favicon"
                    >
                        <input
                            id="use_logo_as_favicon"
                            type="checkbox"
                            checked={useLogoAsFavicon}
                            onChange={(e) => handleUseLogoAsFavicon(e.target.checked)}
                            style={{ width: 'auto', cursor: 'pointer' }}
                        />
                        <span style={{ fontWeight: 'normal' }}>Use logo as favicon</span>
                    </label>

                    {/* Favicon Upload */}
                    {!useLogoAsFavicon && (
                        <div className="admin-field admin-field-full">
                            <span>Favicon</span>
                            <p className="settings-admin-copy" style={{ marginBottom: '8px' }}>
                                Recommended: 32×32 PNG or ICO, max 512 KB. Shown in browser tabs.
                            </p>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
                                {faviconPreview && (
                                    <div
                                        style={{
                                            width: 40,
                                            height: 40,
                                            border: '1px solid var(--border)',
                                            borderRadius: '6px',
                                            overflow: 'hidden',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            background: '#f5f5f5',
                                            flexShrink: 0,
                                        }}
                                    >
                                        <img
                                            src={faviconPreview}
                                            alt="Favicon preview"
                                            style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                                        />
                                    </div>
                                )}
                                <div>
                                    <input
                                        ref={faviconInputRef}
                                        type="file"
                                        id="favicon"
                                        accept="image/png,image/jpeg,image/x-icon,image/svg+xml"
                                        style={{ display: 'none' }}
                                        onChange={handleFaviconChange}
                                    />
                                    <button
                                        type="button"
                                        className="admin-button admin-button-secondary"
                                        onClick={() => faviconInputRef.current?.click()}
                                    >
                                        {faviconPreview ? 'Change favicon' : 'Upload favicon'}
                                    </button>
                                    {faviconPreview && (
                                        <span style={{ marginLeft: '8px', fontSize: '12px', color: 'var(--text-muted)' }}>
                                            PNG, ICO, or SVG
                                        </span>
                                    )}
                                </div>
                            </div>
                            <InputError message={form.errors.favicon} />
                        </div>
                    )}

                    {/* Save */}
                    <div className="admin-field admin-field-full">
                        <button
                            type="submit"
                            className="admin-button admin-button-primary"
                            disabled={form.processing}
                        >
                            {form.processing ? 'Saving…' : 'Save settings'}
                        </button>
                    </div>
                </form>
            </section>
        </>
    );
}

ApplicationSettings.layout = {
    breadcrumbs: [
        { title: 'Settings', href: '/settings' },
        { title: 'Application', href: '/settings/application' },
    ],
};
