import { Head, router, useForm } from '@inertiajs/react';
import {
    ChevronDown,
    Edit2,
    Eye,
    EyeOff,
    Link2,
    Plus,
    Save,
    Trash2,
    X,
} from 'lucide-react';
import { useState } from 'react';
import { AdminCardHeader, AdminPageHero } from '@/components/admin/page-primitives';

type LandingSection = {
    id: number;
    section: string;
    label: string;
    kicker?: string;
    title?: string;
    subtitle?: string;
    description?: string;
    data: Record<string, any>;
    is_active: boolean;
    updated_at: string;
};

type SocialLink = {
    platform: string;
    url: string;
};

type Props = {
    sections: LandingSection[];
    landingSettings: {
        copyrightText: string;
        socialLinks: SocialLink[];
    };
};

export default function AdminLandingContent({ sections, landingSettings }: Props) {
    const [expandedId, setExpandedId] = useState<number | null>(null);
    const [editingId, setEditingId] = useState<number | null>(null);
    const [formData, setFormData] = useState<Partial<LandingSection> | null>(null);
    const [isCreating, setIsCreating] = useState(false);

    const handleEdit = (section: LandingSection) => {
        setEditingId(section.id);
        setFormData(section);
        setExpandedId(section.id);
    };

    const handleCancel = () => {
        setEditingId(null);
        setFormData(null);
        setIsCreating(false);
    };

    const handleSave = () => {
        if (!formData) {
            return;
        }

        if (isCreating) {
            router.post('/admin/landing-content', formData, {
                onSuccess: () => {
                    handleCancel();
                },
            });
        } else {
            router.patch(`/admin/landing-content/${formData.id}`, formData, {
                onSuccess: () => {
                    handleCancel();
                },
            });
        }
    };

    const handleDelete = (id: number) => {
        if (confirm('Are you sure you want to delete this section?')) {
            router.delete(`/admin/landing-content/${id}`);
        }
    };

    const toggleActive = (section: LandingSection) => {
        router.patch(`/admin/landing-content/${section.id}`, {
            is_active: !section.is_active,
        });
    };

    const handleNewSection = () => {
        setFormData({
            section: '',
            label: '',
            kicker: '',
            title: '',
            subtitle: '',
            description: '',
            data: {},
            is_active: true,
        });
        setIsCreating(true);
        setEditingId(0);
    };

    return (
        <>
            <Head title="Landing Content CMS" />

            <AdminPageHero
                eyebrow="Landing Content"
                title="Landing Page CMS"
                description="Manage all landing page content from here"
                actions={(
                    <button type="button" onClick={handleNewSection} className="admin-primary-link">
                        Add Section <Plus size={14} />
                    </button>
                )}
            />

            <FooterSettingsCard landingSettings={landingSettings} />

            <div className="admin-container">
                <div className="admin-section">
                    {sections.length === 0 && !isCreating ? (
                        <div className="admin-empty-state">
                            <p>No landing content sections yet. Create your first one!</p>
                            <button
                                onClick={handleNewSection}
                                className="admin-btn admin-btn-primary"
                            >
                                <Plus size={16} />
                                Create Section
                            </button>
                        </div>
                    ) : (
                        <div className="landing-cms-list">
                            {/* Create Form */}
                            {isCreating && (
                                <LandingContentForm
                                    data={formData}
                                    setData={setFormData}
                                    onSave={handleSave}
                                    onCancel={handleCancel}
                                    isNew
                                />
                            )}

                            {/* Existing Sections */}
                            {sections.map((section) => (
                                <div
                                    key={section.id}
                                    className={`landing-cms-card ${
                                        expandedId === section.id ? 'expanded' : ''
                                    } ${!section.is_active ? 'inactive' : ''}`}
                                >
                                    <div className="landing-cms-header">
                                        <div
                                            className="landing-cms-header-content"
                                            onClick={() =>
                                                setExpandedId(
                                                    expandedId === section.id ? null : section.id
                                                )
                                            }
                                        >
                                            <div className="landing-cms-title-group">
                                                <ChevronDown
                                                    size={18}
                                                    className={`chevron-icon ${
                                                        expandedId === section.id ? 'rotated' : ''
                                                    }`}
                                                />
                                                <div>
                                                    <h3 className="landing-cms-card-title">
                                                        {section.label}
                                                    </h3>
                                                    <p className="landing-cms-card-meta">
                                                        <code>{section.section}</code> •{' '}
                                                        {section.updated_at}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="landing-cms-actions">
                                            <button
                                                onClick={() => toggleActive(section)}
                                                className={`admin-icon-btn ${
                                                    section.is_active ? 'active' : ''
                                                }`}
                                                title={
                                                    section.is_active ? 'Hide' : 'Show'
                                                }
                                            >
                                                {section.is_active ? <Eye size={18} /> : <EyeOff size={18} />}
                                            </button>

                                            {editingId !== section.id && (
                                                <>
                                                    <button
                                                        onClick={() => handleEdit(section)}
                                                        className="admin-icon-btn"
                                                        title="Edit"
                                                    >
                                                        <Edit2 size={18} />
                                                    </button>
                                                    <button
                                                        onClick={() =>
                                                            handleDelete(section.id)
                                                        }
                                                        className="admin-icon-btn admin-icon-btn-danger"
                                                        title="Delete"
                                                    >
                                                        <Trash2 size={18} />
                                                    </button>
                                                </>
                                            )}
                                        </div>
                                    </div>

                                    {/* Expanded Content */}
                                    {expandedId === section.id && (
                                        <div className="landing-cms-content">
                                            {editingId === section.id ? (
                                                <LandingContentForm
                                                    data={formData}
                                                    setData={setFormData}
                                                    onSave={handleSave}
                                                    onCancel={handleCancel}
                                                />
                                            ) : (
                                                <LandingContentPreview section={section} />
                                            )}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <style>{`
                .landing-cms-list {
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                }

                .landing-cms-card {
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    background: white;
                    overflow: hidden;
                    transition: all 0.2s ease;
                }

                .landing-cms-card.expanded {
                    border-color: #1f4c40;
                    box-shadow: 0 4px 12px rgba(31, 76, 64, 0.08);
                }

                .landing-cms-card.inactive {
                    opacity: 0.6;
                    background: #f9fafb;
                }

                .landing-cms-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 16px;
                    cursor: pointer;
                    user-select: none;
                }

                .landing-cms-header-content {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    min-width: 0;
                }

                .landing-cms-title-group {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    flex: 1;
                    min-width: 0;
                }

                .chevron-icon {
                    flex-shrink: 0;
                    color: #6b7280;
                    transition: transform 0.2s ease;
                }

                .chevron-icon.rotated {
                    transform: rotate(180deg);
                }

                .landing-cms-card-title {
                    font-size: 15px;
                    font-weight: 600;
                    color: #111827;
                    margin: 0;
                }

                .landing-cms-card-meta {
                    font-size: 13px;
                    color: #6b7280;
                    margin: 4px 0 0;
                    display: flex;
                    gap: 8px;
                    align-items: center;
                }

                .landing-cms-card-meta code {
                    background: #f3f4f6;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-family: 'Courier New', monospace;
                    font-size: 12px;
                }

                .landing-cms-actions {
                    display: flex;
                    gap: 8px;
                    align-items: center;
                    flex-shrink: 0;
                }

                .landing-cms-content {
                    border-top: 1px solid #e5e7eb;
                    padding: 20px;
                    background: #fafbfc;
                }

                .landing-content-form {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 6px;
                }

                .form-label {
                    font-size: 14px;
                    font-weight: 600;
                    color: #374151;
                }

                .form-input,
                .form-textarea {
                    padding: 10px 12px;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 14px;
                    font-family: inherit;
                    transition: border-color 0.2s ease;
                }

                .form-input:focus,
                .form-textarea:focus {
                    outline: none;
                    border-color: #1f4c40;
                    background: white;
                }

                .form-textarea {
                    resize: vertical;
                    min-height: 100px;
                }

                .form-actions {
                    display: flex;
                    gap: 10px;
                    justify-content: flex-end;
                    padding-top: 10px;
                    border-top: 1px solid #e5e7eb;
                }

                .landing-content-preview {
                    display: flex;
                    flex-direction: column;
                    gap: 16px;
                }

                .preview-row {
                    display: flex;
                    flex-direction: column;
                    gap: 4px;
                }

                .preview-label {
                    font-size: 12px;
                    font-weight: 600;
                    color: #6b7280;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }

                .preview-value {
                    font-size: 14px;
                    color: #111827;
                    padding: 8px 12px;
                    background: white;
                    border-radius: 6px;
                    border: 1px solid #e5e7eb;
                    white-space: pre-wrap;
                    word-break: break-word;
                    font-family: 'Courier New', monospace;
                }

                .preview-value.empty {
                    color: #9ca3af;
                    font-style: italic;
                }

                @media (max-width: 860px) {
                    .landing-cms-header {
                        flex-wrap: wrap;
                    }

                    .landing-cms-actions {
                        width: 100%;
                        margin-top: 12px;
                        padding-top: 12px;
                        border-top: 1px solid #e5e7eb;
                    }
                }
            `}</style>
        </>
    );
}

function LandingContentForm({
    data,
    setData,
    onSave,
    onCancel,
    isNew = false,
}: {
    data: Partial<LandingSection> | null;
    setData: (data: Partial<LandingSection>) => void;
    onSave: () => void;
    onCancel: () => void;
    isNew?: boolean;
}) {
    if (!data) {
        return null;
    }

    return (
        <div className="landing-content-form">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="form-group">
                    <label className="form-label">Section ID</label>
                    <input
                        type="text"
                        className="form-input"
                        value={data.section || ''}
                        onChange={(e) =>
                            setData({ ...data, section: e.target.value })
                        }
                        placeholder="e.g., hero, pricing, integrations"
                        disabled={!isNew}
                    />
                </div>

                <div className="form-group">
                    <label className="form-label">Display Label</label>
                    <input
                        type="text"
                        className="form-input"
                        value={data.label || ''}
                        onChange={(e) =>
                            setData({ ...data, label: e.target.value })
                        }
                        placeholder="e.g., Hero Section"
                    />
                </div>
            </div>

            <div className="form-group">
                <label className="form-label">Kicker (Small Label)</label>
                <input
                    type="text"
                    className="form-input"
                    value={data.kicker || ''}
                    onChange={(e) =>
                        setData({ ...data, kicker: e.target.value })
                    }
                    placeholder="e.g., Getting Started"
                />
            </div>

            <div className="form-group">
                <label className="form-label">Title</label>
                <input
                    type="text"
                    className="form-input"
                    value={data.title || ''}
                    onChange={(e) =>
                        setData({ ...data, title: e.target.value })
                    }
                    placeholder="Main heading"
                />
            </div>

            <div className="form-group">
                <label className="form-label">Subtitle</label>
                <input
                    type="text"
                    className="form-input"
                    value={data.subtitle || ''}
                    onChange={(e) =>
                        setData({ ...data, subtitle: e.target.value })
                    }
                    placeholder="Secondary heading"
                />
            </div>

            <div className="form-group">
                <label className="form-label">Description</label>
                <textarea
                    className="form-textarea"
                    value={data.description || ''}
                    onChange={(e) =>
                        setData({ ...data, description: e.target.value })
                    }
                    placeholder="Detailed description..."
                />
            </div>

            <div className="form-actions">
                <button
                    onClick={onCancel}
                    className="admin-btn admin-btn-secondary"
                >
                    Cancel
                </button>
                <button
                    onClick={onSave}
                    className="admin-btn admin-btn-primary"
                >
                    <Save size={16} />
                    {isNew ? 'Create' : 'Save'} Section
                </button>
            </div>
        </div>
    );
}

function LandingContentPreview({ section }: { section: LandingSection }) {
    return (
        <div className="landing-content-preview">
            {section.kicker && (
                <div className="preview-row">
                    <div className="preview-label">Kicker</div>
                    <div className="preview-value">{section.kicker}</div>
                </div>
            )}

            {section.title && (
                <div className="preview-row">
                    <div className="preview-label">Title</div>
                    <div className="preview-value">{section.title}</div>
                </div>
            )}

            {section.subtitle && (
                <div className="preview-row">
                    <div className="preview-label">Subtitle</div>
                    <div className="preview-value">{section.subtitle}</div>
                </div>
            )}

            {section.description && (
                <div className="preview-row">
                    <div className="preview-label">Description</div>
                    <div className="preview-value">{section.description}</div>
                </div>
            )}

            {Object.keys(section.data).length > 0 && (
                <div className="preview-row">
                    <div className="preview-label">Data</div>
                    <div className="preview-value">
                        {JSON.stringify(section.data, null, 2)}
                    </div>
                </div>
            )}

            {!section.title && !section.description && Object.keys(section.data).length === 0 && (
                <div className="preview-row">
                    <div className="preview-value empty">No content yet</div>
                </div>
            )}
        </div>
    );
}

// ---------------------------------------------------------------------------
// Footer & Social settings card
// ---------------------------------------------------------------------------

const SOCIAL_PLATFORMS = [
    'Twitter / X', 'Facebook', 'Instagram', 'LinkedIn', 'YouTube',
    'GitHub', 'TikTok', 'Discord', 'Pinterest', 'Mastodon', 'Other',
];

function FooterSettingsCard({
    landingSettings,
}: {
    landingSettings: { copyrightText: string; socialLinks: { platform: string; url: string }[] };
}) {
    const form = useForm({
        copyright_text: landingSettings.copyrightText,
        social_links: landingSettings.socialLinks.length > 0
            ? landingSettings.socialLinks
            : ([] as { platform: string; url: string }[]),
    });

    const addLink = () => {
        form.setData('social_links', [
            ...form.data.social_links,
            { platform: 'Twitter / X', url: '' },
        ]);
    };

    const removeLink = (index: number) => {
        form.setData(
            'social_links',
            form.data.social_links.filter((_, i) => i !== index),
        );
    };

    const updateLink = (index: number, field: 'platform' | 'url', value: string) => {
        const updated = form.data.social_links.map((link, i) =>
            i === index ? { ...link, [field]: value } : link,
        );
        form.setData('social_links', updated);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        form.patch('/admin/landing-settings', { preserveScroll: true });
    };

    return (
        <div className="admin-container" style={{ marginBottom: 0 }}>
            <section className="admin-surface" style={{ marginBottom: '16px' }}>
                <AdminCardHeader
                    label="Footer"
                    title="Social media &amp; copyright"
                />
                <p className="settings-admin-copy">
                    Set the copyright line and social media links shown in the landing page footer.
                </p>

                <form className="admin-form-grid" onSubmit={handleSubmit}>
                    {/* Copyright */}
                    <label className="admin-field admin-field-full" htmlFor="copyright_text">
                        <span>Copyright text</span>
                        <input
                            id="copyright_text"
                            type="text"
                            className="admin-text-input"
                            value={form.data.copyright_text}
                            onChange={(e) => form.setData('copyright_text', e.target.value)}
                            placeholder={`© ${new Date().getFullYear()} Your Company, Inc. All rights reserved.`}
                            maxLength={255}
                        />
                    </label>

                    {/* Social Links */}
                    <div className="admin-field admin-field-full">
                        <span>Social media links</span>

                        {form.data.social_links.length > 0 && (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '8px' }}>
                                {form.data.social_links.map((link, i) => (
                                    <div
                                        key={i}
                                        style={{ display: 'grid', gridTemplateColumns: '180px 1fr auto', gap: '8px', alignItems: 'center' }}
                                    >
                                        <select
                                            className="admin-select-input"
                                            value={link.platform}
                                            onChange={(e) => updateLink(i, 'platform', e.target.value)}
                                        >
                                            {SOCIAL_PLATFORMS.map((p) => (
                                                <option key={p} value={p}>{p}</option>
                                            ))}
                                        </select>
                                        <input
                                            type="url"
                                            className="admin-text-input"
                                            value={link.url}
                                            onChange={(e) => updateLink(i, 'url', e.target.value)}
                                            placeholder="https://..."
                                        />
                                        <button
                                            type="button"
                                            className="admin-icon-btn admin-icon-btn-danger"
                                            onClick={() => removeLink(i)}
                                            title="Remove"
                                        >
                                            <X size={16} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}

                        <button
                            type="button"
                            className="admin-btn admin-btn-secondary"
                            onClick={addLink}
                            style={{ marginTop: '10px', alignSelf: 'flex-start' }}
                        >
                            <Link2 size={14} />
                            Add social link
                        </button>
                    </div>

                    {/* Save */}
                    <div className="admin-field admin-field-full">
                        <button
                            type="submit"
                            className="admin-btn admin-btn-primary"
                            disabled={form.processing}
                        >
                            {form.processing ? 'Saving…' : 'Save footer settings'}
                        </button>
                    </div>
                </form>
            </section>
        </div>
    );
}

AdminLandingContent.layout = {
    breadcrumbs: [
        {
            title: 'Landing content',
            href: '/admin/landing-content',
        },
    ],
};
