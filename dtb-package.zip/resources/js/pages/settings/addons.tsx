import { Head, useForm } from '@inertiajs/react';
import { PackageCheck, PackageX, Upload } from 'lucide-react';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type AddonRecord = {
    id: number;
    slug: string;
    name: string;
    enabled: boolean;
    installedAt: string | null;
    requiredFiles: string[];
};

type Props = {
    addons: AddonRecord[];
};

function InstallForm({ addon }: { addon: AddonRecord }) {
    const form = useForm<{ zip_file: File | null }>({ zip_file: null });

    function submit(e: React.FormEvent) {
        e.preventDefault();
        form.post(`/admin/addons/${addon.id}/install`, {
            forceFormData: true,
            onSuccess: () => form.reset(),
        });
    }

    return (
        <form onSubmit={submit} className="flex items-center gap-3">
            <input
                type="file"
                accept=".zip"
                className="text-sm text-gray-600"
                onChange={(e) => form.setData('zip_file', e.target.files?.[0] ?? null)}
            />
            <button
                type="submit"
                disabled={form.processing || !form.data.zip_file}
                className="inline-flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
            >
                <Upload className="size-3" />
                {addon.enabled ? 'Re-install' : 'Install'}
            </button>
            <InputError message={form.errors.zip_file} />
        </form>
    );
}

function DisableForm({ addon }: { addon: AddonRecord }) {
    const form = useForm({});

    function submit(e: React.FormEvent) {
        e.preventDefault();
        form.post(`/admin/addons/${addon.id}/uninstall`);
    }

    return (
        <form onSubmit={submit}>
            <button
                type="submit"
                disabled={form.processing}
                className="inline-flex items-center gap-1.5 rounded bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700 disabled:opacity-50"
            >
                <PackageX className="size-3" />
                Disable
            </button>
        </form>
    );
}

export default function Addons({ addons }: Props) {
    return (
        <>
            <Head title="Addons" />

            <h1 className="sr-only">Addons</h1>

            <section className="admin-surface">
                <AdminCardHeader
                    label="Feature addons"
                    title="Installed addons"
                    action={<span className="admin-pill">platform admin</span>}
                />
                <p className="settings-admin-copy">
                    Upload a signed addon ZIP to activate a feature. The system verifies the file contents and HMAC signature before enabling.
                </p>

                <div className="mt-6 space-y-3">
                    {addons.length === 0 && (
                        <p className="text-sm text-gray-500">No addons registered.</p>
                    )}

                    {addons.map((addon) => (
                        <div key={addon.id} className="rounded-lg border bg-white shadow-sm">
                            {/* ── Identity + upload row (always visible) ── */}
                            <div className="flex items-center gap-4 p-4">
                                <PackageCheck className={`size-5 shrink-0 ${addon.enabled ? 'text-green-500' : 'text-gray-400'}`} />
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-2">
                                        <p className="font-medium text-gray-900">{addon.name}</p>
                                        {addon.enabled && (
                                            <span className="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-green-700">
                                                Active
                                            </span>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-400">{addon.slug}</p>
                                </div>
                                <InstallForm addon={addon} />
                            </div>

                            {/* ── Active status row (only when enabled) ── */}
                            {addon.enabled && (
                                <div className="flex items-center justify-between gap-4 border-t border-green-100 bg-green-50/60 px-4 py-2.5">
                                    <div className="flex items-center gap-2 text-xs text-green-700">
                                        <PackageCheck className="size-3.5 shrink-0" />
                                        <span>
                                            Active
                                            {addon.installedAt && (
                                                <> &mdash; installed {new Date(addon.installedAt).toLocaleDateString()}</>
                                            )}
                                        </span>
                                    </div>
                                    <DisableForm addon={addon} />
                                </div>
                            )}

                            {/* ── Required files hint ── */}
                            {addon.requiredFiles.length > 0 && (
                                <p className="border-t px-4 py-2 text-xs text-gray-400">
                                    Required: {addon.requiredFiles.join(', ')}
                                </p>
                            )}
                        </div>
                    ))}
                </div>
            </section>
        </>
    );
}

Addons.layout = {
    breadcrumbs: [
        { title: 'Settings', href: '/settings' },
        { title: 'Addons', href: '/admin/addons' },
    ],
};
