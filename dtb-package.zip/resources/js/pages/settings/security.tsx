import { Form, Head } from '@inertiajs/react';
import { ShieldCheck } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import SecurityController from '@/actions/App/Http/Controllers/Settings/SecurityController';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import PasswordInput from '@/components/password-input';
import TwoFactorRecoveryCodes from '@/components/two-factor-recovery-codes';
import TwoFactorSetupModal from '@/components/two-factor-setup-modal';
import { useTwoFactorAuth } from '@/hooks/use-two-factor-auth';
import { edit } from '@/routes/security';
import { disable, enable } from '@/routes/two-factor';

type Props = {
    canManageTwoFactor?: boolean;
    requiresConfirmation?: boolean;
    twoFactorEnabled?: boolean;
};

export default function Security({
    canManageTwoFactor = false,
    requiresConfirmation = false,
    twoFactorEnabled = false,
}: Props) {
    const passwordInput = useRef<HTMLInputElement>(null);
    const currentPasswordInput = useRef<HTMLInputElement>(null);

    const {
        qrCodeSvg,
        hasSetupData,
        manualSetupKey,
        clearSetupData,
        clearTwoFactorAuthData,
        fetchSetupData,
        recoveryCodesList,
        fetchRecoveryCodes,
        errors,
    } = useTwoFactorAuth();
    const [showSetupModal, setShowSetupModal] = useState<boolean>(false);
    const prevTwoFactorEnabled = useRef(twoFactorEnabled);

    useEffect(() => {
        if (prevTwoFactorEnabled.current && !twoFactorEnabled) {
            clearTwoFactorAuthData();
        }

        prevTwoFactorEnabled.current = twoFactorEnabled;
    }, [twoFactorEnabled, clearTwoFactorAuthData]);

    return (
        <>
            <Head title="Security settings" />

            <h1 className="sr-only">Security settings</h1>

            <section className="admin-surface">
                <AdminCardHeader label="Password" title="Update password" action={<span className="admin-pill">required</span>} />
                <p className="settings-admin-copy">Keep this account protected with a long, random password.</p>

                <Form
                    {...SecurityController.update.form()}
                    options={{
                        preserveScroll: true,
                    }}
                    resetOnError={[
                        'password',
                        'password_confirmation',
                        'current_password',
                    ]}
                    resetOnSuccess
                    onError={(errors) => {
                        if (errors.password) {
                            passwordInput.current?.focus();
                        }

                        if (errors.current_password) {
                            currentPasswordInput.current?.focus();
                        }
                    }}
                    className="admin-form-grid"
                >
                    {({ errors, processing }) => (
                        <>
                            <label className="admin-field admin-field-full" htmlFor="current_password">
                                <span>Current password</span>

                                <PasswordInput
                                    id="current_password"
                                    ref={currentPasswordInput}
                                    name="current_password"
                                    className="admin-text-input"
                                    autoComplete="current-password"
                                    placeholder="Current password"
                                />

                                <InputError message={errors.current_password} />
                            </label>

                            <label className="admin-field" htmlFor="password">
                                <span>New password</span>

                                <PasswordInput
                                    id="password"
                                    ref={passwordInput}
                                    name="password"
                                    className="admin-text-input"
                                    autoComplete="new-password"
                                    placeholder="New password"
                                />

                                <InputError message={errors.password} />
                            </label>

                            <label className="admin-field" htmlFor="password_confirmation">
                                <span>Confirm password</span>

                                <PasswordInput
                                    id="password_confirmation"
                                    name="password_confirmation"
                                    className="admin-text-input"
                                    autoComplete="new-password"
                                    placeholder="Confirm password"
                                />

                                <InputError
                                    message={errors.password_confirmation}
                                />
                            </label>

                            <div className="admin-form-actions admin-field-full">
                                <button
                                    type="submit"
                                    className="admin-button admin-button-primary"
                                    disabled={processing}
                                    data-test="update-password-button"
                                >
                                    Save password
                                </button>
                            </div>
                        </>
                    )}
                </Form>
            </section>

            {canManageTwoFactor && (
                <section className="admin-surface">
                    <AdminCardHeader label="Two-factor" title="Two-factor authentication" action={<span className="admin-pill">optional</span>} />
                    {twoFactorEnabled ? (
                        <div className="settings-admin-stack">
                            <p className="settings-admin-copy">
                                You will be prompted for a secure, random pin
                                during login, which you can retrieve from the
                                TOTP-supported application on your phone.
                            </p>

                            <div>
                                <Form {...disable.form()}>
                                    {({ processing }) => (
                                        <button
                                            className="admin-button settings-danger-button"
                                            type="submit"
                                            disabled={processing}
                                        >
                                            Disable 2FA
                                        </button>
                                    )}
                                </Form>
                            </div>

                            <TwoFactorRecoveryCodes
                                recoveryCodesList={recoveryCodesList}
                                fetchRecoveryCodes={fetchRecoveryCodes}
                                errors={errors}
                            />
                        </div>
                    ) : (
                        <div className="settings-admin-stack">
                            <p className="settings-admin-copy">
                                When you enable two-factor authentication, you
                                will be prompted for a secure pin during login.
                                This pin can be retrieved from a TOTP-supported
                                application on your phone.
                            </p>

                            <div>
                                {hasSetupData ? (
                                    <button
                                        type="button"
                                        className="admin-button admin-button-primary"
                                        onClick={() => setShowSetupModal(true)}
                                    >
                                        <ShieldCheck size={14} />
                                        Continue setup
                                    </button>
                                ) : (
                                    <Form
                                        {...enable.form()}
                                        onSuccess={() =>
                                            setShowSetupModal(true)
                                        }
                                    >
                                        {({ processing }) => (
                                            <button
                                                className="admin-button admin-button-primary"
                                                type="submit"
                                                disabled={processing}
                                            >
                                                Enable 2FA
                                            </button>
                                        )}
                                    </Form>
                                )}
                            </div>
                        </div>
                    )}

                    <TwoFactorSetupModal
                        isOpen={showSetupModal}
                        onClose={() => setShowSetupModal(false)}
                        requiresConfirmation={requiresConfirmation}
                        twoFactorEnabled={twoFactorEnabled}
                        qrCodeSvg={qrCodeSvg}
                        manualSetupKey={manualSetupKey}
                        clearSetupData={clearSetupData}
                        fetchSetupData={fetchSetupData}
                        errors={errors}
                    />
                </section>
            )}
        </>
    );
}

Security.layout = {
    breadcrumbs: [
        {
            title: 'Security settings',
            href: edit(),
        },
    ],
};
