import { Form, Head, Link, usePage } from '@inertiajs/react';
import ProfileController from '@/actions/App/Http/Controllers/Settings/ProfileController';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import DeleteUser from '@/components/delete-user';
import InputError from '@/components/input-error';
import { edit } from '@/routes/profile';
import { send } from '@/routes/verification';

export default function Profile({
    mustVerifyEmail,
    status,
}: {
    mustVerifyEmail: boolean;
    status?: string;
}) {
    const { auth } = usePage().props;

    return (
        <>
            <Head title="Profile settings" />

            <h1 className="sr-only">Profile settings</h1>

            <section className="admin-surface">
                <AdminCardHeader label="Profile" title="Profile information" action={<span className="admin-pill">identity</span>} />
                <p className="settings-admin-copy">Update the name and email address used across this account.</p>

                <Form
                    {...ProfileController.update.form()}
                    options={{
                        preserveScroll: true,
                    }}
                    className="admin-form-grid"
                >
                    {({ processing, errors }) => (
                        <>
                            <label className="admin-field admin-field-full" htmlFor="name">
                                <span>Name</span>

                                <input
                                    id="name"
                                    className="admin-text-input"
                                    defaultValue={auth.user.name}
                                    name="name"
                                    required
                                    autoComplete="name"
                                    placeholder="Full name"
                                />

                                <InputError
                                    message={errors.name}
                                />
                            </label>

                            <label className="admin-field admin-field-full" htmlFor="email">
                                <span>Email address</span>

                                <input
                                    id="email"
                                    type="email"
                                    className="admin-text-input"
                                    defaultValue={auth.user.email}
                                    name="email"
                                    required
                                    autoComplete="username"
                                    placeholder="Email address"
                                />

                                <InputError
                                    message={errors.email}
                                />
                            </label>

                            {mustVerifyEmail &&
                                auth.user.email_verified_at === null && (
                                    <div className="settings-verification-note admin-field-full">
                                        <p>
                                            Your email address is unverified.{' '}
                                            <Link
                                                href={send()}
                                                as="button"
                                                className="settings-inline-button"
                                            >
                                                Click here to resend the
                                                verification email.
                                            </Link>
                                        </p>

                                        {status ===
                                            'verification-link-sent' && (
                                            <div className="settings-success-note">
                                                A new verification link has been
                                                sent to your email address.
                                            </div>
                                        )}
                                    </div>
                                )}

                            <div className="admin-form-actions admin-field-full">
                                <button
                                    type="submit"
                                    className="admin-button admin-button-primary"
                                    disabled={processing}
                                    data-test="update-profile-button"
                                >
                                    Save
                                </button>
                            </div>
                        </>
                    )}
                </Form>
            </section>

            <DeleteUser />
        </>
    );
}

Profile.layout = {
    breadcrumbs: [
        {
            title: 'Profile settings',
            href: edit(),
        },
    ],
};
