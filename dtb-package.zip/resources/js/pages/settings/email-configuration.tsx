import { Head, useForm } from '@inertiajs/react';
import { Mail, PlugZap } from 'lucide-react';
import { AdminCardHeader } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type Props = {
    emailConfiguration: {
        provider: 'smtp';
        host: string;
        port: number;
        encryption: 'tls' | 'ssl' | 'none';
        username: string;
        passwordConfigured: boolean;
        fromAddress: string;
        fromName: string;
        timeout: number;
    };
};

export default function EmailConfiguration({ emailConfiguration }: Props) {
    const form = useForm({
        host: emailConfiguration.host,
        port: emailConfiguration.port,
        encryption: emailConfiguration.encryption,
        username: emailConfiguration.username,
        password: '',
        fromAddress: emailConfiguration.fromAddress,
        fromName: emailConfiguration.fromName,
        timeout: emailConfiguration.timeout,
    });

    const saveSettings = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        form.patch('/settings/email-configuration', {
            preserveScroll: true,
        });
    };

    const testConnection = () => {
        form.post('/settings/email-configuration/test', {
            preserveScroll: true,
        });
    };

    return (
        <>
            <Head title="Email configuration" />

            <h1 className="sr-only">Email configuration</h1>

            <section className="admin-surface">
                <AdminCardHeader
                    label="Email"
                    title="SMTP configuration"
                    action={<span className="admin-pill">platform admin</span>}
                />
                <p className="settings-admin-copy">
                    Configure SMTP credentials used for transactional email and test connection before using it in production.
                </p>

                <form className="admin-form-grid" onSubmit={saveSettings}>
                    <label className="admin-field admin-field-full" htmlFor="host">
                        <span>SMTP host</span>
                        <input
                            id="host"
                            type="text"
                            className="admin-text-input"
                            value={form.data.host}
                            onChange={(event) => form.setData('host', event.target.value)}
                            placeholder="smtp.example.com"
                        />
                        <InputError message={form.errors.host} />
                    </label>

                    <label className="admin-field" htmlFor="port">
                        <span>Port</span>
                        <input
                            id="port"
                            type="number"
                            className="admin-text-input"
                            value={form.data.port}
                            onChange={(event) => form.setData('port', Number(event.target.value))}
                            min={1}
                            max={65535}
                        />
                        <InputError message={form.errors.port} />
                    </label>

                    <label className="admin-field" htmlFor="encryption">
                        <span>Encryption</span>
                        <select
                            id="encryption"
                            className="admin-select-input"
                            value={form.data.encryption}
                            onChange={(event) => form.setData('encryption', event.target.value as 'tls' | 'ssl' | 'none')}
                        >
                            <option value="tls">TLS</option>
                            <option value="ssl">SSL</option>
                            <option value="none">None</option>
                        </select>
                        <InputError message={form.errors.encryption} />
                    </label>

                    <label className="admin-field" htmlFor="username">
                        <span>Username</span>
                        <input
                            id="username"
                            type="text"
                            className="admin-text-input"
                            value={form.data.username}
                            onChange={(event) => form.setData('username', event.target.value)}
                            placeholder="SMTP username"
                        />
                        <InputError message={form.errors.username} />
                    </label>

                    <label className="admin-field" htmlFor="password">
                        <span>Password</span>
                        <input
                            id="password"
                            type="password"
                            className="admin-text-input"
                            value={form.data.password}
                            onChange={(event) => form.setData('password', event.target.value)}
                            placeholder={emailConfiguration.passwordConfigured ? 'Stored password will be kept if empty' : 'SMTP password'}
                        />
                        <InputError message={form.errors.password} />
                    </label>

                    <label className="admin-field" htmlFor="fromAddress">
                        <span>From address</span>
                        <input
                            id="fromAddress"
                            type="email"
                            className="admin-text-input"
                            value={form.data.fromAddress}
                            onChange={(event) => form.setData('fromAddress', event.target.value)}
                            placeholder="no-reply@example.com"
                        />
                        <InputError message={form.errors.fromAddress} />
                    </label>

                    <label className="admin-field" htmlFor="fromName">
                        <span>From name</span>
                        <input
                            id="fromName"
                            type="text"
                            className="admin-text-input"
                            value={form.data.fromName}
                            onChange={(event) => form.setData('fromName', event.target.value)}
                            placeholder="Support"
                        />
                        <InputError message={form.errors.fromName} />
                    </label>

                    <label className="admin-field" htmlFor="timeout">
                        <span>Timeout (seconds)</span>
                        <input
                            id="timeout"
                            type="number"
                            className="admin-text-input"
                            value={form.data.timeout}
                            onChange={(event) => form.setData('timeout', Number(event.target.value))}
                            min={1}
                            max={120}
                        />
                        <InputError message={form.errors.timeout} />
                    </label>

                    <div className="admin-form-actions settings-admin-actions admin-field-full">
                        <button
                            type="submit"
                            className="admin-button admin-button-primary"
                            disabled={form.processing}
                        >
                            <Mail size={14} />
                            Save SMTP settings
                        </button>

                        <button
                            type="button"
                            className="admin-button admin-button-secondary"
                            disabled={form.processing}
                            onClick={testConnection}
                        >
                            <PlugZap size={14} />
                            Test connection
                        </button>
                    </div>
                </form>
            </section>
        </>
    );
}

EmailConfiguration.layout = {
    breadcrumbs: [
        {
            title: 'Email configuration',
            href: '/settings/email-configuration',
        },
    ],
};
