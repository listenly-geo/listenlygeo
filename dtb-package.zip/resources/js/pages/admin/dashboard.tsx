import { Head, Link } from '@inertiajs/react';
import { ArrowUpRight, BarChart3, Building2, CreditCard, TrendingUp, WalletCards } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';

type AdminDashboardProps = {
    summary: {
        planCount: number;
        activePlanCount: number;
        customerCount: number;
        newCustomersLast30Days: number;
        userCount: number;
        platformAdminCount: number;
        activeSubscriptionCount: number;
        trialingSubscriptionCount: number;
        pastDueCount: number;
        monthlyRecurringRevenueCents: number;
        publishedPageCount: number;
        releasesLast30Days: number;
    };
    gateway: {
        provider: string;
        mode: string;
        status: string;
    };
    recentOrganizations: Array<{
        id: number;
        name: string;
        slug: string;
        ownerName: string | null;
        ownerEmail: string | null;
        billingEmail: string | null;
        planLabel: string;
        status: string;
        createdAt: string | null;
    }>;
    subscriptionStatusBreakdown: Array<{
        label: string;
        value: number;
    }>;
    planBreakdown: Array<{
        slug: string;
        label: string;
        status: string;
        subscribers: number;
        monthlyRecurringRevenueCents: number;
        monthlyPriceCents: number;
        annualPriceCents: number;
    }>;
    customerGrowth: Array<{
        label: string;
        value: number;
    }>;
    releaseTrend: Array<{
        label: string;
        value: number;
    }>;
    netRevenueTrend: Array<{
        label: string;
        newRevenueCents: number;
        churnedRevenueCents: number;
        netRevenueCents: number;
    }>;
    churnReportTrend: Array<{
        label: string;
        canceled: number;
        recovered: number;
    }>;
};

function formatMoney(amountCents: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0,
    }).format(amountCents / 100);
}

function humanStatus(value: string): string {
    return value.replaceAll('_', ' ');
}

function formatDate(value: string | null): string {
    if (!value) {
        return 'Unknown';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
    }).format(new Date(value));
}

function maxValue(items: Array<{ value: number }>): number {
    return Math.max(1, ...items.map((item) => item.value));
}

export default function AdminDashboard({ summary, gateway, recentOrganizations, subscriptionStatusBreakdown, planBreakdown, customerGrowth, releaseTrend, netRevenueTrend, churnReportTrend }: AdminDashboardProps) {
    const customerGrowthMax = maxValue(customerGrowth);
    const releaseTrendMax = maxValue(releaseTrend);
    const planRevenueMax = Math.max(1, ...planBreakdown.map((plan) => plan.monthlyRecurringRevenueCents));
    const totalPlanRevenue = Math.max(1, planBreakdown.reduce((sum, plan) => sum + plan.monthlyRecurringRevenueCents, 0));
    const totalStatusCount = Math.max(1, subscriptionStatusBreakdown.reduce((sum, item) => sum + item.value, 0));
    const activeCount = subscriptionStatusBreakdown.find((item) => item.label.toLowerCase() === 'active')?.value ?? 0;
    const healthScore = Math.round((activeCount / totalStatusCount) * 100);
    const statusChartStops = subscriptionStatusBreakdown
        .reduce<Array<{ color: string; from: number; to: number }>>((acc, item, index) => {
            const previousStop = index === 0 ? 0 : acc[index - 1]?.to ?? 0;
            const nextStop = previousStop + ((item.value / totalStatusCount) * 100);
            const palette = [
                'oklch(62% 0.19 258)',
                'oklch(66% 0.16 170)',
                'oklch(74% 0.15 80)',
                'oklch(71% 0.17 30)',
                'oklch(58% 0.06 260)',
                'oklch(65% 0.08 330)',
            ];

            acc.push({
                color: palette[index % palette.length],
                from: Number(previousStop.toFixed(2)),
                to: Number(nextStop.toFixed(2)),
            });

            return acc;
        }, []);
    const statusDonutBackground = statusChartStops.length > 0
        ? `conic-gradient(${statusChartStops.map((stop) => `${stop.color} ${stop.from}% ${stop.to}%`).join(', ')})`
        : 'conic-gradient(oklch(85% 0.02 250) 0% 100%)';
    const netRevenueMax = Math.max(1, ...netRevenueTrend.map((point) => Math.max(point.newRevenueCents, point.churnedRevenueCents, Math.abs(point.netRevenueCents))));
    const churnMax = Math.max(1, ...churnReportTrend.map((point) => Math.max(point.canceled, point.recovered)));

    return (
        <>
            <Head title="Platform Admin" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Platform Admin"
                    title="Run plans, customers, and platform operations."
                    description="This separates platform administration from customer workspaces while keeping the same product language."
                    actions={(
                        <>
                            <Link href="/admin/plans" className="admin-secondary-link">
                                Manage plans
                            </Link>

                            <Link href="/admin/commerce" className="admin-primary-link">
                                Open commerce <ArrowUpRight size={14} />
                            </Link>
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Platform admin summary">
                    <AdminStatCard label="Customers" value={summary.customerCount.toLocaleString()} meta={`${summary.newCustomersLast30Days} new in 30 days`} />
                    <AdminStatCard label="Subscriptions" value={summary.activeSubscriptionCount.toLocaleString()} meta={`${summary.trialingSubscriptionCount} trialing / ${summary.pastDueCount} past due`} />
                    <AdminStatCard label="MRR" value={formatMoney(summary.monthlyRecurringRevenueCents)} meta={`${summary.activePlanCount} active plans`} />
                    <AdminStatCard label="Published docs" value={summary.publishedPageCount.toLocaleString()} meta={`${summary.releasesLast30Days} releases in 30 days`} />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface admin-dashboard-chart-surface">
                            <AdminCardHeader label="Growth" title="Customer and release cadence" action={<TrendingUp size={16} />} />

                            <div className="admin-dashboard-chart-grid">
                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>New customers</strong>
                                        <small>Last 6 months</small>
                                    </div>
                                    <div className="admin-dashboard-bars" aria-label="Customer growth chart">
                                        {customerGrowth.map((point) => (
                                            <div key={point.label} className="admin-dashboard-bar-group">
                                                <div className="admin-dashboard-bar-track">
                                                    <div className="admin-dashboard-bar-fill" style={{ height: `${(point.value / customerGrowthMax) * 100}%` }} />
                                                </div>
                                                <strong>{point.value}</strong>
                                                <span>{point.label}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>Publish cadence</strong>
                                        <small>Releases last 6 months</small>
                                    </div>
                                    <div className="admin-dashboard-bars" aria-label="Release trend chart">
                                        {releaseTrend.map((point) => (
                                            <div key={point.label} className="admin-dashboard-bar-group">
                                                <div className="admin-dashboard-bar-track">
                                                    <div className="admin-dashboard-bar-fill admin-dashboard-bar-fill-secondary" style={{ height: `${(point.value / releaseTrendMax) * 100}%` }} />
                                                </div>
                                                <strong>{point.value}</strong>
                                                <span>{point.label}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Recent customers" title="Newest billing accounts" action={<Building2 size={16} />} />

                            {recentOrganizations.length > 0 ? (
                                <div className="admin-billing-account-list">
                                    {recentOrganizations.map((organization) => (
                                        <div key={organization.id} className="admin-billing-account-row">
                                            <div className="admin-list-leading">
                                                <Building2 size={14} />
                                                <div>
                                                    <strong>{organization.name}</strong>
                                                    <small>
                                                        {organization.ownerEmail ?? organization.billingEmail ?? 'No contact'} / {organization.planLabel} / {humanStatus(organization.status)}
                                                    </small>
                                                </div>
                                            </div>
                                            <div className="admin-billing-account-meta">
                                                <span>{organization.slug}</span>
                                                <small>{formatDate(organization.createdAt)}</small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Building2 size={16} />}>No customer workspaces exist yet.</AdminEmptyState>
                            )}
                        </section>

                        <section className="admin-surface admin-dashboard-chart-surface">
                            <AdminCardHeader label="Insights" title="Earnings and advanced reports" action={<BarChart3 size={16} />} />

                            <div className="admin-dashboard-chart-grid">
                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>Earnings chart</strong>
                                        <small>Monthly recurring revenue by plan</small>
                                    </div>

                                    <div className="admin-dashboard-earnings-list" aria-label="Earnings by plan">
                                        {planBreakdown.length > 0 ? (
                                            [...planBreakdown]
                                                .sort((a, b) => b.monthlyRecurringRevenueCents - a.monthlyRecurringRevenueCents)
                                                .map((plan) => (
                                                    <div key={plan.slug} className="admin-dashboard-earnings-row">
                                                        <div className="admin-dashboard-earnings-copy">
                                                            <strong>{plan.label}</strong>
                                                            <small>{plan.subscribers.toLocaleString()} subscribers</small>
                                                        </div>
                                                        <div className="admin-dashboard-earnings-track">
                                                            <div
                                                                className="admin-dashboard-earnings-fill"
                                                                style={{ width: `${(plan.monthlyRecurringRevenueCents / totalPlanRevenue) * 100}%` }}
                                                            />
                                                        </div>
                                                        <strong className="admin-dashboard-earnings-value">{formatMoney(plan.monthlyRecurringRevenueCents)}</strong>
                                                    </div>
                                                ))
                                        ) : (
                                            <AdminEmptyState icon={<BarChart3 size={16} />}>No earnings data available yet.</AdminEmptyState>
                                        )}
                                    </div>
                                </div>

                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>Advanced report chart</strong>
                                        <small>Subscription health and status split</small>
                                    </div>

                                    <div className="admin-dashboard-advanced-wrap">
                                        <div className="admin-dashboard-status-donut" style={{ background: statusDonutBackground }} aria-label="Subscription status distribution">
                                            <div className="admin-dashboard-status-donut-center">
                                                <strong>{healthScore}%</strong>
                                                <small>Health score</small>
                                            </div>
                                        </div>

                                        <div className="admin-dashboard-status-legend">
                                            {subscriptionStatusBreakdown.map((item, index) => (
                                                <div key={item.label} className="admin-dashboard-status-legend-row">
                                                    <span
                                                        className="admin-dashboard-status-legend-dot"
                                                        style={{ background: statusChartStops[index]?.color ?? 'oklch(82% 0.02 250)' }}
                                                    />
                                                    <span>{item.label}</span>
                                                    <strong>{item.value.toLocaleString()}</strong>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section className="admin-surface admin-dashboard-chart-surface">
                            <AdminCardHeader label="Revenue intelligence" title="Net earnings and churn report" action={<TrendingUp size={16} />} />

                            <div className="admin-dashboard-chart-grid">
                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>Net revenue trend</strong>
                                        <small>New MRR vs churned MRR over last 6 months</small>
                                    </div>
                                    <div className="admin-dashboard-dual-bars" aria-label="Net revenue trend chart">
                                        {netRevenueTrend.map((point) => (
                                            <div key={point.label} className="admin-dashboard-dual-group">
                                                <div className="admin-dashboard-dual-track">
                                                    <div className="admin-dashboard-dual-fill" style={{ height: `${(point.newRevenueCents / netRevenueMax) * 100}%` }} title={`New ${formatMoney(point.newRevenueCents)}`} />
                                                    <div className="admin-dashboard-dual-fill admin-dashboard-dual-fill-secondary" style={{ height: `${(point.churnedRevenueCents / netRevenueMax) * 100}%` }} title={`Churned ${formatMoney(point.churnedRevenueCents)}`} />
                                                </div>
                                                <strong>{formatMoney(point.netRevenueCents)}</strong>
                                                <span>{point.label}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="admin-dashboard-chart-card">
                                    <div className="admin-dashboard-chart-header">
                                        <strong>Churn report chart</strong>
                                        <small>Canceled vs recovered subscriptions</small>
                                    </div>
                                    <div className="admin-dashboard-dual-bars" aria-label="Churn report chart">
                                        {churnReportTrend.map((point) => (
                                            <div key={point.label} className="admin-dashboard-dual-group">
                                                <div className="admin-dashboard-dual-track">
                                                    <div className="admin-dashboard-dual-fill admin-dashboard-dual-fill-danger" style={{ height: `${(point.canceled / churnMax) * 100}%` }} title={`Canceled ${point.canceled}`} />
                                                    <div className="admin-dashboard-dual-fill admin-dashboard-dual-fill-secondary" style={{ height: `${(point.recovered / churnMax) * 100}%` }} title={`Recovered ${point.recovered}`} />
                                                </div>
                                                <strong>{point.canceled}/{point.recovered}</strong>
                                                <span>{point.label}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface admin-dashboard-chart-surface">
                            <AdminCardHeader label="Revenue mix" title="Plan performance snapshot" action={<BarChart3 size={16} />} />

                            <div className="admin-dashboard-metric-stack">
                                {planBreakdown.map((plan) => (
                                    <div key={plan.slug} className="admin-dashboard-metric-row">
                                        <div className="admin-dashboard-metric-copy">
                                            <strong>{plan.label}</strong>
                                            <small>{plan.subscribers.toLocaleString()} subscribers / {formatMoney(plan.monthlyRecurringRevenueCents)} MRR</small>
                                        </div>
                                        <div className="admin-dashboard-meter">
                                            <div className="admin-dashboard-meter-fill" style={{ width: `${(plan.monthlyRecurringRevenueCents / planRevenueMax) * 100}%` }} />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Commerce status" title="Gateway posture" action={<WalletCards size={16} />} />

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">Provider</span>
                                    <strong>{gateway.provider}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Mode</span>
                                    <strong>{gateway.mode}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Status</span>
                                    <strong>{humanStatus(gateway.status)}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Plans</span>
                                    <strong>{summary.planCount.toLocaleString()}</strong>
                                </div>
                            </div>

                            <div className="admin-dashboard-status-list">
                                {subscriptionStatusBreakdown.map((item) => (
                                    <div key={item.label} className="admin-dashboard-status-row">
                                        <span>{item.label}</span>
                                        <strong>{item.value.toLocaleString()}</strong>
                                    </div>
                                ))}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Quick actions" title="Platform modules" action={<CreditCard size={16} />} />

                            <div className="admin-billing-account-list">
                                {[
                                    { href: '/admin/plans', title: 'Plan Management', meta: 'Create and edit live pricing tiers' },
                                    { href: '/admin/users', title: 'User Management', meta: 'Review platform admins and customers' },
                                    { href: '/admin/reports', title: 'Reports', meta: 'Inspect plan and customer billing posture' },
                                    { href: '/admin/analytics', title: 'Analytics', meta: 'Track platform growth and activity' },
                                    { href: '/admin/commerce', title: 'Commerce', meta: 'Handle subscriptions and payment gateway state' },
                                ].map((item) => (
                                    <Link key={item.href} href={item.href} className="admin-billing-account-row">
                                        <div className="admin-list-leading">
                                            <ArrowUpRight size={14} />
                                            <div>
                                                <strong>{item.title}</strong>
                                                <small>{item.meta}</small>
                                            </div>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}