import { Head } from '@inertiajs/react';
import { ShieldCheck, Users } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';

type UserRow = {
    id: number;
    name: string;
    email: string;
    membershipCount: number;
    createdAt: string | null;
    verifiedAt?: string | null;
};

type AdminUsersProps = {
    summary: {
        platformAdminCount: number;
        customerUserCount: number;
        verifiedUserCount: number;
    };
    platformAdmins: UserRow[];
    recentUsers: UserRow[];
};

function formatDate(value: string | null | undefined): string {
    if (!value) {
        return 'Not verified';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
    }).format(new Date(value));
}

export default function AdminUsers({ summary, platformAdmins, recentUsers }: AdminUsersProps) {
    return (
        <>
            <Head title="User Management" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="User Management"
                    title="Review platform admins and customer accounts."
                    description="This gives the platform team a separate place to inspect operator access and customer account creation without entering workspace routes."
                />

                <AdminStatGrid ariaLabel="User summary">
                    <AdminStatCard label="Platform admins" value={summary.platformAdminCount.toLocaleString()} meta="Full platform access" />
                    <AdminStatCard label="Customer users" value={summary.customerUserCount.toLocaleString()} meta="Non-platform accounts" />
                    <AdminStatCard label="Verified users" value={summary.verifiedUserCount.toLocaleString()} meta="Email verification complete" />
                    <AdminStatCard label="Recent users" value={recentUsers.length.toLocaleString()} meta="Loaded on this page" />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Platform admins" title="Operator access" action={<ShieldCheck size={16} />} />

                            {platformAdmins.length > 0 ? (
                                <div className="admin-billing-account-list">
                                    {platformAdmins.map((user) => (
                                        <div key={user.id} className="admin-billing-account-row">
                                            <div className="admin-list-leading">
                                                <ShieldCheck size={14} />
                                                <div>
                                                    <strong>{user.name}</strong>
                                                    <small>{user.email}</small>
                                                </div>
                                            </div>
                                            <div className="admin-billing-account-meta">
                                                <span>{user.membershipCount} org memberships</span>
                                                <small>{formatDate(user.createdAt)}</small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<ShieldCheck size={16} />}>No platform admins were found.</AdminEmptyState>
                            )}
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Customer users" title="Newest non-platform accounts" action={<Users size={16} />} />

                            {recentUsers.length > 0 ? (
                                <div className="admin-billing-account-list">
                                    {recentUsers.map((user) => (
                                        <div key={user.id} className="admin-billing-account-row">
                                            <div className="admin-list-leading">
                                                <Users size={14} />
                                                <div>
                                                    <strong>{user.name}</strong>
                                                    <small>{user.email}</small>
                                                </div>
                                            </div>
                                            <div className="admin-billing-account-meta">
                                                <span>{user.membershipCount} org memberships</span>
                                                <small>{formatDate(user.verifiedAt)}</small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Users size={16} />}>No customer users were found.</AdminEmptyState>
                            )}
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}