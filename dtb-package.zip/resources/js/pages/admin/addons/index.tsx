import { Head, useForm } from '@inertiajs/react';
import { PackageCheck, PackageX, Upload } from 'lucide-react';
import { AdminPageHero } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type AddonRecord = {
    id: number;
    slug: string;
    name: string;
    enabled: boolean;
    installedAt: string | null;
    requiredFiles: string[];
};

type AdminAddonsProps = {
    addons: AddonRecord[];
};

function InstallForm({ addon }: { addon: AddonRecord }) {
    const form = useForm<{ zip_file: File | null }>({ zip_file: null });

    function submit(e: React.FormEvent) {
        e.preventDefault();
        form.post(`/admin/addons/${addon.id}/install`, {
            forceFormData: true,
        });
    }

    return (
        <form onSubmit={submit} className="flex items-center gap-3">
            <input
                type="file"
                accept=".zip"
                className="text-sm text-gray-600"
                onChange={(e) => form.setData('zip_file', e.target.files?.[0] ?? null)}
            />
            <button
                type="submit"
                disabled={form.processing || !form.data.zip_file}
                className="inline-flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
            >
                <Upload className="size-3" />
                Install
            </button>
            <InputError message={form.errors.zip_file} />
        </form>
    );
}

function UninstallForm({ addon }: { addon: AddonRecord }) {
    const form = useForm({});

    function submit(e: React.FormEvent) {
        e.preventDefault();
        form.post(`/admin/addons/${addon.id}/uninstall`);
    }

    return (
        <form onSubmit={submit}>
            <button
                type="submit"
                disabled={form.processing}
                className="inline-flex items-center gap-1.5 rounded bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700 disabled:opacity-50"
            >
                <PackageX className="size-3" />
                Disable
            </button>
        </form>
    );
}

export default function AdminAddons({ addons }: AdminAddonsProps) {
    return (
        <>
            <Head title="Addons" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Addons"
                    title="Manage feature addons."
                    description="Upload a signed addon ZIP to activate a feature. The system verifies the file contents before enabling."
                />

                <div className="mt-8 space-y-4">
                    <h2 className="text-base font-semibold text-gray-900">Installed Addons</h2>

                    {addons.length === 0 && (
                        <p className="text-sm text-gray-500">No addons registered.</p>
                    )}

                    {addons.map((addon) => (
                        <div key={addon.id} className="rounded-lg border bg-white p-4 shadow-sm">
                            <div className="flex items-start justify-between gap-4">
                                <div className="flex items-center gap-3">
                                    {addon.enabled ? (
                                        <PackageCheck className="size-5 text-green-600" />
                                    ) : (
                                        <PackageX className="size-5 text-gray-400" />
                                    )}
                                    <div>
                                        <p className="font-medium text-gray-900">{addon.name}</p>
                                        <p className="text-xs text-gray-500">
                                            {addon.slug}
                                            {addon.installedAt && (
                                                <> &mdash; installed {new Date(addon.installedAt).toLocaleDateString()}</>
                                            )}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3">
                                    {addon.enabled ? (
                                        <UninstallForm addon={addon} />
                                    ) : (
                                        <InstallForm addon={addon} />
                                    )}
                                </div>
                            </div>
                            {addon.requiredFiles.length > 0 && (
                                <p className="mt-2 text-xs text-gray-400">
                                    Required: {addon.requiredFiles.join(', ')}
                                </p>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}
