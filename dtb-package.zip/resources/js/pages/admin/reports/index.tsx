import { Head } from '@inertiajs/react';
import { ReceiptText, ScrollText } from 'lucide-react';
import { AdminCardHeader, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';

type AdminReportsProps = {
    summary: {
        customerCount: number;
        subscriptionCount: number;
        planCount: number;
    };
    planBreakdown: Array<{
        plan: string;
        slug: string;
        customers: number;
        activeCustomers: number;
        pastDueCustomers: number;
    }>;
    customerRows: Array<{
        name: string;
        billingEmail: string | null;
        plan: string;
        status: string;
        createdAt: string | null;
    }>;
};

function formatDate(value: string | null): string {
    if (!value) {
        return 'Unknown';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
    }).format(new Date(value));
}

export default function AdminReports({ summary, planBreakdown, customerRows }: AdminReportsProps) {
    return (
        <>
            <Head title="Reports" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Reports"
                    title="Inspect platform-wide subscription posture and customer billing state."
                    description="These reports are separated from customer analytics so platform operators can monitor plans and accounts without crossing into workspace reporting."
                />

                <AdminStatGrid ariaLabel="Report summary">
                    <AdminStatCard label="Customers" value={summary.customerCount.toLocaleString()} meta="Organizations with docs workspaces" />
                    <AdminStatCard label="Subscriptions" value={summary.subscriptionCount.toLocaleString()} meta="Stored subscription records" />
                    <AdminStatCard label="Plans" value={summary.planCount.toLocaleString()} meta="Database-backed catalog entries" />
                    <AdminStatCard label="Rows loaded" value={customerRows.length.toLocaleString()} meta="Customer accounts on this page" />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Plan breakdown" title="Customers by plan" action={<ScrollText size={16} />} />

                            <div className="admin-billing-account-list">
                                {planBreakdown.map((row) => (
                                    <div key={row.slug} className="admin-billing-account-row">
                                        <div className="admin-list-leading">
                                            <ScrollText size={14} />
                                            <div>
                                                <strong>{row.plan}</strong>
                                                <small>{row.customers} customers / {row.activeCustomers} active</small>
                                            </div>
                                        </div>
                                        <div className="admin-billing-account-meta">
                                            <span>{row.pastDueCustomers} past due</span>
                                            <small>{row.slug}</small>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Customer accounts" title="Latest billing rows" action={<ReceiptText size={16} />} />

                            <div className="admin-billing-account-list">
                                {customerRows.map((row) => (
                                    <div key={`${row.name}-${row.billingEmail ?? 'none'}`} className="admin-billing-account-row">
                                        <div className="admin-list-leading">
                                            <ReceiptText size={14} />
                                            <div>
                                                <strong>{row.name}</strong>
                                                <small>{row.billingEmail ?? 'No billing email'} / {row.plan}</small>
                                            </div>
                                        </div>
                                        <div className="admin-billing-account-meta">
                                            <span>{row.status}</span>
                                            <small>{formatDate(row.createdAt)}</small>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}