import { Head } from '@inertiajs/react';
import { Activity, BarChart3 } from 'lucide-react';
import { AdminCardHeader, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';

type AnalyticsWindow = {
    label: string;
    organizations: number;
    users: number;
    releases: number;
    revisions: number;
};

type AdminAnalyticsProps = {
    summary: {
        newOrganizations7Days: number;
        newUsers7Days: number;
        releases30Days: number;
        revisions30Days: number;
    };
    windows: AnalyticsWindow[];
};

export default function AdminAnalytics({ summary, windows }: AdminAnalyticsProps) {
    return (
        <>
            <Head title="Analytics" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Analytics"
                    title="Watch platform growth and documentation activity separately from customer dashboards."
                    description="Platform analytics focus on global account creation, publishing velocity, and revision activity across the whole application."
                />

                <AdminStatGrid ariaLabel="Platform analytics summary">
                    <AdminStatCard label="New orgs" value={summary.newOrganizations7Days.toLocaleString()} meta="Last 7 days" />
                    <AdminStatCard label="New users" value={summary.newUsers7Days.toLocaleString()} meta="Last 7 days" />
                    <AdminStatCard label="Releases" value={summary.releases30Days.toLocaleString()} meta="Last 30 days" />
                    <AdminStatCard label="Revisions" value={summary.revisions30Days.toLocaleString()} meta="Last 30 days" />
                </AdminStatGrid>

                <section className="admin-surface">
                    <AdminCardHeader label="Trend windows" title="Platform activity snapshots" action={<BarChart3 size={16} />} />

                    <div className="admin-billing-account-list">
                        {windows.map((window) => (
                            <div key={window.label} className="admin-billing-account-row">
                                <div className="admin-list-leading">
                                    <Activity size={14} />
                                    <div>
                                        <strong>{window.label}</strong>
                                        <small>{window.organizations} organizations / {window.users} users</small>
                                    </div>
                                </div>
                                <div className="admin-billing-account-meta">
                                    <span>{window.releases} releases</span>
                                    <small>{window.revisions} revisions</small>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
        </>
    );
}