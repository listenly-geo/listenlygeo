import { Head, Link, useForm } from '@inertiajs/react';
import { ArrowUpRight, Building2, ReceiptText, WalletCards } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type BillingInterval = 'monthly' | 'annual';
type SubscriptionStatus = 'trialing' | 'active' | 'past_due' | 'canceled' | 'incomplete';

type PlanCatalogItem = {
    key: string;
    label: string;
    description: string;
    monthlyPriceCents: number;
    annualPriceCents: number;
    includedSites: number;
    includedMembers: number;
    includedPublishedPages: number;
    includedStorageBytes: number;
    isCurrent: boolean;
};

type PlatformAccount = {
    id: number;
    name: string;
    slug: string;
    billingEmail: string | null;
    plan: string;
    interval: BillingInterval;
    status: SubscriptionStatus;
    cancelAtPeriodEnd: boolean;
    currentPeriodEndsAt: string | null;
    amountCents: number;
    memberCount: number;
    siteCount: number;
};

type AdminCommerceProps = {
    plans: PlanCatalogItem[];
    platformBilling: {
        summary: {
            customerCount: number;
            activeSubscriptionCount: number;
            pastDueCount: number;
            monthlyRecurringRevenueCents: number;
        };
        accounts: PlatformAccount[];
    };
    paymentGateway: {
        provider: string;
        mode: 'test' | 'live';
        status: string;
        publicKey: string | null;
        secretKeyConfigured: boolean;
        webhookEndpoint: string | null;
        webhookSecretConfigured: boolean;
        stripeWebhookEndpointId: string | null;
        stripeWebhookSyncedAt: string | null;
        providers: Array<{ key: string; label: string }>;
        statuses: Array<{ key: string; label: string }>;
    };
};

function formatMoney(amountCents: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0,
    }).format(amountCents / 100);
}

function formatBytes(value: number): string {
    if (value <= 0) {
        return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const exponent = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
    const size = value / 1024 ** exponent;

    return `${size.toFixed(size >= 10 || exponent === 0 ? 0 : 1)} ${units[exponent]}`;
}

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not yet synced';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

function humanStatus(value: string): string {
    return value.replaceAll('_', ' ');
}

const fallbackPlan: PlanCatalogItem = {
    key: 'free',
    label: 'Free',
    description: 'Start publishing with a small workspace before upgrading.',
    monthlyPriceCents: 0,
    annualPriceCents: 0,
    includedSites: 1,
    includedMembers: 1,
    includedPublishedPages: 25,
    includedStorageBytes: 268_435_456,
    isCurrent: false,
};

export default function AdminCommerce({ plans, platformBilling, paymentGateway }: AdminCommerceProps) {
    const platformAccounts = platformBilling.accounts;
    const firstPlatformAccount = platformAccounts[0];

    const billingForm = useForm({
        organizationId: firstPlatformAccount?.id ?? null,
        billingEmail: firstPlatformAccount?.billingEmail ?? '',
        plan: firstPlatformAccount?.plan ?? plans[0]?.key ?? fallbackPlan.key,
        interval: firstPlatformAccount?.interval ?? 'monthly',
        status: firstPlatformAccount?.status ?? 'active',
        cancelAtPeriodEnd: firstPlatformAccount?.cancelAtPeriodEnd ?? false,
    });

    const gatewayForm = useForm({
        provider: paymentGateway.provider,
        mode: paymentGateway.mode,
        status: paymentGateway.status,
        publicKey: paymentGateway.publicKey ?? '',
        secretKey: '',
        webhookEndpoint: paymentGateway.webhookEndpoint ?? '',
    });

    const handleBillingSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        billingForm.patch('/admin/commerce', {
            preserveScroll: true,
        });
    };

    const handleGatewaySubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        gatewayForm.patch('/admin/commerce/gateway', {
            preserveScroll: true,
        });
    };

    const handlePlatformAccountChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const account = platformAccounts.find((item) => item.id === Number(event.target.value));

        if (!account) {
            return;
        }

        billingForm.setData('organizationId', account.id);
        billingForm.setData('billingEmail', account.billingEmail ?? '');
        billingForm.setData('plan', account.plan);
        billingForm.setData('interval', account.interval);
        billingForm.setData('status', account.status);
        billingForm.setData('cancelAtPeriodEnd', account.cancelAtPeriodEnd);
    };

    const currentPlan = plans.find((plan) => plan.key === billingForm.data.plan) ?? plans[0] ?? fallbackPlan;

    return (
        <>
            <Head title="Commerce" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Commerce"
                    title="Manage subscriptions, customer billing, and payment gateway state."
                    description="Commerce now lives in the platform admin namespace, separate from customer dashboard billing."
                    actions={(
                        <>
                            <Link href="/admin/plans" className="admin-secondary-link">
                                Manage plans
                            </Link>

                            <Link href="/admin/reports" className="admin-primary-link">
                                Open reports <ArrowUpRight size={14} />
                            </Link>
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Platform commerce summary">
                    <AdminStatCard label="Customers" value={platformBilling.summary.customerCount.toLocaleString()} meta="Organizations with billing accounts" />
                    <AdminStatCard label="Active subscriptions" value={platformBilling.summary.activeSubscriptionCount.toLocaleString()} meta={`${platformBilling.summary.pastDueCount} past due`} />
                    <AdminStatCard label="MRR" value={formatMoney(platformBilling.summary.monthlyRecurringRevenueCents)} meta="Normalized monthly revenue" />
                    <AdminStatCard label="Gateway" value={humanStatus(paymentGateway.status)} meta={paymentGateway.provider} />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Customer subscriptions" title="Plan and bill controls" action={<span className="admin-pill admin-pill-accent">platform admin</span>} />

                            {platformAccounts.length > 0 ? (
                                <form className="admin-form-grid" onSubmit={handleBillingSubmit}>
                                    <label className="admin-field admin-field-full">
                                        <span>Customer account</span>
                                        <select className="admin-select-input" value={billingForm.data.organizationId ?? ''} onChange={handlePlatformAccountChange}>
                                            {platformAccounts.map((account) => (
                                                <option key={account.id} value={account.id}>
                                                    {account.name} - {account.plan} / {account.status}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={billingForm.errors.organizationId} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Billing email</span>
                                        <input
                                            type="email"
                                            className="admin-text-input"
                                            value={billingForm.data.billingEmail}
                                            onChange={(event) => billingForm.setData('billingEmail', event.target.value)}
                                            placeholder="finance@example.com"
                                        />
                                        <InputError message={billingForm.errors.billingEmail} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Plan</span>
                                        <select className="admin-select-input" value={billingForm.data.plan} onChange={(event) => billingForm.setData('plan', event.target.value)}>
                                            {plans.map((plan) => (
                                                <option key={plan.key} value={plan.key}>
                                                    {plan.label}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={billingForm.errors.plan} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Interval</span>
                                        <select className="admin-select-input" value={billingForm.data.interval} onChange={(event) => billingForm.setData('interval', event.target.value as BillingInterval)}>
                                            <option value="monthly">Monthly</option>
                                            <option value="annual">Annual</option>
                                        </select>
                                        <InputError message={billingForm.errors.interval} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Status</span>
                                        <select className="admin-select-input" value={billingForm.data.status} onChange={(event) => billingForm.setData('status', event.target.value as SubscriptionStatus)}>
                                            <option value="trialing">Trialing</option>
                                            <option value="active">Active</option>
                                            <option value="past_due">Past due</option>
                                            <option value="canceled">Canceled</option>
                                            <option value="incomplete">Incomplete</option>
                                        </select>
                                        <InputError message={billingForm.errors.status} />
                                    </label>

                                    <label className="admin-checkbox-row admin-field-full">
                                        <input
                                            type="checkbox"
                                            checked={billingForm.data.cancelAtPeriodEnd}
                                            onChange={(event) => billingForm.setData('cancelAtPeriodEnd', event.target.checked)}
                                        />
                                        <div>
                                            <strong>Cancel at period end</strong>
                                            <small>Keep customer access through the current cycle and stop the next renewal.</small>
                                        </div>
                                    </label>

                                    <div className="admin-form-actions admin-field-full">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={billingForm.processing}>
                                            {billingForm.processing ? 'Saving...' : 'Update customer billing'}
                                        </button>
                                    </div>
                                </form>
                            ) : (
                                <AdminEmptyState icon={<Building2 size={16} />}>No customer accounts have been created yet.</AdminEmptyState>
                            )}
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Plan catalog"
                                title="Live subscription tiers"
                                action={<Link href="/admin/plans" className="admin-inline-link">Edit plans</Link>}
                            />

                            <div className="admin-plan-grid">
                                {plans.map((plan) => (
                                    <div key={plan.key} className={`admin-plan-card ${billingForm.data.plan === plan.key ? 'is-current' : ''}`}>
                                        <div className="admin-plan-copy">
                                            <div className="admin-plan-head">
                                                <strong>{plan.label}</strong>
                                                <span className="admin-pill">{formatMoney(plan.monthlyPriceCents)}/mo</span>
                                            </div>
                                            <p>{plan.description}</p>
                                        </div>
                                        <div className="admin-plan-meta">
                                            <span>{plan.includedSites} sites</span>
                                            <span>{plan.includedMembers} members</span>
                                            <span>{plan.includedPublishedPages} published pages</span>
                                            <span>{formatBytes(plan.includedStorageBytes)} storage</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Payment gateway" title="Checkout and invoice routing" action={<span className="admin-pill">{paymentGateway.mode}</span>} />

                            <form className="admin-form-grid" onSubmit={handleGatewaySubmit}>
                                <label className="admin-field">
                                    <span>Provider</span>
                                    <select className="admin-select-input" value={gatewayForm.data.provider} onChange={(event) => gatewayForm.setData('provider', event.target.value)}>
                                        {paymentGateway.providers.map((provider) => (
                                            <option key={provider.key} value={provider.key}>
                                                {provider.label}
                                            </option>
                                        ))}
                                    </select>
                                    <InputError message={gatewayForm.errors.provider} />
                                </label>

                                <label className="admin-field">
                                    <span>Mode</span>
                                    <select className="admin-select-input" value={gatewayForm.data.mode} onChange={(event) => gatewayForm.setData('mode', event.target.value as 'test' | 'live')}>
                                        <option value="test">Test</option>
                                        <option value="live">Live</option>
                                    </select>
                                    <InputError message={gatewayForm.errors.mode} />
                                </label>

                                <label className="admin-field admin-field-full">
                                    <span>Status</span>
                                    <select className="admin-select-input" value={gatewayForm.data.status} onChange={(event) => gatewayForm.setData('status', event.target.value)}>
                                        {paymentGateway.statuses.map((status) => (
                                            <option key={status.key} value={status.key}>
                                                {status.label}
                                            </option>
                                        ))}
                                    </select>
                                    <InputError message={gatewayForm.errors.status} />
                                </label>

                                <label className="admin-field admin-field-full">
                                    <span>Publishable key</span>
                                    <input
                                        type="text"
                                        className="admin-text-input"
                                        value={gatewayForm.data.publicKey}
                                        onChange={(event) => gatewayForm.setData('publicKey', event.target.value)}
                                        placeholder="pk_live_..."
                                    />
                                    <InputError message={gatewayForm.errors.publicKey} />
                                </label>

                                <label className="admin-field admin-field-full">
                                    <span>Secret key</span>
                                    <input
                                        type="password"
                                        className="admin-text-input"
                                        value={gatewayForm.data.secretKey}
                                        onChange={(event) => gatewayForm.setData('secretKey', event.target.value)}
                                        placeholder={paymentGateway.secretKeyConfigured ? 'Saved securely - enter a new key to replace' : 'sk_live_...'}
                                        autoComplete="off"
                                    />
                                    <InputError message={gatewayForm.errors.secretKey} />
                                </label>

                                <label className="admin-field admin-field-full">
                                    <span>Webhook endpoint</span>
                                    <input
                                        type="url"
                                        className="admin-text-input"
                                        value={gatewayForm.data.webhookEndpoint}
                                        onChange={(event) => gatewayForm.setData('webhookEndpoint', event.target.value)}
                                        placeholder="https://example.com/webhooks/stripe"
                                    />
                                    <InputError message={gatewayForm.errors.webhookEndpoint} />
                                </label>

                                <div className="admin-site-grid admin-field-full">
                                    <div>
                                        <span className="admin-site-key">Publishable key</span>
                                        <strong>{paymentGateway.publicKey ? 'Configured' : 'Missing'}</strong>
                                    </div>
                                    <div>
                                        <span className="admin-site-key">Secret key</span>
                                        <strong>{paymentGateway.secretKeyConfigured ? 'Stored securely' : 'Missing'}</strong>
                                    </div>
                                    <div>
                                        <span className="admin-site-key">Webhook secret</span>
                                        <strong>{paymentGateway.webhookSecretConfigured ? 'Generated' : 'Pending'}</strong>
                                    </div>
                                    <div>
                                        <span className="admin-site-key">Stripe endpoint ID</span>
                                        <strong>{paymentGateway.stripeWebhookEndpointId ?? 'Not created yet'}</strong>
                                    </div>
                                </div>

                                <div className="admin-site-grid admin-field-full">
                                    <div>
                                        <span className="admin-site-key">Webhook URL</span>
                                        <strong>{paymentGateway.webhookEndpoint ?? 'Not set yet'}</strong>
                                    </div>
                                    <div>
                                        <span className="admin-site-key">Last synced</span>
                                        <strong>{formatDate(paymentGateway.stripeWebhookSyncedAt)}</strong>
                                    </div>
                                </div>

                                <small>
                                    Saving a valid publishable key and secret key creates or refreshes the Stripe webhook automatically and stores the signing secret securely.
                                </small>

                                <div className="admin-form-actions admin-field-full">
                                    <button type="submit" className="admin-button admin-button-primary" disabled={gatewayForm.processing}>
                                        {gatewayForm.processing ? 'Connecting...' : 'Connect Stripe'}
                                    </button>
                                </div>
                            </form>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Bills" title="Customer billing accounts" action={<WalletCards size={16} />} />

                            <div className="admin-billing-account-list">
                                {platformAccounts.map((account) => (
                                    <div key={account.id} className="admin-billing-account-row">
                                        <div className="admin-list-leading">
                                            <ReceiptText size={14} />
                                            <div>
                                                <strong>{account.name}</strong>
                                                <small>{account.billingEmail ?? 'No billing email'} / {account.siteCount} sites / {account.memberCount} members</small>
                                            </div>
                                        </div>
                                        <div className="admin-billing-account-meta">
                                            <span>{formatMoney(account.amountCents)}</span>
                                            <small>{account.plan} / {account.status}</small>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">Selected plan</span>
                                    <strong>{currentPlan.label}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Included storage</span>
                                    <strong>{formatBytes(currentPlan.includedStorageBytes)}</strong>
                                </div>
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}