import { Head, Link, useForm } from '@inertiajs/react';
import { ArrowRight, ArrowUpRight, CreditCard, Layers3, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { AdminCardHeader, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';

type PlanStatus = 'draft' | 'active' | 'archived';

type PlanRecord = {
    id: number;
    slug: string;
    label: string;
    description: string;
    status: PlanStatus;
    monthlyPriceCents: number;
    annualPriceCents: number;
    includedSites: number;
    includedMembers: number;
    includedPublishedPages: number;
    includedStorageBytes: number;
    sortOrder: number;
    isFeatured: boolean;
    stripeProductId: string | null;
    stripeMonthlyPriceId: string | null;
    stripeAnnualPriceId: string | null;
    stripeSyncedAt: string | null;
    subscriberCount: number;
    updatedAt: string | null;
};

type StatusOption = {
    key: PlanStatus;
    label: string;
};

type PlanFormState = {
    slug: string;
    label: string;
    description: string;
    status: PlanStatus;
    monthly_price_cents: number;
    annual_price_cents: number;
    included_sites: number;
    included_members: number;
    included_published_pages: number;
    included_storage_bytes: number;
    sort_order: number;
    is_featured: boolean;
};

type AdminPlansProps = {
    plans: PlanRecord[];
    statuses: StatusOption[];
};

function formatMoney(amountCents: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0,
    }).format(amountCents / 100);
}

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not synced yet';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

function statusTone(status: PlanStatus): string {
    if (status === 'active') {
        return 'admin-pill-accent';
    }

    return '';
}

function PlanSection({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
    return (
        <section className="admin-plan-section">
            <div className="admin-plan-section-copy">
                <strong>{title}</strong>
                <small>{description}</small>
            </div>
            <div className="admin-plan-section-grid">{children}</div>
        </section>
    );
}

function PlanEditorCard({
    plan,
    statuses,
    expanded,
    onToggle,
}: {
    plan: PlanRecord;
    statuses: StatusOption[];
    expanded: boolean;
    onToggle: () => void;
}) {
    const form = useForm<PlanFormState>({
        slug: plan.slug,
        label: plan.label,
        description: plan.description,
        status: plan.status,
        monthly_price_cents: plan.monthlyPriceCents,
        annual_price_cents: plan.annualPriceCents,
        included_sites: plan.includedSites,
        included_members: plan.includedMembers,
        included_published_pages: plan.includedPublishedPages,
        included_storage_bytes: plan.includedStorageBytes,
        sort_order: plan.sortOrder,
        is_featured: plan.isFeatured,
    });
    const syncForm = useForm({});
    const isFreePlan = plan.monthlyPriceCents === 0 && plan.annualPriceCents === 0;

    const submit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        form.patch(`/admin/plans/${plan.id}`, {
            preserveScroll: true,
        });
    };

    const syncWithStripe = () => {
        syncForm.post(`/admin/plans/${plan.id}/stripe-sync`, {
            preserveScroll: true,
        });
    };

    const stripeReady = isFreePlan || (plan.stripeProductId && plan.stripeMonthlyPriceId && plan.stripeAnnualPriceId);

    return (
        <section className={`admin-surface admin-plan-editor-shell ${expanded ? 'is-expanded' : ''}`}>
            <div className="admin-plan-editor-header">
                <div className="admin-plan-editor-headline">
                    <div className="admin-plan-head">
                        <strong>{plan.label}</strong>
                        <div className="admin-pill-row">
                            {plan.isFeatured ? <span className="admin-pill admin-pill-accent">featured</span> : null}
                            <span className={`admin-pill ${statusTone(plan.status)}`}>{plan.status}</span>
                            <span className={`admin-pill ${stripeReady ? 'admin-pill-accent' : ''}`}>{isFreePlan ? 'No Stripe sync needed' : stripeReady ? 'Stripe synced' : 'Stripe needs sync'}</span>
                        </div>
                    </div>
                    <p>{plan.description}</p>
                    <div className="admin-chip-row">
                        <span className="admin-chip">{formatMoney(plan.monthlyPriceCents)}/mo</span>
                        <span className="admin-chip">{formatMoney(plan.annualPriceCents)}/yr</span>
                        <span className="admin-chip">{plan.subscriberCount.toLocaleString()} subscribers</span>
                        <span className="admin-chip">{plan.includedSites} sites</span>
                        <span className="admin-chip">{plan.includedMembers} members</span>
                    </div>
                </div>

                <div className="admin-form-actions-inline admin-plan-editor-actions">
                    {!isFreePlan ? (
                        <button type="button" className="admin-button admin-button-secondary" onClick={syncWithStripe} disabled={syncForm.processing}>
                            {syncForm.processing ? 'Syncing...' : 'Sync with Stripe'}
                        </button>
                    ) : null}
                    <button type="button" className="admin-button admin-button-secondary" onClick={onToggle}>
                        {expanded ? 'Hide editor' : 'Edit plan'}
                    </button>
                </div>
            </div>

            <div className="admin-site-grid">
                <div>
                    <span className="admin-site-key">Stripe product ID</span>
                    <strong>{plan.stripeProductId ?? 'Not created yet'}</strong>
                </div>
                <div>
                    <span className="admin-site-key">Monthly price ID</span>
                    <strong>{plan.stripeMonthlyPriceId ?? 'Not created yet'}</strong>
                </div>
                <div>
                    <span className="admin-site-key">Annual price ID</span>
                    <strong>{plan.stripeAnnualPriceId ?? 'Not created yet'}</strong>
                </div>
                <div>
                    <span className="admin-site-key">Last Stripe sync</span>
                    <strong>{formatDate(plan.stripeSyncedAt)}</strong>
                </div>
            </div>

            {expanded ? (
                <form className="admin-plan-editor-form" onSubmit={submit}>
                    <PlanSection title="Identity" description="Name and classify this plan first.">
                        <label className="admin-field">
                            <span>Slug</span>
                            <input className="admin-text-input" value={form.data.slug} onChange={(event) => form.setData('slug', event.target.value)} />
                            <InputError message={form.errors.slug} />
                        </label>

                        <label className="admin-field">
                            <span>Label</span>
                            <input className="admin-text-input" value={form.data.label} onChange={(event) => form.setData('label', event.target.value)} />
                            <InputError message={form.errors.label} />
                        </label>

                        <label className="admin-field admin-field-full">
                            <span>Description</span>
                            <textarea className="admin-textarea-input" rows={3} value={form.data.description} onChange={(event) => form.setData('description', event.target.value)} />
                            <InputError message={form.errors.description} />
                        </label>

                        <label className="admin-field">
                            <span>Status</span>
                            <select className="admin-select-input" value={form.data.status} onChange={(event) => form.setData('status', event.target.value as PlanStatus)}>
                                {statuses.map((status) => (
                                    <option key={status.key} value={status.key}>
                                        {status.label}
                                    </option>
                                ))}
                            </select>
                            <InputError message={form.errors.status} />
                        </label>

                        <label className="admin-field">
                            <span>Sort order</span>
                            <input type="number" className="admin-text-input" value={form.data.sort_order} onChange={(event) => form.setData('sort_order', Number(event.target.value))} />
                            <InputError message={form.errors.sort_order} />
                        </label>
                    </PlanSection>

                    <PlanSection title="Pricing" description="Monthly and annual prices in cents.">
                        <label className="admin-field">
                            <span>Monthly price</span>
                            <input type="number" className="admin-text-input" value={form.data.monthly_price_cents} onChange={(event) => form.setData('monthly_price_cents', Number(event.target.value))} />
                            <InputError message={form.errors.monthly_price_cents} />
                        </label>

                        <label className="admin-field">
                            <span>Annual price</span>
                            <input type="number" className="admin-text-input" value={form.data.annual_price_cents} onChange={(event) => form.setData('annual_price_cents', Number(event.target.value))} />
                            <InputError message={form.errors.annual_price_cents} />
                        </label>
                    </PlanSection>

                    <PlanSection title="Limits" description="Define what this tier unlocks for customers.">
                        <label className="admin-field">
                            <span>Included sites</span>
                            <input type="number" className="admin-text-input" value={form.data.included_sites} onChange={(event) => form.setData('included_sites', Number(event.target.value))} />
                            <InputError message={form.errors.included_sites} />
                        </label>

                        <label className="admin-field">
                            <span>Included members</span>
                            <input type="number" className="admin-text-input" value={form.data.included_members} onChange={(event) => form.setData('included_members', Number(event.target.value))} />
                            <InputError message={form.errors.included_members} />
                        </label>

                        <label className="admin-field">
                            <span>Published pages</span>
                            <input type="number" className="admin-text-input" value={form.data.included_published_pages} onChange={(event) => form.setData('included_published_pages', Number(event.target.value))} />
                            <InputError message={form.errors.included_published_pages} />
                        </label>

                        <label className="admin-field">
                            <span>Storage bytes</span>
                            <input type="number" className="admin-text-input" value={form.data.included_storage_bytes} onChange={(event) => form.setData('included_storage_bytes', Number(event.target.value))} />
                            <InputError message={form.errors.included_storage_bytes} />
                        </label>
                    </PlanSection>

                    <label className="admin-checkbox-row admin-field-full">
                        <input type="checkbox" checked={form.data.is_featured} onChange={(event) => form.setData('is_featured', event.target.checked)} />
                        <div>
                            <strong>Featured plan</strong>
                            <small>Highlight this tier across customer-facing billing views.</small>
                        </div>
                    </label>

                    <div className="admin-form-actions admin-field-full">
                        <button type="submit" className="admin-button admin-button-primary" disabled={form.processing}>
                            {form.processing ? 'Saving...' : 'Update plan'}
                        </button>
                    </div>
                </form>
            ) : null}
        </section>
    );
}

export default function AdminPlans({ plans, statuses }: AdminPlansProps) {
    const [activePlanId, setActivePlanId] = useState<number | null>(plans[0]?.id ?? null);
    const createForm = useForm<PlanFormState>({
        slug: '',
        label: '',
        description: '',
        status: 'draft',
        monthly_price_cents: 0,
        annual_price_cents: 0,
        included_sites: 1,
        included_members: 1,
        included_published_pages: 1,
        included_storage_bytes: 1_073_741_824,
        sort_order: plans.length + 10,
        is_featured: false,
    });

    const activePlans = plans.filter((plan) => plan.status === 'active').length;
    const featuredPlans = plans.filter((plan) => plan.isFeatured).length;
    const totalSubscribers = plans.reduce((total, plan) => total + plan.subscriberCount, 0);
    const featuredPlan = plans.find((plan) => plan.isFeatured) ?? null;

    const submit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        createForm.post('/admin/plans', {
            preserveScroll: true,
        });
    };

    return (
        <>
            <Head title="Plan Management" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Plan Management"
                    title="Create and edit the live subscription catalog."
                    description="Plans now come from database records, so the admin catalog directly controls customer-facing billing choices."
                    actions={(
                        <>
                            <Link href="/admin/commerce" className="admin-secondary-link">
                                Open commerce
                            </Link>

                            <Link href="/dashboard/billing" className="admin-primary-link">
                                Review customer billing <ArrowUpRight size={14} />
                            </Link>
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Plan catalog summary">
                    <AdminStatCard label="Plans" value={plans.length.toLocaleString()} meta={`${activePlans} active`} />
                    <AdminStatCard label="Featured" value={featuredPlans.toLocaleString()} meta="Customer billing emphasis" />
                    <AdminStatCard label="Subscribers" value={totalSubscribers.toLocaleString()} meta="Across all plan records" />
                    <AdminStatCard label="Top annual" value={plans[0] ? formatMoney(Math.max(...plans.map((plan) => plan.annualPriceCents))) : '$0'} meta="Highest configured annual price" />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface admin-plan-create-surface">
                            <AdminCardHeader label="Create plan" title="Add a new subscription tier" action={<Sparkles size={16} />} />

                            <div className="admin-plan-create-intro">
                                <div className="admin-plan-quick-card">
                                    <span className="admin-pill admin-pill-accent">fast setup</span>
                                    <strong>Start with identity, then price, then limits.</strong>
                                    <small>New plan appears in catalog immediately after save.</small>
                                </div>

                                <div className="admin-plan-quick-card">
                                    <span className="admin-pill">featured plan</span>
                                    <strong>{featuredPlan ? featuredPlan.label : 'No featured plan set'}</strong>
                                    <small>{featuredPlan ? 'Current highlighted customer tier.' : 'You can flag one plan to emphasize billing choice.'}</small>
                                </div>
                            </div>

                            <form className="admin-plan-editor-form" onSubmit={submit}>
                                <PlanSection title="Identity" description="Basic catalog details customers will recognize.">
                                    <label className="admin-field">
                                        <span>Slug</span>
                                        <input className="admin-text-input" value={createForm.data.slug} onChange={(event) => createForm.setData('slug', event.target.value)} placeholder="enterprise" />
                                        <InputError message={createForm.errors.slug} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Label</span>
                                        <input className="admin-text-input" value={createForm.data.label} onChange={(event) => createForm.setData('label', event.target.value)} placeholder="Enterprise" />
                                        <InputError message={createForm.errors.label} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Description</span>
                                        <textarea className="admin-textarea-input" rows={3} value={createForm.data.description} onChange={(event) => createForm.setData('description', event.target.value)} placeholder="High-touch plan for multi-site customer operations." />
                                        <InputError message={createForm.errors.description} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Status</span>
                                        <select className="admin-select-input" value={createForm.data.status} onChange={(event) => createForm.setData('status', event.target.value as PlanStatus)}>
                                            {statuses.map((status) => (
                                                <option key={status.key} value={status.key}>
                                                    {status.label}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={createForm.errors.status} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Sort order</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.sort_order} onChange={(event) => createForm.setData('sort_order', Number(event.target.value))} />
                                        <InputError message={createForm.errors.sort_order} />
                                    </label>
                                </PlanSection>

                                <PlanSection title="Pricing" description="Store prices in cents so catalog math stays exact.">
                                    <label className="admin-field">
                                        <span>Monthly price</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.monthly_price_cents} onChange={(event) => createForm.setData('monthly_price_cents', Number(event.target.value))} />
                                        <InputError message={createForm.errors.monthly_price_cents} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Annual price</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.annual_price_cents} onChange={(event) => createForm.setData('annual_price_cents', Number(event.target.value))} />
                                        <InputError message={createForm.errors.annual_price_cents} />
                                    </label>
                                </PlanSection>

                                <PlanSection title="Limits" description="Set operational caps for this tier.">
                                    <label className="admin-field">
                                        <span>Included sites</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.included_sites} onChange={(event) => createForm.setData('included_sites', Number(event.target.value))} />
                                        <InputError message={createForm.errors.included_sites} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Included members</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.included_members} onChange={(event) => createForm.setData('included_members', Number(event.target.value))} />
                                        <InputError message={createForm.errors.included_members} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Published pages</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.included_published_pages} onChange={(event) => createForm.setData('included_published_pages', Number(event.target.value))} />
                                        <InputError message={createForm.errors.included_published_pages} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Storage bytes</span>
                                        <input type="number" className="admin-text-input" value={createForm.data.included_storage_bytes} onChange={(event) => createForm.setData('included_storage_bytes', Number(event.target.value))} />
                                        <InputError message={createForm.errors.included_storage_bytes} />
                                    </label>
                                </PlanSection>

                                <label className="admin-checkbox-row admin-field-full">
                                    <input type="checkbox" checked={createForm.data.is_featured} onChange={(event) => createForm.setData('is_featured', event.target.checked)} />
                                    <div>
                                        <strong>Featured plan</strong>
                                        <small>Use this to emphasize the tier inside customer billing.</small>
                                    </div>
                                </label>

                                <div className="admin-form-actions admin-field-full">
                                    <button type="submit" className="admin-button admin-button-primary" disabled={createForm.processing}>
                                        {createForm.processing ? 'Creating...' : 'Create plan'}
                                    </button>
                                </div>
                            </form>
                        </section>

                        <section className="admin-surface admin-plan-catalog-surface">
                            <AdminCardHeader label="Catalog posture" title="Current plan levels" action={<CreditCard size={16} />} />

                            <div className="admin-plan-grid">
                                {plans.map((plan) => (
                                    <button
                                        key={plan.id}
                                        type="button"
                                        className={`admin-plan-card ${activePlanId === plan.id ? 'is-current' : ''}`}
                                        onClick={() => setActivePlanId(plan.id)}
                                    >
                                        <div className="admin-plan-copy">
                                            <div className="admin-plan-head">
                                                <strong>{plan.label}</strong>
                                                {plan.isFeatured ? <span className="admin-pill admin-pill-accent">featured</span> : <span className={`admin-pill ${statusTone(plan.status)}`}>{plan.status}</span>}
                                            </div>
                                            <p>{plan.description}</p>
                                        </div>
                                        <div className="admin-plan-meta">
                                            <span>{formatMoney(plan.monthlyPriceCents)}/mo</span>
                                            <span>{formatMoney(plan.annualPriceCents)}/yr</span>
                                            <span>{plan.subscriberCount} subscribers</span>
                                            <span>{plan.stripeProductId ?? 'Stripe sync needed'}</span>
                                        </div>
                                        <div className="admin-plan-card-footer">
                                            <span>{plan.includedSites} sites · {plan.includedMembers} members</span>
                                            <span className="admin-site-value-link">Edit <ArrowRight size={12} /></span>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface admin-plan-catalog-surface">
                            <AdminCardHeader label="Edit plans" title="Work on one tier at a time" action={<Layers3 size={16} />} />

                            <div className="admin-plan-editor-stack">
                                {plans.map((plan) => (
                                    <PlanEditorCard
                                        key={plan.id}
                                        plan={plan}
                                        statuses={statuses}
                                        expanded={activePlanId === plan.id}
                                        onToggle={() => setActivePlanId((current) => (current === plan.id ? null : plan.id))}
                                    />
                                ))}
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}