import { Head, Link } from '@inertiajs/react';
import {
    Activity,
    ArrowUpRight,
    BookOpenText,
    CheckCircle2,
    FileText,
    Globe,
    HardDriveUpload,
    Layers3,
    Rocket,
    Settings,
    Users,
} from 'lucide-react';
import {
    AdminCardHeader,
    AdminEmptyState,
    AdminPageHero,
    AdminStatCard,
    AdminStatGrid,
} from '@/components/admin/page-primitives';

type DashboardProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    summary: {
        totalSites: number;
        totalSpaces: number;
        totalPages: number;
        totalMembers: number;
        totalPublishedPages: number;
        storageBytes: number;
    };
    primarySite: {
        name: string;
        slug: string;
        status: string;
        visibility: string;
        defaultSpaceName: string | null;
        spacesCount: number;
        pagesCount: number;
        domainsCount: number;
        currentReleaseVersion: string | null;
        currentReleasePublishedAt: string | null;
        lastEditedAt: string | null;
    };
    onboarding: {
        isFreshWorkspace: boolean;
        completedSteps: number;
        remainingSteps: number;
        steps: Array<{
            id: 'structure' | 'release' | 'media' | 'team' | 'domain';
            title: string;
            description: string;
            href: string;
            actionLabel: string;
            completed: boolean;
        }>;
    };
    spaces: Array<{
        id: number;
        name: string;
        slug: string;
        icon: string;
        color: string;
        pagesCount: number;
        publishedPagesCount: number;
        unpublishedPagesCount: number;
    }>;
    activity: Array<{
        id: number;
        title: string;
        path: string | null;
        message: string;
        saveType: string;
        author: string;
        createdAt: string | null;
    }>;
};

const formatBytes = (value: number) => {
    if (value <= 0) {
        return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB'];
    const exponent = Math.min(
        Math.floor(Math.log(value) / Math.log(1024)),
        units.length - 1,
    );
    const size = value / 1024 ** exponent;

    return `${size.toFixed(size >= 10 || exponent === 0 ? 0 : 1)} ${units[exponent]}`;
};

const formatDate = (value: string | null) => {
    if (!value) {
        return 'No activity yet';
    }

    return new Intl.DateTimeFormat('en', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    }).format(new Date(value));
};

const onboardingIcons = {
    structure: Layers3,
    release: Rocket,
    media: HardDriveUpload,
    team: Users,
    domain: Globe,
};

export default function Dashboard({
    organization,
    summary,
    primarySite,
    onboarding,
    spaces,
    activity,
}: DashboardProps) {
    const publishStatus = primarySite.currentReleaseVersion
        ? 'Published'
        : 'Draft only';
    const publishedRatio =
        summary.totalPages > 0
            ? Math.round(
                  (summary.totalPublishedPages / summary.totalPages) * 100,
              )
            : 0;
    const quickActions = [
        {
            title: 'Write docs',
            description:
                'Open the editor for page writing, structure edits, and publishing prep.',
            href: '/editor',
            icon: BookOpenText,
        },
        {
            title: 'Organize structure',
            description:
                'Review sites, spaces, default space, and navigation shape.',
            href: '/dashboard/sites',
            icon: Layers3,
        },
        {
            title: 'Publish releases',
            description:
                'Create snapshots and review the current public release.',
            href: '/dashboard/releases',
            icon: Rocket,
        },
        {
            title: 'Manage media',
            description: 'Upload and curate reusable images and files.',
            href: '/dashboard/media',
            icon: HardDriveUpload,
        },
        {
            title: 'Invite team',
            description: 'Control collaborators, roles, and access.',
            href: '/dashboard/team',
            icon: Users,
        },
        {
            title: 'Site settings',
            description: 'Update domains, SEO, and brand configuration.',
            href: '/dashboard/settings',
            icon: Settings,
        },
    ];

    return (
        <>
            <Head title="Dashboard" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    accent={false}
                    eyebrow="Workspace overview"
                    title={organization.name}
                    description="A clean operating view for docs structure, publishing status, recent work, team access, media, and site configuration."
                    actions={
                        <>
                            <a href="/editor" className="admin-primary-link">
                                <BookOpenText size={14} /> Open editor
                            </a>
                            {primarySite.currentReleaseVersion ? (
                                <a
                                    href={`/docs/${primarySite.slug}`}
                                    className="admin-secondary-link"
                                >
                                    <ArrowUpRight size={14} /> View public docs
                                </a>
                            ) : (
                                <Link
                                    href="/dashboard/releases"
                                    className="admin-secondary-link"
                                >
                                    <Rocket size={14} /> Prepare release
                                </Link>
                            )}
                        </>
                    }
                />

                <AdminStatGrid ariaLabel="Workspace summary">
                    <AdminStatCard
                        label="Sites"
                        value={summary.totalSites}
                        meta="Docs properties in this workspace"
                    />
                    <AdminStatCard
                        label="Spaces"
                        value={summary.totalSpaces}
                        meta="Top-level content groups"
                    />
                    <AdminStatCard
                        label="Pages"
                        value={summary.totalPages}
                        meta={`${summary.totalPublishedPages} published, ${summary.totalPages - summary.totalPublishedPages} draft`}
                    />
                    <AdminStatCard
                        label="Team"
                        value={summary.totalMembers}
                        meta="Active workspace members"
                    />
                    <AdminStatCard
                        label="Storage"
                        value={formatBytes(summary.storageBytes)}
                        meta="Shared media usage"
                    />
                </AdminStatGrid>

                <section className="admin-dashboard-grid">
                    <div className="admin-column-stack">
                        <article className="admin-surface admin-site-card">
                            <AdminCardHeader
                                label="Active site"
                                title={primarySite.name}
                                action={
                                    <div className="admin-pill-row">
                                        <span className="admin-pill">
                                            {primarySite.visibility}
                                        </span>
                                        <span className="admin-pill admin-pill-accent">
                                            {publishStatus}
                                        </span>
                                    </div>
                                }
                            />

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">
                                        Public path
                                    </span>
                                    <strong>/docs/{primarySite.slug}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">
                                        Default space
                                    </span>
                                    <strong>
                                        {primarySite.defaultSpaceName ??
                                            'Not set'}
                                    </strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">
                                        Release
                                    </span>
                                    <strong>
                                        {primarySite.currentReleaseVersion ??
                                            'Draft only'}
                                    </strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">
                                        Last edit
                                    </span>
                                    <strong>
                                        {formatDate(primarySite.lastEditedAt)}
                                    </strong>
                                </div>
                            </div>

                            <div
                                className="admin-overview-strip"
                                aria-label="Publishing coverage"
                            >
                                <div>
                                    <span>Published coverage</span>
                                    <strong>{publishedRatio}%</strong>
                                </div>
                                <div className="admin-progress-track">
                                    <span
                                        style={{ width: `${publishedRatio}%` }}
                                    />
                                </div>
                                <small>
                                    {summary.totalPublishedPages} of{' '}
                                    {summary.totalPages} pages are included in
                                    the current public release.
                                </small>
                            </div>

                            <div className="admin-chip-row">
                                <span className="admin-chip">
                                    <Layers3 size={13} />{' '}
                                    {primarySite.spacesCount} spaces
                                </span>
                                <span className="admin-chip">
                                    <BookOpenText size={13} />{' '}
                                    {primarySite.pagesCount} pages
                                </span>
                                <span className="admin-chip">
                                    <Globe size={13} />{' '}
                                    {primarySite.domainsCount} domains
                                </span>
                                <span className="admin-chip">
                                    <Rocket size={13} />{' '}
                                    {summary.totalPublishedPages} published
                                    pages
                                </span>
                            </div>
                        </article>

                        <article className="admin-surface">
                            <AdminCardHeader
                                label="Content structure"
                                title="Spaces and draft load"
                                action={
                                    <Link
                                        href="/dashboard/sites"
                                        className="admin-secondary-link admin-secondary-link-inline"
                                    >
                                        Manage
                                    </Link>
                                }
                            />

                            {spaces.length ? (
                                <div className="admin-list">
                                    {spaces.map((space) => (
                                        <div
                                            key={space.id}
                                            className="admin-list-row"
                                        >
                                            <div className="admin-list-leading">
                                                <span
                                                    className="admin-color-dot"
                                                    style={{
                                                        background: space.color,
                                                    }}
                                                />
                                                <div>
                                                    <div className="admin-list-title">
                                                        {space.name}
                                                    </div>
                                                    <div className="admin-list-meta">
                                                        /{space.slug}
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="admin-list-trailing">
                                                <span>
                                                    {space.pagesCount} pages
                                                </span>
                                                <span>
                                                    {space.publishedPagesCount}{' '}
                                                    published
                                                </span>
                                                {space.unpublishedPagesCount >
                                                0 ? (
                                                    <span>
                                                        {
                                                            space.unpublishedPagesCount
                                                        }{' '}
                                                        unpublished
                                                    </span>
                                                ) : null}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Layers3 size={16} />}>
                                    No spaces yet. Create the first structure
                                    pass and the dashboard will start reflecting
                                    the site architecture here.
                                </AdminEmptyState>
                            )}
                        </article>

                        <article className="admin-surface">
                            <AdminCardHeader
                                label="Recent work"
                                title="Latest edits"
                                action={
                                    <Link
                                        href="/dashboard/analytics"
                                        className="admin-secondary-link admin-secondary-link-inline"
                                    >
                                        Analytics
                                    </Link>
                                }
                            />

                            {activity.length ? (
                                <div className="admin-activity-list">
                                    {activity.map((item) => (
                                        <div
                                            key={item.id}
                                            className="admin-activity-row"
                                        >
                                            <div
                                                className={`admin-activity-dot is-${item.saveType}`}
                                            />
                                            <div className="admin-activity-copy">
                                                <div className="admin-activity-head">
                                                    <strong>
                                                        {item.title}
                                                    </strong>
                                                    <span>
                                                        {formatDate(
                                                            item.createdAt,
                                                        )}
                                                    </span>
                                                </div>
                                                <p>{item.message}</p>
                                                <small>
                                                    {item.author} ·{' '}
                                                    {item.saveType}
                                                    {item.path
                                                        ? ` · /${item.path}`
                                                        : ''}
                                                </small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Activity size={16} />}>
                                    No recent activity yet. Draft saves and
                                    publishes will start building this feed as
                                    soon as the workspace moves past the
                                    scaffold.
                                </AdminEmptyState>
                            )}
                        </article>
                    </div>

                    <div className="admin-column-stack">
                        <article className="admin-surface">
                            <AdminCardHeader
                                label="Quick actions"
                                title="Where to go next"
                            />

                            <div className="admin-action-grid">
                                {quickActions.map((action) => {
                                    const Icon = action.icon;

                                    return (
                                        <Link
                                            key={action.title}
                                            href={action.href}
                                            className="admin-action-card"
                                        >
                                            <span>
                                                <Icon size={15} />
                                            </span>
                                            <div>
                                                <strong>{action.title}</strong>
                                                <small>
                                                    {action.description}
                                                </small>
                                            </div>
                                        </Link>
                                    );
                                })}
                            </div>
                        </article>

                        <article className="admin-surface admin-surface-accent">
                            <AdminCardHeader
                                label="Launch checklist"
                                title={
                                    onboarding.remainingSteps > 0
                                        ? 'Finish the workspace setup'
                                        : 'Workspace setup is complete'
                                }
                                action={
                                    <span className="admin-pill">
                                        {onboarding.completedSteps}/
                                        {onboarding.steps.length} done
                                    </span>
                                }
                            />

                            {onboarding.remainingSteps > 0 ? (
                                <>
                                    <p className="admin-onboarding-copy">
                                        Complete these operational steps in
                                        order: structure first, then release,
                                        assets, team, and public domain.
                                    </p>

                                    <ol className="admin-roadmap-list admin-checklist-list">
                                        {onboarding.steps.map((step, index) => {
                                            const Icon =
                                                onboardingIcons[step.id];

                                            return (
                                                <li
                                                    key={step.id}
                                                    className="admin-roadmap-item"
                                                >
                                                    <span>
                                                        {step.completed
                                                            ? 'OK'
                                                            : String(
                                                                  index + 1,
                                                              ).padStart(
                                                                  2,
                                                                  '0',
                                                              )}
                                                    </span>
                                                    <div>
                                                        <strong>
                                                            <Icon size={14} />{' '}
                                                            {step.title}
                                                        </strong>
                                                        <small>
                                                            {step.description}
                                                        </small>
                                                        <div className="admin-onboarding-actions">
                                                            <span
                                                                className={`admin-pill ${step.completed ? 'admin-pill-accent' : ''}`}
                                                            >
                                                                {step.completed
                                                                    ? 'Complete'
                                                                    : 'Pending'}
                                                            </span>
                                                            {!step.completed ? (
                                                                <Link
                                                                    href={
                                                                        step.href
                                                                    }
                                                                    className="admin-secondary-link admin-secondary-link-inline"
                                                                >
                                                                    {
                                                                        step.actionLabel
                                                                    }
                                                                </Link>
                                                            ) : null}
                                                        </div>
                                                    </div>
                                                </li>
                                            );
                                        })}
                                    </ol>
                                </>
                            ) : (
                                <AdminEmptyState
                                    icon={<CheckCircle2 size={16} />}
                                >
                                    Structure, release flow, media, team, and
                                    domain setup are in place.
                                </AdminEmptyState>
                            )}
                        </article>

                        <article className="admin-surface">
                            <AdminCardHeader
                                label="Account and site health"
                                title="Operational details"
                            />

                            <div className="admin-health-grid">
                                <div className="admin-health-item">
                                    <Users size={14} />
                                    <div>
                                        <strong>{summary.totalMembers}</strong>
                                        <span>active members</span>
                                    </div>
                                </div>
                                <div className="admin-health-item">
                                    <FileText size={14} />
                                    <div>
                                        <strong>{primarySite.status}</strong>
                                        <span>site status</span>
                                    </div>
                                </div>
                                <div className="admin-health-item">
                                    <HardDriveUpload size={14} />
                                    <div>
                                        <strong>
                                            {formatBytes(summary.storageBytes)}
                                        </strong>
                                        <span>media storage used</span>
                                    </div>
                                </div>
                                <div className="admin-health-item">
                                    <Globe size={14} />
                                    <div>
                                        <strong>
                                            {organization.billingEmail ??
                                                'not set'}
                                        </strong>
                                        <span>billing contact</span>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </section>
            </div>
        </>
    );
}
