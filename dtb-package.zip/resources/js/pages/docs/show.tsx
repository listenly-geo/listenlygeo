import { Head } from '@inertiajs/react';
import { useMemo, useState } from 'react';
import type { CSSProperties } from 'react';
import { resolveDocsTheme } from './themes';
import type { DocsShowProps } from './themes';
import { resolveDocsThemeFontFamily, resolveDocsThemeOptionStyles } from './themes/catalog';
import { extractHeadings, filterNavigation, formatDate, groupNavigation } from './themes/shared';

export default function DocsShow({
    site,
    release,
    navigation,
    searchIndex,
    page,
    previousPage,
    nextPage,
}: DocsShowProps) {
    const [navigationQuery, setNavigationQuery] = useState('');

    const groupedNavigation = useMemo(() => groupNavigation(navigation), [navigation]);

    const searchDocumentsByPath = useMemo(
        () => Object.fromEntries(searchIndex.map((entry) => [entry.path, entry.searchDocument ?? ''])),
        [searchIndex],
    );

    const filteredNavigation = useMemo(
        () => groupedNavigation
            .map((group) => ({ ...group, nodes: filterNavigation(group.nodes, navigationQuery, searchDocumentsByPath) }))
            .filter((group) => group.nodes.length > 0),
        [groupedNavigation, navigationQuery, searchDocumentsByPath],
    );

    const headings = useMemo(() => extractHeadings(page.blocks), [page.blocks]);
    const pageTitle = `${page.title} - ${site.seoTitle ?? site.brandName}`;
    const metaDescription = site.seoDescription ?? page.subtitle ?? site.tagline ?? `${site.brandName} documentation`;
    const canonicalUrl = site.primaryDomain ? `https://${site.primaryDomain}/${page.path}` : null;
    const publishedDate = formatDate(release.publishedAt);
    const publishedDateTime = formatDate(release.publishedAt, true);
    const theme = resolveDocsTheme(site.docsTheme);
    const ThemeComponent = theme.component;
    const rootStyle: CSSProperties = {
        ...theme.styles,
        ...resolveDocsThemeOptionStyles(site.docsThemeOptions),
        fontFamily: resolveDocsThemeFontFamily(site.docsThemeOptions),
    };

    return (
        <>
            <Head title={pageTitle}>
                <meta name="description" content={metaDescription} />
                {canonicalUrl ? <link rel="canonical" href={canonicalUrl} /> : null}
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
                <link
                    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap"
                    rel="stylesheet"
                />
            </Head>

            <ThemeComponent
                site={site}
                release={release}
                navigation={navigation}
                searchIndex={searchIndex}
                page={page}
                previousPage={previousPage}
                nextPage={nextPage}
                theme={theme}
                rootStyle={rootStyle}
                groupedNavigation={groupedNavigation}
                filteredNavigation={filteredNavigation}
                navigationQuery={navigationQuery}
                setNavigationQuery={setNavigationQuery}
                headings={headings}
                publishedDate={publishedDate}
                publishedDateTime={publishedDateTime}
            />
        </>
    );
}
