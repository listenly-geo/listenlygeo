import { Head, Link, usePage } from '@inertiajs/react';
import {
    ArrowRight,
    BadgeCheck,
    Facebook,
    ChartNoAxesCombined,
    Cloud,
    Code2,
    CreditCard,
    Database,
    Download,
    GitBranch,
    FileCheck2,
    Handshake,
    Instagram,
    LayoutPanelTop,
    Library,
    Linkedin,
    Lock,
    Mail,
    Orbit,
    ServerCog,
    Rocket,
    Sparkles,
    Twitter,
    Webhook,
    Workflow,
} from 'lucide-react';
import { dashboard, login, register } from '@/routes';

type WelcomeProps = {
    canRegister?: boolean;
};

type PageProps = {
    name?: string;
    auth: {
        user: {
            name: string;
        } | null;
    };
};

const heroPoints = [
    'Blocks + structured writing',
    'Release snapshots + public docs',
    'Stripe-ready subscription control',
];

const trustStats = [
    { label: 'Publish success', value: '99.9%' },
    { label: 'Editor actions', value: '42k/day' },
    { label: 'Avg. setup time', value: '8 min' },
    { label: 'Team roles', value: '4 levels' },
];

const featureCards = [
    {
        title: 'Doc Studio',
        description:
            'Focused block editor for guides, API docs, and release notes with clear writing flow.',
        icon: LayoutPanelTop,
    },
    {
        title: 'Release Engine',
        description:
            'Draft preview, immutable release snapshots, and environment-ready publishing controls.',
        icon: FileCheck2,
    },
    {
        title: 'Media Library',
        description:
            'Drive-style assets with folders, previews, and quick reuse in pages and sections.',
        icon: Library,
    },
    {
        title: 'Commerce Layer',
        description:
            'Plan management, MRR visibility, subscription health, and Stripe sync surfaces for growth.',
        icon: ChartNoAxesCombined,
    },
];

const workflowRows = [
    ['Model', 'Define Site, Space, and Page structure once. Keep navigation stable as docs scale.'],
    ['Write', 'Compose with reusable blocks, callouts, references, and role-safe collaboration.'],
    ['Publish', 'Push updates as versioned releases. Keep current draft separate from public state.'],
    ['Scale', 'Track usage, billing, and customer growth from one admin command center.'],
];

const pricingCards = [
    {
        title: 'Starter',
        price: '$0',
        period: '/month',
        detail: 'Best for early product docs',
        bullets: ['1 Site', '25 published pages', 'Core editor + publish'],
        cta: 'Start for free',
        ctaHref: '/register',
    },
    {
        title: 'Growth',
        price: '$29',
        period: '/month',
        detail: 'For active SaaS documentation',
        bullets: ['Multiple spaces', 'Team collaboration', 'Release workflows'],
        highlight: true,
        badge: 'Most Popular',
        cta: 'Get started',
        ctaHref: '/register',
    },
    {
        title: 'Scale',
        price: '$99',
        period: '/month',
        detail: 'For multi-product organizations',
        bullets: ['Advanced reporting', 'Commerce controls', 'Priority support'],
        cta: 'Talk to sales',
        ctaHref: '/register',
    },
];

const faqItems = [
    {
        q: 'Can admins and editors have different permissions?',
        a: 'Yes. Workspace roles separate platform configuration from writing and publishing tasks.',
    },
    {
        q: 'Do we support staging drafts before launch?',
        a: 'Yes. Draft content stays private until you publish a release snapshot.',
    },
    {
        q: 'Is billing integrated with Stripe?',
        a: 'Yes. Plans, subscriptions, cancel/resume, and sync flows are Stripe-ready.',
    },
];

const quoteCards = [
    {
        quote: 'Publishing moved from chaotic docs handoffs to one clean release command.',
        name: 'Product Team',
        company: 'Teleman',
        initials: 'PT',
        color: '#1f4c40',
        bg: 'rgba(31,76,64,0.12)',
    },
    {
        quote: 'Site/Space/Page model removed confusion and made onboarding much faster.',
        name: 'Operations Lead',
        company: 'Nimbus',
        initials: 'OL',
        color: '#6772e5',
        bg: 'rgba(103,114,229,0.12)',
    },
    {
        quote: 'Release snapshots gave us confidence to push docs and code at the same time.',
        name: 'Docs Engineer',
        company: 'Fieldstack',
        initials: 'DE',
        color: '#c47c2e',
        bg: 'rgba(196,124,46,0.12)',
    },
];

const useCaseCards = [
    {
        title: 'SaaS Product Docs',
        description: 'Ship onboarding, API references, and release notes in one flow.',
        icon: Code2,
    },
    {
        title: 'Internal Knowledge Base',
        description: 'Document SOPs, architecture, and team playbooks with role-safe access.',
        icon: Database,
    },
    {
        title: 'Developer Portals',
        description: 'Serve public docs with predictable versioning and clean information hierarchy.',
        icon: Cloud,
    },
];

const integrationRows = [
    {
        title: 'Stripe',
        tag: 'Billing',
        description: 'Plan management, subscriptions, cancel/resume lifecycle, and commerce sync.',
        icon: CreditCard,
        color: '#6772e5',
        bg: 'rgba(103, 114, 229, 0.1)',
    },
    {
        title: 'SMTP',
        tag: 'Email',
        description: 'Platform email delivery and test flow for account and billing notifications.',
        icon: Mail,
        color: '#1f4c40',
        bg: 'rgba(31, 76, 64, 0.1)',
    },
    {
        title: 'Exports',
        tag: 'Data',
        description: 'Generate JSON, HTML, and downloadable artifacts from publication-ready docs.',
        icon: Download,
        color: '#c47c2e',
        bg: 'rgba(196, 124, 46, 0.1)',
    },
    {
        title: 'Webhooks',
        tag: 'Events',
        description: 'Connect subscription and release events to your operations pipelines.',
        icon: Webhook,
        color: '#b03a3a',
        bg: 'rgba(176, 58, 58, 0.1)',
    },
];

const migrationSteps = [
    {
        title: 'Map current docs',
        description: 'Define Site -> Space -> Page model from your existing structure first.',
        icon: GitBranch,
    },
    {
        title: 'Import content',
        description: 'Bring drafts in chunks, validate formatting, and align navigation paths.',
        icon: ServerCog,
    },
    {
        title: 'Go live safely',
        description: 'Use release snapshots and staged rollout before full public switch.',
        icon: Handshake,
    },
];

const editorBlocks = [
    { kind: 'h1', text: 'Launch-ready docs, finally.' },
    {
        kind: 'p',
        text: 'Turn product knowledge into a polished customer-facing knowledge base without leaving the editor.',
    },
    {
        kind: 'callout',
        text: 'Admin controls stay separate from writing workflows.',
    },
    { kind: 'code', text: 'GET /v1/docs/releases' },
];

const sidebarPages = [
    { label: 'Getting Started', active: false, indent: 0 },
    { label: 'Installation', active: false, indent: 1 },
    { label: 'API Reference', active: true, indent: 0 },
    { label: 'Authentication', active: false, indent: 1 },
    { label: 'Endpoints', active: false, indent: 1 },
    { label: 'Release Notes', active: false, indent: 0 },
];

export default function Welcome({ canRegister = true }: WelcomeProps) {
    const { auth, name } = usePage<PageProps>().props;
    const authed = Boolean(auth.user);
    const primaryHref = authed
        ? dashboard()
        : canRegister
          ? register()
          : login();
    const primaryLabel = authed
        ? 'Open dashboard'
        : canRegister
          ? 'Create workspace'
          : 'Log in';
    const appName = name?.trim() || 'DocTheBuilder';

    return (
        <>
            <Head title={appName}>
                <link rel="preconnect" href="https://fonts.bunny.net" />
                <link
                    href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600,700"
                    rel="stylesheet"
                />
            </Head>

            <main className="dtx-landing-shell">
                <header className="dtx-landing-nav">
                    <Link href="/" className="dtx-landing-logo" aria-label={`${appName} home`}>
                        <span>D</span>
                        <strong>{appName}</strong>
                    </Link>

                    <nav className="dtx-landing-nav-links" aria-label="Primary navigation">
                        <a href="#capabilities">Capabilities</a>
                        <a href="#use-cases">Use Cases</a>
                        <a href="#integrations">Integrations</a>
                        <a href="#workflow">Workflow</a>
                        <a href="#pricing">Pricing</a>
                        <a href="#faq">FAQ</a>
                    </nav>

                    <div className="dtx-landing-nav-actions">
                        {authed ? (
                            <Link href={dashboard()} className="dtx-landing-secondary-action">
                                Dashboard
                            </Link>
                        ) : (
                            <>
                                <Link href={login()} className="dtx-landing-secondary-action">
                                    Log in
                                </Link>
                                {canRegister ? (
                                    <Link href={register()} className="dtx-landing-primary-action">
                                        Start free
                                    </Link>
                                ) : null}
                            </>
                        )}
                    </div>
                </header>

                <section className="dtx-landing-hero" aria-labelledby="landing-title">
                    <div className="dtx-hero-copy">
                        <div className="dtx-hero-kicker">
                            <Sparkles size={14} />
                            Product docs, release flow, admin controls
                        </div>

                        <h1 id="landing-title">Front-door experience that matches power of your editor.</h1>
                        <p>
                            Build documentation platform with clean structure, versioned publishing, and subscription-ready operations.
                            One product surface for writers, admins, and customer-facing docs.
                        </p>

                        <div className="dtx-hero-actions">
                            <Link href={primaryHref} className="dtx-hero-primary">
                                {primaryLabel}
                                <ArrowRight size={16} />
                            </Link>
                            <a href="#workflow" className="dtx-hero-secondary">
                                Explore workflow
                                <Workflow size={16} />
                            </a>
                        </div>

                        <div className="dtx-hero-points">
                            {heroPoints.map((point) => (
                                <span key={point}>
                                    <BadgeCheck size={14} />
                                    {point}
                                </span>
                            ))}
                        </div>
                    </div>

                    <div className="dtx-hero-preview" aria-hidden="true">
                        <div className="dtx-preview-topbar">
                            <div className="dtx-preview-topbar-left">
                                <span className="dtx-preview-logo-dot" />
                                <strong>{appName}</strong>
                                <span className="dtx-preview-breadcrumb">
                                    <span>/</span> API Reference
                                </span>
                            </div>
                            <div className="dtx-preview-topbar-right">
                                <span className="dtx-preview-status">Draft</span>
                                <span className="dtx-preview-publish-btn">Publish</span>
                            </div>
                        </div>

                        <div className="dtx-preview-body">
                            <div className="dtx-preview-sidebar">
                                <div className="dtx-preview-space-badge">v1 Docs</div>
                                {sidebarPages.map((p) => (
                                    <div
                                        key={p.label}
                                        className={`dtx-preview-nav-item${p.active ? ' is-active' : ''}`}
                                        style={{ paddingLeft: `${10 + p.indent * 12}px` }}
                                    >
                                        {p.label}
                                    </div>
                                ))}
                            </div>

                            <div className="dtx-preview-canvas">
                                {editorBlocks.map((block, index) => (
                                    <div key={block.kind} className={`dtx-preview-block is-${block.kind}`} style={{ animationDelay: `${index * 120}ms` }}>
                                        <span className="dtx-preview-handle" />
                                        <div>
                                            <small>{block.kind.toUpperCase()}</small>
                                            <p>{block.text}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="dtx-preview-footer">
                            <div>
                                <Orbit size={12} />
                                Space switch, no reload
                            </div>
                            <div>
                                <Lock size={12} />
                                Admin-only controls
                            </div>
                            <div>
                                <Rocket size={12} />
                                Publish flow ready
                            </div>
                        </div>
                    </div>
                </section>

                <section className="dtx-trust-strip" aria-label="Trust and metrics">
                    {trustStats.map((item) => (
                        <div key={item.label}>
                            <strong>{item.value}</strong>
                            <span>{item.label}</span>
                        </div>
                    ))}
                </section>

                <section className="dtx-section" id="capabilities">
                    <div className="dtx-section-head">
                        <span>Capabilities</span>
                        <h2>Everything needed to ship docs like product, not side project.</h2>
                    </div>

                    <div className="dtx-feature-grid">
                        {featureCards.map((card) => {
                            const Icon = card.icon;

                            return (
                                <article key={card.title} className="dtx-feature-card">
                                    <span>
                                        <Icon size={18} />
                                    </span>
                                    <h3>{card.title}</h3>
                                    <p>{card.description}</p>
                                </article>
                            );
                        })}
                    </div>
                </section>

                <section className="dtx-section" id="use-cases">
                    <div className="dtx-section-head">
                        <span>Use Cases</span>
                        <h2>Built for teams shipping docs as product surface.</h2>
                    </div>

                    <div className="dtx-usecase-grid">
                        {useCaseCards.map((card) => {
                            const Icon = card.icon;

                            return (
                                <article key={card.title} className="dtx-usecase-card">
                                    <span>
                                        <Icon size={18} />
                                    </span>
                                    <h3>{card.title}</h3>
                                    <p>{card.description}</p>
                                </article>
                            );
                        })}
                    </div>
                </section>

                <section className="dtx-section dtx-integrations" id="integrations">
                    <div className="dtx-section-head">
                        <span>Integrations</span>
                        <h2>Operational hooks that keep docs and business flow aligned.</h2>
                    </div>

                    <div className="dtx-integration-grid">
                        {integrationRows.map((item) => {
                            const Icon = item.icon;

                            return (
                                <div key={item.title} className="dtx-integration-card">
                                    <div className="dtx-integration-icon" style={{ background: item.bg, color: item.color }}>
                                        <Icon size={20} />
                                    </div>
                                    <div className="dtx-integration-body">
                                        <div className="dtx-integration-name">
                                            <strong>{item.title}</strong>
                                            <span>{item.tag}</span>
                                        </div>
                                        <p>{item.description}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </section>

                <section className="dtx-section dtx-workflow" id="workflow">
                    <div className="dtx-section-head">
                        <span>Workflow</span>
                        <h2>Simple sequence from structure to release.</h2>
                    </div>

                    <div className="dtx-workflow-steps">
                        {workflowRows.map(([title, description], index) => (
                            <div key={title} className="dtx-workflow-step">
                                <div className="dtx-workflow-step-head">
                                    {index > 0 && <div className="dtx-workflow-connector" />}
                                    <div className="dtx-workflow-node">
                                        <span>{String(index + 1).padStart(2, '0')}</span>
                                    </div>
                                    {index < workflowRows.length - 1 && <div className="dtx-workflow-connector" />}
                                </div>
                                <strong>{title}</strong>
                                <p>{description}</p>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="dtx-section dtx-migration">
                    <div className="dtx-section-head">
                        <span>Migration Path</span>
                        <h2>Move from current docs setup without disruption.</h2>
                    </div>

                    <div className="dtx-migration-grid">
                        {migrationSteps.map((step, index) => {
                            const Icon = step.icon;

                            return (
                                <article key={step.title} className="dtx-migration-card">
                                    <div className="dtx-migration-head">
                                        <span>{String(index + 1).padStart(2, '0')}</span>
                                        <Icon size={16} />
                                    </div>
                                    <h3>{step.title}</h3>
                                    <p>{step.description}</p>
                                </article>
                            );
                        })}
                    </div>
                </section>

                <section className="dtx-section" id="pricing">
                    <div className="dtx-section-head">
                        <span>Pricing Snapshot</span>
                        <h2>Choose plan and scale with clear upgrade path.</h2>
                    </div>

                    <div className="dtx-pricing-grid">
                        {pricingCards.map((card) => (
                            <article key={card.title} className={`dtx-pricing-card ${card.highlight ? 'is-highlight' : ''}`}>
                                {card.badge && <div className="dtx-pricing-badge">{card.badge}</div>}
                                <div className="dtx-pricing-top">
                                    <strong>{card.title}</strong>
                                    <p>
                                        <span>{card.price}</span>
                                        <small>{card.period}</small>
                                    </p>
                                    <em>{card.detail}</em>
                                </div>

                                <div className="dtx-pricing-divider" />

                                <ul>
                                    {card.bullets.map((bullet) => (
                                        <li key={bullet}>
                                            <BadgeCheck size={14} />
                                            {bullet}
                                        </li>
                                    ))}
                                </ul>

                                <a href={card.ctaHref} className={`dtx-pricing-cta${card.highlight ? ' is-primary' : ''}`}>
                                    {card.cta}
                                </a>
                            </article>
                        ))}
                    </div>
                </section>

                <section className="dtx-section dtx-voices">
                    <div className="dtx-section-head">
                        <span>Teams Say</span>
                        <h2>Built for operators, writers, and product owners.</h2>
                    </div>

                    <div className="dtx-voice-grid">
                        {quoteCards.map((item) => (
                            <article key={item.company} className="dtx-voice-card">
                                <div className="dtx-voice-quote-mark">&ldquo;</div>
                                <p>{item.quote}</p>
                                <div className="dtx-voice-stars">
                                    {[1,2,3,4,5].map((s) => <span key={s}>&#9733;</span>)}
                                </div>
                                <div className="dtx-voice-author">
                                    <div className="dtx-voice-avatar" style={{ background: item.bg, color: item.color }}>
                                        {item.initials}
                                    </div>
                                    <div>
                                        <strong>{item.name}</strong>
                                        <small>{item.company}</small>
                                    </div>
                                </div>
                            </article>
                        ))}
                    </div>
                </section>

                <section className="dtx-section dtx-faq" id="faq">
                    <div className="dtx-section-head">
                        <span>FAQ</span>
                        <h2>Common launch questions, answered fast.</h2>
                    </div>

                    <div className="dtx-faq-list">
                        {faqItems.map((item) => (
                            <article key={item.q}>
                                <strong>{item.q}</strong>
                                <p>{item.a}</p>
                            </article>
                        ))}
                    </div>
                </section>

                <section className="dtx-final-cta" id="launch">
                    <div>
                        <span>Ready to ship docs better?</span>
                        <h2>Launch with UI your users trust from first visit.</h2>
                        <p>Start now, then tune workspace, plans, and publish pipeline as product grows.</p>
                    </div>

                    <div className="dtx-final-actions">
                        <Link href={primaryHref} className="dtx-hero-primary">
                            {primaryLabel}
                            <ArrowRight size={16} />
                        </Link>
                        <Link href={authed ? dashboard() : login()} className="dtx-hero-secondary">
                            {authed ? 'Go dashboard' : 'Log in'}
                        </Link>
                    </div>
                </section>

                <footer className="dtx-landing-footer">
                    <div className="dtx-footer-watermark" aria-hidden="true">{appName}</div>

                    <div className="dtx-footer-branding">
                        <div className="dtx-footer-brand-row">
                            <span>D</span>
                            <strong>{appName}</strong>
                        </div>
                        <p>©2026 DocTheBuilder Inc.</p>
                        <small>Handcrafted with care for product teams.</small>
                    </div>

                    <div className="dtx-footer-socials" aria-label="Social links">
                        <a href="#" aria-label="Facebook">
                            <Facebook size={14} />
                        </a>
                        <a href="#" aria-label="Instagram">
                            <Instagram size={14} />
                        </a>
                        <a href="#" aria-label="X">
                            <Twitter size={14} />
                        </a>
                        <a href="#" aria-label="LinkedIn">
                            <Linkedin size={14} />
                        </a>
                    </div>
                </footer>
            </main>
        </>
    );
}
