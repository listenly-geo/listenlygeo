import { Head, Link, useForm } from '@inertiajs/react';
import { ArrowUpRight, Globe, Rocket, ShieldCheck } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import { dashboard } from '@/routes';

type DashboardReleasesProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    permissions: {
        canPublish: boolean;
    };
    sites: Array<{
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        pagesCount: number;
        releaseCount: number;
        releasablePagesCount: number;
        currentReleaseVersion: string | null;
        isSelected: boolean;
    }>;
    selectedSite: {
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        docsUrl: string | null;
        currentReleaseVersion: string | null;
        currentReleasePublishedAt: string | null;
        releaseCount: number;
        releasablePagesCount: number;
        releases: Array<{
            id: number;
            version: string;
            status: string;
            environment: string;
            message: string | null;
            publishedAt: string | null;
            publishedBy: string | null;
            publishedPagesCount: number;
            isCurrent: boolean;
        }>;
    };
};

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not published yet';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

export default function DashboardReleases({ organization, permissions, sites, selectedSite }: DashboardReleasesProps) {
    const publishForm = useForm({
        environment: 'production' as 'production' | 'staging',
        message: '',
    });

    const handlePublish = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        publishForm.post(`/dashboard/releases/sites/${selectedSite.id}/publish`, {
            preserveScroll: true,
            onSuccess: () => publishForm.reset('message'),
        });
    };

    return (
        <>
            <Head title="Releases" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Releases"
                    title="Publish immutable documentation snapshots without leaving the admin shell."
                    description={`Draft content for ${organization.name} stays in the editor. This workflow captures the current site state as a release, tracks the environment, and keeps the public docs pinned to a specific snapshot until the next publish.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                Open editor <ArrowUpRight size={14} />
                            </a>

                            {selectedSite.docsUrl ? (
                                <a href={selectedSite.docsUrl} className="admin-secondary-link">
                                    View published docs <Globe size={14} />
                                </a>
                            ) : null}
                        </>
                    )}
                />

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Sites" title="Release scope" action={<span className="admin-pill">{sites.length} tracked</span>} />

                            <div className="admin-directory-list">
                                {sites.map((site) => (
                                    <Link
                                        key={site.id}
                                        href={`/dashboard/releases?site=${site.id}`}
                                        preserveScroll
                                        className={`admin-directory-item ${site.isSelected ? 'is-selected' : ''}`}
                                    >
                                        <div className="admin-directory-head">
                                            <div>
                                                <strong>{site.name}</strong>
                                                <small>{site.slug}</small>
                                            </div>
                                            <span className="admin-pill">{site.visibility}</span>
                                        </div>

                                        <div className="admin-chip-row">
                                            <span className="admin-chip">{site.status}</span>
                                            <span className="admin-chip">{site.releasablePagesCount} releasable pages</span>
                                            <span className="admin-chip">{site.releaseCount} releases</span>
                                            {site.currentReleaseVersion ? <span className="admin-chip">{site.currentReleaseVersion}</span> : null}
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Publish workflow"
                                title="Create a new release snapshot"
                                action={(
                                    <span className="admin-pill admin-pill-accent">
                                    <Rocket size={12} /> immutable snapshot
                                    </span>
                                )}
                            />

                            {permissions.canPublish ? (
                                <form className="admin-form-grid" onSubmit={handlePublish}>
                                    <label className="admin-field">
                                        <span>Environment</span>
                                        <select
                                            className="admin-select-input"
                                            value={publishForm.data.environment}
                                            onChange={(event) => publishForm.setData('environment', event.target.value as 'production' | 'staging')}
                                        >
                                            <option value="production">Production</option>
                                            <option value="staging">Staging</option>
                                        </select>
                                        <InputError message={publishForm.errors.environment} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Release message</span>
                                        <textarea
                                            className="admin-textarea-input"
                                            value={publishForm.data.message}
                                            onChange={(event) => publishForm.setData('message', event.target.value)}
                                            rows={4}
                                            placeholder="Summarize what changed in this publish."
                                        />
                                        <InputError message={publishForm.errors.message} />
                                    </label>

                                    <div className="admin-form-actions admin-field-full">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={publishForm.processing}>
                                            {publishForm.processing ? 'Publishing…' : 'Publish release'}
                                        </button>
                                    </div>
                                </form>
                            ) : (
                                <AdminEmptyState icon={<ShieldCheck size={16} />}>
                                    Only owners, admins, and editors can publish releases. You still have visibility into release history for this site.
                                </AdminEmptyState>
                            )}
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Current state"
                                title={selectedSite.name}
                                action={(
                                    <div className="admin-pill-row">
                                    <span className="admin-pill">{selectedSite.visibility}</span>
                                    <span className="admin-pill admin-pill-accent">{selectedSite.status}</span>
                                    </div>
                                )}
                            />

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">Live release</span>
                                    <strong>{selectedSite.currentReleaseVersion ?? 'Draft only'}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Last published</span>
                                    <strong>{formatDate(selectedSite.currentReleasePublishedAt)}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Releasable pages</span>
                                    <strong>{selectedSite.releasablePagesCount}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Total releases</span>
                                    <strong>{selectedSite.releaseCount}</strong>
                                </div>
                            </div>

                            <div className="admin-chip-row">
                                <span className="admin-chip">/{selectedSite.slug}</span>
                                {selectedSite.docsUrl ? <span className="admin-chip">public docs live</span> : <span className="admin-chip">not public yet</span>}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Release history"
                                title="Snapshot timeline"
                                action={<span className="admin-pill">{selectedSite.releases.length} recorded</span>}
                            />

                            {selectedSite.releases.length ? (
                                <div className="admin-directory-list">
                                    {selectedSite.releases.map((release) => (
                                        <div key={release.id} className="admin-directory-item">
                                            <div className="admin-directory-head">
                                                <div>
                                                    <strong>{release.version}</strong>
                                                    <small>
                                                        {release.publishedBy ?? 'Unknown publisher'} · {formatDate(release.publishedAt)}
                                                    </small>
                                                </div>

                                                <div className="admin-pill-row">
                                                    <span className="admin-pill">{release.environment}</span>
                                                    <span className="admin-pill">{release.publishedPagesCount} pages</span>
                                                    {release.isCurrent ? <span className="admin-pill admin-pill-accent">current</span> : null}
                                                </div>
                                            </div>

                                            <div className="admin-directory-meta">{release.message || 'Published from dashboard workflow.'}</div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Rocket size={16} />}>
                                    No releases yet. Publish the current draft state and this page will start tracking immutable snapshots.
                                </AdminEmptyState>
                            )}
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}