import { Head, Link, router, useForm } from '@inertiajs/react';
import { ArrowUpRight, CheckCircle2, Clock3, MailPlus, ShieldCheck, Users } from 'lucide-react';
import { useState } from 'react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import { dashboard } from '@/routes';

type TeamPageProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
        ownerUserId: number;
    };
    summary: {
        totalMembers: number;
        adminCount: number;
        editorCount: number;
        viewerCount: number;
        pendingInvitesCount: number;
    };
    permissions: {
        canManageTeam: boolean;
        currentUserRole: string;
    };
    members: Array<{
        id: number;
        userId: number;
        name: string;
        email: string;
        role: string;
        status: string;
        joinedAt: string | null;
        isOwner: boolean;
        isCurrentUser: boolean;
        canChangeRole: boolean;
    }>;
    invitations: Array<{
        id: number;
        email: string;
        role: string;
        invitedBy: string | null;
        invitedAt: string | null;
        expiresAt: string | null;
        isExpired: boolean;
    }>;
};

const roleOptions = [
    { value: 'admin', label: 'Admin' },
    { value: 'editor', label: 'Editor' },
    { value: 'viewer', label: 'Viewer' },
];

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not available';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

export default function DashboardTeam({ organization, summary, permissions, members, invitations }: TeamPageProps) {
    const inviteForm = useForm({
        email: '',
        role: 'editor',
    });

    const [draftRoles, setDraftRoles] = useState<Record<number, string>>({});
    const [updatingMemberId, setUpdatingMemberId] = useState<number | null>(null);

    const handleInvite = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        inviteForm.post('/dashboard/team/invitations', {
            preserveScroll: true,
            onSuccess: () => inviteForm.reset('email'),
        });
    };

    const handleRoleUpdate = (memberId: number, nextRole: string) => {
        setUpdatingMemberId(memberId);

        router.patch(`/dashboard/team/members/${memberId}`, { role: nextRole }, {
            preserveScroll: true,
            onFinish: () => setUpdatingMemberId(null),
        });
    };

    return (
        <>
            <Head title="Team & Roles" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Team & Roles"
                    title="Control collaborator access without leaving."
                    description={`Keep ownership clear, assign editing rights deliberately, and prepare invites for the next people joining ${organization.name}.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                Open editor <ArrowUpRight size={14} />
                            </a>
                        </>
                    )}
                />

                <AdminStatGrid>
                    <AdminStatCard label="Active members" value={summary.totalMembers} meta="People currently attached to this workspace." />
                    <AdminStatCard label="Owners & admins" value={summary.adminCount} meta="People who can operate sensitive workspace controls." />
                    <AdminStatCard label="Editors" value={summary.editorCount} meta="People who can work inside the docs canvas." />
                    <AdminStatCard label="Pending invites" value={summary.pendingInvitesCount} meta="Prepared collaborator handoffs waiting to be accepted." />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Access policy" title="Invite collaborators" action={<span className="admin-pill admin-pill-accent">You are {permissions.currentUserRole}</span>} />

                            {permissions.canManageTeam ? (
                                <form className="admin-form-grid admin-form-grid-inline" onSubmit={handleInvite}>
                                    <label className="admin-field admin-field-grow">
                                        <span>Email</span>
                                        <input
                                            type="email"
                                            value={inviteForm.data.email}
                                            onChange={(event) => inviteForm.setData('email', event.target.value)}
                                            className="admin-text-input"
                                            placeholder="teammate@example.com"
                                        />
                                        <InputError message={inviteForm.errors.email} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Role</span>
                                        <select
                                            value={inviteForm.data.role}
                                            onChange={(event) => inviteForm.setData('role', event.target.value as 'admin' | 'editor' | 'viewer')}
                                            className="admin-select-input"
                                        >
                                            {roleOptions.map((option) => (
                                                <option key={option.value} value={option.value}>
                                                    {option.label}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={inviteForm.errors.role} />
                                    </label>

                                    <div className="admin-form-actions admin-form-actions-inline">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={inviteForm.processing}>
                                            <MailPlus size={14} />
                                            {inviteForm.processing ? 'Preparing…' : 'Prepare invite'}
                                        </button>
                                    </div>
                                </form>
                            ) : (
                                <AdminEmptyState icon={<ShieldCheck size={16} />}>
                                    Only owners and admins can change roles or prepare invites. You still have visibility into the current team.
                                </AdminEmptyState>
                            )}
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Members" title="Current workspace access" action={<span className="admin-pill">{members.length} listed</span>} />

                            <div className="admin-member-list">
                                {members.map((member) => {
                                    const selectedRole = draftRoles[member.id] ?? member.role;

                                    return (
                                        <div key={member.id} className="admin-member-row">
                                            <div className="admin-member-main">
                                                <div>
                                                    <strong>{member.name}</strong>
                                                    <small>{member.email}</small>
                                                </div>

                                                <div className="admin-chip-row">
                                                    <span className="admin-chip">{member.role}</span>
                                                    <span className="admin-chip">{member.status}</span>
                                                    {member.isOwner ? <span className="admin-chip">owner</span> : null}
                                                    {member.isCurrentUser ? <span className="admin-chip">you</span> : null}
                                                </div>
                                            </div>

                                            <div className="admin-member-actions">
                                                <div className="admin-member-meta">Joined {formatDate(member.joinedAt)}</div>

                                                {member.canChangeRole ? (
                                                    <div className="admin-inline-form">
                                                        <select
                                                            value={selectedRole}
                                                            onChange={(event) => setDraftRoles((current) => ({
                                                                ...current,
                                                                [member.id]: event.target.value,
                                                            }))}
                                                            className="admin-select-input admin-select-compact"
                                                        >
                                                            {roleOptions.map((option) => (
                                                                <option key={option.value} value={option.value}>
                                                                    {option.label}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button
                                                            type="button"
                                                            className="admin-button admin-button-secondary"
                                                            onClick={() => handleRoleUpdate(member.id, selectedRole)}
                                                            disabled={updatingMemberId !== null || selectedRole === member.role}
                                                        >
                                                            {updatingMemberId === member.id ? 'Updating…' : 'Update role'}
                                                        </button>
                                                    </div>
                                                ) : null}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Pending invites" title="Prepared collaborator handoffs" action={<span className="admin-pill">{invitations.length} waiting</span>} />

                            {invitations.length ? (
                                <div className="admin-directory-list">
                                    {invitations.map((invitation) => (
                                        <div key={invitation.id} className="admin-directory-item">
                                            <div className="admin-directory-head">
                                                <div>
                                                    <strong>{invitation.email}</strong>
                                                    <small>
                                                        Invited by {invitation.invitedBy ?? 'system'} · {formatDate(invitation.invitedAt)}
                                                    </small>
                                                </div>

                                                <div className="admin-pill-row">
                                                    <span className="admin-pill">{invitation.role}</span>
                                                    {invitation.isExpired ? (
                                                        <span className="admin-pill">expired</span>
                                                    ) : (
                                                        <span className="admin-pill admin-pill-accent">
                                                            <Clock3 size={12} /> active
                                                        </span>
                                                    )}
                                                </div>
                                            </div>

                                            <small className="admin-directory-meta">Expires {formatDate(invitation.expiresAt)}</small>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<CheckCircle2 size={16} />}>
                                    No pending invites. The current team is fully provisioned.
                                </AdminEmptyState>
                            )}
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Role guidance" title="Keep permissions deliberate" />

                            <div className="admin-health-grid">
                                <div className="admin-health-item">
                                    <ShieldCheck size={14} />
                                    <div>
                                        <strong>Owner / Admin</strong>
                                        <span>Can manage teammates, invites, and future operational settings.</span>
                                    </div>
                                </div>
                                <div className="admin-health-item">
                                    <Users size={14} />
                                    <div>
                                        <strong>Editor</strong>
                                        <span>Can work in the docs editor without taking over workspace administration.</span>
                                    </div>
                                </div>
                                <div className="admin-health-item">
                                    <MailPlus size={14} />
                                    <div>
                                        <strong>Viewer</strong>
                                        <span>Read-only visibility into the workspace team surface.</span>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}