import { Head, Link } from '@inertiajs/react';
import { Activity, BookOpenText, Globe, Rocket } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import { dashboard } from '@/routes';

type DashboardAnalyticsProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    sites: Array<{
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        pagesCount: number;
        publishedPagesCount: number;
        releaseCount: number;
        currentReleaseVersion: string | null;
        isSelected: boolean;
    }>;
    selectedSite: {
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        docsUrl: string | null;
        currentReleaseVersion: string | null;
        currentReleasePublishedAt: string | null;
        analytics: {
            totalPages: number;
            totalPublishedPages: number;
            totalRevisions: number;
            totalManualSaves: number;
            totalAutosaves: number;
            totalReleases: number;
            productionReleases: number;
            stagingReleases: number;
            totalContributors: number;
            recentEventsLast7Days: number;
            publishesLast30Days: number;
        };
        activity: Array<{
            id: string;
            kind: 'revision' | 'release';
            tone: 'manual' | 'autosave' | 'release' | string;
            title: string;
            message: string;
            actor: string;
            createdAt: string | null;
            meta: string;
        }>;
    };
};

function formatDate(value: string | null): string {
    if (!value) {
        return 'No activity yet';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

export default function DashboardAnalytics({ organization, sites, selectedSite }: DashboardAnalyticsProps) {
    return (
        <>
            <Head title="Analytics" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Analytics"
                    title="Measure revision volume and publish cadence for each documentation surface."
                    description={`This page stays intentionally operational: draft saves, publish frequency, contributor activity, and release state for ${organization.name}.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                <BookOpenText size={14} /> Open editor
                            </a>

                            {selectedSite.docsUrl ? (
                                <a href={selectedSite.docsUrl} className="admin-secondary-link">
                                    View published docs <Globe size={14} />
                                </a>
                            ) : null}
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Analytics summary">
                    <AdminStatCard label="Revisions" value={selectedSite.analytics.totalRevisions} meta="All saved revisions for this site." />
                    <AdminStatCard label="Manual saves" value={selectedSite.analytics.totalManualSaves} meta="Deliberate editor saves recorded so far." />
                    <AdminStatCard label="Autosaves" value={selectedSite.analytics.totalAutosaves} meta="Background draft checkpoints." />
                    <AdminStatCard label="Releases" value={selectedSite.analytics.totalReleases} meta="Immutable snapshots created for this site." />
                    <AdminStatCard label="Published pages" value={selectedSite.analytics.totalPublishedPages} meta="Pages currently represented in a live release." />
                    <AdminStatCard label="Contributors" value={selectedSite.analytics.totalContributors} meta="Editors who created revisions on this site." />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Sites" title="Analytics scope" action={<span className="admin-pill">{sites.length} tracked</span>} />

                            <div className="admin-directory-list">
                                {sites.map((site) => (
                                    <Link
                                        key={site.id}
                                        href={`/dashboard/analytics?site=${site.id}`}
                                        preserveScroll
                                        className={`admin-directory-item ${site.isSelected ? 'is-selected' : ''}`}
                                    >
                                        <div className="admin-directory-head">
                                            <div>
                                                <strong>{site.name}</strong>
                                                <small>{site.slug}</small>
                                            </div>
                                            <span className="admin-pill">{site.visibility}</span>
                                        </div>

                                        <div className="admin-chip-row">
                                            <span className="admin-chip">{site.status}</span>
                                            <span className="admin-chip">{site.pagesCount} pages</span>
                                            <span className="admin-chip">{site.releaseCount} releases</span>
                                            {site.currentReleaseVersion ? <span className="admin-chip">{site.currentReleaseVersion}</span> : null}
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Cadence"
                                title="Release and editing signal"
                                action={(
                                    <span className="admin-pill admin-pill-accent">
                                    <Rocket size={12} /> site telemetry
                                    </span>
                                )}
                            />

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">Current release</span>
                                    <strong>{selectedSite.currentReleaseVersion ?? 'Draft only'}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Last published</span>
                                    <strong>{formatDate(selectedSite.currentReleasePublishedAt)}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Events in 7 days</span>
                                    <strong>{selectedSite.analytics.recentEventsLast7Days}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Publishes in 30 days</span>
                                    <strong>{selectedSite.analytics.publishesLast30Days}</strong>
                                </div>
                            </div>

                            <div className="admin-chip-row">
                                <span className="admin-chip">production {selectedSite.analytics.productionReleases}</span>
                                <span className="admin-chip">staging {selectedSite.analytics.stagingReleases}</span>
                                <span className="admin-chip">/{selectedSite.slug}</span>
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Recent activity"
                                title="Revision and release timeline"
                                action={<span className="admin-pill">{selectedSite.activity.length} events</span>}
                            />

                            {selectedSite.activity.length ? (
                                <div className="admin-activity-list">
                                    {selectedSite.activity.map((item) => (
                                        <div key={item.id} className="admin-activity-row">
                                            <div className={`admin-activity-dot is-${item.tone}`} />
                                            <div className="admin-activity-copy">
                                                <div className="admin-activity-head">
                                                    <strong>{item.kind === 'release' ? `Release ${item.title}` : item.title}</strong>
                                                    <span>{formatDate(item.createdAt)}</span>
                                                </div>
                                                <p>{item.message}</p>
                                                <small>
                                                    {item.actor} · {item.meta}
                                                </small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Activity size={16} />}>
                                    No analytics events yet. Save draft revisions or publish a release to start building the timeline.
                                </AdminEmptyState>
                            )}
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}