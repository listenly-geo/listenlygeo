import { Head, Link, router, useForm } from '@inertiajs/react';
import { ArrowUpRight, FileImage, FileText, FileVideo, Folder, FolderOpen, Globe, HardDriveUpload, Image, Search, ShieldCheck, Sparkles, Trash2, Upload } from 'lucide-react';
import { useMemo, useState } from 'react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import { dashboard } from '@/routes';

type MediaPageProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    permissions: {
        canManageMedia: boolean;
    };
    sites: Array<{
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        assetsCount: number;
        pagesCount: number;
        currentReleaseVersion: string | null;
        isSelected: boolean;
    }>;
    selectedSite: {
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        docsUrl: string | null;
        currentReleaseVersion: string | null;
        assetsCount: number;
        assets: Array<{
            id: number;
            name: string;
            url: string;
            mimeType: string;
            sizeBytes: number;
            width: number | null;
            height: number | null;
            uploadedBy: string | null;
            uploadedAt: string | null;
            isImage: boolean;
            isVideo: boolean;
        }>;
    };
    usage: {
        storageBytes: number;
        totalAssets: number;
        siteStorageBytes: number;
    };
    upload: {
        maxFileSizeBytes: number;
        acceptedTypes: string[];
    };
};

function formatBytes(value: number): string {
    if (value <= 0) {
        return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB'];
    const exponent = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
    const size = value / 1024 ** exponent;

    return `${size.toFixed(size >= 10 || exponent === 0 ? 0 : 1)} ${units[exponent]}`;
}

function formatDate(value: string | null): string {
    if (!value) {
        return 'Unknown time';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

function assetKindLabel(mimeType: string, isImage: boolean, isVideo: boolean): string {
    if (isImage) {
        return 'Image';
    }

    if (isVideo) {
        return 'Video';
    }

    if (mimeType === 'application/pdf') {
        return 'PDF';
    }

    if (mimeType === 'application/zip' || mimeType === 'application/x-zip-compressed') {
        return 'ZIP';
    }

    if (mimeType.startsWith('text/')) {
        return 'Text';
    }

    return 'File';
}

function assetExtension(name: string): string {
    const segments = name.split('.');

    return segments.length > 1 ? segments.pop()!.toUpperCase() : 'FILE';
}

export default function DashboardMedia({ organization, permissions, sites, selectedSite, usage, upload }: MediaPageProps) {
    const [queryState, setQueryState] = useState({ siteId: selectedSite.id, value: '' });
    const [uploadInputKey, setUploadInputKey] = useState(0);
    const query = queryState.siteId === selectedSite.id ? queryState.value : '';

    const uploadForm = useForm<{ file: File | null }>({
        file: null,
    });

    const filteredAssets = useMemo(() => {
        const term = query.trim().toLowerCase();

        if (!term) {
            return selectedSite.assets;
        }

        return selectedSite.assets.filter((asset) => {
            const haystack = [asset.name, asset.mimeType, asset.uploadedBy ?? '', assetKindLabel(asset.mimeType, asset.isImage, asset.isVideo)]
                .join(' ')
                .toLowerCase();

            return haystack.includes(term);
        });
    }, [query, selectedSite.assets]);

    const imageCount = useMemo(
        () => selectedSite.assets.filter((asset) => asset.isImage).length,
        [selectedSite.assets],
    );

    const videoCount = useMemo(
        () => selectedSite.assets.filter((asset) => asset.isVideo).length,
        [selectedSite.assets],
    );

    const documentCount = selectedSite.assets.length - imageCount - videoCount;
    const folderPath = `workspace / ${selectedSite.slug}`;

    const handleUpload = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        uploadForm.post(`/dashboard/media/sites/${selectedSite.id}/assets`, {
            preserveScroll: true,
            forceFormData: true,
            onSuccess: () => {
                uploadForm.reset();
                setUploadInputKey((current) => current + 1);
            },
        });
    };

    const handleDelete = (assetId: number) => {
        router.delete(`/dashboard/media/assets/${assetId}`, {
            preserveScroll: true,
        });
    };

    return (
        <>
            <Head title="Media Library" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Media library"
                    title="Upload and govern the asset library."
                    description={`Keep images, videos, PDFs, and supporting files organized by site while staying in the same operational shell as publishing and billing for ${organization.name}.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                Open editor <ArrowUpRight size={14} />
                            </a>

                            {selectedSite.docsUrl ? (
                                <a href={selectedSite.docsUrl} className="admin-secondary-link">
                                    View published docs <Globe size={14} />
                                </a>
                            ) : null}
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Media summary">
                    <AdminStatCard label="Org assets" value={usage.totalAssets} meta="All uploaded assets across the workspace." />
                    <AdminStatCard label="Site assets" value={selectedSite.assetsCount} meta={`Files currently attached to ${selectedSite.name}.`} />
                    <AdminStatCard label="Org storage" value={formatBytes(usage.storageBytes)} meta="Used by all uploaded assets across the workspace." />
                    <AdminStatCard label="Site storage" value={formatBytes(usage.siteStorageBytes)} meta={`Consumed by ${selectedSite.name} assets only.`} />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface admin-media-folder-surface">
                            <AdminCardHeader label="Site folders" title="Browse by folder" action={<span className="admin-pill">{sites.length} folders</span>} />

                            <p className="admin-media-copy">
                                Every site owns one media folder. Files uploaded here become same files your team can use inside editor for that site.
                            </p>

                            <div className="admin-media-folder-list">
                                {sites.map((site) => (
                                    <Link
                                        key={site.id}
                                        href={`/dashboard/media?site=${site.id}`}
                                        preserveScroll
                                        className={`admin-media-folder-card ${site.isSelected ? 'is-selected' : ''}`}
                                    >
                                        <div className="admin-media-folder-row">
                                            <span className="admin-media-folder-icon" aria-hidden="true">
                                                {site.isSelected ? <FolderOpen size={18} /> : <Folder size={18} />}
                                            </span>

                                            <div className="admin-media-folder-copy">
                                                <strong>{site.name}</strong>
                                                <small>{`/${site.slug}`}</small>
                                            </div>

                                            <span className="admin-pill">{site.visibility}</span>
                                        </div>

                                        <div className="admin-chip-row admin-media-folder-chips">
                                            <span className="admin-chip">{site.status}</span>
                                            <span className="admin-chip">{site.assetsCount} assets</span>
                                            <span className="admin-chip">{site.pagesCount} pages</span>
                                            {site.currentReleaseVersion ? <span className="admin-chip">{site.currentReleaseVersion}</span> : null}
                                        </div>

                                        <div className="admin-media-folder-footer">
                                            <span className="admin-media-folder-summary">Editor reads from this site folder.</span>
                                            {site.isSelected ? (
                                                <span className="admin-pill admin-pill-accent">
                                                    <Sparkles size={12} /> open folder
                                                </span>
                                            ) : null}
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface admin-media-browser-surface">
                            <div className="admin-media-browser-head">
                                <div className="admin-media-browser-copy">
                                    <span className="admin-media-browser-path">{folderPath}</span>
                                    <h2>{selectedSite.name} folder</h2>
                                    <p>
                                        Files in this folder are editor-ready for {selectedSite.name}. Open asset here, then use same file inside docs editor for this site.
                                    </p>
                                </div>

                                <div className="admin-media-browser-pills">
                                    <span className="admin-pill admin-pill-accent">
                                        <FolderOpen size={12} /> site folder
                                    </span>
                                    <span className="admin-pill">
                                        <Sparkles size={12} /> available in editor
                                    </span>
                                    {selectedSite.docsUrl ? (
                                        <a href={selectedSite.docsUrl} className="admin-secondary-link admin-secondary-link-inline">
                                            <Globe size={14} /> View docs
                                        </a>
                                    ) : null}
                                </div>
                            </div>

                            <div className="admin-media-toolbar">
                                <label className="admin-media-search" htmlFor="media-library-search">
                                    <Search size={15} />
                                    <input
                                        id="media-library-search"
                                        type="search"
                                        value={query}
                                        onChange={(event) => setQueryState({ siteId: selectedSite.id, value: event.target.value })}
                                        placeholder={`Search inside ${selectedSite.name} folder`}
                                    />
                                </label>

                                <div className="admin-chip-row admin-media-toolbar-chips">
                                    <span className="admin-chip">{selectedSite.assets.length} files</span>
                                    <span className="admin-chip">{imageCount} images</span>
                                    <span className="admin-chip">{videoCount} videos</span>
                                    <span className="admin-chip">{documentCount} docs</span>
                                    <span className="admin-chip">{formatBytes(usage.siteStorageBytes)}</span>
                                </div>
                            </div>

                            <section className="admin-media-upload-card">
                                <div className="admin-media-upload-head">
                                    <div>
                                        <span className="admin-media-section-kicker">Upload into folder</span>
                                        <strong>{`/${selectedSite.slug}`}</strong>
                                        <p>New files land in this site folder and become available inside editor immediately.</p>
                                    </div>

                                    <span className="admin-pill admin-pill-accent">
                                        <Upload size={12} /> {formatBytes(upload.maxFileSizeBytes)} max
                                    </span>
                                </div>

                                {permissions.canManageMedia ? (
                                    <form className="admin-form-grid" onSubmit={handleUpload}>
                                        <label className="admin-field admin-field-full">
                                            <span>Choose file for {selectedSite.name}</span>
                                            <input
                                                key={uploadInputKey}
                                                type="file"
                                                className="admin-file-input admin-media-file-input"
                                                accept={upload.acceptedTypes.join(',')}
                                                onChange={(event) => uploadForm.setData('file', event.target.files?.[0] ?? null)}
                                            />
                                            <small className="admin-field-hint">PNG, JPEG, GIF, WEBP, SVG, MP4, WEBM, OGG, PDF, ZIP, and TXT stay inside this site folder.</small>
                                            <InputError message={uploadForm.errors.file} />
                                        </label>

                                        <div className="admin-form-actions admin-field-full admin-media-upload-actions">
                                            <button type="submit" className="admin-button admin-button-primary" disabled={uploadForm.processing || !uploadForm.data.file}>
                                                {uploadForm.processing ? 'Uploading…' : `Upload to ${selectedSite.name}`}
                                            </button>
                                            {uploadForm.progress ? <span className="admin-inline-progress">{uploadForm.progress.percentage}%</span> : null}
                                        </div>
                                    </form>
                                ) : (
                                    <AdminEmptyState icon={<ShieldCheck size={16} />}>
                                        Only owners, admins, and editors can upload or remove assets. Folder still visible for browsing.
                                    </AdminEmptyState>
                                )}
                            </section>

                            <section>
                                <AdminCardHeader
                                    label="Folder contents"
                                    title={query ? `Search results in ${selectedSite.name}` : `Assets inside ${selectedSite.name}`}
                                    action={<span className="admin-pill">{filteredAssets.length} shown</span>}
                                />

                                {filteredAssets.length ? (
                                    <div className="admin-media-file-grid">
                                        {filteredAssets.map((asset) => (
                                            <article key={asset.id} className="admin-media-file-card">
                                                <div className="admin-media-file-preview">
                                                    <div className="admin-media-file-top">
                                                        <span className="admin-chip">{assetKindLabel(asset.mimeType, asset.isImage, asset.isVideo)}</span>
                                                        <span className="admin-pill admin-pill-accent">
                                                            <Sparkles size={12} /> editor ready
                                                        </span>
                                                    </div>

                                                    {asset.isImage ? (
                                                        <img src={asset.url} alt={asset.name} className="admin-media-file-image" />
                                                    ) : asset.isVideo ? (
                                                        <video src={asset.url} className="admin-media-file-image" controls preload="metadata" playsInline />
                                                    ) : (
                                                        <div className="admin-media-file-fallback">
                                                            <FileText size={24} />
                                                            <span>{assetExtension(asset.name)}</span>
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="admin-media-file-copy">
                                                    <div className="admin-media-file-title-row">
                                                        <strong>{asset.name}</strong>
                                                        {asset.isImage ? <Image size={14} /> : asset.isVideo ? <FileVideo size={14} /> : <FileImage size={14} />}
                                                    </div>
                                                    <small>{asset.mimeType}</small>
                                                    <small>
                                                        {formatBytes(asset.sizeBytes)}
                                                        {asset.width !== null && asset.height !== null ? ` · ${asset.width}x${asset.height}` : ''}
                                                    </small>
                                                    <small>{asset.uploadedBy ?? 'Unknown uploader'} · {formatDate(asset.uploadedAt)}</small>
                                                </div>

                                                <div className="admin-media-file-actions">
                                                    <a href={asset.url} target="_blank" rel="noreferrer" className="admin-secondary-link admin-secondary-link-inline">
                                                        {asset.isImage ? <FileImage size={14} /> : asset.isVideo ? <FileVideo size={14} /> : <FileText size={14} />}
                                                        Open asset
                                                    </a>

                                                    {permissions.canManageMedia ? (
                                                        <button
                                                            type="button"
                                                            className="admin-button admin-button-secondary"
                                                            onClick={() => handleDelete(asset.id)}
                                                        >
                                                            <Trash2 size={14} /> Remove
                                                        </button>
                                                    ) : null}
                                                </div>
                                            </article>
                                        ))}
                                    </div>
                                ) : (
                                    <AdminEmptyState icon={query ? <Search size={16} /> : <HardDriveUpload size={16} />}>
                                        {query
                                            ? `No files matched “${query}” inside ${selectedSite.name}.`
                                            : 'No assets in this folder yet. Upload first file and this site folder becomes your editor media source.'}
                                    </AdminEmptyState>
                                )}
                            </section>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}