import { Head, Link, useForm } from '@inertiajs/react';
import { ArrowUpRight, Building2, CreditCard, HardDriveUpload, ReceiptText, ShieldCheck, Users, WalletCards } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero, AdminStatCard, AdminStatGrid } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import { dashboard } from '@/routes';

type PlanKey = string;
type BillingInterval = 'monthly' | 'annual';
type SubscriptionStatus = 'trialing' | 'active' | 'past_due' | 'canceled' | 'incomplete';
type GatewayProvider = string;
type GatewayMode = 'test' | 'live';
type GatewayStatus = string;

type PlanCatalogItem = {
    key: PlanKey;
    label: string;
    description: string;
    monthlyPriceCents: number;
    annualPriceCents: number;
    includedSites: number;
    includedMembers: number;
    includedPublishedPages: number;
    includedStorageBytes: number;
    isFree: boolean;
    isCurrent: boolean;
};

type PlatformAccount = {
    id: number;
    name: string;
    slug: string;
    billingEmail: string | null;
    plan: PlanKey;
    interval: BillingInterval;
    status: SubscriptionStatus;
    cancelAtPeriodEnd: boolean;
    currentPeriodEndsAt: string | null;
    amountCents: number;
    memberCount: number;
    siteCount: number;
};

type BillingPageProps = {
    billingMode: 'platform' | 'customer';
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    permissions: {
        canManageBilling: boolean;
        canManageCustomerBilling?: boolean;
        canManagePlatformBilling?: boolean;
    };
    subscription: {
        plan: PlanKey;
        interval: BillingInterval;
        status: SubscriptionStatus;
        cancelAtPeriodEnd: boolean;
        currentPeriodStartsAt: string | null;
        currentPeriodEndsAt: string | null;
        amountCents: number;
        stripeConfigured: boolean;
        stripeSubscriptionId: string | null;
        stripePriceId: string | null;
        stripeSyncedAt: string | null;
    };
    usage: {
        siteCount: number;
        memberCount: number;
        publishedPageCount: number;
        storageBytes: number;
        limits: {
            sites: number;
            members: number;
            publishedPages: number;
            storageBytes: number;
        };
    };
    plans: PlanCatalogItem[];
    platformBilling: {
        summary: {
            customerCount: number;
            activeSubscriptionCount: number;
            pastDueCount: number;
            monthlyRecurringRevenueCents: number;
        };
        accounts: PlatformAccount[];
    } | null;
    paymentGateway: {
        provider: GatewayProvider;
        mode: GatewayMode;
        status: GatewayStatus;
        publicKey: string | null;
        webhookEndpoint: string | null;
        providers: Array<{ key: GatewayProvider; label: string }>;
        statuses: Array<{ key: GatewayStatus; label: string }>;
    } | null;
};

function formatMoney(amountCents: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0,
    }).format(amountCents / 100);
}

function formatBytes(value: number): string {
    if (value <= 0) {
        return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const exponent = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
    const size = value / 1024 ** exponent;

    return `${size.toFixed(size >= 10 || exponent === 0 ? 0 : 1)} ${units[exponent]}`;
}

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not scheduled';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

function resolvePeriodEndDate(startAt: string | null, endAt: string | null, interval: BillingInterval): string | null {
    if (endAt) {
        return endAt;
    }

    if (!startAt) {
        return null;
    }

    const date = new Date(startAt);

    if (Number.isNaN(date.getTime())) {
        return null;
    }

    if (interval === 'annual') {
        date.setFullYear(date.getFullYear() + 1);
    } else {
        date.setMonth(date.getMonth() + 1);
    }

    return date.toISOString();
}

function usageRatio(used: number, included: number): number {
    if (included <= 0) {
        return 0;
    }

    return Math.min((used / included) * 100, 100);
}

function humanStatus(value: string): string {
    return value.replaceAll('_', ' ');
}

const fallbackPlan: PlanCatalogItem = {
    key: 'free',
    label: 'Free',
    description: 'Start publishing with a small workspace before upgrading.',
    monthlyPriceCents: 0,
    annualPriceCents: 0,
    includedSites: 1,
    includedMembers: 1,
    includedPublishedPages: 25,
    includedStorageBytes: 268_435_456,
    isFree: true,
    isCurrent: true,
};

export default function DashboardBilling({ billingMode, organization, permissions, subscription, usage, plans, platformBilling, paymentGateway }: BillingPageProps) {
    const platformAccounts = platformBilling?.accounts ?? [];
    const firstPlatformAccount = platformAccounts[0];

    const billingForm = useForm({
        organizationId: billingMode === 'platform' ? firstPlatformAccount?.id ?? null : null,
        billingEmail: billingMode === 'platform' ? firstPlatformAccount?.billingEmail ?? '' : organization.billingEmail ?? '',
        plan: billingMode === 'platform' ? firstPlatformAccount?.plan ?? subscription.plan : subscription.plan,
        interval: billingMode === 'platform' ? firstPlatformAccount?.interval ?? subscription.interval : subscription.interval,
        status: billingMode === 'platform' ? firstPlatformAccount?.status ?? subscription.status : subscription.status,
        cancelAtPeriodEnd: billingMode === 'platform' ? firstPlatformAccount?.cancelAtPeriodEnd ?? subscription.cancelAtPeriodEnd : subscription.cancelAtPeriodEnd,
    });

    const gatewayForm = useForm({
        provider: paymentGateway?.provider ?? 'stripe',
        mode: paymentGateway?.mode ?? 'test',
        status: paymentGateway?.status ?? 'setup_required',
        publicKey: paymentGateway?.publicKey ?? '',
        webhookEndpoint: paymentGateway?.webhookEndpoint ?? '',
    });

    const handleBillingSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        billingForm.patch(billingMode === 'platform' ? '/admin/commerce' : '/dashboard/billing', {
            preserveScroll: true,
        });
    };

    const handleGatewaySubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        gatewayForm.patch('/admin/commerce/gateway', {
            preserveScroll: true,
        });
    };

    const handlePlatformAccountChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const account = platformAccounts.find((item) => item.id === Number(event.target.value));

        if (!account) {
            return;
        }

        billingForm.setData('organizationId', account.id);
        billingForm.setData('billingEmail', account.billingEmail ?? '');
        billingForm.setData('plan', account.plan);
        billingForm.setData('interval', account.interval);
        billingForm.setData('status', account.status);
        billingForm.setData('cancelAtPeriodEnd', account.cancelAtPeriodEnd);
    };

    const currentPlan = plans.find((plan) => plan.key === billingForm.data.plan) ?? plans[0] ?? fallbackPlan;
    const currentAmount = billingForm.data.interval === 'annual' ? currentPlan.annualPriceCents : currentPlan.monthlyPriceCents;
    const renewalAt = resolvePeriodEndDate(subscription.currentPeriodStartsAt, subscription.currentPeriodEndsAt, subscription.interval);

    const usageRows = [
        {
            label: 'Sites',
            used: usage.siteCount,
            included: usage.limits.sites,
            display: `${usage.siteCount} / ${usage.limits.sites}`,
            icon: CreditCard,
        },
        {
            label: 'Members',
            used: usage.memberCount,
            included: usage.limits.members,
            display: `${usage.memberCount} / ${usage.limits.members}`,
            icon: Users,
        },
        {
            label: 'Published pages',
            used: usage.publishedPageCount,
            included: usage.limits.publishedPages,
            display: `${usage.publishedPageCount} / ${usage.limits.publishedPages}`,
            icon: ArrowUpRight,
        },
        {
            label: 'Storage',
            used: usage.storageBytes,
            included: usage.limits.storageBytes,
            display: `${formatBytes(usage.storageBytes)} / ${formatBytes(usage.limits.storageBytes)}`,
            icon: HardDriveUpload,
        },
    ];

    if (billingMode === 'platform') {
        const platformSummary = platformBilling?.summary ?? {
            customerCount: 0,
            activeSubscriptionCount: 0,
            pastDueCount: 0,
            monthlyRecurringRevenueCents: 0,
        };

        return (
            <>
                <Head title="Commerce" />

                <div className="admin-page-wrap">
                    <AdminPageHero
                        eyebrow="Commerce"
                        title="Manage plans, customer bills, and payment gateways."
                        description="Control subscription accounts, plan posture, invoices, and checkout configuration across the application."
                    />

                    <AdminStatGrid ariaLabel="Platform commerce summary">
                        <AdminStatCard label="Customers" value={platformSummary.customerCount.toLocaleString()} meta="Organizations with billing accounts" />
                        <AdminStatCard label="Active subscriptions" value={platformSummary.activeSubscriptionCount.toLocaleString()} meta={`${platformSummary.pastDueCount} past due`} />
                        <AdminStatCard label="MRR" value={formatMoney(platformSummary.monthlyRecurringRevenueCents)} meta="Normalized monthly revenue" />
                        <AdminStatCard label="Gateway" value={humanStatus(paymentGateway?.status ?? 'setup_required')} meta={paymentGateway?.provider ?? 'stripe'} />
                    </AdminStatGrid>

                    <section className="admin-management-grid">
                        <div className="admin-column-stack">
                            <section className="admin-surface">
                                <AdminCardHeader label="Customer subscriptions" title="Plan and bill controls" action={<span className="admin-pill admin-pill-accent">platform admin</span>} />

                                {platformAccounts.length > 0 ? (
                                    <form className="admin-form-grid" onSubmit={handleBillingSubmit}>
                                        <label className="admin-field admin-field-full">
                                            <span>Customer account</span>
                                            <select className="admin-select-input" value={billingForm.data.organizationId ?? ''} onChange={handlePlatformAccountChange}>
                                                {platformAccounts.map((account) => (
                                                    <option key={account.id} value={account.id}>
                                                        {account.name} - {account.plan} / {account.status}
                                                    </option>
                                                ))}
                                            </select>
                                            <InputError message={billingForm.errors.organizationId} />
                                        </label>

                                        <label className="admin-field admin-field-full">
                                            <span>Billing email</span>
                                            <input
                                                type="email"
                                                className="admin-text-input"
                                                value={billingForm.data.billingEmail}
                                                onChange={(event) => billingForm.setData('billingEmail', event.target.value)}
                                                placeholder="finance@example.com"
                                            />
                                            <InputError message={billingForm.errors.billingEmail} />
                                        </label>

                                        <label className="admin-field">
                                            <span>Plan</span>
                                            <select className="admin-select-input" value={billingForm.data.plan} onChange={(event) => billingForm.setData('plan', event.target.value as PlanKey)}>
                                                {plans.map((plan) => (
                                                    <option key={plan.key} value={plan.key}>
                                                        {plan.label}
                                                    </option>
                                                ))}
                                            </select>
                                            <InputError message={billingForm.errors.plan} />
                                        </label>

                                        <label className="admin-field">
                                            <span>Interval</span>
                                            <select className="admin-select-input" value={billingForm.data.interval} onChange={(event) => billingForm.setData('interval', event.target.value as BillingInterval)}>
                                                <option value="monthly">Monthly</option>
                                                <option value="annual">Annual</option>
                                            </select>
                                            <InputError message={billingForm.errors.interval} />
                                        </label>

                                        <label className="admin-field">
                                            <span>Status</span>
                                            <select className="admin-select-input" value={billingForm.data.status} onChange={(event) => billingForm.setData('status', event.target.value as SubscriptionStatus)}>
                                                <option value="trialing">Trialing</option>
                                                <option value="active">Active</option>
                                                <option value="past_due">Past due</option>
                                                <option value="canceled">Canceled</option>
                                                <option value="incomplete">Incomplete</option>
                                            </select>
                                            <InputError message={billingForm.errors.status} />
                                        </label>

                                        <label className="admin-checkbox-row admin-field-full">
                                            <input
                                                type="checkbox"
                                                checked={billingForm.data.cancelAtPeriodEnd}
                                                onChange={(event) => billingForm.setData('cancelAtPeriodEnd', event.target.checked)}
                                            />
                                            <div>
                                                <strong>Cancel at period end</strong>
                                                <small>Keep customer access through the current cycle and stop the next renewal.</small>
                                            </div>
                                        </label>

                                        <div className="admin-form-actions admin-field-full">
                                            <button type="submit" className="admin-button admin-button-primary" disabled={billingForm.processing}>
                                                {billingForm.processing ? 'Saving...' : 'Update customer billing'}
                                            </button>
                                        </div>
                                    </form>
                                ) : (
                                    <AdminEmptyState icon={<Building2 size={16} />}>No customer accounts have been created yet.</AdminEmptyState>
                                )}
                            </section>

                            <section className="admin-surface">
                                <AdminCardHeader label="Plan catalog" title="Application subscription tiers" />

                                <div className="admin-plan-grid">
                                    {plans.map((plan) => (
                                        <div key={plan.key} className={`admin-plan-card ${billingForm.data.plan === plan.key ? 'is-current' : ''}`}>
                                            <div className="admin-plan-copy">
                                                <div className="admin-plan-head">
                                                    <strong>{plan.label}</strong>
                                                    <span className="admin-pill">{formatMoney(plan.monthlyPriceCents)}/mo</span>
                                                </div>
                                                <p>{plan.description}</p>
                                            </div>
                                            <div className="admin-plan-meta">
                                                <span>{plan.includedSites} sites</span>
                                                <span>{plan.includedMembers} members</span>
                                                <span>{plan.includedPublishedPages} published pages</span>
                                                <span>{formatBytes(plan.includedStorageBytes)} storage</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>
                        </div>

                        <div className="admin-column-stack">
                            <section className="admin-surface">
                                <AdminCardHeader label="Payment gateway" title="Checkout and invoice routing" action={<span className="admin-pill">{paymentGateway?.mode ?? 'test'}</span>} />

                                <form className="admin-form-grid" onSubmit={handleGatewaySubmit}>
                                    <label className="admin-field">
                                        <span>Provider</span>
                                        <select className="admin-select-input" value={gatewayForm.data.provider} onChange={(event) => gatewayForm.setData('provider', event.target.value as GatewayProvider)}>
                                            {(paymentGateway?.providers ?? [{ key: 'stripe' as const, label: 'Stripe' }]).map((provider) => (
                                                <option key={provider.key} value={provider.key}>
                                                    {provider.label}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={gatewayForm.errors.provider} />
                                    </label>

                                    <label className="admin-field">
                                        <span>Mode</span>
                                        <select className="admin-select-input" value={gatewayForm.data.mode} onChange={(event) => gatewayForm.setData('mode', event.target.value as GatewayMode)}>
                                            <option value="test">Test</option>
                                            <option value="live">Live</option>
                                        </select>
                                        <InputError message={gatewayForm.errors.mode} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Status</span>
                                        <select className="admin-select-input" value={gatewayForm.data.status} onChange={(event) => gatewayForm.setData('status', event.target.value as GatewayStatus)}>
                                            {(paymentGateway?.statuses ?? [{ key: 'setup_required' as const, label: 'Setup Required' }]).map((status) => (
                                                <option key={status.key} value={status.key}>
                                                    {status.label}
                                                </option>
                                            ))}
                                        </select>
                                        <InputError message={gatewayForm.errors.status} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Publishable key</span>
                                        <input
                                            type="text"
                                            className="admin-text-input"
                                            value={gatewayForm.data.publicKey}
                                            onChange={(event) => gatewayForm.setData('publicKey', event.target.value)}
                                            placeholder="pk_live_..."
                                        />
                                        <InputError message={gatewayForm.errors.publicKey} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Webhook endpoint</span>
                                        <input
                                            type="url"
                                            className="admin-text-input"
                                            value={gatewayForm.data.webhookEndpoint}
                                            onChange={(event) => gatewayForm.setData('webhookEndpoint', event.target.value)}
                                            placeholder="https://example.com/webhooks/stripe"
                                        />
                                        <InputError message={gatewayForm.errors.webhookEndpoint} />
                                    </label>

                                    <div className="admin-form-actions admin-field-full">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={gatewayForm.processing}>
                                            {gatewayForm.processing ? 'Saving...' : 'Save gateway'}
                                        </button>
                                    </div>
                                </form>
                            </section>

                            <section className="admin-surface">
                                <AdminCardHeader label="Bills" title="Customer billing accounts" action={<WalletCards size={16} />} />

                                <div className="admin-billing-account-list">
                                    {platformAccounts.map((account) => (
                                        <div key={account.id} className="admin-billing-account-row">
                                            <div className="admin-list-leading">
                                                <ReceiptText size={14} />
                                                <div>
                                                    <strong>{account.name}</strong>
                                                    <small>{account.billingEmail ?? 'No billing email'} / {account.siteCount} sites / {account.memberCount} members</small>
                                                </div>
                                            </div>
                                            <div className="admin-billing-account-meta">
                                                <span>{formatMoney(account.amountCents)}</span>
                                                <small>{account.plan} / {account.status}</small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>
                        </div>
                    </section>
                </div>
            </>
        );
    }

    return (
        <>
            <Head title="Plans & Billing" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Plans & Billing"
                    title="Manage your documentation subscription."
                    description={`Keep plan selection, billing contact, renewal state, and workspace usage visible in one place for ${organization.name}.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                Open editor <ArrowUpRight size={14} />
                            </a>
                        </>
                    )}
                />

                <AdminStatGrid ariaLabel="Billing summary">
                    <AdminStatCard label="Current plan" value={currentPlan.label} meta={`${subscription.status} / ${billingForm.data.interval}`} />
                    <AdminStatCard label="Renewal" value={formatDate(renewalAt)} meta={subscription.cancelAtPeriodEnd ? 'Cancels at period end' : 'Auto-renews'} />
                    <AdminStatCard label="Charge" value={formatMoney(currentAmount)} meta={billingForm.data.interval === 'annual' ? 'Annual subscription' : 'Monthly subscription'} />
                    <AdminStatCard label="Billing contact" value={<span className="billing-stat-value">{organization.billingEmail ?? 'Not set'}</span>} meta="Invoices and plan notices route here." />
                </AdminStatGrid>

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Subscription controls" title="Workspace billing configuration" action={<span className="admin-pill admin-pill-accent">{currentPlan.label}</span>} />

                            {permissions.canManageBilling ? (
                                <form className="admin-form-grid" onSubmit={handleBillingSubmit}>
                                    <label className="admin-field admin-field-full">
                                        <span>Billing email</span>
                                        <input
                                            type="email"
                                            className="admin-text-input"
                                            value={billingForm.data.billingEmail}
                                            onChange={(event) => billingForm.setData('billingEmail', event.target.value)}
                                            placeholder="finance@example.com"
                                        />
                                        <InputError message={billingForm.errors.billingEmail} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Preferred billing interval</span>
                                        <select className="admin-select-input" value={billingForm.data.interval} onChange={(event) => billingForm.setData('interval', event.target.value as BillingInterval)}>
                                            <option value="monthly">Monthly</option>
                                            <option value="annual">Annual</option>
                                        </select>
                                    </label>

                                    <div className="admin-form-actions admin-billing-actions admin-field-full">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={billingForm.processing}>
                                            {billingForm.processing ? 'Saving...' : 'Save billing settings'}
                                        </button>
                                        {subscription.stripeSubscriptionId && !subscription.cancelAtPeriodEnd ? (
                                            <Link href="/dashboard/billing/cancel" method="post" as="button" className="admin-button admin-button-secondary">
                                                Cancel subscription
                                            </Link>
                                        ) : null}
                                        {subscription.cancelAtPeriodEnd ? (
                                            <Link href="/dashboard/billing/resume" method="post" as="button" className="admin-button admin-button-secondary">
                                                Resume subscription
                                            </Link>
                                        ) : null}
                                    </div>
                                </form>
                            ) : (
                                <AdminEmptyState icon={<ShieldCheck size={16} />}>
                                    Only customer owners and admins can change plan or billing details. You still have visibility into the current subscription and usage posture.
                                </AdminEmptyState>
                            )}
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Plan catalog" title="Available workspace tiers" />

                            <div className="admin-plan-grid">
                                {plans.map((plan) => (
                                    <div key={plan.key} className={`admin-plan-card ${subscription.plan === plan.key ? 'is-current' : ''}`}>
                                        <div className="admin-plan-copy">
                                            <div className="admin-plan-head">
                                                <strong>{plan.label}</strong>
                                                {subscription.plan === plan.key ? <span className="admin-pill admin-pill-accent">current</span> : null}
                                            </div>
                                            <p>{plan.description}</p>
                                        </div>
                                        <div className="admin-plan-price">
                                            {formatMoney(billingForm.data.interval === 'annual' ? plan.annualPriceCents : plan.monthlyPriceCents)}
                                        </div>
                                        <div className="admin-plan-meta">
                                            <span>{plan.includedSites} sites</span>
                                            <span>{plan.includedMembers} members</span>
                                            <span>{plan.includedPublishedPages} published pages</span>
                                            <span>{formatBytes(plan.includedStorageBytes)} storage</span>
                                        </div>
                                        <div className="admin-plan-card-footer">
                                            {subscription.plan === plan.key ? (
                                                <span className="admin-pill admin-pill-accent">Current plan</span>
                                            ) : permissions.canManageBilling ? (
                                                <Link
                                                    href="/dashboard/billing/checkout"
                                                    method="post"
                                                    data={{ plan: plan.key, interval: billingForm.data.interval }}
                                                    as="button"
                                                    className="admin-button admin-button-primary"
                                                >
                                                    {plan.isFree ? 'Move to free' : subscription.stripeSubscriptionId ? 'Change plan' : 'Subscribe'}
                                                </Link>
                                            ) : null}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Current subscription" title={`${currentPlan.label} workspace posture`} action={<span className="admin-pill">{subscription.status}</span>} />

                            <div className="admin-site-grid">
                                <div>
                                    <span className="admin-site-key">Interval</span>
                                    <strong>{subscription.interval}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Renews</span>
                                    <strong>{formatDate(subscription.currentPeriodEndsAt)}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Amount</span>
                                    <strong>{formatMoney(subscription.amountCents)}</strong>
                                </div>
                                <div>
                                    <span className="admin-site-key">Billing email</span>
                                    <strong>{organization.billingEmail ?? 'Not set'}</strong>
                                </div>
                            </div>

                            <div className="admin-status-line">
                                {subscription.cancelAtPeriodEnd ? 'Cancellation is scheduled for the end of the current billing period.' : 'This subscription will renew automatically unless you change it.'}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Usage against plan" title="Workspace consumption" />

                            <div className="admin-usage-list">
                                {usageRows.map((row) => {
                                    const Icon = row.icon;

                                    return (
                                        <div key={row.label} className="admin-usage-row">
                                            <div className="admin-usage-head">
                                                <div className="admin-list-leading">
                                                    <Icon size={14} />
                                                    <div>
                                                        <strong>{row.label}</strong>
                                                        <small>{row.display}</small>
                                                    </div>
                                                </div>
                                                <span>{Math.round(usageRatio(row.used, row.included))}%</span>
                                            </div>
                                            <div className="admin-usage-meter">
                                                <div className="admin-usage-fill" style={{ width: `${usageRatio(row.used, row.included)}%` }} />
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}
