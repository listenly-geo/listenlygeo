import { Head, Link, router, useForm } from '@inertiajs/react';
import { ArrowUpRight, Check, Globe, Palette, Settings2, ShieldCheck } from 'lucide-react';
import { AdminCardHeader, AdminEmptyState, AdminPageHero } from '@/components/admin/page-primitives';
import InputError from '@/components/input-error';
import { docsThemeOptions } from '@/pages/docs/themes/catalog';
import type { DocsThemeId, DocsThemeOptions } from '@/pages/docs/themes/catalog';
import { useAddon } from '@/hooks/use-addons';
import { dashboard } from '@/routes';

type DashboardSettingsProps = {
    organization: {
        name: string;
        slug: string;
        billingEmail: string | null;
    };
    permissions: {
        canManageSettings: boolean;
    };
    sites: Array<{
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        domainsCount: number;
        pagesCount: number;
        currentReleaseVersion: string | null;
        isSelected: boolean;
    }>;
    selectedSite: {
        id: number;
        name: string;
        slug: string;
        status: string;
        visibility: string;
        docsUrl: string | null;
        currentReleaseVersion: string | null;
        branding: {
            brandName: string;
            logoUrl: string | null;
            tagline: string | null;
        };
        seo: {
            title: string | null;
            description: string | null;
        };
        appearance: {
            docsTheme: DocsThemeId;
            docsThemeOptions: DocsThemeOptions;
        };
        domains: Array<{
            id: number;
            host: string;
            isPrimary: boolean;
            status: string;
            dnsTarget: string | null;
            verifiedAt: string | null;
        }>;
    };
};

function formatDate(value: string | null): string {
    if (!value) {
        return 'Not verified yet';
    }

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(new Date(value));
}

export default function DashboardSettings({ organization, permissions, sites, selectedSite }: DashboardSettingsProps) {
    const settingsForm = useForm({
        brandName: selectedSite.branding.brandName,
        tagline: selectedSite.branding.tagline ?? '',
        seoTitle: selectedSite.seo.title ?? '',
        seoDescription: selectedSite.seo.description ?? '',
        docsTheme: selectedSite.appearance.docsTheme,
    });

    const domainForm = useForm({
        host: '',
    });

    const handleSettingsSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        settingsForm.patch(`/dashboard/settings/sites/${selectedSite.id}`, {
            preserveScroll: true,
        });
    };

    const handleDomainSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        domainForm.post(`/dashboard/settings/sites/${selectedSite.id}/domains`, {
            preserveScroll: true,
            onSuccess: () => domainForm.reset(),
        });
    };

    const handlePrimaryDomain = (domainId: number) => {
        router.patch(`/dashboard/settings/domains/${domainId}/primary`, {}, {
            preserveScroll: true,
        });
    };

    const hasDocsThemeAddon = useAddon('docs-theme');
    const availableThemes = docsThemeOptions.filter((t) => t.id !== 'laravel' || hasDocsThemeAddon);
    const previewTitle = settingsForm.data.seoTitle || settingsForm.data.brandName || selectedSite.name;
    const previewDescription = settingsForm.data.seoDescription || settingsForm.data.tagline || 'Published documentation for your product surface.';
    const selectedTheme = availableThemes.find((theme) => theme.id === settingsForm.data.docsTheme) ?? availableThemes[0];

    return (
        <>
            <Head title="Settings" />

            <div className="admin-page-wrap">
                <AdminPageHero
                    eyebrow="Settings"
                    title="Configure domains, SEO, and brand framing."
                    description={`This keeps delivery settings out of the editor while still changing what readers see when they open ${organization.name} documentation.`}
                    actions={(
                        <>
                            <Link href={dashboard().url} className="admin-secondary-link">
                                Back to overview
                            </Link>

                            <a href="/editor" className="admin-primary-link">
                                Open editor <ArrowUpRight size={14} />
                            </a>

                            {selectedSite.docsUrl ? (
                                <a href={selectedSite.docsUrl} className="admin-secondary-link">
                                    View published docs <Globe size={14} />
                                </a>
                            ) : null}
                        </>
                    )}
                />

                <section className="admin-management-grid">
                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Sites" title="Settings scope" action={<span className="admin-pill">{sites.length} tracked</span>} />

                            <div className="admin-directory-list">
                                {sites.map((site) => (
                                    <Link
                                        key={site.id}
                                        href={`/dashboard/settings?site=${site.id}`}
                                        preserveScroll
                                        className={`admin-directory-item ${site.isSelected ? 'is-selected' : ''}`}
                                    >
                                        <div className="admin-directory-head">
                                            <div>
                                                <strong>{site.name}</strong>
                                                <small>{site.slug}</small>
                                            </div>
                                            <span className="admin-pill">{site.visibility}</span>
                                        </div>

                                        <div className="admin-chip-row">
                                            <span className="admin-chip">{site.status}</span>
                                            <span className="admin-chip">{site.domainsCount} domains</span>
                                            <span className="admin-chip">{site.pagesCount} pages</span>
                                            {site.currentReleaseVersion ? <span className="admin-chip">{site.currentReleaseVersion}</span> : null}
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader
                                label="Public metadata"
                                title="SEO and branding"
                                action={(
                                    <span className="admin-pill admin-pill-accent">
                                    <Settings2 size={12} /> live docs payload
                                    </span>
                                )}
                            />

                            {permissions.canManageSettings ? (
                                <form className="admin-form-grid" onSubmit={handleSettingsSubmit}>
                                    <label className="admin-field">
                                        <span>Brand name</span>
                                        <input
                                            type="text"
                                            className="admin-text-input"
                                            value={settingsForm.data.brandName}
                                            onChange={(event) => settingsForm.setData('brandName', event.target.value)}
                                        />
                                        <InputError message={settingsForm.errors.brandName} />
                                    </label>

                                    <label className="admin-field">
                                        <span>SEO title</span>
                                        <input
                                            type="text"
                                            className="admin-text-input"
                                            value={settingsForm.data.seoTitle}
                                            onChange={(event) => settingsForm.setData('seoTitle', event.target.value)}
                                            placeholder="Acme Developer Docs"
                                        />
                                        <InputError message={settingsForm.errors.seoTitle} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>Tagline</span>
                                        <input
                                            type="text"
                                            className="admin-text-input"
                                            value={settingsForm.data.tagline}
                                            onChange={(event) => settingsForm.setData('tagline', event.target.value)}
                                            placeholder="Guides, references, and release notes for your product."
                                        />
                                        <InputError message={settingsForm.errors.tagline} />
                                    </label>

                                    <label className="admin-field admin-field-full">
                                        <span>SEO description</span>
                                        <textarea
                                            className="admin-textarea-input"
                                            value={settingsForm.data.seoDescription}
                                            onChange={(event) => settingsForm.setData('seoDescription', event.target.value)}
                                            placeholder="Concise search summary for published docs pages."
                                            rows={4}
                                        />
                                        <InputError message={settingsForm.errors.seoDescription} />
                                    </label>

                                    <div className="admin-field admin-field-full">
                                        <span>Docs theme template</span>
                                        <div className="grid gap-3 md:grid-cols-2">
                                            {availableThemes.map((theme) => {
                                                const isSelected = settingsForm.data.docsTheme === theme.id;

                                                return (
                                                    <button
                                                        key={theme.id}
                                                        type="button"
                                                        className={`flex min-h-[118px] flex-col justify-between rounded-lg border p-4 text-left transition ${
                                                            isSelected
                                                                ? 'border-[#1f4c40] bg-[rgba(31,76,64,0.07)] shadow-[0_16px_42px_-32px_rgba(31,76,64,0.65)] ring-1 ring-[#1f4c40]/20'
                                                                : 'border-[var(--border)] bg-[var(--bg-elevated)] hover:border-[var(--border-strong)] hover:bg-[var(--bg-subtle)]'
                                                        }`}
                                                        onClick={() => settingsForm.setData('docsTheme', theme.id)}
                                                        aria-pressed={isSelected}
                                                    >
                                                        <div className="flex items-start justify-between gap-3">
                                                            <div>
                                                                <strong className="block text-sm font-semibold text-[var(--text)]">{theme.name}</strong>
                                                                <p className="mt-1 text-sm leading-6 text-[var(--text-muted)]">{theme.description}</p>
                                                                <small className="mt-2 block font-mono text-xs text-[var(--text-muted)]">themes/{theme.id}</small>
                                                            </div>
                                                            <div className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border ${isSelected ? 'border-[#1f4c40] bg-[#1f4c40] text-white' : 'border-[var(--border)] text-transparent'}`}>
                                                                <Check size={13} />
                                                            </div>
                                                        </div>
                                                        <div className="mt-4 flex items-center gap-2">
                                                            {theme.swatches.map((color) => (
                                                                <div
                                                                    key={`${theme.id}-${color}`}
                                                                    className="h-6 flex-1 rounded-md border border-black/10"
                                                                    style={{ background: color }}
                                                                />
                                                            ))}
                                                        </div>
                                                    </button>
                                                );
                                            })}
                                        </div>
                                        <InputError message={settingsForm.errors.docsTheme} />
                                    </div>

                                    <div className="admin-form-actions admin-field-full">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={settingsForm.processing}>
                                            {settingsForm.processing ? 'Saving…' : 'Save settings'}
                                        </button>
                                    </div>
                                </form>
                            ) : (
                                <AdminEmptyState icon={<ShieldCheck size={16} />}>
                                    Only owners and admins can change domains or public metadata. You still have visibility into the current configuration.
                                </AdminEmptyState>
                            )}
                        </section>
                    </div>

                    <div className="admin-column-stack">
                        <section className="admin-surface">
                            <AdminCardHeader label="Metadata preview" title="What readers and search engines will see" />

                            <div className="admin-preview-card">
                                <div className="admin-preview-kicker">Search result preview</div>
                                <div className="admin-preview-title">{previewTitle}</div>
                                <div className="admin-preview-url">{selectedSite.docsUrl ?? `/docs/${selectedSite.slug}`}</div>
                                <p className="admin-preview-description">{previewDescription}</p>
                            </div>

                            <div className="admin-preview-card" style={{ marginTop: 12 }}>
                                <div className="admin-preview-kicker">Reader theme</div>
                                <div className="admin-preview-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                    <Palette size={16} /> {selectedTheme.name}
                                </div>
                                <p className="admin-preview-description">{selectedTheme.description}</p>
                                <div className="admin-preview-url">themes/{selectedTheme.id}</div>
                                <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                                    {selectedTheme.swatches.map((color) => (
                                        <div
                                            key={`preview-${selectedTheme.id}-${color}`}
                                            style={{
                                                background: color,
                                                border: '1px solid var(--border)',
                                                borderRadius: 8,
                                                flex: 1,
                                                height: 34,
                                            }}
                                        />
                                    ))}
                                </div>
                            </div>
                        </section>

                        <section className="admin-surface">
                            <AdminCardHeader label="Domains" title="Attach delivery hosts" action={<span className="admin-pill">{selectedSite.domains.length} configured</span>} />

                            {permissions.canManageSettings ? (
                                <form className="admin-form-grid admin-form-grid-inline" onSubmit={handleDomainSubmit}>
                                    <label className="admin-field admin-field-grow">
                                        <span>Domain host</span>
                                        <input
                                            type="text"
                                            className="admin-text-input"
                                            value={domainForm.data.host}
                                            onChange={(event) => domainForm.setData('host', event.target.value)}
                                            placeholder="docs.example.com"
                                        />
                                        <InputError message={domainForm.errors.host} />
                                    </label>

                                    <div className="admin-form-actions admin-form-actions-inline">
                                        <button type="submit" className="admin-button admin-button-primary" disabled={domainForm.processing}>
                                            {domainForm.processing ? 'Adding…' : 'Add domain'}
                                        </button>
                                    </div>
                                </form>
                            ) : null}

                            {selectedSite.domains.length ? (
                                <div className="admin-directory-list">
                                    {selectedSite.domains.map((domain) => (
                                        <div key={domain.id} className="admin-directory-item">
                                            <div className="admin-directory-head">
                                                <div>
                                                    <strong>{domain.host}</strong>
                                                    <small>DNS target: {domain.dnsTarget ?? 'Not assigned'}</small>
                                                </div>
                                                <div className="admin-pill-row">
                                                    <span className="admin-pill">{domain.status}</span>
                                                    {domain.isPrimary ? <span className="admin-pill admin-pill-accent">primary</span> : null}
                                                </div>
                                            </div>

                                            <div className="admin-directory-meta">Verified: {formatDate(domain.verifiedAt)}</div>

                                            {!domain.isPrimary && permissions.canManageSettings ? (
                                                <div className="admin-inline-actions">
                                                    <button
                                                        type="button"
                                                        className="admin-button admin-button-secondary"
                                                        onClick={() => handlePrimaryDomain(domain.id)}
                                                    >
                                                        Make primary
                                                    </button>
                                                </div>
                                            ) : null}
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <AdminEmptyState icon={<Globe size={16} />}>
                                    No custom domains yet. Add one now and the docs payload will expose it as the primary canonical host when selected.
                                </AdminEmptyState>
                            )}
                        </section>
                    </div>
                </section>
            </div>
        </>
    );
}