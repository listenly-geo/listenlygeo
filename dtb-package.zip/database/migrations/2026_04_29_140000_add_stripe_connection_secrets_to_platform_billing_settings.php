<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('platform_billing_settings', function (Blueprint $table): void {
            if (! Schema::hasColumn('platform_billing_settings', 'secret_key')) {
                $table->text('secret_key')->nullable()->after('public_key');
            }

            if (! Schema::hasColumn('platform_billing_settings', 'webhook_secret')) {
                $table->text('webhook_secret')->nullable()->after('webhook_endpoint');
            }
        });

        DB::table('platform_billing_settings')
            ->whereNull('webhook_endpoint')
            ->orWhere('webhook_endpoint', 'like', '%/webhooks/billing')
            ->update([
                'webhook_endpoint' => url('/webhooks/stripe'),
                'updated_at' => now(),
            ]);
    }

    public function down(): void
    {
        Schema::table('platform_billing_settings', function (Blueprint $table): void {
            if (Schema::hasColumn('platform_billing_settings', 'secret_key')) {
                $table->dropColumn('secret_key');
            }

            if (Schema::hasColumn('platform_billing_settings', 'webhook_secret')) {
                $table->dropColumn('webhook_secret');
            }
        });
    }
};
