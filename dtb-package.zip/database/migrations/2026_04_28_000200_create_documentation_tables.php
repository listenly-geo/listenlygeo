<?php

use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sites', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('slug');
            $table->string('visibility', 32)->default('private');
            $table->string('status', 32)->default('draft');
            $table->unsignedBigInteger('default_space_id')->nullable();
            $table->unsignedBigInteger('current_release_id')->nullable();
            $table->json('settings_json')->nullable();
            $table->foreignIdFor(User::class, 'created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignIdFor(User::class, 'updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->unique(['organization_id', 'slug']);
            $table->index('default_space_id');
            $table->index('current_release_id');
        });

        Schema::create('site_domains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('site_id')->constrained()->cascadeOnDelete();
            $table->string('host')->unique();
            $table->boolean('is_primary')->default(false);
            $table->string('status', 32)->default('pending');
            $table->string('dns_target')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
        });

        Schema::create('spaces', function (Blueprint $table) {
            $table->id();
            $table->foreignId('site_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('slug');
            $table->string('icon', 32)->nullable();
            $table->string('color', 64)->nullable();
            $table->unsignedInteger('position')->default(0);
            $table->foreignIdFor(User::class, 'created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignIdFor(User::class, 'updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->unique(['site_id', 'slug']);
        });

        Schema::create('pages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('site_id')->constrained()->cascadeOnDelete();
            $table->foreignId('space_id')->constrained()->cascadeOnDelete();
            $table->foreignId('parent_id')->nullable()->constrained('pages')->cascadeOnDelete();
            $table->string('title');
            $table->string('slug');
            $table->string('path');
            $table->string('icon', 32)->nullable();
            $table->unsignedInteger('position')->default(0);
            $table->string('status', 32)->default('draft');
            $table->unsignedBigInteger('current_revision_id')->nullable();
            $table->unsignedBigInteger('published_revision_id')->nullable();
            $table->foreignIdFor(User::class, 'created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignIdFor(User::class, 'updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->softDeletes();
            $table->timestamps();

            $table->unique(['site_id', 'path']);
            $table->index('current_revision_id');
            $table->index('published_revision_id');
        });

        Schema::create('page_revisions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('page_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('version_number');
            $table->string('title');
            $table->text('subtitle')->nullable();
            $table->json('blocks_json');
            $table->json('editor_meta_json')->nullable();
            $table->longText('search_document')->nullable();
            $table->string('save_type', 32)->default('autosave');
            $table->string('change_message')->nullable();
            $table->foreignIdFor(User::class, 'created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->unique(['page_id', 'version_number']);
        });

        Schema::create('releases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('site_id')->constrained()->cascadeOnDelete();
            $table->string('version');
            $table->string('status', 32)->default('pending');
            $table->string('environment', 32)->default('production');
            $table->string('message')->nullable();
            $table->foreignIdFor(User::class, 'published_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();

            $table->unique(['site_id', 'version']);
        });

        Schema::create('release_pages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('release_id')->constrained()->cascadeOnDelete();
            $table->foreignId('page_id')->nullable();
            $table->foreignId('space_id')->nullable();
            $table->string('title');
            $table->text('subtitle')->nullable();
            $table->string('path');
            $table->json('blocks_json');
            $table->longText('search_document')->nullable();
            $table->timestamps();

            $table->unique(['release_id', 'path']);
            $table->index('page_id');
            $table->index('space_id');
        });

        Schema::create('media_assets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->foreignId('site_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('disk', 64)->default('public');
            $table->string('path')->unique();
            $table->string('mime_type');
            $table->unsignedBigInteger('size_bytes')->default(0);
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->foreignIdFor(User::class, 'uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('media_assets');
        Schema::dropIfExists('release_pages');
        Schema::dropIfExists('releases');
        Schema::dropIfExists('page_revisions');
        Schema::dropIfExists('pages');
        Schema::dropIfExists('spaces');
        Schema::dropIfExists('site_domains');
        Schema::dropIfExists('sites');
    }
};
