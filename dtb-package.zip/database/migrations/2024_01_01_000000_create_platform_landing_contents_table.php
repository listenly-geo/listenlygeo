<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('platform_landing_contents', function (Blueprint $table) {
            $table->id();
            $table->string('section')->unique(); // hero, capabilities, integrations, workflow, pricing, testimonials, etc.
            $table->string('label')->nullable(); // display name
            $table->text('kicker')->nullable(); // small label above title
            $table->text('title')->nullable();
            $table->text('subtitle')->nullable();
            $table->longText('description')->nullable();
            $table->json('data')->nullable(); // flexible array of section-specific content
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index('section');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('platform_landing_contents');
    }
};
