<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscription_plans', function (Blueprint $table): void {
            $table->id();
            $table->string('slug')->unique();
            $table->string('label');
            $table->text('description');
            $table->string('status')->default('active');
            $table->unsignedBigInteger('monthly_price_cents');
            $table->unsignedBigInteger('annual_price_cents');
            $table->unsignedInteger('included_sites');
            $table->unsignedInteger('included_members');
            $table->unsignedInteger('included_published_pages');
            $table->unsignedBigInteger('included_storage_bytes');
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->timestamps();
        });

        DB::table('subscription_plans')->insert([
            [
                'slug' => 'free',
                'label' => 'Free',
                'description' => 'Start publishing with a small workspace before upgrading.',
                'status' => 'active',
                'monthly_price_cents' => 0,
                'annual_price_cents' => 0,
                'included_sites' => 1,
                'included_members' => 1,
                'included_published_pages' => 25,
                'included_storage_bytes' => 268_435_456,
                'sort_order' => 0,
                'is_featured' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'slug' => 'starter',
                'label' => 'Starter',
                'description' => 'Launch one documentation workspace with a lean team.',
                'status' => 'active',
                'monthly_price_cents' => 1900,
                'annual_price_cents' => 19000,
                'included_sites' => 1,
                'included_members' => 3,
                'included_published_pages' => 100,
                'included_storage_bytes' => 1_073_741_824,
                'sort_order' => 10,
                'is_featured' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'slug' => 'pro',
                'label' => 'Pro',
                'description' => 'Run multiple product surfaces with shared governance.',
                'status' => 'active',
                'monthly_price_cents' => 7900,
                'annual_price_cents' => 79000,
                'included_sites' => 5,
                'included_members' => 10,
                'included_published_pages' => 1500,
                'included_storage_bytes' => 10_737_418_240,
                'sort_order' => 20,
                'is_featured' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'slug' => 'business',
                'label' => 'Business',
                'description' => 'Scale documentation operations across larger teams.',
                'status' => 'active',
                'monthly_price_cents' => 24900,
                'annual_price_cents' => 249000,
                'included_sites' => 15,
                'included_members' => 25,
                'included_published_pages' => 5000,
                'included_storage_bytes' => 107_374_182_400,
                'sort_order' => 30,
                'is_featured' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_plans');
    }
};
