<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('organizations', function (Blueprint $table): void {
            $table->string('stripe_customer_id')->nullable()->after('billing_email')->index();
        });

        Schema::table('subscription_plans', function (Blueprint $table): void {
            $table->string('stripe_product_id')->nullable()->after('is_featured')->index();
            $table->string('stripe_monthly_price_id')->nullable()->after('stripe_product_id');
            $table->string('stripe_annual_price_id')->nullable()->after('stripe_monthly_price_id');
            $table->timestamp('stripe_synced_at')->nullable()->after('stripe_annual_price_id');
        });

        Schema::table('organization_subscriptions', function (Blueprint $table): void {
            $table->string('stripe_subscription_id')->nullable()->after('status')->index();
            $table->string('stripe_price_id')->nullable()->after('stripe_subscription_id');
            $table->string('stripe_checkout_session_id')->nullable()->after('stripe_price_id');
            $table->timestamp('stripe_synced_at')->nullable()->after('stripe_checkout_session_id');
        });

        DB::table('subscription_plans')->updateOrInsert(
            ['slug' => 'free'],
            [
                'label' => 'Free',
                'description' => 'Start publishing with a small workspace before upgrading.',
                'status' => 'active',
                'monthly_price_cents' => 0,
                'annual_price_cents' => 0,
                'included_sites' => 1,
                'included_members' => 1,
                'included_published_pages' => 25,
                'included_storage_bytes' => 268_435_456,
                'sort_order' => 0,
                'is_featured' => false,
                'updated_at' => now(),
                'created_at' => now(),
            ],
        );

        DB::table('platform_billing_settings')->update([
            'provider' => 'stripe',
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::table('organization_subscriptions', function (Blueprint $table): void {
            $table->dropColumn([
                'stripe_subscription_id',
                'stripe_price_id',
                'stripe_checkout_session_id',
                'stripe_synced_at',
            ]);
        });

        Schema::table('subscription_plans', function (Blueprint $table): void {
            $table->dropColumn([
                'stripe_product_id',
                'stripe_monthly_price_id',
                'stripe_annual_price_id',
                'stripe_synced_at',
            ]);
        });

        Schema::table('organizations', function (Blueprint $table): void {
            $table->dropColumn('stripe_customer_id');
        });
    }
};
