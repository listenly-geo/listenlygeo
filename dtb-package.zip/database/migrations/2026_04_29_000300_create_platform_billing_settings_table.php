<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('platform_billing_settings', function (Blueprint $table) {
            $table->id();
            $table->string('provider', 32)->default('stripe');
            $table->string('mode', 16)->default('test');
            $table->string('status', 32)->default('setup_required');
            $table->string('public_key')->nullable();
            $table->text('secret_key')->nullable();
            $table->string('webhook_endpoint')->nullable();
            $table->text('webhook_secret')->nullable();
            $table->json('metadata_json')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('platform_billing_settings');
    }
};
