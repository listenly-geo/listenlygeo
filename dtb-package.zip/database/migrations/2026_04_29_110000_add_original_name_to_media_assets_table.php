<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('media_assets', function (Blueprint $table) {
            $table->string('original_name')->nullable()->after('path');
        });

        DB::table('media_assets')
            ->select(['id', 'path'])
            ->whereNull('original_name')
            ->orderBy('id')
            ->lazyById()
            ->each(function (object $asset): void {
                DB::table('media_assets')
                    ->where('id', $asset->id)
                    ->update([
                        'original_name' => basename((string) $asset->path),
                    ]);
            });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('media_assets', function (Blueprint $table) {
            $table->dropColumn('original_name');
        });
    }
};
