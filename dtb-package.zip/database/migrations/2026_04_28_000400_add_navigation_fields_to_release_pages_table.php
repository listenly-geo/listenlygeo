<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('release_pages', function (Blueprint $table) {
            $table->string('space_name')->nullable()->after('space_id');
            $table->string('parent_path')->nullable()->after('path');
            $table->unsignedInteger('position')->default(0)->after('parent_path');

            $table->index(['release_id', 'parent_path', 'position'], 'release_pages_navigation_index');
        });
    }

    public function down(): void
    {
        Schema::table('release_pages', function (Blueprint $table) {
            $table->dropIndex('release_pages_navigation_index');
            $table->dropColumn(['space_name', 'parent_path', 'position']);
        });
    }
};
