<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('addons')->insertOrIgnore([
            'slug'           => 'docs-theme',
            'name'           => 'Docs Theme',
            'required_files' => json_encode(['theme.json', 'LICENSE']),
            'enabled'        => false,
            'token'          => null,
            'installed_at'   => null,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);
    }

    public function down(): void
    {
        DB::table('addons')->where('slug', 'docs-theme')->delete();
    }
};
