<?php

namespace Database\Seeders;

use App\Models\PlatformLandingContent;
use Illuminate\Database\Seeder;

class PlatformLandingContentSeeder extends Seeder
{
    public function run(): void
    {
        $sections = [
            [
                'section' => 'hero',
                'label' => 'Hero Section',
                'kicker' => 'Welcome to DocTheBuilder',
                'title' => 'Build beautiful docs in minutes',
                'subtitle' => 'The fastest way to create, manage, and deploy technical documentation',
                'description' => 'Professional documentation platform built for technical teams. Write once, deploy everywhere.',
                'is_active' => true,
            ],
            [
                'section' => 'features',
                'label' => 'Features Section',
                'kicker' => 'Powerful Capabilities',
                'title' => 'Everything you need for great documentation',
                'subtitle' => 'Built-in tools that make documentation a breeze',
                'description' => 'From AI-powered writing to collaborative editing, we have everything.',
                'is_active' => true,
            ],
            [
                'section' => 'pricing',
                'label' => 'Pricing Section',
                'kicker' => 'Simple, transparent pricing',
                'title' => 'Plans for every team size',
                'subtitle' => 'Start free. Scale as you grow.',
                'description' => 'No credit card required. Upgrade or downgrade anytime.',
                'is_active' => true,
            ],
            [
                'section' => 'integrations',
                'label' => 'Integrations Section',
                'kicker' => 'Connected ecosystem',
                'title' => 'Works with your favorite tools',
                'subtitle' => 'Seamlessly integrate with tools you already use',
                'description' => 'API-first platform that connects to your entire stack.',
                'is_active' => true,
            ],
            [
                'section' => 'testimonials',
                'label' => 'Testimonials Section',
                'kicker' => 'Loved by teams',
                'title' => 'What our users say',
                'subtitle' => 'Real feedback from real customers',
                'description' => 'Join hundreds of teams already building amazing documentation.',
                'is_active' => true,
            ],
            [
                'section' => 'workflow',
                'label' => 'Workflow Section',
                'kicker' => 'Simple workflow',
                'title' => 'From idea to published in 4 steps',
                'subtitle' => 'Our streamlined process makes documentation easy',
                'description' => 'Model → Write → Publish → Scale. That\'s it.',
                'is_active' => true,
            ],
        ];

        foreach ($sections as $section) {
            PlatformLandingContent::updateOrCreate(
                ['section' => $section['section']],
                $section
            );
        }
    }
}
