<?php

namespace Database\Seeders;

use App\Actions\Docs\PublishSiteRelease;
use App\Actions\Docs\SyncOrganizationUsageCounter;
use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\OrganizationSubscription;
use App\Models\Page;
use App\Models\PageRevision;
use App\Models\PlatformBillingSetting;
use App\Models\Site;
use App\Models\Space;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ([
            [
                'slug' => 'free',
                'label' => 'Free',
                'description' => 'Start publishing with a small workspace before upgrading.',
                'status' => 'active',
                'monthly_price_cents' => 0,
                'annual_price_cents' => 0,
                'included_sites' => 1,
                'included_members' => 1,
                'included_published_pages' => 25,
                'included_storage_bytes' => 268435456,
                'sort_order' => 0,
                'is_featured' => false,
            ],
            [
                'slug' => 'starter',
                'label' => 'Starter',
                'description' => 'Launch one documentation workspace with a lean team.',
                'status' => 'active',
                'monthly_price_cents' => 1900,
                'annual_price_cents' => 19000,
                'included_sites' => 1,
                'included_members' => 3,
                'included_published_pages' => 100,
                'included_storage_bytes' => 1073741824,
                'sort_order' => 10,
                'is_featured' => false,
            ],
            [
                'slug' => 'pro',
                'label' => 'Pro',
                'description' => 'Run multiple product surfaces with shared governance.',
                'status' => 'active',
                'monthly_price_cents' => 7900,
                'annual_price_cents' => 79000,
                'included_sites' => 5,
                'included_members' => 10,
                'included_published_pages' => 1500,
                'included_storage_bytes' => 10737418240,
                'sort_order' => 20,
                'is_featured' => true,
            ],
            [
                'slug' => 'business',
                'label' => 'Business',
                'description' => 'Scale documentation operations across larger teams.',
                'status' => 'active',
                'monthly_price_cents' => 24900,
                'annual_price_cents' => 249000,
                'included_sites' => 15,
                'included_members' => 25,
                'included_published_pages' => 5000,
                'included_storage_bytes' => 107374182400,
                'sort_order' => 30,
                'is_featured' => false,
            ],
        ] as $plan) {
            SubscriptionPlan::query()->updateOrCreate(['slug' => $plan['slug']], $plan);
        }

        $admin = User::factory()->create([
            'name' => 'Admin User',
            'email' => 'admin@mail.com',
            'is_platform_admin' => true,
        ]);

        $customer = User::factory()->create([
            'name' => 'Customer User',
            'email' => 'customer@mail.com',
        ]);

        $organization = Organization::query()->create([
            'name' => 'DocTheBuilder Workspace',
            'slug' => 'docthebuilder-workspace',
            'owner_user_id' => $customer->id,
            'billing_email' => $customer->email,
        ]);

        OrganizationMembership::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $customer->id,
            'role' => 'owner',
            'status' => 'active',
        ]);

        OrganizationSubscription::query()->create([
            'organization_id' => $organization->id,
            'plan' => 'pro',
            'interval' => 'monthly',
            'status' => 'active',
            'current_period_starts_at' => now(),
            'current_period_ends_at' => now()->addMonth(),
        ]);

        $site = Site::query()->create([
            'organization_id' => $organization->id,
            'name' => 'Product Docs',
            'slug' => 'product-docs',
            'visibility' => 'public',
            'status' => 'draft',
            'settings_json' => [
                'branding' => [
                    'name' => 'DocTheBuilder',
                    'tagline' => 'Production-ready documentation workspace.',
                ],
                'seo' => [
                    'title' => 'DocTheBuilder Product Docs',
                    'description' => 'Starter documentation for the DocTheBuilder workspace.',
                ],
            ],
            'created_by' => $customer->id,
            'updated_by' => $customer->id,
        ]);

        $space = Space::query()->create([
            'site_id' => $site->id,
            'name' => 'Getting Started',
            'slug' => 'getting-started',
            'icon' => 'bolt',
            'color' => 'oklch(55% 0.14 255)',
            'position' => 0,
            'created_by' => $customer->id,
            'updated_by' => $customer->id,
        ]);

        $site->forceFill([
            'default_space_id' => $space->id,
        ])->save();

        $page = Page::query()->create([
            'site_id' => $site->id,
            'space_id' => $space->id,
            'title' => 'Quickstart',
            'slug' => 'quickstart',
            'path' => 'quickstart',
            'icon' => 'bolt',
            'position' => 0,
            'status' => 'draft',
            'created_by' => $customer->id,
            'updated_by' => $customer->id,
        ]);

        $revision = PageRevision::query()->create([
            'page_id' => $page->id,
            'version_number' => 1,
            'title' => 'Quickstart',
            'subtitle' => 'Start writing and publishing customer-facing documentation.',
            'blocks_json' => [
                [
                    'id' => 'b_intro',
                    'kind' => 'p',
                    'html' => 'Welcome to your clean DocTheBuilder workspace. Use the editor to create pages, preview drafts, export content, and publish public documentation.',
                ],
                [
                    'id' => 'b_admin',
                    'kind' => 'callout',
                    'variant' => 'ok',
                    'title' => 'Admin login',
                    'text' => 'Use admin@mail.com with password password for platform administration and commerce management.',
                ],
                [
                    'id' => 'b_customer',
                    'kind' => 'callout',
                    'variant' => 'note',
                    'title' => 'Customer login',
                    'text' => 'Use customer@mail.com with password password for customer workspace, editor, and billing access.',
                ],
            ],
            'editor_meta_json' => [
                'readTime' => '2 min',
                'viewCount' => 0,
            ],
            'search_document' => 'Quickstart Start writing and publishing customer-facing documentation.',
            'save_type' => 'manual',
            'change_message' => 'Seed clean workspace',
            'created_by' => $customer->id,
        ]);

        $page->forceFill([
            'current_revision_id' => $revision->id,
            'published_revision_id' => $revision->id,
        ])->save();

        app(PublishSiteRelease::class)($site->fresh(), $customer, [
            'environment' => 'production',
            'message' => 'Initial clean workspace release',
        ]);

        PlatformBillingSetting::query()->create([
            'provider' => 'stripe',
            'mode' => 'test',
            'status' => 'setup_required',
            'public_key' => 'pk_test_configure_me',
            'webhook_endpoint' => route('stripe.webhook'),
        ]);

        app(SyncOrganizationUsageCounter::class)($organization->fresh());
    }
}
