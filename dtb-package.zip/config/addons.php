<?php

return [
    /*
     | The secret key used to sign and verify addon tokens.
     | Set ADDON_SIGNING_KEY in your .env file.
     | Never commit the actual key value to source control.
     */
    'signing_key' => env('ADDON_SIGNING_KEY', ''),
];
