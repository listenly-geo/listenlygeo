<?php
require 'vendor/autoload.php';

$app = require 'bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$user = App\Models\User::factory()->create();
$workspace = app(App\Actions\Docs\EnsureEditorWorkspace::class)($user);
$site = App\Models\Site::findOrFail($workspace['site']['id']);

app(App\Actions\Docs\PublishSiteRelease::class)($site, $user);
$export = app(App\Actions\Docs\ExportSiteProject::class)($site, 'plain-html');
$zipPath = is_array($export)
    ? (string) ($export['path'] ?? ($export[0] ?? ''))
    : (string) $export;
if ($zipPath === '') {
    var_dump($export);
    exit(1);
}

$out = storage_path('app/tmp/plain-export-check');
if (is_dir($out)) {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($out, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $file) {
        if ($file->isDir()) {
            rmdir($file->getRealPath());
        } else {
            unlink($file->getRealPath());
        }
    }
}

@mkdir($out, 0777, true);
$zip = new ZipArchive();
$zip->open($zipPath);
$zip->extractTo($out);
$zip->close();

echo "ZIP={$zipPath}\n";
echo "ENTRY={$out}\\index.html\n";
?>
